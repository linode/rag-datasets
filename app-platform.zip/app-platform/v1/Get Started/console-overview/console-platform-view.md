# [Platform view and dashboard](https://techdocs.akamai.com/app-platform/docs/console-platform-view#platform-view-and-dashboard)

The Platform view is only visible for platform administrators and provides access to:

- [Dashboard](#platform-dashboard): A global overview of cluster resource utilization and cluster resource request commitments.
- [Apps](https://techdocs.akamai.com/app-platform/docs/apps): All active and inactive apps. Activate apps clicking on the power-on button.
- [Teams](https://techdocs.akamai.com/app-platform/docs/teams): A list of all Teams.
- [User Management](https://techdocs.akamai.com/app-platform/docs/user-management): Manage Users.
- [Backups](https://techdocs.akamai.com/app-platform/docs/backups): A list of all Backups.
- [Maintenance](https://techdocs.akamai.com/app-platform/docs/platform-maintenance): Maintenance actions.
- [Settings](https://techdocs.akamai.com/app-platform/docs/platform-settings): Specific configuration of the platform.

# [Platform dashboard](https://techdocs.akamai.com/app-platform/docs/console-platform-view#platform-dashboard)

The Platform Dashboard provides a global overview of information relevant to platform administrators. To access this view, select **Platform** in the **View** selector within the top bar.

 > Note: 
  The Platform Dashboard uses both Grafana and Prometheus. Make sure both are enabled.

The dashboard has four elements

- **Available versions**: Displays the currently installed version of the App Platform along with any new upgrades available.
- **Inventory**: 
- **Cluster Resource Utilization**: The total CPU and memory used by the cluster.
- **Cluster Resource Request Commitments**: The amount of CPU and memory requests commitments out of the total amount of those resources available on the cluster.