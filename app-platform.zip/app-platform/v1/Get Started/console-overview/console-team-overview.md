# [Team view and dashboard](https://techdocs.akamai.com/app-platform/docs/console-team-overview#team-view-and-dashboard)

The Team view in the App Platform Console is the main access point for most users, providing them access to all tools and settings needed to deploy and maintain their applications. While in the Team view, the following links appear in the main menu of the App Platform Console:

- [Dashboard](#team-dashboard): An overview of Team Pod status, resource utilization and vulnerabilities.
- [Apps](https://techdocs.akamai.com/app-platform/docs/apps): All installed apps that are available to the team. This section is not visible when the _admin_ team is selected in the top bar.
- [Catalog](https://techdocs.akamai.com/app-platform/docs/catalog): The Helm charts available for the Team in the Catalog.
- [Code Repositories](https://techdocs.akamai.com/app-platform/docs/code-repositories): A self-service form to register code repositories to App Platform and use them to create Container Images.
- [Container Images](https://techdocs.akamai.com/app-platform/docs/container-images): A self-service form to create container images from registered Code Repositories.
- [Sealed Secrets](https://techdocs.akamai.com/app-platform/docs/secrets): A self-service form to create Sealed Secrets.
- [Workloads](https://techdocs.akamai.com/app-platform/docs/team-workloads): A self-service form to create Workloads.
- [Network Policies](https://techdocs.akamai.com/app-platform/docs/netpols): A self-service form to create Network Policies.
- [Services](https://techdocs.akamai.com/app-platform/docs/services): A self-service form to create Services to publicly expose deployed Workloads.
- [Security Policies](https://techdocs.akamai.com/app-platform/docs/security-policies): A list of Security Policies applicable to the Team.
- [User Management](https://techdocs.akamai.com/app-platform/docs/user-management): A self-service form for Team administrators to add users to the Team. This section is not visible when the _admin_ team is selected in the top bar.
- [Settings](https://techdocs.akamai.com/app-platform/docs/team-settings): Specific Team configuration options. This section is not visible when the _admin_ team is selected in the top bar.
- [Shell](https://techdocs.akamai.com/app-platform/docs/shell): Access to the cloud Shell within the context of the Team.
- A "Download KUBECFG" link to download a KUBECONFIG file that gives access to the namespace of the team selected. Admins can download one with `cluster-admin` permissions (giving access to all namespaces) by setting the team selector to '-'. You can use it like `export KUBECONFIG=$file_location` or by merging it with another KUBECONFIG file like `.kube/config`. Please visit the official Kubernetes [documentation about managing kube contexts](https://kubernetes.io/docs/concepts/configuration/organize-cluster-access-kubeconfig/).
- When Harbor is enabled, a link to download the Dockercfg file.
- When automatic generated CA or Let's Encrypt staging certificates are used, a "Download CA" link is provided.

# [Team dashboard](https://techdocs.akamai.com/app-platform/docs/console-team-overview#team-dashboard)

The team dashboard gives a global overview of information most relevant to the team. It contains the following information, specific to the team selected within the _team_ drop down in the top bar.

- [Inventory](#inventory): A list of resources (such as projects, container images, workloads) and the number of those resources that have been created by the team.

- [Resource Status](#resource-status): Shows any issues with the pods deployed by the team.

- [Resource Utilization](#resource-utilization): The total amount of CPU and memory resources consumed by the team.

- [Vulnerabilities](#vulnerabilities): The total amount of LOW, MEDIUM, HIGH, and CRITICAL vulnerabilities in running containers deployed by the team.

## [Enable Grafana for dashboard metrics](https://techdocs.akamai.com/app-platform/docs/console-team-overview#enable-grafana-for-dashboard-metrics)

The Team dashboard uses the team's Grafana instance to gather information. Grafana needs to be enabled on the team-level by following these instructions:

1. Navigate to **Settings** in the main menu of the App Platform Console (with the _team_ view enabled).
2. Under **Advanced Settings > Dashboard**, check **Enable Grafana**.
3. Click the **Save Changes** button at the bottom of the page.
4. Once Grafana is installed on the team-level, reload the **Dashboard** page.