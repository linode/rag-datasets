# [App Platform Console (UI)](https://techdocs.akamai.com/app-platform/docs/console-overview#app-platform-console-ui)

The App Platform Console is the web-based user interface for the Akamai App Platform. Once logged in to the Console, you can access all integrated apps and self-service tasks. There are two main views for the Console: the **Platform** view and the **Team** view.

# [Views](https://techdocs.akamai.com/app-platform/docs/console-overview#views)

- [Platform view](https://techdocs.akamai.com/app-platform/docs/console-platform-view) (for platform administrators): Access to administration including managing teams, users, and platform-level apps.
- [Team view](https://techdocs.akamai.com/app-platform/docs/console-team-overview) (for development teams): Access to team-level workflows and administration tasks, including accessing apps, deploying workloads from pre-made Helm charts, registering code repositories, and much more.

# [Switch between views](https://techdocs.akamai.com/app-platform/docs/console-overview#switch-between-views)

When logged in as a platform administrator (a user with the _platform-admin_ role), you can switch between these views through the top navigation bar. Users without this role do not have access to the **Platform** view.