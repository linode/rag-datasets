# [Getting started with the Akamai App Platform](https://techdocs.akamai.com/app-platform/docs/getting-started#getting-started-with-the-akamai-app-platform)

# [Step 1: Install the Akamai App Platform](https://techdocs.akamai.com/app-platform/docs/getting-started#step-1-install-the-akamai-app-platform)

The App Platform can be installed automatically when creating a new Linode Kubernetes Engine (LKE) cluster on Akamai Cloud. It can also be installed manually on LKE or any other conformant Kubernetes cluster.

- [Automatic installation on LKE](https://techdocs.akamai.com/app-platform/docs/lke-automatic-install)
- [Manual installation on LKE](https://techdocs.akamai.com/app-platform/docs/lke-manual-install)
- [Custom installation on other Kubernetes services](https://techdocs.akamai.com/app-platform/docs/custom)

# [Step 2: Post-installation steps](https://techdocs.akamai.com/app-platform/docs/getting-started#step-2-post-installation-steps)

After installing the App Platform on your Kubernetes cluster, review the [Post installation steps](https://techdocs.akamai.com/app-platform/docs/post-installation-steps) guide. There may be additional setup or initial configuration steps, such as locating your username and password.

# [Step 3: Explore the hands-on labs](https://techdocs.akamai.com/app-platform/docs/getting-started#step-3-explore-the-hands-on-labs)

To learn how to use the App Platform, review the [hands-on labs](https://techdocs.akamai.com/app-platform/docs/labs-overview) section. These tutorials are designed as walk-throughs for new users, instructing them on creating container images, code repositories, and workloads. In addition,  learn how to monitor these items and implement basic security checks.