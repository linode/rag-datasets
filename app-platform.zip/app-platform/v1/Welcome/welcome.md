# [Welcome to the Akamai App Platform](https://techdocs.akamai.com/app-platform/docs/welcome#welcome-to-the-akamai-app-platform)

The Akamai App Platform is a pre-built Kubernetes developer platform that is intended to accelerate your platform development so you can quickly deploy, manage, and secure your containerized workloads. It combines both developer-centric and operations-centric tooling into a single self-service portal. The App Platform is optimized to run on Linode Kubernetes Engine (LKE), but it can also be manually installed on any other [conformant Kubernetes cluster](https://www.cncf.io/training/certification/software-conformance/).

The App Platform connects many of the technologies found in the Cloud Native Computing Foundation (CNCF) landscape in a way that provides direct value. This avoids the need to reinvent the wheel when building and maintaining your own Kubernetes-based platform or bespoke stack. The App Platform includes:

- An **integrated and pre-configured stack of open source Kubernetes projects** to support all the essential capabilities for running cloud native applications in production on Kubernetes.

- An easy **self-service portal** for developers to deploy workloads from Helm charts, build images, and publicly expose services

- A **catalog** with Helm charts that serve as golden path templates and can be added, removed, or modified according to your needs.

- Kubernetes **Operators and GitOps** to manage the state of the platform based on configuration-as-code.

# [Key benefits](https://techdocs.akamai.com/app-platform/docs/welcome#key-benefits)

- Speed up time to market by automating and simplifying building and running applications on Kubernetes, reducing the complexity for development teams.

- Reduce toil and avoid technical debt by providing a pre-configured and integrated suite of tools for CI/CD, observability, and security out-of-the-box, accelerating the application delivery and enhancing security.

- Support multi-tenancy by allowing multiple teams or projects to share the same cluster, with self-service features that enable faster, independent deployments by developers.

- Self-service features enable developers to build, deploy, expose, observe, and secure containerized applications on Kubernetes using a web-based portal.

# [Integrated Kubernetes apps](https://techdocs.akamai.com/app-platform/docs/welcome#integrated-kubernetes-apps)

The App Platform includes many integrated and pre-configured Kubernetes projects, enabling you to compose your ideal platform with all the capabilities you may require.

# [Developer-enablement](https://techdocs.akamai.com/app-platform/docs/welcome#developer-enablement)

- Build OCI-compliant images from source code.

- Deploy containerized workloads (the GitOps way) using the provided quickstarts or BYO golden path templates.

- Automatically update container images of workloads.

- Publicly expose applications.

- Get instant access to logs, metrics, and traces.

- Store images in a private registry.

- Configure network policies, response headers, and CNAMEs.

- Check applications against a comprehensive set of built-in security policies.

- Create and manage secrets.

- Create private Git repositories and use the built-in CI/CD pipelines

# [Administrative features](https://techdocs.akamai.com/app-platform/docs/welcome#administrative-features)

- Onboard development teams to the same multi-tenant cluster.

- Ensure governance with security policies.

- Implement zero-trust networking.

- Change the desired state of the platform based on configuration-as-code architecture.

- Support multi- and hybrid cloud scenarios, which also prevents cloud provider lock-in.

- Implement full observability.

- Comply with disaster recovery requirements