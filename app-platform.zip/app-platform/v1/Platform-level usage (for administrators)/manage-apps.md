# [Apps](https://techdocs.akamai.com/app-platform/docs/manage-apps#apps)

_Apps_ are the integrated applications that add capabilities to your Kubernetes developer platform.

# [Included apps](https://techdocs.akamai.com/app-platform/docs/manage-apps#included-apps)

- Alertmanager
- Argo CD
- Cnpg (CloudNativePG)
- Gitea
- Grafana
- Harbor
- Httpbin
- Istio
- Jaeger
- Keyclock
- Kiali
- Knative
- Kyverno
- Loki
- Otel (OpenTelemetry)
- Prometheus
- Rabbitmq
- Sealed Secrets
- Tekton
- Tempo
- Thanos
- Trivy

# [Release stages](https://techdocs.akamai.com/app-platform/docs/manage-apps#release-stages)

Apps within the Akamai App Platform have 3 release stages: Alpha, Beta and GA. Apps in the alpha stage are experimental, may change significantly, and should can be used for previewing functionality and testing purposes. Beta apps are more stable and can be used in pre-production. Apps that reach the General Availability (GA) stage are considered stable and have a commitment to remain unchanged within a major version. While apps in the alpha and beta stages are labeled as such in the App Platform, apps that reach GA do not have any release label.

# [App integration criteria](https://techdocs.akamai.com/app-platform/docs/manage-apps#app-integration-criteria)

App Platform also sets standards for the following integration criteria:

1. **Backup and restore:** Databases used by a platform app are automatically backed-up and restore procedures are tested.
2. **Smooth database upgrades:** Databases used by a platform app are automatically upgraded.
3. **Lifecycle management:** The platform app is part of the platform release cycle and will be upgraded accordingly.
4. **Authentication:** Only authenticated users can access the platform app.
5. **Graceful termination:** Pods of a platform app will terminate gracefully in case of a node drain operation.
6. **Continuity:** A platform app will not be removed without a deprecation notice.
7. **Kubernetes version support:** A platform app is supported on all App Platform supported Kubernetes versions.
8. **Monitoring and observability:** Prometheus rules and grafana dashboards are provided and maintained for the app.
9. **Resource management:** Correct resources are set and managed.

Based on the release stage, a platform app partially or fully complies to the integration criteria due to its immaturity or current limitations of the platform itself:

| Release Stage | Integration Criteria Compliance   |
| ------------- | --------------------------------- |
| Alpha         | Minimal compliant (4, 5)          |
| Beta          | Partial compliant (4, 5, 6, 7, 9) |
| GA            | Fully compliant                   |