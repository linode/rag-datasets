# [Teams](https://techdocs.akamai.com/app-platform/docs/platform-teams#teams)

Teams are isolated tenants on the App Platform instance intended to support a development team or a project. Since the App Platform is multi-tenancy, multiple teams can be created and each team can have their own set of users. Users that belong to a particular team will be able to manage all team-level self-service features for that team, including creating images and deploying workloads that belong to the team. Users can also access any apps that are enabled for the team.

# [Admin team](https://techdocs.akamai.com/app-platform/docs/platform-teams#admin-team)

By default, a team called `admin` is created. Platform administrators can use this team to deploy workloads in any namespace and expose services from any namespace namespace. In addition, there are a few templates in the catalog that are only available to platform administrators. Unlike other teams, the Admin team does not have apps and it is not possible to configure any team settings.

# [Create a team](https://techdocs.akamai.com/app-platform/docs/platform-teams#create-a-team)

1. Log in to a user account with the `platform-admin` role (like the `platform-admin` user).

2. Provide a name for the team (lowercase). The name of a team can not be changed afterwards. Creating a team will result in the creation of namespace `team-$NAME`. The name of a team can be max `12` characters.

3. Optional: Provide a OIDC group name/id for granting access to the team when using an external IdP. Only members of this group will get access to the team in the App Platform Console.

4. Optional: Configure advanced settings, explained below under [Configuration options](#settings-and-configuration-options).

5. Click the **Create Team** button to finish and create your new team.

# [Settings and configuration options](https://techdocs.akamai.com/app-platform/docs/platform-teams#settings-and-configuration-options)

## [Dashboards](https://techdocs.akamai.com/app-platform/docs/platform-teams#dashboards)

The **Enable dashboards** setting installs a dedicated Grafana instance in the team namespace with pre-configured dashboards. Dashboards are added based on which other apps have been activated on the platform-level. The Grafana instance is also used by Loki to show logs.

## [Alerts](https://techdocs.akamai.com/app-platform/docs/platform-teams#alerts)

The **Enable alerts** setting installs a dedicated Alertmanager instance in the team namespace to receive team-specific alerts from Prometheus. You can optionally configure Slack or Microsoft Teams to receive and display notifications.

- **Slack**: Enter a Slack endpoint URL as well as the channels for _critical_ alerts and _non-critical_ alerts.
- **Microsoft** Teams: Enter webhooks for _critical_ alerts and _non-critical_ alerts.

If a notification receiver is not configured, team members can always use the Alertmanager UI (available in the Apps section) to see alerts.

## [Resource Quotas](https://techdocs.akamai.com/app-platform/docs/platform-teams#resource-quotas)

The **Resource Quotas** section enables you to adjust the default _count quota_ and _compute resource quota_ as needed. You can also add custom resource quotes, which should adhere to the format outlined in the [Kubernetes Resource Quota](https://kubernetes.io/docs/concepts/policy/resource-quotas/) documentation.

 > Warning: 
  There is no validation as there is no schema published. Add/change resource quota at your own risk.

## [Network Policies](https://techdocs.akamai.com/app-platform/docs/platform-teams#network-policies)

The **Network Policies** section enables controls for both ingress and egress:

- **Ingress control**: When enabled team services will be bound by (ingress) network policies.
- **Egress control**: When enabled team service egress traffic will be limited to pre-defined endpoints only.

## [Permissions](https://techdocs.akamai.com/app-platform/docs/platform-teams#permissions)

The permissions section shows the permissions of the team. These permissions are applied to all team members:

| Action                            | Description                                                                                                |
| --------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| Create Services                   | Select to grant team members permission to create services                                                 |
| Edit Security Policies            | Select to grant team members permission to edit security policies                                          |
| Use Cloud Shell                   | Select to grant team members permission to use the cloud shell                                             |
| Download kubeconfig file          | Select to grant team members permission to download the KubeConfig to get Kube API access to the namespace |
| Download docker login credentials | Select to grant team members permission to download the Dockerconfig for the teams project in Harbor       |