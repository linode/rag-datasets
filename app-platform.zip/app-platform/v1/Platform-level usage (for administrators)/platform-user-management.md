# [Users](https://techdocs.akamai.com/app-platform/docs/platform-user-management#users)

 > Note: 
  User management is only available when Keycloak is configured as the identity provider, which is the default setting. When OIDC is configured, the user management feature is not available through the App Platform.

User accounts are created for a single user and provide access to the App Platform Console. Each user account is assigned a role which grants or restricts access to certain features. They can either be a platform administrator (and have access to the entire App Platform installation) or can belong to one or more teams as either a member or team administrator.

# [User roles](https://techdocs.akamai.com/app-platform/docs/platform-user-management#user-roles)

- **Platform administrators** (`platform-admin` role): User can access the entire App Platform instance and can manage all platform-level configuration options and all teams.
- **Team administrators** (`team-admin` role): User can access the resources and configurations for the specified teams as an administrator. They can access a special **User Management** area in the Team view of the App Platform Console, which enables them to add other users to the teams they manage.
- **Team member** (`team-member` role): User can access all team-level configuration options for the specified teams, but cannot add or remove other users from their teams.

# [Create a new user](https://techdocs.akamai.com/app-platform/docs/platform-user-management#create-a-new-user)

New users can only be created (and deleted) by a platform administrator. During creation, they are given a role and can be assigned to one or more teams. You can also create users without assigning them to any team and, instead, team administrators can add the user to their teams at any point.

1. Log in to the App Platform Console as a platform administrator and select the **Platform** view in the top bar.

2. Click on **User Management** in the main navigation menu.

3. Click on **Create User** to open the _New User_ form.

4. Enter the user's email address (unique from other users) and their first and last name.

5. Assign the desired roles to the user:
   - **Is platform admin**: This user will be a platform administrator and can access all platform-level configuration options and all teams.
   - **Is team admin**: This user will be a team administrator of the teams specified in the **Teams** selector.

6. Assign the desired teams to the user in the **Team** selector. This user will have access to all team-level configuration options for these teams. If the user is also a team administrator, they can add or remove users from these teams.

7. Click **Submit** to create the user.

8. Once the user has been created, obtain the initial password. This can be done by finding the new user within the list of users and clicking on the corresponding _copy_ icon in the **Initial password** column.

9. Provide the initial password to the new user. They are automatically prompted to change this password upon their first log in.

# [Assign existing users to teams](https://techdocs.akamai.com/app-platform/docs/platform-user-management#assign-existing-users-to-teams)

Users can be added to a team within the **Team** console view by any platform or team administrator. Team administrators cannot remove themselves or other team administrators from the teams they manage.

1. Log in to the App Platform Console as a platform or team administrator, select the **Team** view in the top bar, and select the team you would like to administer.
2. Navigate to the **User management** page in the main navigation menu.
3. Within the list of users, locate the user you would like to add to the team.
4. Check the corresponding checkbox within the **Assign to team $NAME** column.
5. Click on the **Update users** button to make the change. 

# [Additional user management details](https://techdocs.akamai.com/app-platform/docs/platform-user-management#additional-user-management-details)

- Users are stored encrypted in the `values` repository.
- Users’ passwords are not stored in the values repo (except initial password).
- A password reset can only be performed by a platform admin. Password resets need to be done in the Keycloak app using the `otomi-admin` credentials. As an alternative, platform administrators can also re-create a user.
- Kubernetes secrets are used to pass user data between pods, but there is a limit for user-defined variables. The maximum size of a user-defined environment variable is 32,767 characters. This limits the amount of users that can be created to around 200.
- When user management is handled locally, users cannot be synced between multiple App Platform installations.

# [Change user passwords](https://techdocs.akamai.com/app-platform/docs/platform-user-management#change-user-passwords)

Follow these steps to change or reset passwords of users created in the Console or the `platform-admin` account created during installation:

1. Open the Keycloak app

2. Click on `Administration Console`.

3. Log in with `otomi-admin` credentials.

4. Select the `Otomi` realm.

5. Click on `Users` then click on the required user.

6. Select the `Credentials` tab.

7. Click on `Reset Password`.

8. Fill in a new password.

9. Optional: Make the password `Temporary`. This requires the user to change the password at the first login.

10. Click on "Save".

11. Click `Reset password`.