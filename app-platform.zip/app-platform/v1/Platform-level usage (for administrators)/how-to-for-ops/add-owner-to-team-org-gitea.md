# [Add owner to team organization in Gitea](https://techdocs.akamai.com/app-platform/docs/add-owner-to-team-org-gitea#add-owner-to-team-organization-in-gitea)

Follow these steps to add a user with the platform administrator role to the _owners_ group of a team organization in Gitea:

1. Open the Gitea app.

2. In the top right, click on your profile icon.

3. Click **Site Administration**.

4. Click on **Identity & Access** in the **Admin Settings** on the left and then click on **Organizations**.

5. Select the organization of which you'd like to become an owner.

6. In the **Teams** section, click on **Owners**.

7. In the **Owners** section, click **Join**.