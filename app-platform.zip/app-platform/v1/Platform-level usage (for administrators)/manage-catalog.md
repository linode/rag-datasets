# [Catalog](https://techdocs.akamai.com/app-platform/docs/manage-catalog#catalog)

The catalog is a repository of Helm charts that are made available to teams in the Akamai App Platform, providing them with _golden path templates_ for seamless and consistent deployments. Here's a short overview of how the catalog works:

1. Add a Helm chart to the `otomi/charts` repo in the local Gitea.
2. Configure which teams can use the chart.
3. The selected teams can then create workloads from the Helm charts in the catalog.

# [Default Helm charts](https://techdocs.akamai.com/app-platform/docs/manage-catalog#default-helm-charts)

By default, the catalog includes a few Helm charts to help teams get started with common workloads. The default Helm charts are not mandatory to use and can be removed or modified to your needs. They are primarily included as examples and to make it easier to get started.

## [Team-level helm charts](https://techdocs.akamai.com/app-platform/docs/manage-catalog#team-level-helm-charts)

- **Kubernetes Deployment** (`k8s-deployment`): Creates a Kubernetes `Deployment` (to deploy a single image), a `Service` and a `ServiceAccount`. Optionally a `HorizontalPodAutoscaler`, a Prometheus `ServiceMonitor` and a `Configmap` can be created.
- **Kubernetes Deployment with Open Telemetry Instrumentation** (`k8s-deployment-otel`): Creates a Kubernetes `Deployment` (to deploy a single image), a `Service`, a `ServiceAccount`, an `OpenTelemetryCollector` and an `Instrumentation`. Optionally a `HorizontalPodAutoscaler`, a Prometheus `ServiceMonitor` and a `Configmap` can be created.
- **Kubernetes Canary Deployments** (`k8s-deployments-canary`): Creates two Kubernetes `Deployments` (to deploy 2 versions of an image), a `Service` and a `ServiceAccount`. Optionally a `HorizontalPodAutoscaler`, a Prometheus `ServiceMonitor` and a `Configmap` (for each version) can be created.
- **Knative-service** (`knative-service`): Creates a Knative `Service` (to deploy a single image), a `Service` and a  `ServiceAccount`. Optionally a Prometheus `ServiceMonitor` can be created.
- **PostgreSQL cluster** (`postgresql-cluster`): Creates a cloudnativepg PostgreSQL `Cluster`. Optionally a Prometheus `PodMonitor` and a `Configmap` (for adding a postgresql dashboard to Grafana) can be created.
- **Redis master-replica cluster** (`redis-cluster`): Creates a Redis master-replica cluster.
- **RabbitMQ Cluster and/or Queues** (`rabbitmq-cluster`): Creates a `RabbitmqCluster`, `queues` and `Policy`s. Using the `rabbitmq-cluster` Helm chart requires `RabbitMQ` to be enabled by a platform administrator.

# [Customize the catalog](https://techdocs.akamai.com/app-platform/docs/manage-catalog#customize-the-catalog)

Helm charts can be added, removed, or modified by making commits to the `otomi/charts` repository within your cluster's local Gitea instance. Pull down the `otomi/charts` repository, make your changes, and push those changes. Any newly added charts will immediately become available in the catalog for teams to use.

# [Configure chart access](https://techdocs.akamai.com/app-platform/docs/manage-catalog#configure-chart-access)

For charts to become available for teams to use, teams need to be given access to use a chart. The catalog supports the following access options:

- **Everybody**: If a chart can be used by all teams, including the `team-admin` Team, add the following to the `rbac.yaml` in the root of the `otomi/charts` repository:

  ```yaml
  rbac:
    chart-name: null
  ```

- **Specific teams**:

   If a chart is only allowed to be used by one or more specific teams, add the following to the `rbac.yaml`:

  ```yaml
  rbac:
    chart-name:
      - team-demo
      - team-hello
  ```

- **Admin team (`team-admin`) only**: To allow a chart to be used by the `team-admin` only, add the following to the `rbac.yaml`:

  ```yaml
  rbac:
    chart-name:
      - team-admin
  ```