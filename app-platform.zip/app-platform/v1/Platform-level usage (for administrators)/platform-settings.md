# [Platform settings](https://techdocs.akamai.com/app-platform/docs/platform-settings#platform-settings)

Within the _platform_ view, the **Settings** section of the App Platform Console contains configuration options for the cluster and other systems running on the App Platform. This page also displays important version details for the Kubernetes cluster and the App Platform (Otomi) services running within it.

To view or modify settings, click on one of the categories shown within the **Settings** page.

# [Cluster settings](https://techdocs.akamai.com/app-platform/docs/platform-settings#cluster-settings)

- **Cluster:** Settings for the Kubernetes cluster running the Akamai App Platform instance.
  - **Name:** Short name that will be used in construction of cluster domain and messaging.
  - **Domain suffix:** The domain used for the cluster.
  - **API server:** The full URL of the Kubernetes API server. This is used to generate the _KUBECONFIG_ file for local API access.
  - **Owner:** The name of the organization that owns the cluster.
- **Provider:** The provider used for the cluster, either _Linode_ for LKE clusters or _custom_ for any conformant Kubernetes cluster.