# [Additional administration tasks](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#additional-administration-tasks)

- [Manage ingress controllers](https://techdocs.akamai.com/app-platform/docs/ingress-classes)
- [Deploy without installing the App Platform Console or API](https://techdocs.akamai.com/app-platform/docs/core-only)
- [Create and restore backups](https://techdocs.akamai.com/app-platform/docs/create-and-restore-backups)
- [Clone to a new Kubernetes cluster](https://techdocs.akamai.com/app-platform/docs/clone-apl)
- [Manage Age encryption for development, security, and recovery](https://techdocs.akamai.com/app-platform/docs/manage-age)
- [Change the otomi-admin password](https://techdocs.akamai.com/app-platform/docs/change-admin-password)