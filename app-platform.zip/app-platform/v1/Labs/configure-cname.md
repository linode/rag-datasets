# [Configuring a CNAME](https://techdocs.akamai.com/app-platform/docs/configure-cname#configuring-a-cname)

# [Configure a Service with a CNAME](https://techdocs.akamai.com/app-platform/docs/configure-cname#configure-a-service-with-a-cname)

Select `Use CNAME` when the URL of the service is used as a value in a CNAME.

## [With TLS Termination at the NGINX Controller](https://techdocs.akamai.com/app-platform/docs/configure-cname#with-tls-termination-at-the-nginx-controller)

Follow the steps below to set up a CNAME when the TLS termination happens on the NGINX controller.

1. Configure a CNAME entry with your domain name provider.

2. Generate or copy your domain certificates and store them as a TLS secret in your team's namespace.

3. Go to the service configuration section in the Console.

4. Create a new service by selecting the k8s service and port that you want to expose.

5. Check the "Use CNAME" checkbox. Two text boxes will appear: "domain" and "tlsSecretName".

6. Fill in both text boxes accordingly. Example: domain=`demo.example.com`, tlsSecretName=`my-cname-cert`.

7. Click on the "Submit" button, followed by the "Deploy" button.

## [With TLS Termination at the Application (Pod) Level](https://techdocs.akamai.com/app-platform/docs/configure-cname#with-tls-termination-at-the-application-pod-level)

Follow the steps below to set up a CNAME when the TLS termination happens on the application (pod) running on the cluster. It is expected that the certificates are already embedded or mounted in the application/pod.

1. Configure a CNAME entry with your domain name provider.

2. Go to the service configuration section in the Console.

3. Create a new service by selecting the k8s service and port that you want to expose.

4. Check the "TLS Passthrough" checkbox.

5. Check the "Use CNAME" checkbox. Fill the domain field(leave the tlsSecretName field empty).

6. Provide your cname domain in the text box.

7. Click on the "Submit" button, followed by the "Deploy" button.