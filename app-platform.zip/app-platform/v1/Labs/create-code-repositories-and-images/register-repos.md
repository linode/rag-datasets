# [Register code repositories](https://techdocs.akamai.com/app-platform/docs/register-repos#register-code-repositories)

In the previous lab we created two code repositories: blue and green. Before we can start creating container images using these repositories, we first need to register them in the Akamai App Platform.

1. Sign in to the Akamai App Platform and navigate to **Code repositories** in the left menu.

2. Click on the **Add code repository** button.

3. Provide a name for this code repository. The name will be used to identify the code repository in the App Platform. You can only use the name once within a team. We are going to use the name `blue` for this code repository.

4. Select _Gitea_ for the Git service (default), unless you used another service when creating the repositories.

5. Select _blue_ from the **Repository** drop-down list:

   

6. Click the **Add Code Repository** button.

7. Follow the above steps again, but now for the green repository.

You should now have two code repositories registered for your team.
