# [Create code repositories](https://techdocs.akamai.com/app-platform/docs/create-repos#create-code-repositories)

As a developer, you'll need a Git repository for your code. Most organizations will probably use a Git service like GitLab or GitHub. But if you don't, you can use the integrated Git service powered by Gitea.

As a Team member, you can create and manage your own repositories.

 > Note: 
  Team members first have to sign in to Gitea (using OpenID), after which they are automatically granted access to the team's organization in Gitea.

 > Warning: 
  The default `platform-admin` account does not have access to team organizations in Gitea. When using the `platform-admin` account, make sure to add your account to the Owners group of the Team's organization in Gitea.

In the labs, we'll be using a team called _labs_ and a user called `labs-user@labs.com`.

# [Create the private repository (blue)](https://techdocs.akamai.com/app-platform/docs/create-repos#create-the-private-repository-blue)

In the apps section in the console, you'll see an app called Gitea. Click on it.

1. Navigate to the **Apps** page using the left menu and click on the **Gitea** app.

2. Create a new repository. To do this, you can click the **+** dropdown menu in the top right and select **New repository**.

3. Select _team-labs_ as the **owner**. This is the team that you belong to as a member.

4. Enter _blue_ as the **repository name**.

5. Check the **Make Repository Private** checkbox.

6. Scroll further down the page and check the **Initialize repository** checkbox. This adds a README file, license file, and `.gitignore` file to the new repository.

7. Click the **Create Repository** button at the bottom to continue.

Your repo is now ready to be used.

# [Add initial files](https://techdocs.akamai.com/app-platform/docs/create-repos#add-initial-files)

Add the following two files to the repository:

- `Dockerfile`:

  ```Dockerfile
  FROM nginxinc/nginx-unprivileged:stable
  COPY blue.html /usr/share/nginx/html/index.html
  EXPOSE 8080
  ```

- `blue.html`:

  ```html
  <!DOCTYPE html>
  

    
      
      Sample Deployment
      
    

    

    

        # 
Welcome to Blue

    

    

  

  ```

# [Repeat the steps for the green repository](https://techdocs.akamai.com/app-platform/docs/create-repos#repeat-the-steps-for-the-green-repository)

In the upcoming labs we are going to use the _blue_ repository, but we'll also need a _green_ repository.  
Create the green repository and add the following two files (similar to the ones that where added to the blue repo).

- `Dockerfile`:

  ```Dockerfile
  FROM nginxinc/nginx-unprivileged:stable
  COPY green.html /usr/share/nginx/html/index.html
  EXPOSE 8080
  ```

- `green.html`:

  ```html
  <!DOCTYPE html>
  

    
      
      Sample Deployment
      
    

    

      

        # 
Welcome to Green

      

    

  

  ```

Now continue with the next lab to [register the code repositories](https://techdocs.akamai.com/app-platform/docs/register-repos) in App Platform.