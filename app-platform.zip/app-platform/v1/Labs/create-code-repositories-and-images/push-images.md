# [Push images to Harbor](https://techdocs.akamai.com/app-platform/docs/push-images#push-images-to-harbor)

# [Prerequisites](https://techdocs.akamai.com/app-platform/docs/push-images#prerequisites)

- The Harbor app needs to be activated.
- The App Platform cluster needs to be configured with certificates (such as Let's Encrypt production certificates).
- The _Download the DOCKERCFG_ feature needs to be enabled by a platform administrator.
- Docker needs to be installed on your local (or other development) machine. See [Install Docker Engine](https://docs.docker.com/engine/install/) .

# [Push images to Harbor](https://techdocs.akamai.com/app-platform/docs/push-images#push-images-to-harbor)

To be able to push images to Harbor, you'll need a robot account with push permissions. Teams are offered the option to download the Docker config for their team's private registry in Harbor.

1. Log in to the App Platform Console and select **Download DOCKERCFG** in the left menu. This downloads the docker config file to your local machine.

2. When you have downloaded the docker config, copy the file to your `.Docker` folder.

   ```bash
   cp docker-team-labs.json $HOME/.Docker
   ```

3. Log in to the Harbor registry through the Docker CLI.

   ```bash
   docker login harbor.

   ```

4. Build and tag your image.

   ```bash
   docker build -t harbor.
/team-
/
:
 

   ```

5. Push the image to Harbor:

   ```bash
   docker push harbor.
/team-
/
:

   ```