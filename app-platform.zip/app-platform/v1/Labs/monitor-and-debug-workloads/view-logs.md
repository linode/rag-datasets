# [View container logs](https://techdocs.akamai.com/app-platform/docs/view-logs#view-container-logs)

 > Note: 
  Loki needs to be enabled on the platform level and Grafana needs to be enabled for the Team.

When your application is deployed, container logs are typically needed for debugging purposes. Grafana Loki is used for log aggregation. When Loki on the Platform level is enabled, you'll see the Loki app in your Team Apps.

1. Open the **Loki** app in your team apps:

   

2. In **Grafana**, you are directed to the **Explore** section:

   

3. Select the **app** label, then choose _blue_, and click **Run Query**. This will display all logs for the blue container. You can also create custom queries; learn more about LogQL here: [here](https://grafana.com/docs/loki/latest/logql/).