# [Monitoring service availability](https://techdocs.akamai.com/app-platform/docs/monitor-services#monitoring-service-availability)

When your application is deployed and exposed, you probably would like to get an alert when your application (service) is not available anymore. To automatically monitor you applications for availability, a probe to monitor your service is automatically configured.

In this lab we'll scale down the replicas of a workload to see how this works.

# [Check alerts in Alertmanager](https://techdocs.akamai.com/app-platform/docs/monitor-services#check-alerts-in-alertmanager)

1. In the left menu, click on **Apps** and open **Alertmanager**.

   

2. As you can see, there are currently no alerts:

   

# [Scale down the replicas of a Workload](https://techdocs.akamai.com/app-platform/docs/monitor-services#scale-down-the-replicas-of-a-workload)

In the lab [Expose Services](expose-services) we exposed the `blue` service. Let's scale down the `blue` workload and see what happens:

1. Go to **Workloads** in the left menu and click on the _blue_ workload.

2. Click on the **Values** tab.

3. In the workload `values`, set the `replicaCount` to `0`:

   ```yaml
   replicaCount: 0
   ```

4. Click **Submit**.

# [Check the alerts again](https://techdocs.akamai.com/app-platform/docs/monitor-services#check-the-alerts-again)

1. Go back to Alertmanager and see if there are new alerts. You should see the following alert:

   

2. Click on **+Info** for more details about the alert:

   

3. In the summary field, you should see the following:

   > Target `https://blue-labs.labs.try-apl.net/` is down!