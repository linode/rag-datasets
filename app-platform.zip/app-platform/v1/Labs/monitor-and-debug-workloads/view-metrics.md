# [View container metrics](https://techdocs.akamai.com/app-platform/docs/view-metrics#view-container-metrics)

When your application is deployed, you would of course like to be able to see container metrics for debugging purposes. Prometheus is used for collecting metrics. When Prometheus is enabled on the platform level and Grafana is enabled for the Team, general container metrics (provided by the Platform Prometheus) can be used in Grafana dashboards.

# [Prerequisites](https://techdocs.akamai.com/app-platform/docs/view-metrics#prerequisites)

- Enable Prometheus on the platform-level and Grafana dashboards on the team-level. 

# [View dashboards](https://techdocs.akamai.com/app-platform/docs/view-metrics#view-dashboards)

1. Open the **Grafana** app in your team apps:

   

2. Grafana will open the dashboards page:

   

The dashboards are dynamically added based on the enabled platform capabilities:

| Dashboard               | When added                                           |
| ----------------------- | ---------------------------------------------------- |
| Kubernetes / Deployment | When Prometheus on the platform level is enabled     |
| Kubernetes / Pods       | When Prometheus on the platform level is enabled     |
| Team status             | When Prometheus on the platform level is enabled     |
| Container scan results  | When Trivy Operator on the platform level is enabled |

# [View container metrics](https://techdocs.akamai.com/app-platform/docs/view-metrics#view-container-metrics)

1. Click on the **Kubernetes / Pods** dashboard.

2. Select the desired Pod and Container, e.g., `blue-
` and `all`.