# [Secure workloads](https://techdocs.akamai.com/app-platform/docs/secure-workloads#secure-workloads)

- [Scan your images for vulnerabilities](https://techdocs.akamai.com/app-platform/docs/scan-images)
- [Scan your running containers for vulnerabilities](https://techdocs.akamai.com/app-platform/docs/scan-containers)