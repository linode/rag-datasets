# [Create a RabbitMQ cluster](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster#create-a-rabbitmq-cluster)

In this lab we will create a RabbitMQ cluster using the _rabbitmq-cluster_ Helm chart from the catalog.

 > Note: 
  For this lab, RabbitMQ Operator needs to be activated.

# [Creating the RabbitMQ Cluster](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster#creating-the-rabbitmq-cluster)

1. In the left sidebar click on **Catalog**.

2. Click on the `rabbitmq-cluster` item in the catalog. This will take you to the page with the readme where you can see all specifications and definitions that you can use to create your RabbitMQ cluster with queues and policies.

3. Click on the **Values** tab and fill in a name for the RabbitMQ cluster. In this lab we will create a rabbitMQ Cluster with the name `rabbit1`.

4. Scroll down and optionally edit the cluster parameters.

5. Configure queues and policies for the RabbitMQ cluster with 2 `queues` and 2 `policies`:

   ```yaml
   queues:
     - name: my-quorum-queue1
       spec:
         durable: true
         arguments:
           x-queue-type: quorum
     - name: my-quorum-queue2
       spec:
         arguments:
           autoDelete: true

   policies:
     - name: my-policy1
       pattern: ".*"
       definition:
         dead-letter-exchange: cc
         ha-mode: all
       spec:
         applyTo: classic_queues
         priority: 1
         vhost: "/"
     - name: my-policy2
       pattern: ".*"
       definition:
         dead-letter-exchange: cc
         max-age: 1h
       spec:
         applyTo: quorum_queues
   ```

   > > Note: 
   > 
   > Remember that even though these values can be edited afterwards, not all specifications or definitions can be updated after a `queue` or `policy` has been created. Please make sure everything is filled in correctly.

6. Click **Submit**.

# [Accessing the RabbitMQ Management UI](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster#accessing-the-rabbitmq-management-ui)

To access the **RabbitMQ Management UI** you have two options:

- Retrieve the default user credentials and configure port forwarding on the RabbitMQ server.

- Create a service to expose the RabbitMQ server and access the management UI publicly. This is not recommended for production services.

In this lab we are going to use port forwarding. 

 > Note: 
  In this example the RabbitMQ cluster was created in the team labs, so we have to get the `secret` from the `team-labs` namespace. Please retrieve the `secret` from the namespace where the RabbitMQ cluster was created.

1. Use the following command to retrieve the username:

   ```bash
   kubectl get secret rabbit1-quickstart-rabbitmq-default-user -n team-labs -o jsonpath="{.data.username}" | base64 --decode
   ```

2. Use the following command to retrieve the password:

   ```bash
   kubectl get secret rabbit1-quickstart-rabbitmq-default-user -n team-labs -o jsonpath="{.data.password}" | base64 --decode
   ```

   > > Note: 
   > 
   > Make sure you don't copy the `%` symbol at the end.

   Now you have to `port-forward` the rabbitmq `container` with port number `15672` that is inside the rabbitmq `pod` called `rabbit1-rabbitmq-server-0` to a port of your choice that is not used. In this lab we use port `56027`.

   > > Note: 
   > 
   > `rabbit1-rabbitmq-server-0` has the prefix `rabbit1` because this is the name that we gave the cluster.

3. Use the following command to enable the port forwarding:

   ```bash
   kubectl port-forward -n team-labs rabbit1-rabbitmq-server-0 56027:15672
   ```

4. Open a browser and go to `http://localhost:56027`

5. Use the previously acquired user credentials to log in. If you cannot log in, please check if the credentials are for the correct RabbitMQ cluster.

   

# [Checking the RabbitMQ Management UI](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster#checking-the-rabbitmq-management-ui)

Now that we are logged in you should see the following:

We can also check the `queues` that we specified when creating the rabbitmq cluster in the **Queues and Streams** tab.

To see the policies that we defined you can see them in the **Admin** tab and under **Policies**:

# [Connecting an application to the RabbitMQ cluster](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster#connecting-an-application-to-the-rabbitmq-cluster)

To connect to the RabbitMQ cluster you use `AMQP` to open a connection. To open a connection you need to create a connection string using the `username`, `password`, `host` and `port` of the RabbitMQ cluster.

1. Get the host using the following command:

   ```bash
   kubectl get secret rabbit1-rabbitmq-cluster-default-user -n team-labs -o jsonpath="{.data.host}" | base64 --decode
   ```

2. Get the port use the following command:

   ```bash
   kubectl get secret rabbit1-rabbitmq-cluster-default-user -n team-labs -o jsonpath="{.data.port}" | base64 --decode
   ```

The connection string is build like this:

```
amqp://USERNAME:PASSWORD@HOST:PORT/
```

With values:

```
amqp://default_user_mWPUECo5wsbtpgY3oze:MdzUL4CcgF-cQryLfk5uxqf57qqWBG8l@matthew-rabbit1-rabbitmq.team-admin.svc:5672/
```