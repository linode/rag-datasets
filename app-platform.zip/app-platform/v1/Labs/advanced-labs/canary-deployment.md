# [Canary deployment](https://techdocs.akamai.com/app-platform/docs/canary-deployment#canary-deployment)

In this lab we are going to create a canary deployment. The idea behind canary deployment (or rollout) is to introduce a new version of an application by first testing it using a small percentage of user traffic, and then if all goes well increasing the percentage while simultaneously phasing out the old version.

For this we are going to deploy the stable version (blue), introduce a new version and then change the new version until we are happy with it and then increase the traffic to the new version.

# [Prepare images](https://techdocs.akamai.com/app-platform/docs/canary-deployment#prepare-images)

For this lab we need the 2 images (`blue` and `green`) we already created in the previous labs. If you haven't created the blue and green images, first complete these 4 labs:

- [Create Code Repositories](https://techdocs.akamai.com/app-platform/docs/create-repos)

- [Register Code Repositories](https://techdocs.akamai.com/app-platform/docs/create-repos)

- [Create Container Images](https://techdocs.akamai.com/app-platform/docs/create-images)

- [Trigger Builds](https://techdocs.akamai.com/app-platform/docs/trigger-builds)

Or you can use public images e.g. `nginx:latest` and `tomcat:latest` for this lab.

# [Create a workload from the catalog](https://techdocs.akamai.com/app-platform/docs/canary-deployment#create-a-workload-from-the-catalog)

Go to the list of builds and add the repository of the green build to your clipboard.

1. Go to **Workloads** in the left menu and click on **Create Workload**.

2. Select `k8s-deployment-canary` from the catalog.

3. Add the **Name** _canary_ for the workload.

4. Set the **Auto image updater** to _Digest_ and fill in:

   - imageRepository : paste from the clipboard
   - imageParameter : `versionTwo.image.repository`
   - tagParameter : `versionTwo.image.tag`

5. In the workload _values_, change the following parameters:

   ```yaml
   # For the v1 as the stable version
   versionOne:
     image:
       repository: # paste from clipboard, but change to blue
       tag: main
   # The v2 as canary with the auto image updater configured
   versionTwo:
     image:
       repository: # paste from clipboard. This will be the green image
       tag: main
   ```

6. Click **Submit**

We now created two deployments. One for blue and one for green. The green image (our canary) will be automatically updated after a change (commit).

# [Expose the service](https://techdocs.akamai.com/app-platform/docs/canary-deployment#expose-the-service)

1. In the left menu panel under click **Services** then click on **Create Service**.

2. Select the _canary_ service from the drop-down list.

3. Click on **Advanced Settings**.

4. Click on **Enable Traffic Management** (and use the default weights for v1 and v2).

5. Click **Create Service**.

# [See the results](https://techdocs.akamai.com/app-platform/docs/canary-deployment#see-the-results)

You will see the _canary_ service in the list of **Services**. Click on the URL and refresh the page for a couple of times. You should first see:

After a refresh of the page you should see:

# [Update the canary image](https://techdocs.akamai.com/app-platform/docs/canary-deployment#update-the-canary-image)

Go to the green repo and change the background color (`background-color`) in the `green.html` file from `green` to `MediumSeaGreen` and commit the change. After a couple of minutes you should now see that the background color of version 2 has changed.

Do you see the difference?