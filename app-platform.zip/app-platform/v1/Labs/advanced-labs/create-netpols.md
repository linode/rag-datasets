# [Create network policies](https://techdocs.akamai.com/app-platform/docs/create-netpols#create-network-policies)

Securing the network paths for your applications is often a critical task. This tutorial walks you through explicitly opening up on the network paths needed for your application using the following areas of the Akamai App Platform:

- **[Inbound rules](https://techdocs.akamai.com/app-platform/docs/team-network-policies#inbound-rules):** Pod-to-pod traffic (cluster-internal). Allow specific workloads to connect to your pods.
- **[Outbound rules](https://techdocs.akamai.com/app-platform/docs/team-network-policies#outbound-rules):** External traffic (egress to FQDNs/IPs). Allow namespace‑wide access to specific FQDNs or IPs.

When **Ingress control** is enabled for your team, _all_ pod‑to‑pod traffic is denied by default. When **Egress control** is enabled, _all_ external traffic is denied by default.

In this lab, you will create the rules required by your voting app. The lab consists of four parts:

- [Deploy the voting app](#deploy-the-voting-app-part-1)
- [Create inbound rules](#create-inbound-rules-for-the-voting-app-part-2)
- [Create outbound rule for testing and troubleshooting](#create-outbound-rule-for-testing-and-troubleshooting-part-3)
- [Test network traffic](#test-network-traffic-part-4)

# [Deploy the voting app (Part 1)](https://techdocs.akamai.com/app-platform/docs/create-netpols#deploy-the-voting-app-part-1)

## [Build container images](https://techdocs.akamai.com/app-platform/docs/create-netpols#build-container-images)

1. Register a Code Repository with `https://github.com/linode/apl-examples` as the URL.
2. Create three Docker Container Images. For the Dockerfile path you can use:

   - **vote** → `vote-app/vote/Dockerfile`
   - **worker** → `vote-app/worker/Dockerfile`
   - **result** → `vote-app/result/Dockerfile`

## [Deploy Redis & Postgres](https://techdocs.akamai.com/app-platform/docs/create-netpols#deploy-redis-postgres)

1. In the Catalog, install **redis** (master‑replica) with `auth.enabled=false`.
2. Install **postgresql** with default settings.

## [Deploy your workloads](https://techdocs.akamai.com/app-platform/docs/create-netpols#deploy-your-workloads)

Use the `k8s-deployment` chart to deploy the vote app, worker app, and result app.

- **Vote:**

  ```yaml App: vote
  image:
    repository: harbor.
/team-
/vote
    pullPolicy: IfNotPresent
    tag: main
  containerPorts:
    - name: http
      containerPort: 80
      protocol: TCP
  env:
    - name: REDIS_HOST
      value: 
-quickstart-redis-master
  replicaCount: 1
  ```
- **Worker:**

  ```yaml App: worker
  image:
    repository: harbor.
/team-
/worker
    pullPolicy: IfNotPresent
    tag: main
  containerPorts:
    - name: http
      containerPort: 80
      protocol: TCP
  env:
    - name: DATABASE_USER
      valueFrom:
        secretKeyRef:
          name: 
-app
          key: username
    - name: DATABASE_PASSWORD
      valueFrom:
        secretKeyRef:
          name: 
-app
          key: password
    - name: REDIS_HOST
      value: 
-quickstart-redis-master
    - name: DATABASE_HOST
      value: 
-rw
  replicaCount: 1
  ```
- **Result:**

  ```yaml App: result
  image:
    repository: harbor.
/team-
/result
    pullPolicy: IfNotPresent
    tag: main
  containerPorts:
    - name: http
      containerPort: 80
      protocol: TCP
  env:
    - name: DATABASE_USER
      valueFrom:
        secretKeyRef:
          name: 
-app
          key: username
    - name: DATABASE_PASSWORD
      valueFrom:
        secretKeyRef:
          name: 
-app
          key: password
    - name: DATABASE_HOST
      value: 
-rw
    - name: DATABASE_NAME
      value: 

  replicaCount: 1
  ```

 > Note: 
  The worker and result pods will show an error “Waiting for db” in the logs. This is an expected error that will be resolved when all the steps in the lab are done.

## [Expose your services](https://techdocs.akamai.com/app-platform/docs/create-netpols#expose-your-services)

Create two services, one for the vote app and one for the result app.

# [Create inbound rules for the voting app (Part 2)](https://techdocs.akamai.com/app-platform/docs/create-netpols#create-inbound-rules-for-the-voting-app-part-2)

Use the **Inbound Rules** page to create two rules. One allows the worker and result workloads to reach Postgres workload and the other allows the vote and worker workloads to reach Redis.

## [Postgres Ingress](https://techdocs.akamai.com/app-platform/docs/create-netpols#postgres-ingress)

1. Navigate to the **Inbound Rules** page (under **Network Policies**).

2. Click the **Create inbound rule** button.

3. In the**Name** field, enter `postgres-ingress`.

4. Under **Sources**, add both the worker and result apps:

   - Select _worker_ from the **Workload** dropdown menu.
   - Select `otomi.io/app=worker`from the **Label(s)** dropdown menu.
   - Click **Add Source** to add the second source.
   - Select _result_ from the **Workload** dropdown menu.
   - Select `otomi.io/app=result`from the **Label(s)** dropdown menu.

5. Add the following in the **Target** section:

   - Select _postgres_ from the **Workload** dropdown menu.
   - Select `otomi.io/app=postgres`from the **Label(s)** dropdown menu.

6. Click **Save Changes** to create the rule.

## [Redis Ingress](https://techdocs.akamai.com/app-platform/docs/create-netpols#redis-ingress)

1. Click the **Create inbound rule** button again to create the second rule.

2. In the**Name** field, enter `redis-ingress`.

3. Under **Sources**, add both the worker and vote apps:
   - Select _worker_ from the **Workload** dropdown menu.
   - Select `otomi.io/app=worker`from the **Label(s)** dropdown menu.
   - Click **Add Source** to add the second source.
   - Select _vote_ from the **Workload** dropdown menu.
   - Select `otomi.io/app=vote`from the **Label(s)** dropdown menu.

4. Add Redis to the **Target** section:
   - Select _redis_ from the **Workload** dropdown menu.
   - Select `otomi.io/app=redis`from the **Label(s)** dropdown menu.

5. Click **Save Changes** to create the second rule.

# [Create outbound rule for testing and troubleshooting (Part 3)](https://techdocs.akamai.com/app-platform/docs/create-netpols#create-outbound-rule-for-testing-and-troubleshooting-part-3)

Use the **Outbound Rules** page to allow HTTPS egress to `example.com` so that you can test connectivity.

## [Example.com Egress](https://techdocs.akamai.com/app-platform/docs/create-netpols#examplecom-egress)

1. Navigate to the **Outbound Rules** page (under **Network Policies**).

2. Click the **Create outbound rule** button.

3. In the**Name** field, enter `example-egress`.

4. For the **Domain name or IP address**, enter `example.com`.

5. Finally set the **Protocol** to _HTTPS_ and **Port** to _443_. 

6. Click **Save Changes** to save your new outbound rule.

# [Test network traffic (Part 4)](https://techdocs.akamai.com/app-platform/docs/create-netpols#test-network-traffic-part-4)

## [Verify pod‑to‑pod traffic (ingress)](https://techdocs.akamai.com/app-platform/docs/create-netpols#verify-podtopod-traffic-ingress)

1. Navigate to your **Vote** service’s external URL and cast a vote.
2. Then, navigate to your **Result** service’s URL and confirm the vote appears. If it does, pod-to-pod traffic is working as expected.

## [Verify external traffic (egress)](https://techdocs.akamai.com/app-platform/docs/create-netpols#verify-external-traffic-egress)

1. Launch Netshoot in your team namespace:

   ```bash
   kubectl run -i --tty --rm netshoot \
     --image nicolaka/netshoot -n team-labs
   ```

2. Inside the pod, run:

   ```bash
    curl -s https://example.com | grep -o '<h1.*
'
   ```

   If egress traffic is working as expected, this should display the following output:

   ```
   # 
Example Domain

   ```

3. Exit the pod (`exit`). It will be removed automatically.

If both tests were successful, your voting app is now locked down to exactly the paths you specified in your network policies.