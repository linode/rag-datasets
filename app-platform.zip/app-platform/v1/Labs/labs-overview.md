# [Getting started with labs](https://techdocs.akamai.com/app-platform/docs/labs-overview#getting-started-with-labs)

To help you go further with the Akamai App Platform, additional instructions are provided to help you with common use cases. We recommend reviewing these labs to learn how to use the App Platform or if you would like to learn more about Kubernetes. They will guide you in how to build, deploy, secure, and observe containerized applications on Kubernetes. The labs cover the most common activities performed by developers and DevOps.

# [Prerequisites](https://techdocs.akamai.com/app-platform/docs/labs-overview#prerequisites)

Before continuing with the labs in this section, verify that the following prerequisites are met.

1. Make sure App Platform is configured with DNS. This is done automatically when deployed directly though LKE.

2. Enable the Prometheus app on the platform-level.

3. Enable additional apps on the platform-level to support the following labs:

   | Lab                                         | App                                 |
   | ------------------------------------------- | ----------------------------------- |
   | Create container images                     | Harbor                              |
   | Trigger builds                              | Harbor                              |
   | Manually Push images to Harbor              | Harbor                              |
   | Scan running containers for vulnerabilities | Prometheus, Grafana, Trivy Operator |
   | View container logs                         | Loki, Grafana                       |
   | Tracing with Open Telemetry                 | Loki, Otel, Tempo                   |
   | Create a RabbitMQ cluster                   | RabbitMQ                            |

   > > Note: 
   > 
   > For the [Tracing with Open Telemetry](https://techdocs.akamai.com/app-platform/docs/use-otel) Lab, tracing needs to be configured in the `Istio` and `Nginx Ingress` apps.

4. Create a team called `labs` with both dashboards and alerts enabled. See [Teams](https://techdocs.akamai.com/app-platform/docs/platform-teams) for more details on creating teams.

5. Create a user and make this user a member of the `labs` team. In the labs, we'll be using the user `labs-user@labs.com`. See [Users](https://techdocs.akamai.com/app-platform/docs/platform-user-management) for instructions on how to create users and assign them to teams.

   > > Note: 
   > 
   > The App Platform will automatically create an organization for each team in Gitea. Only members of the team are added to the `Owners` group of this organization. It is possible to go through the labs using the (default) `platform-admin` user account that was created during the installation of the App Platform. When using the `platform-admin` user, then make sure to add your account to the `Owners` group of the team's organization in Gitea. See [Add owner to team organization in Gitea](https://techdocs.akamai.com/app-platform/docs/add-owner-to-team-org-gitea).

6. Add the Kube API to the [Cluster Settings](https://techdocs.akamai.com/app-platform/docs/platform-settings). Select the `platform` view and click on `Settings` in the left menu. Then click on `Cluster`. When using LKE: You can find the Kube API URL in the summary of your LKE cluster. Here it is called the `Kubernetes API Endpoint`. You can remove `:443` at the end.

# [Labs](https://techdocs.akamai.com/app-platform/docs/labs-overview#labs)

**Create and register code repositories and create images**

- [Create code repositories](https://techdocs.akamai.com/app-platform/docs/create-repos)
- [Register code repositories](https://techdocs.akamai.com/app-platform/docs/register-repos)
- [Create container images](https://techdocs.akamai.com/app-platform/docs/create-images)
- [Trigger builds](https://techdocs.akamai.com/app-platform/docs/trigger-builds)
- [Push images to Harbor](https://techdocs.akamai.com/app-platform/docs/push-images)
- [Add owner to team organization in Gitea](https://techdocs.akamai.com/app-platform/docs/add-owner-to-team-org-gitea)

**Create workloads**

- [Create sealed secrets](https://techdocs.akamai.com/app-platform/docs/create-sealed-secrets)
- [Using Argo CD](https://techdocs.akamai.com/app-platform/docs/using-argo-cd)
- [Use the Catalog](https://techdocs.akamai.com/app-platform/docs/use-catalog)
- [Create Workloads](https://techdocs.akamai.com/app-platform/docs/create-workloads)
- [Configure auto image updater](https://techdocs.akamai.com/app-platform/docs/auto-image-update)
- [Create a PostgreSQL database](https://techdocs.akamai.com/app-platform/docs/create-postgresql-db)

**Expose workloads**

- [Publicly expose workloads](https://techdocs.akamai.com/app-platform/docs/expose-services)

**Secure workloads**

- [Scan your images for vulnerabilities](https://techdocs.akamai.com/app-platform/docs/scan-images)
- [Scan your running containers for vulnerabilities](https://techdocs.akamai.com/app-platform/docs/scan-containers)

**Monitor and debug workloads**

- [View container logs](https://techdocs.akamai.com/app-platform/docs/view-logs)
- [View container metrics](https://techdocs.akamai.com/app-platform/docs/view-metrics)
- [Using custom metrics](https://techdocs.akamai.com/app-platform/docs/custom-metrics)
- [Monitoring service availability](https://techdocs.akamai.com/app-platform/docs/monitor-services)

**Advanced labs**

- [Create network policies](https://techdocs.akamai.com/app-platform/docs/create-netpols)
- [OpenTelemetry](https://techdocs.akamai.com/app-platform/docs/use-otel)
- [Canary deployment](https://techdocs.akamai.com/app-platform/docs/canary-deployment)
- [Create rabbitMQ Cluster](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster)

**Additional labs:**

- [Use a Git client](https://techdocs.akamai.com/app-platform/docs/using-git-client)
- [Configuring a CNAME](https://techdocs.akamai.com/app-platform/docs/configure-cname)