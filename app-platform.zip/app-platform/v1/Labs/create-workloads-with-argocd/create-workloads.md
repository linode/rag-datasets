# [Create workloads](https://techdocs.akamai.com/app-platform/docs/create-workloads#create-workloads)

In the previous lab we deployed a workload using Argo CD with a BYO manifest and we explored the catalog. In this lab we'll create a workload (a Kubernetes Deployment) using the catalog and the workload self-service feature.

## [Create a workload using the catalog](https://techdocs.akamai.com/app-platform/docs/create-workloads#create-a-workload-using-the-catalog)

Before creating a workload from the catalog, we'll need the repository and tag of the image to use. Go to the list of container images and add the repository of the blue image to your clipboard. Remember that the tag of the blue image we created is `main`.

You can create a workload from the developer catalog:

1. Go to **Catalog** in the left menu and select the `k8s-deployment`template.

2. Click on the **Values** tab.

3. Set the **name** to _blue_.

4. Leave the **Auto image updater** to _Disabled_.

5. In the workload `values`, change the following parameters:

   ```yaml
   image:
     repository: 

     tag: main
   ```

   

6. Click **Submit**. The App Platform will now create an Argo CD application to deploy the workload. 

7. Click on **Workloads** in the left menu. You will now see a list of all workloads and their status:

   

8. In the workloads list, click on the application link of your workload to see the status of your workload in Argo CD:

   

   The values of a workload can be changed at any time. Changes will automatically be synchronized.