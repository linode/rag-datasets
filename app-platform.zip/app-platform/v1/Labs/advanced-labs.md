# [Advanced labs](https://techdocs.akamai.com/app-platform/docs/advanced-labs#advanced-labs)

- [Create network policies](https://techdocs.akamai.com/app-platform/docs/create-netpols)
- [OpenTelemetry](https://techdocs.akamai.com/app-platform/docs/use-otel)
- [Canary deployment](https://techdocs.akamai.com/app-platform/docs/canary-deployment)
- [Create rabbitMQ Cluster](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster)