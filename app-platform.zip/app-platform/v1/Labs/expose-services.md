# [Publicly expose workloads](https://techdocs.akamai.com/app-platform/docs/expose-services#publicly-expose-workloads)

When you have deployed your application using the workloads feature, you will probably like to expose it publicly. In this lab we'll create a service to publicly expose your application. When you create a service, the Istio virtual service and ingress resource for your application will be created automatically by the App Platform.

# [Create a Service](https://techdocs.akamai.com/app-platform/docs/expose-services#create-a-service)

1. In the left menu, click **Services** then click the **Create Services** button.

2. Select the _blue_ service from the **Service Name** drop-down list:

   

3. Click **Create Service**. After it has been created, you will see your service in the list of services:

   

4. Click on the URL and see the blue application publicly exposed.