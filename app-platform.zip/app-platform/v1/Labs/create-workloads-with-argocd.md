# [Create workloads](https://techdocs.akamai.com/app-platform/docs/create-workloads-with-argocd#create-workloads)

- [Create sealed secrets](https://techdocs.akamai.com/app-platform/docs/create-sealed-secrets)
- [Using Argo CD](https://techdocs.akamai.com/app-platform/docs/using-argo-cd)
- [Use the catalog](https://techdocs.akamai.com/app-platform/docs/use-catalog)
- [Create workloads](https://techdocs.akamai.com/app-platform/docs/create-workloads)
- [Configure auto image updater](https://techdocs.akamai.com/app-platform/docs/auto-image-update)
- [Create a PostgreSQL database](https://techdocs.akamai.com/app-platform/docs/create-postgresql-db)