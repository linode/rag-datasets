# [Monitor and debug workloads](https://techdocs.akamai.com/app-platform/docs/monitor-and-debug-workloads#monitor-and-debug-workloads)

- [View container logs](https://techdocs.akamai.com/app-platform/docs/view-logs)
- [View container metrics](https://techdocs.akamai.com/app-platform/docs/view-metrics)
- [Using custom metrics](https://techdocs.akamai.com/app-platform/docs/custom-metrics)
- [Monitoring service availability](https://techdocs.akamai.com/app-platform/docs/monitor-services)