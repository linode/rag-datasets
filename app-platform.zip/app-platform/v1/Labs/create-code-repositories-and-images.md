# [Create code repositories and images](https://techdocs.akamai.com/app-platform/docs/create-code-repositories-and-images#create-code-repositories-and-images)

- [Create code repositories](https://techdocs.akamai.com/app-platform/docs/create-repos)
- [Register code repositories](https://techdocs.akamai.com/app-platform/docs/register-repos)
- [Create container images](https://techdocs.akamai.com/app-platform/docs/create-images)
- [Trigger builds](https://techdocs.akamai.com/app-platform/docs/trigger-builds)
- [Push images to Harbor](https://techdocs.akamai.com/app-platform/docs/push-images)
- [Add owner to team organization in Gitea](https://techdocs.akamai.com/app-platform/docs/add-owner-to-team-org-gitea)