# [Post installation steps](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#post-installation-steps)

Follow the post-installation steps after initial installation.

# [Obtain the initial admin user credentials](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#obtain-the-initial-admin-user-credentials)

When the installer job (in the default namespace) has finished you can obtain the initial administrator credentials and sign in to the Console.

Use the following command to get the logs of the installer job:

```
kubectl logs jobs/apl -n default -f
```

At the end of the logs you should see the following message:

```bash
########################################################################################################################################
#
# [The App Platform console is available at https://console.${domainSuffix}](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#the-app-platform-console-is-available-at-httpsconsoledomainsuffix)
#
# [Obtain login credentials by using the below commands:](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#obtain-login-credentials-by-using-the-below-commands)
# [kubectl get secret platform-admin-initial-credentials -n keycloak -o jsonpath='{.data.username}' | base64 -d](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#kubectl-get-secret-platform-admin-initial-credentials-n-keycloak-o-jsonpathdatausername-base64-d)
# [kubectl get secret platform-admin-initial-credentials -n keycloak -o jsonpath='{.data.password}' | base64 -d](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#kubectl-get-secret-platform-admin-initial-credentials-n-keycloak-o-jsonpathdatapassword-base64-d)
#
########################################################################################################################################
```

Perform these two commands to obtain the username and password of the initial platform administrator user created during installation. When logging into the App Platform Console for the first time, you are prompted to change your password.

# [Add the auto generated CA to your keychain](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#add-the-auto-generated-ca-to-your-keychain)

The generated CA is not trusted on your local machine when installed using Let's Encrypt `staging` certificates. Here are some options to prevent you from clicking away lots of security warning in your browser:

1. In the left menu of the console, click on "Download CA"
2. Double click the downloaded CA.crt or add the CA to your keychain on Mac using the following command:

   ```bash
   sudo security add-trusted-cert -d -r trustRoot -k /Library/Keychains/System.keychain ~/Downloads/ca.crt
   ```

   On Windows, use PowerShell (running as Administrator) with the Certutil:

   ```powershell
   certutil.exe -addstore root 

   ```

   Or:

   ```powershell
   Import-Certificate -FilePath "
" -CertStoreLocation Cert:\LocalMachine\Root
   # Restart the browser
   ```

   You can also run Chrome in insecure mode:

   ```bash
   alias chrome-insecure='/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --ignore-certificate-errors --ignore-urlfetcher-cert-requests &> /dev/null'
   ```

# [Add the URL of the Kubernetes API](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#add-the-url-of-the-kubernetes-api)

 > Note: 
  Adding the URL of the K8s cluster API is required by teams to be able to download the KUBECONFIG

1. Under **Platform** in the Console, click on **Settings**.

2. Click on **Cluster**.

3. Add the full URL of the API server.

4. Click on **Submit**.

# [Configure object storage](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#configure-object-storage)

Some apps (such as Loki, Harbor, and Tempo) require the use of object storage. Before you can activate those apps, first configure object storage with your App Platform deployment. Review the table in the [activate more apps](#activate-more-apps) section to see which apps require object storage.

1. Navigate to **Platform** in the main menu and click **Settings**.

2. Click on **Object Storage** to open the object storage settings.

3. Within the **object storage provider** field, select your preferred provider:
   - **Disabled**: Object storage is disabled.
   - **Linode**: Buckets are created using Linode Object Storage in the specified region (review [Object Storage endpoints by region](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits)  for a list of regions. To use Linode Object Storage on the App Platform, you will need to create a personal access token and enter those credentials. See [Manage access keys](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys) for instructions.
   - **Minio Local** (development only, not provided for production systems): Buckets are provisioned using a Minio installation on the App Platform cluster.

4. Click **Submit** to save your changes and configure your chosen provider.

Once object storage is configured and an API Token is added, you can then activate any app that depends on object storage.

# [Activate more apps](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#activate-more-apps)

Akamai App Platform is a composable platform. Activate more apps based on the required platform capabilities:

| Capability                                      | App                           | Object storage |
| ----------------------------------------------- | ----------------------------- | -------------- |
| Log aggregation                                 | Loki and Grafana              | Optional       |
| Metric collection                               | Prometheus and Grafana        | No             |
| Send Alerts                                     | Prometheus and Alert manager  | No             |
| Tracing                                         | Tempo, OTEL, Loki and Grafana | Required       |
| Build images from source code                   | Harbor                        | Optional       |
| Scan running containers for vulnerabilities     | Trivy                         | No             |
| Enforce security policies                       | Kyverno                       | No             |
| Database backups                                | CloudnativePG                 | Required       |
| Long term retention of Logs, Metrics and Traces | Thanos                        | Required       |

# [Create teams](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#create-teams)

Create your first team. See [Teams](https://techdocs.akamai.com/app-platform/docs/platform-teams) for instructions on managing teams.

# [Create users and add them to a team](https://techdocs.akamai.com/app-platform/docs/post-installation-steps#create-users-and-add-them-to-a-team)

 > Note: 
  The option to create users and add them to Teams is not available when installed with [OIDC](https://techdocs.akamai.com/app-platform/docs/oidc).

Create Users and add them to a Team. See [Users](https://techdocs.akamai.com/app-platform/docs/platform-user-management) for instructions on managing users.