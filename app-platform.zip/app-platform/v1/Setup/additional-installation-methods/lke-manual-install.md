# [Manual installation on LKE](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#manual-installation-on-lke)

 > Note: 
  Consider using the [automatic installation on LKE](https://techdocs.akamai.com/app-platform/docs/lke-automatic-install) method to quickly deploy the Akamai App Platform on LKE. If your needs require custom DNS or additional configuration options, follow the instructions below to install the App Platform manually.

In addition to installing the Akamai App Platform automatically on LKE through a few simple clicks, you can also manually install the App Platform on LKE. Performing a manual installation allows you to use a custom domain and tweak additional settings.

# [Provision an LKE cluster](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#provision-an-lke-cluster)

First, create a new LKE cluster using Cloud Manager, the Linode API, or the Linode CLI. This deploys a new Kubernetes cluster on Akamai Cloud, which will be used as the underpinning infrastructure for your App Platform deployment. The new cluster should have the following specifications:

- Kubernetes version: v1.31 or v1.32
- HA control plane: enabled
- Minimum node pool configuration: 3 worker nodes with a Dedicated 8 GB plan or higher 

For instructions on provisioning new LKE clusters in the Cloud Manger, review [Create a cluster](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster). To quickly provision a cluster using the Linode CLI, run the following command in your terminal (assuming the [Linode CLI is installed](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli)):

```shell
linode-cli lke cluster-create \
  --label $CLUSTER_NAME \
  --region $REGION \
  --k8s_version 1.32 \
  --control_plane.high_availability true \
  --node_pools.type g6-dedicated-8 \
  --node_pools.count 3
```

# [Configure kubectl](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#configure-kubectl)

The kubectl utility is used to interact with your LKE cluster from the command line. To configure kubectl to work with your cluster, review [Manage a cluster with kubectl](https://techdocs.akamai.com/cloud-computing/docs/manage-a-cluster-with-kubectl). Abbreviated instructions are included below:

1. Download the kubeconfig file through the Cloud Manager or Linode CLI. The Linode CLI command is below. Replace `$CLUSTER_NAME` with the label of your new cluster.
   ```shell
   linode-cli get-kubeconfig --label $CLUSTER_NAME
   ```
2. Update the KUBECONFIG environment variable. Again, replace `$CLUSTER_NAME` with the label of your new cluster.
   ```shell
   export KUBECONFIG=
/$CLUSTER_NAME-kubeconfig.yaml
   ```
3. If you have multiple kubeconfig files, you'll also want to adjust the current kubectl context to use this new cluster. Replace `
` with the ID of your new cluster.
   ```shell
   kubectl config use-context lke\
-ctx
   ```

# [Configure DNS](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#configure-dns)

If you want to learn about how to use Linode DNS Manager read the following tutorial: [Get started with DNS Manager](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-dns-manager).

When you create a domain in Linode, make sure to set the TTL of the SOA Record to 30 seconds:

1. Click on your domain.

2. Click on the tree dots on the right of the SOA Record and click `edit`.

3. Change the default TTL to `30 seconds`.

4. Click `Save`.

# [Creating a personal access token](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#creating-a-personal-access-token)

Create a new Personal Access Token with Read/Write access for Domains:

1. Go to your profile on the top right.

2. Click on `API Tokens`.

3. Click on `Create A Personal Access Token`.

4. Add a `Label`.

5. Select the desired `Expiry`.

6. Select `No Access` for all.

7. Select `Read/Write` for `Domains`.

8. Click `Create Token`.

9. Copy your Personal Access Token.

10. Set environment variable for the token:

```bash
LINODE_TOKEN="
"
```

# [Create the values.yaml file](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#create-the-valuesyaml-file)

```bash
tee values.yaml<<EOF
cluster:
  name: $CLUSTER_NAME
  provider: linode
  domainSuffix: 

otomi:
  hasExternalDNS: true
dns:
  domainFilters:
    - 

  provider:
    linode:
      apiToken: $LINODE_TOKEN
apps:
  cert-manager:
    issuer: letsencrypt
    stage: production
    email: admin@

EOF
```

Adjust the `domainSuffix`, `domainFilters` and `email`!

 > Note: 
  You can also use a different DNS provider. See [DNS setup](https://techdocs.akamai.com/app-platform/docs/dns) for examples on how to use Akamai EdgeDNS, AWS Route53, Cloudflare DNS and many others.

# [Install the Akamai App Platform using Helm](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#install-the-akamai-app-platform-using-helm)

Install using Helm:

```bash
helm repo add apl https://linode.github.io/apl-core
helm repo update
helm install -f values.yaml apl apl/apl
```

Monitor the logs of the installer job:

```bash
kubectl logs jobs/apl -n default -f
```

When the installer is finished, copy the `url` and `admin-password` from the console output.

Follow the [Post installation steps](https://techdocs.akamai.com/app-platform/docs/post-installation-steps) guide.

 > Tip: 
  To learn how to use the Akamai App Platform, review the [Getting started with labs](https://techdocs.akamai.com/app-platform/docs/labs-overview) guide and follow along with these labs.

# [Known issues](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#known-issues)

## [During install Pods get stuck in a Pending state](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#during-install-pods-get-stuck-in-a-pending-state)

During the installation, multiple `StatefullSets` are created that require a `PersistentVolumeClaim` (PVC). Each PVC is attached to a `Volume` in Linode. Volumes count towards the account limits. If you see Pods in a `Pending` state, it might be that your're hitting the account limit.

What to do:

- Delete unused resources in your account (like unused Volumes).

- Create a support ticket and request to increase your account limit.