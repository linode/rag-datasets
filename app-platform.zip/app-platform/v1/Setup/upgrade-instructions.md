# [Upgrade instructions](https://techdocs.akamai.com/app-platform/docs/upgrade-instructions#upgrade-instructions)

The Akamai App Platform is regularly updated to provide new features, improvements, and security enhancements. This page outlines the recommended approach for performing these upgrade.

# [Upgrade through the App Platform Console](https://techdocs.akamai.com/app-platform/docs/upgrade-instructions#upgrade-through-the-app-platform-console)

You can view current version numbers, upgrade details, and initiate an upgrade through the Platform Dashboard page in the App Platform Console.

1. Log in to the App Platform Console as a platform administrator and select the **Platform** view.
2. In the left menu, navigate to **Dashboard**. Within the dashboard you can see your current version in the top right corner. There is also a table listing all available versions, each accompanied by a brief description of the changes introduced in that release. To see the full release notes for a particular version, click on its version tag.
3. Click the **Upgrade to vX.Y.Z** button to initiate the upgrade process. If there is no upgrade available, this button is not displayed. Instead, a message is shown that indicates there are no new updates.

# [Upgrade notes](https://techdocs.akamai.com/app-platform/docs/upgrade-instructions#upgrade-notes)

Some upgrades between versions require additional steps or have certain known issues. This section covers any additional steps or information needed to successfully perform these upgrades.

## [Upgrading to v4.7.0](https://techdocs.akamai.com/app-platform/docs/upgrade-instructions#upgrading-to-v470)

### [Manual updates required for Istio Sidecar](https://techdocs.akamai.com/app-platform/docs/upgrade-instructions#manual-updates-required-for-istio-sidecar)

Due to an issue with automatic Istio Sidecar restarts for certain pod types, manual intervention is required after upgrading Istio to ensure all pods have the latest sidecar version. The following pod types require manual restarts after Istio upgrades:

- **TTY pods** (standalone pods without controllers): Use the following commands to delete all TTY pods. TTY pods are standalone and will not be recreated automatically when deleted. Users can create new TTY sessions through the Console.
  ```
  # Delete all TTY pods (WARNING: This will terminate TTY sessions for any connected users)
  kubectl delete pods -A -l otomi=tty
  ```
  > > Warning: 
  > 
  > Deleting TTY pods will disconnect any active user sessions. These pods are not recreated. Instead, users can create new TTY sessions through the App Platform Console. Coordinate with users before performing this action.
- **Tekton EventListener pods** (managed by Tekton controllers): Use the following command to delete all EventListener pods. The Tekton controller will automatically recreate these pods with the new Istio sidecar.
  ```
  # Delete all EventListener pods (safe - will be recreated automatically)
  kubectl delete pods -A -l app.kubernetes.io/managed-by=EventListener
  ```

After the new pods have been created, you can verify that they have the correct Istio sidecar version by running the following commands:

```
# [Get the current Istio version for comparison](https://techdocs.akamai.com/app-platform/docs/upgrade-instructions#get-the-current-istio-version-for-comparison)
echo "=== Current Istio Version ==="
kubectl get deployment -n istio-system -l app=istiod -o jsonpath='{.items[0].spec.template.spec.containers[0].image}' | cut -d: -f2

echo ""
echo "=== TTY Pods Sidecar Versions ==="
kubectl get pods -A -l otomi=tty -o jsonpath='{range .items[*]}{.metadata.namespace}{"\t"}{.metadata.name}{"\t"}{.spec.containers[?(@.image contains "istio/proxyv2")].image}{"\n"}{end}' | column -t

echo ""
echo "=== EventListener Pods Sidecar Versions ==="
kubectl get pods -A -l app.kubernetes.io/managed-by=EventListener -o jsonpath='{range .items[*]}{.metadata.namespace}{"\t"}{.metadata.name}{"\t"}{.spec.containers[?(@.image contains "istio/proxyv2")].image}{"\n"}{end}' | column -t
```

## [Upgrading from v4.4.4 to v4.7.0 (or higher)](https://techdocs.akamai.com/app-platform/docs/upgrade-instructions#upgrading-from-v444-to-v470-or-higher)

Prior to upgrading from v4.4.4 to v4.7.0 (or higher), ensure that there are no stale pipelines running on your App Platform installation. Part of this upgrade includes a Gitea update and, since stale pipelines interfere with that process, please follow the instructions below to stop stale pipelines. In addition, you might also encounter an issue with the Redis instance of Harbor. For that issue, see [Fixing the Redis instance of Harbor](#fixing-the-redis-instance-of-harbor).

Before upgrading, perform the following steps to ensure there are no stale PipelineRuns in Tekton.

1. Ensure that no other platform users are currently applying changes to the cluster.
2. Log in to the App Platform Console as a platform administrator and select the Platform view.
3. In the left menu, navigate to **Apps** and open the Tekton app.
4. Within the Tekton Dashboard, select **PipelineRuns** on the left menu and **otomi-pipelines** from the dropdown menu on the top right.
5. Verify that no pipelines are in a pending or running state. All pipelines should have a status that indicates it has either succeeded, failed, or was cancelled. If any are in a pending or running state, open the corresponding options menu within the same table row and select **Stop**.

As soon as the upgrade is started, a new _PipelinesRun_ is created in Tekton. This will be automatically terminated and, as of v4.7.0, Tekton is no longer used for applying platform changes.

## [Fixing the Redis instance of Harbor](https://techdocs.akamai.com/app-platform/docs/upgrade-instructions#fixing-the-redis-instance-of-harbor)

After the upgrade, you might notice an issue with the Redis instance of Harbor where the `harbor-redis-0` pod restarts indefinitely. This issue may also present itself outside of an upgrade. To solve this issue, delete the Harbor Redis data as shown in the steps below.

1. Disable ArgoCD autoSync on harbor-harbor.
   ```
   kubectl patch application harbor-harbor \
     -n argocd \
     --type='json' \
     -p='[{"op": "remove", "path": "/spec/syncPolicy/automated"}]'
   ```

2. Scale down harbor-jobservice and harbor-core to zero replicas.
   ```
   kubectl scale deploy harbor-jobservice --replicas=0 -n harbor
   kubectl scale deploy harbor-core --replicas=0 -n harbor
   ```

3. If you are running App Platform v4.7.0 and higher, scale down the apl-operator so that there are zero replicas.
   ```
   kubectl scale deploy apl-operator --replicas=0 -n apl-operator
   ```

4. Scale down harbor-redis so that there are zero replicas.
   ```
   kubectl scale sts harbor-redis --replicas=0 -n harbor
   ```

5. Delete the `data-harbor-redis-0` PersistentVolumeClaim. 
   ```
   kubectl delete pvc data-harbor-redis-0 -n harbor
   ```

6. Scale up harbor-redis to one replica.
   ```
   kubectl scale sts harbor-redis --replicas=1 -n harbor
   ```

7. Wait for the new pod to enter a ready status.

8. If you are running App Platform v4.7.0 and higher, you can now scale back up the apl-operator.
   ```
   kubectl scale deploy apl-operator --replicas=1 -n apl-operator
   ```

9. Re-enable ArgoCD autoSync on harbor-harbor.
   ```
   kubectl patch application harbor-harbor \
     -n argocd \
     --type='json' \
     -p='[{"op": "add", "path": "/spec/syncPolicy/automated", "value": {"prune": true,"selfHeal": true}}]'
   ```