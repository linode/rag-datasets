# [Network policies](https://techdocs.akamai.com/app-platform/docs/team-network-policies#network-policies)

Kubernetes Network Policies (Ingress) and Istio Service Entries (Egress) are managed through the **Inbound Rules** and **Outbound Rules** areas within Akamai App Platform. When Ingress control is enabled for your team, _all_ pod‑to‑pod traffic is denied by default. When Egress control is enabled, _all_ external traffic is denied by default. You must explicitly create rules to open up traffic.

# [Inbound Rules](https://techdocs.akamai.com/app-platform/docs/team-network-policies#inbound-rules)

The **Inbound Rules** page lists all existing ingress polices for your team and is where you to can create, modify, and delete rules. All inbound rules contain the following properties.

| Property | Description                                                                        |
| -------- | ---------------------------------------------------------------------------------- |
| Name     | The name of the inbound rule                                                       |
| Source   | The workload's network traffic that is going to be accepted by the target workload |
| Target   | The workload (and its pod label) receiving traffic                                 |

To create a new inbound rule, follow the instructions below.

1. On the **Inbound Rules** page, click the the **Create Inbound Rule** button.
2. Enter a unique and descriptive **Inbound rule name**.
3. Add at least one source workload:
   1. Click the **Workload** dropdown and select a Knative service, deployment, Helm release or other type of workload.
   2. Select a pod from the **Labels** dropdown. This field automatically generates based on the selected workload.
   3. Click **Add source** to add another source to this rule.
4. Select the target workload from the **Workload** dropdown. Once a workload is selected, you can the choose a pod from the **Labels** dropdown.
5. Click **Save changes** to apply the rule.

# [Outbound rules](https://techdocs.akamai.com/app-platform/docs/team-network-policies#outbound-rules)

The **Outbound Rules** page lists all egress policies for your team. From this page, you can create new rules and modify or delete existing rules. Egress rules have the following properties.

| Property | Description                                                                            |
| -------- | -------------------------------------------------------------------------------------- |
| Name     | The name of the outbound rule                                                          |
| Domain   | The IP address or fully qualified domain name (FQDN) to which you are allowing traffic |
| Port     | The target port number (1–65535)                                                       |
| Protocol | The network protocols that you wish to allow (TCP, HTTP, HTTPS)                        |

To create a new outbound rule, perform the steps below.

1. On the **Outbound Rules** page, click the **Create Outbound Rule** button.
2. Enter a unique and descriptive name for the new rule.
3. Enter the FQDN or IP address to which you are allowing traffic.
4. Enter the protocols and ports for the outbound rule.
   1. Within the **Protocol** dropdown, select from TCP, HTTP, or HTTPS.
   2. In the **Port** text field, enter the port number.
   3. Click **Add port** to open up additional ports and protocols.
5. Click **Save changes** to apply the new rule.