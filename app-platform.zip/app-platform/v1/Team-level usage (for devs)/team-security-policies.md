# [Security policies](https://techdocs.akamai.com/app-platform/docs/team-security-policies#security-policies)

# [Prerequisites](https://techdocs.akamai.com/app-platform/docs/team-security-policies#prerequisites)

The Kyverno app must be activated to use security policies. If it is not activated, contact a platform administrator user so that they can install it.

# [About security policies](https://techdocs.akamai.com/app-platform/docs/team-security-policies#about-security-policies)

When security policies are enabled for the team, then know that:

- Team's can only modify policies if the Platform administrator allowed the team to edit policies (see the team permissions in the team settings)

- Teams can ask the platform administrator to adjust the default list of policies for the team.

- Some of the policies can be adjusted using custom values.

# [View security policies](https://techdocs.akamai.com/app-platform/docs/team-security-policies#view-security-policies)

To view a list of security policies accessible to your team, click on **Security policies** in the main menu of the App Platform Console while in the _Team_ view. The resulting table lists each policy alongside the following details:

| Property | Description                                                                                        |
| -------- | -------------------------------------------------------------------------------------------------- |
| Name     | The name of the security policy                                                                    |
| Severity | The severity of the policy. Can be `low`, `medium` or `high`                                       |
| Action   | The action to take when a policy gets violated. Can be `Audit` (which is the default) or `Enforce` |

# [Adjust security policies](https://techdocs.akamai.com/app-platform/docs/team-security-policies#adjust-security-policies)

1. Select the security policy you like to adjust.

2. Set the **action** to _Enforce_ to block pods from being deployed if the don't comply to the policy.

3. Change the severity from `medium` (default) to `low` or `high`.

# [View policy reports](https://techdocs.akamai.com/app-platform/docs/team-security-policies#view-policy-reports)

1. Go to **Workloads**.

2. Click on the ArgoCD application for the workload you want to see the policy report.

3. In the **Application Details Tree**, you will see a `policyreport` attached to the `ReplicaSet` and an `admissionreport` attached to each pod.