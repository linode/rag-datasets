# [Team Settings](https://techdocs.akamai.com/app-platform/docs/team-settings#team-settings)

 > Note: 
  The team settings can only be changed by a user with the platform administrator role. The team settings are read only for team members. Ask your platform administrator if any changes need to be made to the team settings.

# [Dashboards](https://techdocs.akamai.com/app-platform/docs/team-settings#dashboards)

When Dashboards are enabled, a dedicated Grafana instance is installed in the team namespace and pre-configured with dashboards. To see the Grafana dashboards, go to `Apps` and click on Grafana. The Grafana instance is also used for Loki to show logs. 

## [Alerts](https://techdocs.akamai.com/app-platform/docs/team-settings#alerts)

When alerts are enabled, a dedicated Alertmanager instance is installed in the team namespace. The Alertmanager instance receives alerts relevant for the team from the platform-level Prometheus.

When a notification receiver is configured, Alertmanager will send the team's alerts to the configured receiver (Slack or Microsoft Teams). Ask your platform administrator to enable Alerts and configure a notification receiver.

# [Resource Quotas](https://techdocs.akamai.com/app-platform/docs/team-settings#resource-quotas)

Any configured resource quota for the team are shown here. If the configured resource quota are blocking the team, then ask your platform administrator to change them.

# [Network Policies](https://techdocs.akamai.com/app-platform/docs/team-settings#network-policies)

The network policies section shows if network policies for the team are enabled. There are two types of network policies:

| Option          | Description                                                                            |
| --------------- | -------------------------------------------------------------------------------------- |
| Ingress control | When enabled team services will be bound by (ingress) network policies                 |
| Egress control  | When enabled team service egress traffic will be limited to pre-defined endpoints only |

# [Permissions](https://techdocs.akamai.com/app-platform/docs/team-settings#permissions)

The permissions section shows the permissions of the team. These permissions are applied to all team members:

| Action                            | Description                                                                                             |
| --------------------------------- | ------------------------------------------------------------------------------------------------------- |
| Create Services                   | All team members have the permission to create Services                                                 |
| Edit Security Policies            | All team members have the permission to edit Security Policies                                          |
| Use Cloud Shell                   | All team members have the permission to use the cloud shell                                             |
| Download kubeconfig file          | All team members have the permission to download the KubeConfig to get Kube API access to the namespace |
| Download docker login credentials | All team members have the permission to download the Dockerconfig for the teams project in Harbor       |