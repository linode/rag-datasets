# [Apps](https://techdocs.akamai.com/app-platform/docs/apps#apps)

The Akamai App Platform includes a wide range of apps, a curated collection of Kubernetes projects commonly used to manage, administer, and observe Kubernetes clusters and the business applications that run on them. These apps are pre-configured and integrated with the App Platform. They can be shared by the entire platform (like Harbor and Gitea) or dedicated to a team (like Prometheus, Grafana, Alertmanager, and Tekton Dashboard).

# [View apps](https://techdocs.akamai.com/app-platform/docs/apps#view-apps)

To view the apps that are available to your selected team, click on **Apps** in the main menu of the App Platform Console while in the _Teams_ view.

# [Open an app](https://techdocs.akamai.com/app-platform/docs/apps#open-an-app)

To open an app, click on its name (or the corresponding arrow) within the list of apps. This navigates you away from the App Platform Console and typically opens the main dashboard for that installed application.

# [Adjust app settings](https://techdocs.akamai.com/app-platform/docs/apps#adjust-app-settings)

Settings for a particular app can only be adjusted by platform administrators. If your user fits that criteria, you can open settings by clicking on the gear icon corresponding to the app you wish to modify. This icon is visible when hover overing an app on the **Apps** page.

# [Install additional apps](https://techdocs.akamai.com/app-platform/docs/apps#install-additional-apps)

Additional apps can only be installed by platform administrators. See [Platform - Apps](https://techdocs.akamai.com/app-platform/docs/platform-apps) for instructions.