# [Services](https://techdocs.akamai.com/app-platform/docs/team-services#services)

The _Services_ self-service feature can be used to publicly expose ClusterIP services created by Workloads.

# [View services](https://techdocs.akamai.com/app-platform/docs/team-services#view-services)

To view a list of services belonging to your team, click on **Services** in the main menu of the App Platform Console while in the _Team_ view. The resulting table lists each service alongside the following details:

| Column        | Description                                                                           |
| ------------- | ------------------------------------------------------------------------------------- |
| Name          | The name of the exposed ClusterIP service                                             |
| Ingress class | The ingress class configured. This is the ingress controller that exposes the service |
| URL           | The URL of the exposed service                                                        |
| Status        | The status of the service                                                             |

# [Create a Service](https://techdocs.akamai.com/app-platform/docs/team-services#create-a-service)

1. Click the **Create Service** button.

2. Select a ClusterIP service from the drop-down list. Only ClusterIP services available in the team are listed here.

3. (Optional) If the ClusterIP is exposing multiple ports, select the port to use.

4. (Optional) Expand the [Advanced Settings](#advanced-settings) and adjust as desired.

5. Click the **Create Service** button to create the service.

# [Advanced settings](https://techdocs.akamai.com/app-platform/docs/team-services#advanced-settings)

## [URL paths](https://techdocs.akamai.com/app-platform/docs/team-services#url-paths)

Add one or more URL paths you want to allow access to. When at least one URL path is added, all other paths that are not explicitly added here will result in a page not found (HTTP 404) error.

## [Canonical Name (CNAME)](https://techdocs.akamai.com/app-platform/docs/team-services#canonical-name-cname)

Use a Canonical Name (CNAME) that points to the Service domain name. This feature can also be used together with the TLS Passthrough option. Check the [Configure a CNAME lab](https://techdocs.akamai.com/app-platform/docs/configure-cname) to learn how to configure a CNAME.

## [Enable Traffic Management](https://techdocs.akamai.com/app-platform/docs/team-services#enable-traffic-management)

The traffic management option allows to split traffic between multiple deployed versions of the same app (blue-green, canary). Note that the traffic control can only be used when there are 2 versions deployed of an app deployed and exposed using the same ClusterIP service.

To enable traffic management, follow these steps:

1. Select **Enable Traffic Management**

2. Fill in the weight for the versions A and B. A 50/50 weight can be used for blue/green. A 90/10 weight can be used for canary.

## [HTTP Response Headers](https://techdocs.akamai.com/app-platform/docs/team-services#http-response-headers)

Add HTTP Response headers that will be set on the exposed service.