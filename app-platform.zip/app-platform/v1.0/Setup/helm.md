# [Helm](https://techdocs.akamai.com/app-platform/docs/helm#helm)

Install the Akamai App Platform with Helm.

# [Install client binaries](https://techdocs.akamai.com/app-platform/docs/helm#install-client-binaries)

When installing using the Helm chart, make sure the following client binaries exist:

- [Kubectl](https://kubernetes.io/docs/tasks/tools/#kubectl) to access the cluster
- [Helm](https://helm.sh/docs/intro/install/) for Helm chart installation

# [Add the repository](https://techdocs.akamai.com/app-platform/docs/helm#add-the-repository)

```bash
helm repo add apl https://linode.github.io/apl-core
helm repo update
```

See [helm repo](https://helm.sh/docs/helm/helm_repo/) for command documentation.

When the chart is installed, follow the [post installation steps](https://techdocs.akamai.com/app-platform/docs/post-installation-steps).

# [Custom values](https://techdocs.akamai.com/app-platform/docs/helm#custom-values)

To view the required `values.yaml` file with detailed comments, view and download the chart's latest [values.yaml](https://github.com/linode/apl-core/blob/main/chart/apl/values.yaml). Run the following command to view _all_ the values (which might be overwhelming):

```bash
helm show values apl/apl
```

To test wether the input values are correct run the following command:

```bash
helm template -f values.yaml apl/apl
```

# [Customize the values](https://techdocs.akamai.com/app-platform/docs/helm#customize-the-values)

Adjust the `values.yaml` by changing the `provider` and adding `dns` configuration.

# [Install the Helm chart](https://techdocs.akamai.com/app-platform/docs/helm#install-the-helm-chart)

Install the Helm chart:

```bash
helm install -f values.yaml apl apl/apl
```

# [Monitoring the installation](https://techdocs.akamai.com/app-platform/docs/helm#monitoring-the-installation)

The chart deploys a Job (`-apl`) in the `default` namespace. Monitor the chart install using `kubectl`:

```bash
# [get the status of the job](https://techdocs.akamai.com/app-platform/docs/helm#get-the-status-of-the-job)
kubectl get job apl -w
# [watch the helm chart install status:](https://techdocs.akamai.com/app-platform/docs/helm#watch-the-helm-chart-install-status)
watch helm list -Aa
```

Or view detailed info about Kubernetes resources with [k9s](https://k9scli.io)

When the chart is installed, follow the [post installation steps](https://techdocs.akamai.com/app-platform/docs/post-installation-steps).

# [Installing from source](https://techdocs.akamai.com/app-platform/docs/helm#installing-from-source)

As an alternative, you can also clone the `apl-core` source code from the [Github](https://github.com/linode/apl-core) and install using the chart source code.

## [Download source](https://techdocs.akamai.com/app-platform/docs/helm#download-source)

```bash
git clone https://github.com/linode/apl-core.git
cd apl-core
```

## [Install](https://techdocs.akamai.com/app-platform/docs/helm#install)

Now customize the `values.yaml` file. Make sure to set the version to the branch you like to use:

```
otomi:
  version: main
```

Use the following command to install the chart with the name `my-apl-release` (a custom name that you choose).

```bash
helm install -f values.yaml my-apl-release chart/apl
```