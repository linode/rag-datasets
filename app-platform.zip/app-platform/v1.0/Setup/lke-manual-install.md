# [Manual installation on LKE](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#manual-installation-on-lke)

Provision an LKE cluster in Cloud Manager or by using the Linode CLI. Then manually install App Platform to your new cluster by using a Linode Domain for DNS.

# [Prerequisites](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#prerequisites)

- Create an account for Akamai Cloud [here](https://cloud.linode.com/)

# [Provision an LKE cluster](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#provision-an-lke-cluster)

## [Using Cloud Manager](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#using-cloud-manager)

Provision an LKE cluster with the following specs:

- Fill in the `Cluster Label`

- Use Kubernetes version: `1.31` or `1.32`

- Enable HA Control Plane

- Add Node Pools. Select the Dedicated 8 GB Plan (with 8 GB RAM and 4 CPUs)

- Wait until the nodes are in a `Running` state

- Download the `kubeconfig`

```bash
# [Update the KUBECONFIG env to gain access to the cluster](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#update-the-kubeconfig-env-to-gain-access-to-the-cluster)
export KUBECONFIG=
/$CLUSTER_NAME-kubeconfig.yaml
```

## [Using Linode CLI](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#using-linode-cli)

[Install and configure](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli) the CLI.

Provision an LKE cluster using the Linode CLI:

```bash
linode-cli lke cluster-create \
  --label $CLUSTER_NAME \
  --region $REGION \
  --k8s_version 1.32 \
  --control_plane.high_availability true \
  --node_pools.type g6-dedicated-8 \
  --node_pools.count 3
```

And get the Kubecfg:

```bash
linode-cli get-kubeconfig --label $CLUSTER_NAME
kubectl config use-context lke
-ctx
```

# [Create a Domain](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#create-a-domain)

If you want to learn about how to use Linode DNS Manager read the following tutorial: [Get started with DNS Manager](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-dns-manager).

When you create a domain in Linode, make sure to set the TTL of the SOA Record to 30 seconds:

1. Click on your domain.

2. Click on the tree dots on the right of the SOA Record and click `edit`.

3. Change the default TTL to `30 seconds`.

4. Click `Save`.

# [Creating a Personal Access Token](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#creating-a-personal-access-token)

Create a new Personal Access Token with Read/Write access for Domains:

1. Go to your profile on the top right.

2. Click on `API Tokens`.

3. Click on `Create A Personal Access Token`.

4. Add a `Label`.

5. Select the desired `Expiry`.

6. Select `No Access` for all.

7. Select `Read/Write` for `Domains`.

8. Click `Create Token`.

9. Copy your Personal Access Token.

10. Set environment variable for the token:

```bash
LINODE_TOKEN="
"
```

# [Create the values.yaml file](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#create-the-valuesyaml-file)

```bash
tee values.yaml<<EOF
cluster:
  name: $CLUSTER_NAME
  provider: linode
  domainSuffix: 

otomi:
  hasExternalDNS: true
dns:
  domainFilters:
    - 

  provider:
    linode:
      apiToken: $LINODE_TOKEN
apps:
  cert-manager:
    issuer: letsencrypt
    stage: production
    email: admin@

EOF
```

Adjust the `domainSuffix`, `domainFilters` and `email`!

 > Note: 
  You can also use a different DNS provider. See [here](https://techdocs.akamai.com/app-platform/docs/dns) for examples on how to use Akamai EdgeDNS, AWS Route53, Cloudflare DNS and many others.

# [Install the Akamai App Platform](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#install-the-akamai-app-platform)

Install using Helm:

```bash
helm repo add apl https://linode.github.io/apl-core
helm repo update
helm install -f values.yaml apl apl/apl
```

Monitor the logs of the installer job:

```bash
kubectl logs jobs/apl -n default -f
```

When the installer is finished, copy the `url` and `admin-password` from the console output.

Follow the post installation steps [here](https://techdocs.akamai.com/app-platform/docs/post-installation-steps).

 > Tip: 
  To learn how to use the Akamai App Platform, go through the [Get Started labs](https://techdocs.akamai.com/app-platform/docs/overview).

# [Known issues](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#known-issues)

## [During install Pods get stuck in a Pending state](https://techdocs.akamai.com/app-platform/docs/lke-manual-install#during-install-pods-get-stuck-in-a-pending-state)

During the installation, multiple `StatefullSets` are created that require a `PersistentVolumeClaim` (PVC). Each PVC is attached to a `Volume` in Linode. Volumes count towards the account limits. If you see Pods in a `Pending` state, it might be that your're hitting the account limit.

What to do:

- Delete unused resources in your account (like unused Volumes).

- Create a support ticket and request to increase your account limit.