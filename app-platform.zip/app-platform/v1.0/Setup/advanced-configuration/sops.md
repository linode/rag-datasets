# [Use SOPS for value encryption](https://techdocs.akamai.com/app-platform/docs/sops#use-sops-for-value-encryption)

If you would like sensitive information in the `values` repository to be encrypted, you will have to use [sops](https://github.com/mozilla/sops).

# [Use SOPS with AGE](https://techdocs.akamai.com/app-platform/docs/sops#use-sops-with-age)

[AGE](https://github.com/FiloSottile/age) is a simple, modern, and secure encryption tool (and Go library) with small explicit keys, no config options, and UNIX-style composability.

To install with SOPS/Age, use the following values:

```yaml
kms:
  sops:
    provider: "age"
# [age:](https://techdocs.akamai.com/app-platform/docs/sops#age)
# [publicKey: ''](https://techdocs.akamai.com/app-platform/docs/sops#publickey)
# [privateKey: ''](https://techdocs.akamai.com/app-platform/docs/sops#privatekey)
```

# [Use SOPS with an external Key Management Service (KMS)](https://techdocs.akamai.com/app-platform/docs/sops#use-sops-with-an-external-key-management-service-kms)

Find quick start documentation below on how to setup KMS access per supported provider:

- [AWS KMS](https://aws.amazon.com/kms/getting-started/)
- [Azure Vault](https://azure.microsoft.com/en-us/services/key-vault/#getting-started)
- [Google KMS](https://cloud.google.com/kms/docs/quickstart)

Follow the instructions of the provider of your choosing and jot down the credentials obtained for the next steps.

To install with SOPS/KMS, use the following values:

```yaml
kms:
  sops:
    provider: "" # provider can be one of aws|azure|google|vault
# [aws:](https://techdocs.akamai.com/app-platform/docs/sops#aws)
# [keys: ''](https://techdocs.akamai.com/app-platform/docs/sops#keys)
# [accessKey: ''](https://techdocs.akamai.com/app-platform/docs/sops#accesskey)
# [secretKey: ''](https://techdocs.akamai.com/app-platform/docs/sops#secretkey)
# [region: ''](https://techdocs.akamai.com/app-platform/docs/sops#region)
# [azure:](https://techdocs.akamai.com/app-platform/docs/sops#azure)
# [keys: ''](https://techdocs.akamai.com/app-platform/docs/sops#keys)
# [tenantID: ''](https://techdocs.akamai.com/app-platform/docs/sops#tenantid)
# [clientID: ''](https://techdocs.akamai.com/app-platform/docs/sops#clientid)
# [clientSecret: ''](https://techdocs.akamai.com/app-platform/docs/sops#clientsecret)
# [google:](https://techdocs.akamai.com/app-platform/docs/sops#google)
# [keys: ''](https://techdocs.akamai.com/app-platform/docs/sops#keys)
# [accountJson: ''](https://techdocs.akamai.com/app-platform/docs/sops#accountjson)
# [project: ''](https://techdocs.akamai.com/app-platform/docs/sops#project)
# [vault:](https://techdocs.akamai.com/app-platform/docs/sops#vault)
# [token: ''](https://techdocs.akamai.com/app-platform/docs/sops#token)
```