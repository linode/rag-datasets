# [Advanced setup configurations](https://techdocs.akamai.com/app-platform/docs/advanced-configuration#advanced-setup-configurations)

**Advanced configurations**

### [Use DNS](https://techdocs.akamai.com/app-platform/docs/dns)

Install with DNS.

### [Use Azure AD as IDP](https://techdocs.akamai.com/app-platform/docs/oidc)

Install with Azure Entra ID for OIDC.

### [Use SOPS for encryption](https://techdocs.akamai.com/app-platform/docs/sops)

Install with SOPS.

### [Use an entrypoint](https://techdocs.akamai.com/app-platform/docs/entrypoint)

Install with an entrypoint for an external gateway.

### [Bring Your Own Wild Card Certificate](https://techdocs.akamai.com/app-platform/docs/byo-wildcard-cert)

Install using a BYO (wild card) certificate.