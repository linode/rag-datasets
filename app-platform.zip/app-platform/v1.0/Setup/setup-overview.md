# [Setup overview](https://techdocs.akamai.com/app-platform/docs/setup-overview#setup-overview)

**How to get the Akamai App Platform up and running**

***

### [Automatic deployment on LKE](https://techdocs.akamai.com/app-platform/docs/akamai-connected-cloud)

Deploy the Akamai App Platform automatically through LKE (Akamai Cloud's managed Kubernetes service).

***

**Manual installation**

### [Manual installation on LKE](https://techdocs.akamai.com/app-platform/docs/linode)

Create an LKE cluster and manually install the Akamai App Platform. This is not recommended unless you have specific needs that are not addressed in the automatic deployment method.

### [Custom installation on other Kubernetes services](https://techdocs.akamai.com/app-platform/docs/custom)

Install the Akamai App Platform on any other conformant Kubernetes cluster.

***

**Other installation resources**

### [Helm](https://techdocs.akamai.com/app-platform/docs/helm)

Instructions for using the Helm chart.

***

**Advanced configurations**

### [Use DNS](https://techdocs.akamai.com/app-platform/docs/dns)

Install with DNS.

### [Use Azure AD as IDP](https://techdocs.akamai.com/app-platform/docs/oidc)

Install with Azure Entra ID for OIDC.

### [Use SOPS for encryption](https://techdocs.akamai.com/app-platform/docs/sops)

Install with SOPS.

### [Use an entrypoint](https://techdocs.akamai.com/app-platform/docs/entrypoint)

Install with an entrypoint for an external gateway.

### [Bring Your Own Wild Card Certificate](https://techdocs.akamai.com/app-platform/docs/byo-wildcard-cert)

Install using a BYO (wild card) certificate.