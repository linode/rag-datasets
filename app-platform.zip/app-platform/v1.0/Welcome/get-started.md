# [Get started](https://techdocs.akamai.com/app-platform/docs/get-started#get-started)

**How to get started with Akamai App Platform**

---

### [Step 1: [Install App Platform](https://techdocs.akamai.com/app-platform/docs/overview)](https://techdocs.akamai.com/app-platform/docs/get-started#step-1-install-app-platformhttpstechdocsakamaicomapp-platformdocsoverview)

Install App Platform on Linode Kubernetes Engine (LKE) or any other conformant Kubernetes cluster.

### [Step 2: [Follow the post installation steps ](https://techdocs.akamai.com/app-platform/docs/post-installation-steps)](https://techdocs.akamai.com/app-platform/docs/get-started#step-2-follow-the-post-installation-steps-httpstechdocsakamaicomapp-platformdocspost-installation-steps)

Configure App Platform for usage.

### [Step 3: [Explore App Platform through hands-on labs](https://techdocs.akamai.com/app-platform/docs/overview)](https://techdocs.akamai.com/app-platform/docs/get-started#step-3-explore-app-platform-through-hands-on-labshttpstechdocsakamaicomapp-platformdocsoverview)

Explore App Platform with a comprehensive set of hands-on labs.