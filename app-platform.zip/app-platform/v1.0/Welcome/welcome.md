# [Welcome to the Akamai App Platform](https://techdocs.akamai.com/app-platform/docs/welcome#welcome-to-the-akamai-app-platform)

The Akamai App Platform is a Kubernetes platform that combines developer-centric and operations-centric tooling along with automation and a self-service portal. This streamlines the application life cycle when using Kubernetes, from development to delivery to the management of containerized application workloads.

The platform connects many of the technologies found in the Cloud Native Computing Foundation (CNCF) landscape in a way that provides direct value. This avoids the need to reinvent the wheel when building and maintaining your own Kubernetes based platform or bespoke stack.

The Akamai App Platform is optimized to run on Linode Kubernetes Engine (LKE), but it can also be manually installed on any other [conformant Kubernetes cluster](https://www.cncf.io/training/certification/software-conformance/).

The platform includes:

- An **integrated and pre-configured Stack of open source Kubernetes projects** to support all the essential capabilities for running cloud native applications in production on Kubernetes.

- An easy **self-service portal** for Developers to build images, create workloads, create secrets and publicly expose services

- A **Catalog** with pre-build golden path templates that can be customized.

- Kubernetes **Operators and GitOps** to manage the state of the platform based on configuration-as-code.

# [Key benefits](https://techdocs.akamai.com/app-platform/docs/welcome#key-benefits)

- Speed up time to market by automating and simplifying building and running applications on Kubernetes, reducing the complexity for Development teams.

- Reduce toil and avoid technical debt by providing a pre-configured and integrated suite of tools for CI/CD, Observability and Security out-of-the-box, accelerating the application delivery and enhancing security.

- Support multi-tenancy by allowing multiple teams or projects to share the same cluster, with self-service features that enable faster, independent deployments by developers.

- Self-Serving Developers to allow Developers to Build, Deploy, Expose, Observe and Secure containerized applications on Kubernetes using a web based self-service portal

# [Enable developers](https://techdocs.akamai.com/app-platform/docs/welcome#enable-developers)

- Build OCI compliant images from source code.

- Deploy containerized workloads the GitOps way using the provided quickstarts or BYO golden path templates.

- Automatically update container images of workloads.

- Publicly expose applications.

- Get instant access to logs, metrics and traces.

- Store images in a private registry.

- Configure network policies, response headers and CNAMEs.

- Check applications against a comprehensive set of built-in security policies.

- Create and manage secrets.

- Create private Git repositories and use the built-in CI/CD pipelines

# [Enable administrators](https://techdocs.akamai.com/app-platform/docs/welcome#enable-administrators)

- Get all the required capabilities in an integrated and automated way.

- Onboard development Teams in a comprehensive multi-tenant setup and make them self-serving.

- Manage users.

- Ensure governance with security policies.

- Implement zero-trust networking.

- Change the desired state of the platform based on Configuration-as-Code.

- Support multi- and hybrid cloud scenarios.

- Prevent cloud provider lock-in.

- Implement full observability.

- Comply with Disaster Recovery requirements

# [Integrated and pre-configured Kubernetes projects](https://techdocs.akamai.com/app-platform/docs/welcome#integrated-and-pre-configured-kubernetes-projects)

Get a complete suite of integrated and pre-configured Kubernetes projects to support all the required platform capabilities. Compose your ideal platform by enabling the Kubernetes applications to support all the required capabilities.
