# [How to](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#how-to)

### [[Managing the Catalog](https://techdocs.akamai.com/app-platform/docs/catalog).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#managing-the-cataloghttpstechdocsakamaicomapp-platformdocscatalog)

### [[Managing Ingress Controllers](https://techdocs.akamai.com/app-platform/docs/ingress-classes).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#managing-ingress-controllershttpstechdocsakamaicomapp-platformdocsingress-classes)

### [[Use the team-admin](https://techdocs.akamai.com/app-platform/docs/use-team-admin).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#use-the-team-adminhttpstechdocsakamaicomapp-platformdocsuse-team-admin)

### [[Using Core only](https://techdocs.akamai.com/app-platform/docs/core-only).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#using-core-onlyhttpstechdocsakamaicomapp-platformdocscore-only)

### [[Create and restore backups](https://techdocs.akamai.com/app-platform/docs/backups).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#create-and-restore-backupshttpstechdocsakamaicomapp-platformdocsbackups)

### [[Clone the Platform configuration](https://techdocs.akamai.com/app-platform/docs/clone-apl).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#clone-the-platform-configurationhttpstechdocsakamaicomapp-platformdocsclone-apl)

### [[Manage Age for Development, Security, and Recovery](https://techdocs.akamai.com/app-platform/docs/manage-age).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#manage-age-for-development-security-and-recoveryhttpstechdocsakamaicomapp-platformdocsmanage-age)

### [[Change the otomi-admin password](https://techdocs.akamai.com/app-platform/docs/change-admin-password).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#change-the-otomi-admin-passwordhttpstechdocsakamaicomapp-platformdocschange-admin-password)

### [[Change or reset user passwords](https://techdocs.akamai.com/app-platform/docs/change-user-passwords).](https://techdocs.akamai.com/app-platform/docs/how-to-for-ops#change-or-reset-user-passwordshttpstechdocsakamaicomapp-platformdocschange-user-passwords)