# [Managing the Catalog](https://techdocs.akamai.com/app-platform/docs/catalog#managing-the-catalog)

A Catalog is made available to Teams on the platform to offer them golden path templates (Helm charts). This is how it works:

- Add a Helm chart to the `otomi/charts` repo in the local Gitea.

- Configure which Teams can use the chart.

- Teams can create Workloads from the Catalog.

The Catalog (the `otomi/charts` repo) will contain a set of quick start Helm charts. The Helm charts are not mandatory to use and can be removed or modified to your own liking. They are only provided to make it easier to get started.

# [Quick start Helm charts](https://techdocs.akamai.com/app-platform/docs/catalog#quick-start-helm-charts)

The Catalog contains a set of Helm charts that can be used as quick starts. The following quick starts are available:

## [quickstart-k8s-deployment](https://techdocs.akamai.com/app-platform/docs/catalog#quickstart-k8s-deployment)

The `k8s-deployment` Helm chart can be used to create a Kubernetes `Deployment` (to deploy a single image), a `Service` and a `ServiceAccount`. Optionally a `HorizontalPodAutoscaler`, a Prometheus `ServiceMonitor` and a `Configmap` can be created.

## [quickstart-k8s-deployment-otel](https://techdocs.akamai.com/app-platform/docs/catalog#quickstart-k8s-deployment-otel)

The `k8s-deployment-otel` Helm chart can be used to create a Kubernetes `Deployment` (to deploy a single image), a `Service`, a `ServiceAccount`, an `OpenTelemetryCollector` and an `Instrumentation`. Optionally a `HorizontalPodAutoscaler`, a Prometheus `ServiceMonitor` and a `Configmap` can be created.

## [quickstart-k8s-deployments-canary](https://techdocs.akamai.com/app-platform/docs/catalog#quickstart-k8s-deployments-canary)

The `k8s-deployments-canary` Helm chart can be used to create 2 Kubernetes `Deployments` (to deploy 2 versions of an image), a `Service` and a `ServiceAccount`. Optionally a `HorizontalPodAutoscaler`, a Prometheus `ServiceMonitor` and a `Configmap` (for each version) can be created.

## [quickstart-knative-service](https://techdocs.akamai.com/app-platform/docs/catalog#quickstart-knative-service)

The `knative-service` Helm chart can be used to create a Knative `Service` (to deploy a single image), a `Service` and a  `ServiceAccount`. Optionally a Prometheus `ServiceMonitor` can be created.

## [quickstart-postgresql](https://techdocs.akamai.com/app-platform/docs/catalog#quickstart-postgresql)

The `postgresql-cluster` Helm chart can be used to create a cloudnativepg PostgreSQL `Cluster`. Optionally a Prometheus `PodMonitor` and a `Configmap` (for adding a postgresql dashboard to Grafana) can be created.

## [quickstart-redis](https://techdocs.akamai.com/app-platform/docs/catalog#quickstart-redis)

The `redis-cluster` Helm chart can be used to create a Redis master-replica cluster.

# [Customize the catalog](https://techdocs.akamai.com/app-platform/docs/catalog#customize-the-catalog)

The charts are not mandetory to use and can be removed or modified to your own liking. They are only provided to make it easier to get started. To manage the catalog, just pull the `otomi/charts` repo, add the Helm charts you would like to make available and push changes. A newly added chart will immediately become available in the catalog for Teams to use.

# [Configure chart access](https://techdocs.akamai.com/app-platform/docs/catalog#configure-chart-access)

For charts to become available for Teams to use, Teams need to be given access to use a chart. The catalog supports the following access options:

## [Everybody](https://techdocs.akamai.com/app-platform/docs/catalog#everybody)

If a chart can be used by all teams, including the `team-admin` Team, add the following to the `rbac.yaml` in the root of the `otomi/charts` repository:

```yaml
rbac:
  chart-name: null
```

## [Specific teams](https://techdocs.akamai.com/app-platform/docs/catalog#specific-teams)

If a chart is only allowed to be used by one or more specific teams, add the following to the `rbac.yaml`:

```yaml
rbac:
  chart-name:
    - team-demo
    - team-hello
```

To allow a chart to be used by the `team-admin` only, add the following to the `rbac.yaml`:

```yaml
rbac:
  chart-name:
    - team-admin
```