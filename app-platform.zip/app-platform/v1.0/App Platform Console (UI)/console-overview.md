# [Console overview](https://techdocs.akamai.com/app-platform/docs/console-overview#console-overview)

The App Platform Console is the web-based user interface for the Akamai App Platform. Once logged in to the Console, you can access all integrated apps and self-service tasks. There are two main views for the Console: the **Platform** view and the **Team** view.

# [Console views](https://techdocs.akamai.com/app-platform/docs/console-overview#console-views)

- [Platform view](https://techdocs.akamai.com/app-platform/docs/platform-overview): For platform administrators. Access to administration including managing teams, users, and platform-level apps.
- [Team view](https://techdocs.akamai.com/app-platform/docs/console-team-overview): For developers: Access to team-level workflows and administration tasks, including deploying apps, using pre-made Helm charts, registering code repositories, and much more. Users that are platform administrators will see slightly different options in this view than other users.

# [Switch between views](https://techdocs.akamai.com/app-platform/docs/console-overview#switch-between-views)

When logged in as a platform administrator (a user with the _platform-admin_ role), you can switch between these views through the top navigation bar. Users without this role do not have access to the **Platform** view.