# [Team Admin Workloads](https://techdocs.akamai.com/app-platform/docs/team-admin-workloads#team-admin-workloads)

The Workload self-service feature for the Team Admin is the same as for regular Teams, but with the following differences:

- The Workload can be used to deploy Helm charts from the Catalog in any namespace (also in all Team namespaces).

- If the namespace does not exist, the namespace can be automatically created.

- Istio sidecars can optionally be enabled for all Pods in the Workload.

See [here](https://techdocs.akamai.com/app-platform/docs/workloads) for more information about Workloads.