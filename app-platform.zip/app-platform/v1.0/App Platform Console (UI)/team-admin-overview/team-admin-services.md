# [Team Admin Services](https://techdocs.akamai.com/app-platform/docs/team-admin-services#team-admin-services)

The Services self-service feature for the Team Admin is the same as for regular Teams, but with the following difference:

- The Service created can be used to expose any K8s `ClusterIP` service in any namespace.

See [here](https://techdocs.akamai.com/app-platform/docs/services) for more information about Services.