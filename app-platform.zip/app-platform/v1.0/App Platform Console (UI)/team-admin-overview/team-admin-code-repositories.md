# [Team Admin Code Repositories](https://techdocs.akamai.com/app-platform/docs/team-admin-code-repositories#team-admin-code-repositories)

The Code Repositories self-service feature for the Team Admin is the same as for regular teams. See [here](https://techdocs.akamai.com/app-platform/docs/code-repositories) for more information about Code Repositories.