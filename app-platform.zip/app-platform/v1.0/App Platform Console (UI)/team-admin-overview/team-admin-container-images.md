# [Team Admin Container Images](https://techdocs.akamai.com/app-platform/docs/team-admin-container-images#team-admin-container-images)

The Container Images self-service feature for the Team Admin is the same as for regular teams. See [here](https://techdocs.akamai.com/app-platform/docs/container-images) for more information about Container Images.