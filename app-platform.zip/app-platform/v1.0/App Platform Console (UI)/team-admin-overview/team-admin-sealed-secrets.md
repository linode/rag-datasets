# [Team Admin Sealed Secrets](https://techdocs.akamai.com/app-platform/docs/team-admin-sealed-secrets#team-admin-sealed-secrets)

The Sealed Secrets self-service feature for the Team Admin is the same as for regular teams. Sealed Secrets can only be created in the `team-admin` namespace. See [here](https://techdocs.akamai.com/app-platform/docs/secrets) for more information about Sealed Secrets.