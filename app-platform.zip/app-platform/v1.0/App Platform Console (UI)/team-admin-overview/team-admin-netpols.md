# [Team Admin Network Policies](https://techdocs.akamai.com/app-platform/docs/team-admin-netpols#team-admin-network-policies)

The Network Policies self-service feature for the Team Admin is the same as for regular teams. See [here](https://techdocs.akamai.com/app-platform/docs/netpols) for more information about Network Policies.