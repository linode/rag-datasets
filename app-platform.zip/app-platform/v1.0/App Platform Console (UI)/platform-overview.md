# [Platform view](https://techdocs.akamai.com/app-platform/docs/platform-overview#platform-view)

The Platform is only visible for platform administrators and provides access to:

- [Dashboard](https://techdocs.akamai.com/app-platform/docs/dashboard): A global overview of cluster resource utilization and cluster resource request commitments.
- [Apps](https://techdocs.akamai.com/app-platform/docs/apps): All active and inactive apps. Activate apps clicking on the power-on button.
- [Teams](https://techdocs.akamai.com/app-platform/docs/teams): A list of all Teams.
- [User Management](https://techdocs.akamai.com/app-platform/docs/user-management): Manage Users.
- [Backups](https://techdocs.akamai.com/app-platform/docs/backups): A list of all Backups.
- [Maintenance](https://techdocs.akamai.com/app-platform/docs/maintenance): Maintenance actions.
- [Settings](https://techdocs.akamai.com/app-platform/docs/alerts): Specific configuration of the platform.