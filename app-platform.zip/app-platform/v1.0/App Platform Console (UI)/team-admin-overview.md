# [Team Admin Overview](https://techdocs.akamai.com/app-platform/docs/team-admin-overview#team-admin-overview)

Self-service section:

- [Catalog](https://techdocs.akamai.com/app-platform/docs/team-admin-catalog): The Helm charts available for platform administrators to install in any namespace
- [Code Repositories](https://techdocs.akamai.com/app-platform/docs/team-admin-code-repositories): A self-service form for platform administrators to register code repositories.
- [Container Images](https://techdocs.akamai.com/app-platform/docs/team-admin-container-images): A self-service form for platform administrators to create container images from registered code repositories.
- [Sealed Secrets](https://techdocs.akamai.com/app-platform/docs/team-admin-sealed-secrets): A self-service form for platform administrators to create Sealed Secrets.
- [Workloads](https://techdocs.akamai.com/app-platform/docs/team-admin-workloads): A self-service form to create for platform administrators Workloads in any namespace.
- [Network Policies](https://techdocs.akamai.com/app-platform/docs/team-admin-netpols): A self-service form for platform administrators to create Network Policies (in the `team-admin` namespace only).
- [Services](https://techdocs.akamai.com/app-platform/docs/team-admin-services): A self-service form for platform administrators to create Services to expose endpoints (`ClusterIP` services) from any namespace.
- [Security Policies](https://techdocs.akamai.com/app-platform/docs/team-admin-security-policies): A list of all Security Policies applicable to the `team-admin` namespace only.

Access Section:

- [Shell](https://techdocs.akamai.com/app-platform/docs/shell): Access to the cloud Shell within the context of the complete cluster (all namespaces).
- The `Download KUBECFG` is disabled for platform administrators.
- When Harbor is enabled, a link to download the Dockercfg file.
- When automatic generated CA or Let's Encrypt staging certificates are used, a "Download CA" link is provided.