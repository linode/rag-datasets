# [Team Apps](https://techdocs.akamai.com/app-platform/docs/team-apps#team-apps)

The Apps that are available for teams to use. There are 2 types of Apps:

- Dedicated for the Team (like Prometheus, Grafana, Alertmanager and Tekton Dashboard)

- Shared by the Platform (like Harbor and Gitea)

Click on the Icon of the app to go directly to the UI of the application, or click on the configuration icon to go to the app details.

# [Info](https://techdocs.akamai.com/app-platform/docs/team-apps#info)

Here you will find more information about the app.