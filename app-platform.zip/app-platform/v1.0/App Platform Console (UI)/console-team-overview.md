# [Team view](https://techdocs.akamai.com/app-platform/docs/console-team-overview#team-view)

The Team view in the Console gives access to both the self-service section and the access section:

Self-service section:

- [Dashboard](https://techdocs.akamai.com/app-platform/docs/dashboard): An overview of Team Pod status, resource utilization and vulnerabilities.
- [Apps](https://techdocs.akamai.com/app-platform/docs/apps): All the apps available to the Team.
- [Catalog](https://techdocs.akamai.com/app-platform/docs/catalog): The Helm charts available for the Team in the Catalog.
- [Code Repositories](https://techdocs.akamai.com/app-platform/docs/code-repositories): A self-service form to register code repositories to App Platform and use them to create Container Images.
- [Container Images](https://techdocs.akamai.com/app-platform/docs/container-images): A self-service form to create container images from registered Code Repositories.
- [Sealed Secrets](https://techdocs.akamai.com/app-platform/docs/secrets): A self-service form to create Sealed Secrets.
- [Workloads](https://techdocs.akamai.com/app-platform/docs/workloads): A self-service form to create Workloads.
- [Network Policies](https://techdocs.akamai.com/app-platform/docs/netpols): A self-service form to create Network Policies.
- [Services](https://techdocs.akamai.com/app-platform/docs/services): A self-service form to create Services to publicly expose deployed Workloads.
- [Security Policies](https://techdocs.akamai.com/app-platform/docs/security-policies): A list of Security Policies applicable to the Team.
- [User Management](https://techdocs.akamai.com/app-platform/docs/user-management): A self-service form for Team administrators to add users to the Team
- [Settings](https://techdocs.akamai.com/app-platform/docs/settings): Specific Team configuration options.

Access Section:

- [Shell](https://techdocs.akamai.com/app-platform/docs/shell): Access to the cloud Shell within the context of the Team.
- A "Download KUBECFG" link to download a KUBECONFIG file that gives access to the namespace of the team selected. Admins can download one with `cluster-admin` permissions (giving access to all namespaces) by setting the team selector to '-'. You can use it like `export KUBECONFIG=$file_location` or by merging it with another KUBECONFIG file like `.kube/config`. Please visit the official Kubernetes [documentation about managing kube contexts](https://kubernetes.io/docs/concepts/configuration/organize-cluster-access-kubeconfig/).
- When Harbor is enabled, a link to download the Dockercfg file.
- When automatic generated CA or Let's Encrypt staging certificates are used, a "Download CA" link is provided.