# [Push images to Harbor](https://techdocs.akamai.com/app-platform/docs/push-images#push-images-to-harbor)

:::info  
For this lab, Harbor needs to be activated and the cluster needs to be configured with trusted certificates (Let's Encrypt production certificates).  
:::

## [Login to Harbor](https://techdocs.akamai.com/app-platform/docs/push-images#login-to-harbor)

To be able to push images to Harbor, you'll need a robot account with push permissions. Teams are offered the option to download the Docker config for their Team's private registry in Harbor. In the left menu you will see the option `Download DOCKERCFG`. Click on it to download the credentials.

:::info  
The Download the DOCKERCFG feature needs to be enabled by a platform admin!  
:::

When you have downloaded the docker config, copy the file to your `.Docker` folder:

```bash
cp docker-team-labs.json $HOME/.Docker
```

And log in to the Harbor registry:

```bash
docker login harbor.

```

Build and tag your image:

```bash
docker build -t harbor.
/team-
/
:
 

```

Push the image to Harbor:

```bash
docker push harbor.
/team-
/
:

```