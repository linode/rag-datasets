# [Overview and prerequisites](https://techdocs.akamai.com/app-platform/docs/lab-prerequisites#overview-and-prerequisites)

Welcome to the Akamai App Platform labs! We recommend reviewing these labs to learn how to use App Platform or if you would like to learn Kubernetes. They will guide you in how to build, deploy, secure and observe containerized applications on Kubernetes. The labs cover the most common activities performed by developer and DevOps teams

# [Prerequisites](https://techdocs.akamai.com/app-platform/docs/lab-prerequisites#prerequisites)

1. DNS is configured. See [here](https://techdocs.akamai.com/app-platform/docs/overview). Not needed when using the LKE automatic installation.

2. Prometheus is enabled on the platform level.

3. Enable additional apps on the platform level to support the following labs:

| Lab                                         | App                                 |
| ------------------------------------------- | ----------------------------------- |
| Create container images                     | Harbor                              |
| Trigger builds                              | Harbor                              |
| Manually Push images to Harbor              | Harbor                              |
| Scan running containers for vulnerabilities | Prometheus, Grafana, Trivy Operator |
| View container logs                         | Loki, Grafana                       |
| Tracing with Open Telemetry                 | Loki, Otel, Tempo                   |
| Create a RabbitMQ cluster                   | RabbitMQ                            |

:::info  
For the [Tracing with Open Telemetry](https://techdocs.akamai.com/app-platform/docs/use-otel) Lab, tracing needs to be configured in the `Istio` and `Nginx Ingress` apps.  
:::

3. A team called `labs` is created with `Dashboards` and `Alerts` enabled. See [here](docs/for-ops/console/teams.md) how to create Teams.

4. A user account is created and added to the `labs` Team. In the labs we'll be using the user `labs-user@labs.com`. See [here](docs/for-ops/console/usermgnt.md) how to create users and assign them to Teams.

:::note  
An organization in Gitea is automatically created for each Team. Only members of the Team are added to the `Owners` group of this organization. When using the `platform-admin` account, make sure to add your account to the `Owners` group of the Team's organization in Gitea.  
:::

5. The Kube API URL has been added to the [Cluster Settings](https://techdocs.akamai.com/app-platform/docs/cluster). Select the `platform` view and click on `Settings` in the left menu. Then click on `Cluster`. When using LKE: You can find the Kube API URL in the Summary of your LKE cluster. Here it is called the `Kubernetes API Endpoint`. You can remove `:443` at the end.

# [Sign in to the Console](https://techdocs.akamai.com/app-platform/docs/lab-prerequisites#sign-in-to-the-console)

- Go to the provided URL. The URL will look like this: 

- Sign in with the created user account.

After sign in, you will see this page (with Dashboards enabled):
