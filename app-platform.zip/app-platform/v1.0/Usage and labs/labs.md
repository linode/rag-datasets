# [Labs](https://techdocs.akamai.com/app-platform/docs/labs#labs)

Welcome to the Akamai App Platform labs! We recommend reviewing these labs to learn how to use App Platform or if you would like to learn Kubernetes. They will guide you in how to build, deploy, secure and observe containerized applications on Kubernetes. The labs cover the most common activities performed by developer and DevOps teams.

***

**Make sure everything is ready to get started**

### [Provision an LKE Kubernetes cluster and install the App Platform](https://techdocs.akamai.com/app-platform/docs/linode)

### [Lab prerequisites](https://techdocs.akamai.com/app-platform/docs/lab-prerequisites)

***

**Create and register code repositories and create images**

### [Create private Git repositories](https://techdocs.akamai.com/app-platform/docs/create-repos)

### [Register code repositories](https://techdocs.akamai.com/app-platform/docs/register-repos)

### [Create container images](https://techdocs.akamai.com/app-platform/docs/create-images)

### [Trigger builds](https://techdocs.akamai.com/app-platform/docs/trigger-builds)

### [Push images to Harbor](https://techdocs.akamai.com/app-platform/docs/push-images)

***

**Create workloads**

### [Create Sealed secrets](https://techdocs.akamai.com/app-platform/docs/create-sealed-secrets)

### [Create Kubernetes resources with Argo CD](https://techdocs.akamai.com/app-platform/docs/using-argo-cd)

### [Use the Catalog](https://techdocs.akamai.com/app-platform/docs/use-catalog)

### [Create a workload using catalog](https://techdocs.akamai.com/app-platform/docs/create-workloads)

### [Configure the auto image updater](https://techdocs.akamai.com/app-platform/docs/auto-image-update)

### [Create a PostgreSQL database](https://techdocs.akamai.com/app-platform/docs/create-postgresql-db)

***

**Expose workloads**

### [Publicly expose workloads](https://techdocs.akamai.com/app-platform/docs/expose-services)

***

**Secure workloads**

### [Scan images for vulnerabilities](https://techdocs.akamai.com/app-platform/docs/scan-images)

### [Scan running containers for vulnerabilities](https://techdocs.akamai.com/app-platform/docs/scan-containers)

***

**Monitor and debug workloads**

### [View container logs](https://techdocs.akamai.com/app-platform/docs/view-logs)

### [View container metrics](https://techdocs.akamai.com/app-platform/docs/view-metrics)

### [Using custom metrics](https://techdocs.akamai.com/app-platform/docs/custom-metrics)

### [Monitoring availability of Services](https://techdocs.akamai.com/app-platform/docs/monitor-services)

***

**Advanced Labs**

### [Create network policies](https://techdocs.akamai.com/app-platform/docs/create-netpols)

### [Tracing with OpenTelemetry](https://techdocs.akamai.com/app-platform/docs/use-otel)

### [Canary Deployments](https://techdocs.akamai.com/app-platform/docs/canary-deployment)

### [Create a RabbitMQ cluster](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster)