# [Create a PostgreSQL database](https://techdocs.akamai.com/app-platform/docs/create-postgresql-db#create-a-postgresql-database)

The Cloudnative POstgreSQL database operator is installed by default. Teams can use the operator and the `postgresql` quick start to create their own PostgreSQL databases.

# [Create a database](https://techdocs.akamai.com/app-platform/docs/create-postgresql-db#create-a-database)

You can create a postgresql database from the Catalog:

1. Go to `Catalog` in the left menu and click on the `postgresql` template.

2. Click on `Values`.

3. Fill in a name for the database.

4. Change other parameter values if required.

5. Click `Submit`.

The operator will now create the database and add the secret `
-app` to the team's namespace. This secret contains the username and password for the database with the keys `username` and `password`.

You can now provide the username and password to a container as environment variables using a `secretKeyRef`:

```yaml
env:
  - name: DB_USER
    valueFrom:
      secretKeyRef:
        name: 
-app
        key: username
  - name: DB_PASSWORD
    valueFrom:
      secretKeyRef:
        name: 
-app
        key: password
```

# [Monitoring](https://techdocs.akamai.com/app-platform/docs/create-postgresql-db#monitoring)

The `postgresql` quick start template includes two parameters that can be used to create a `PodMonitor` and a Grafana Dashboard. Set the `monitoring` parameter to `true` to create a PodMonitor and set the `dashboard` parameter to `true` to add a cloudnativepg dashboard to the Team's Grafana. Note that this dashboard can be used to monitor multiple databases so you'll just need to create it once.