# [Create Workloads](https://techdocs.akamai.com/app-platform/docs/create-workloads#create-workloads)

In the previous lab we deployed a workload using Argo CD with a BYO manifest and we explored the Catalog. In this lab we'll create a Workload (a Kubernetes Deployment) using the Catalog and the Workload self-service feature.

## [Create a Workload using the Catalog](https://techdocs.akamai.com/app-platform/docs/create-workloads#create-a-workload-using-the-catalog)

Before creating a Workload from the Catalog, we'll need the `repository` and `tag` of the image to use. Go to the list of Container Images and add the `repository` of the `blue` image to your clipboard. Remember that the tag of the blue image we created is `main`.

You can create a workload from the developer catalog:

1. Go to `Catalog` in the left menu and click on the `k8s-deployment`template.

2. Click on `VALUES`.

3. Add the Name `blue`.

4. Leave the `Auto image updater` to `Disabled`.

5. In the workload `values`, change the following parameters:

```yaml
image:
  repository: 

  tag: main
```

6. Click `SUBMIT`.

App Platform will now create an Argo CD application to deploy the workload. 

7. Click on `Workloads` in the left menu. You will now see a list of all Workloads and their status:

8. In the workloads list, click on the `Application` link of your workload to see the status of your workload in Argo CD:

The values of a workload can be changed at any time. Changes will automatically be synchronized.