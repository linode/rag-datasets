# [Secure workloads](https://techdocs.akamai.com/app-platform/docs/secure-workloads#secure-workloads)

**Secure workloads**

### [Scan images for vulnerabilities](https://techdocs.akamai.com/app-platform/docs/scan-images)

### [Scan running containers for vulnerabilities](https://techdocs.akamai.com/app-platform/docs/scan-containers)