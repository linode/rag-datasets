# [Create workloads](https://techdocs.akamai.com/app-platform/docs/create-workloads-with-argocd#create-workloads)

**Create workloads**

### [Create Sealed secrets](https://techdocs.akamai.com/app-platform/docs/create-sealed-secrets)

### [Create Kubernetes resources with Argo CD](https://techdocs.akamai.com/app-platform/docs/using-argo-cd)

### [Use the Catalog](https://techdocs.akamai.com/app-platform/docs/use-catalog)

### [Create a workload using catalog](https://techdocs.akamai.com/app-platform/docs/create-workloads)

### [Configure the auto image updater](https://techdocs.akamai.com/app-platform/docs/auto-image-update)

### [Create a PostgreSQL database](https://techdocs.akamai.com/app-platform/docs/create-postgresql-db)