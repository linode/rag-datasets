# [Advanced labs](https://techdocs.akamai.com/app-platform/docs/advanced-labs#advanced-labs)

**Advanced Labs**

### [Create network policies](https://techdocs.akamai.com/app-platform/docs/create-netpols)

### [Tracing with OpenTelemetry](https://techdocs.akamai.com/app-platform/docs/use-otel)

### [Canary Deployments](https://techdocs.akamai.com/app-platform/docs/canary-deployment)

### [Create a RabbitMQ cluster](https://techdocs.akamai.com/app-platform/docs/create-rabbitmq-cluster)