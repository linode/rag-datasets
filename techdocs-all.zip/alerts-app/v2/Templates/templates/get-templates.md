# [List templates](https://techdocs.akamai.com/alerts-app/docs/get-templates#list-templates)
