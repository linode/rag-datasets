# [Get a template](https://techdocs.akamai.com/alerts-app/docs/get-template#get-a-template)
