# [Templates](https://techdocs.akamai.com/alerts-app/docs/templates#templates)
