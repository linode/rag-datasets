# [List sparklines](https://techdocs.akamai.com/alerts-app/docs/get-sparklines#list-sparklines)
