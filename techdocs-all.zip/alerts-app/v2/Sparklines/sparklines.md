# [Sparklines](https://techdocs.akamai.com/alerts-app/docs/sparklines#sparklines)
