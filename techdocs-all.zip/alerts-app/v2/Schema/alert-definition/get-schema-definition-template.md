# [Get definition schema](https://techdocs.akamai.com/alerts-app/docs/get-schema-definition-template#get-definition-schema)
