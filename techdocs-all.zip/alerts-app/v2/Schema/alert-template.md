# [Alert template](https://techdocs.akamai.com/alerts-app/docs/alert-template#alert-template)
