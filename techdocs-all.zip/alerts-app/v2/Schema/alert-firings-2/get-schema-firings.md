# [Get firings schema](https://techdocs.akamai.com/alerts-app/docs/get-schema-firings#get-firings-schema)
