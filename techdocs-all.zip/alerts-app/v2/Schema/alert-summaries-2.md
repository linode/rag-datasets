# [Alert summaries](https://techdocs.akamai.com/alerts-app/docs/alert-summaries-2#alert-summaries)
