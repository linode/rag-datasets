# [Alert definition](https://techdocs.akamai.com/alerts-app/docs/alert-definition#alert-definition)
