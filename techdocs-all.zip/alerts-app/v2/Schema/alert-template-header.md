# [Alert template header](https://techdocs.akamai.com/alerts-app/docs/alert-template-header#alert-template-header)
