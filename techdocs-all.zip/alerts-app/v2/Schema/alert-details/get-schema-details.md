# [Get details schema](https://techdocs.akamai.com/alerts-app/docs/get-schema-details#get-details-schema)
