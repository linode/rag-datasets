# [Get summary schema](https://techdocs.akamai.com/alerts-app/docs/get-schema-summaries#get-summary-schema)
