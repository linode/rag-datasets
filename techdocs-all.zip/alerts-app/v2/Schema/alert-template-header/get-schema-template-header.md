# [Get template header schema](https://techdocs.akamai.com/alerts-app/docs/get-schema-template-header#get-template-header-schema)
