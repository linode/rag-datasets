# [Get template schema](https://techdocs.akamai.com/alerts-app/docs/get-schema-template#get-template-schema)
