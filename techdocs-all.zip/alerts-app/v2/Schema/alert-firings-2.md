# [Alert firings](https://techdocs.akamai.com/alerts-app/docs/alert-firings-2#alert-firings)
