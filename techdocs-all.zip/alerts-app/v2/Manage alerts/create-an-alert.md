# [Create an alert](https://techdocs.akamai.com/alerts-app/docs/create-an-alert#create-an-alert)

Create an alert to monitor the crucial aspects of your services.

**How to**

1. Go to ☰ > **COMMON SERVICES** > **Alerts**.

1. Click **Create New Alert**.

1. In the wizard, select an alert and click **Next**.

1. Select properties (groups, domains, or CP codes) you want to monitor. Click **Next**.

1. Configure the threshold criteria for when the alert must fire. Click **Next**.
 > Note: 
 To set the threshold appropriately, it's best to analyze everyday conditions for your site and set it based on the data gathered. This step differs for each alert. Read the alert's description to learn what settings are required for your alert.
 1. Add recipients' email addresses. Click **Next**.
 > Note: 
 A valid email address has a maximum of 255 characters and follows the format: name@company.com. To enter multiple addresses, separate them with a comma.
 1. Create a custom name for the alert configuration and select the group. Click** Submit**.
 > Note: 
 The name must be unique and have no more than 120 characters. Also, the more descriptive the name, the better, because it will allow you to quickly locate the problem after receiving the notification.
 **What you should see**

The alert is created and applied within eight minutes. You can see it in the **Other** list.