# [Delete an alert](https://techdocs.akamai.com/alerts-app/docs/delete-alert#delete-an-alert)

If you don't want the application to monitor a particular condition, you can delete the configuration.

**How to**

1. Go to ☰ > **COMMON SERVICES** > **Alerts**.

1. Click the name of the alert you want to delete.

1. On the alert's page, click **Delete**.
 > Note: 
 Some alerts on Premium accounts can't be deleted because they are created by Akamai personnel for monitoring purposes. If you want, you can remove your email from the notification recipient list. To learn how to do it, see [Edit an alert](https://techdocs.akamai.com/alerts-app/docs/edit-alert).
 1. Click **Yes**.

**What you should see**

The alert is removed from the list and the condition is no longer monitored.