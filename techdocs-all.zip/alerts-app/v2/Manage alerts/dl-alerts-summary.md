# [Download alerts](https://techdocs.akamai.com/alerts-app/docs/dl-alerts-summary#download-alerts)

If you want, you can download the CSV file with the summary of the available alerts. The alerts' summary shows:
- whether they fired
- who is the recipient of the notification

**How to**

1. Go to ☰ > **COMMON SERVICES** > **Alerts**.

1. Click **Download Alerts**.

**What you should see**

The alerts' summary is downloaded to your computer.