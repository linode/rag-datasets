# [Edit an alert](https://techdocs.akamai.com/alerts-app/docs/edit-alert#edit-an-alert)

If you note that the configured threshold is not appropriate or you want to edit the list of notification recipients, you can edit the alert.

**How to**

1. Go to ☰ > **COMMON SERVICES** > **Alerts**.

1. Click the name of the alert you want to edit.

1. On the alert's page, click **Settings**.

1. Change the alert configurations.

1. Click **Save**.

**What you should see**

For the majority of alerts, changes are applied within three minutes.