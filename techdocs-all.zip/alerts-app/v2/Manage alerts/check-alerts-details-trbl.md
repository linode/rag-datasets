# [Check alert](https://techdocs.akamai.com/alerts-app/docs/check-alerts-details-trbl#check-alert)

After receiving the notification about an alert, you can check its details on the alert's page in the application. This page also shows you suggested ways of troubleshooting the alert.

**How to**

1. Go to ☰ > **COMMON SERVICES** > **Alerts**.

1. Expand the appropriate section, depending on when the alert fired.

1. Click the alert's name.

**What you should see**

The page with all alert details, including the history of its firings, opens. The troubleshooting methods are listed in the **Troubleshooting** section.