# [Welcome to Alerts](https://techdocs.akamai.com/alerts-app/docs/welcome-alerts#welcome-to-alerts)

The Alerts application provides automatic, real-time notifications about changes detected in your infrastructure and information-delivery patterns.

Depending on purchased products, the application offers you a list of alerts designed to monitor the crucial aspects of your services. The majority of alerts require setting a threshold, that when reached or crossed triggers the alert. But there are also alerts that just notify you about the detection of a particular state. To check what alerts you can create with your products, see [Available alerts](https://techdocs.akamai.com/alerts-app/docs/available-alerts).

In the application, you can set who needs to be notified about the firing of particular alerts. To learn more about this feature, read [Notifications](https://techdocs.akamai.com/alerts-app/docs/notif).

The warning sign icon at the top of the screen displays the number of alerts that are active for your account.

# [Developer tools](https://techdocs.akamai.com/alerts-app/docs/welcome-alerts#developer-tools)
- [Alerts API v2](https://techdocs.akamai.com/alerts-app/reference/api)

# [What's new](https://techdocs.akamai.com/alerts-app/docs/welcome-alerts#whats-new)
- [Release notes](https://techdocs.akamai.com/alerts-app/changelog)