# [List modeling suppressions](https://techdocs.akamai.com/alerts-app/docs/get-definition-suppressions#list-modeling-suppressions)
