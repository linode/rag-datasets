# [Create a new modeling suppressions](https://techdocs.akamai.com/alerts-app/docs/post-definition-suppression#create-a-new-modeling-suppressions)
