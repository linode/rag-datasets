# [Alert definitions](https://techdocs.akamai.com/alerts-app/docs/alert-definitions#alert-definitions)
