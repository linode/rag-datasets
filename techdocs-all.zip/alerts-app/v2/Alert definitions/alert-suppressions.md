# [Alert suppressions](https://techdocs.akamai.com/alerts-app/docs/alert-suppressions#alert-suppressions)
