# [List alerts](https://techdocs.akamai.com/alerts-app/docs/get-definitions#list-alerts)
