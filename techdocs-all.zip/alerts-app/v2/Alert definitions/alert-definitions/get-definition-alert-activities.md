# [List adaptive alert activity log](https://techdocs.akamai.com/alerts-app/docs/get-definition-alert-activities#list-adaptive-alert-activity-log)
