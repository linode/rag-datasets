# [Update an alert](https://techdocs.akamai.com/alerts-app/docs/put-definition#update-an-alert)
