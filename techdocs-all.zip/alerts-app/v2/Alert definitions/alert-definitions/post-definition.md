# [Create a new alert](https://techdocs.akamai.com/alerts-app/docs/post-definition#create-a-new-alert)
