# [Get an alert](https://techdocs.akamai.com/alerts-app/docs/get-definition#get-an-alert)
