# [Remove an alert](https://techdocs.akamai.com/alerts-app/docs/delete-definition#remove-an-alert)
