# [List fired alerts](https://techdocs.akamai.com/alerts-app/docs/get-definition-alert-firings#list-fired-alerts)
