# [Alert firings](https://techdocs.akamai.com/alerts-app/docs/alert-firings#alert-firings)
