# [High Disk Usage - NetStorage](https://techdocs.akamai.com/alerts-app/docs/high-disk-usage-ns#high-disk-usage-netstorage)

This alert notifies you that the total storage of NetStorage exceeded a set threshold.

You can set this alert to monitor multiple CP codes.

> Info: Due to differences between alerts data and invoices, it's best not to use this alert to monitor your Committed Volume of Storage (CVS). CVS is billed on a 95/5 basis and thus has a time window that cannot be built into the alert mechanism.

If you consistently exceed the committed storage volume on your contract and you require additional space, please contact your account team to request additional NetStorage.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-disk-usage-ns#available-for)

- NetStorage
- Site Defender

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-disk-usage-ns#notification-time)

- **New Alert** - The condition is present for four to seven minutes.
- **Alert Cleared** - The condition is cleared for 10 to 14 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-disk-usage-ns#threshold-configuration)

You need to set how much the contracted storage must be exceeded (in megabytes) to trigger the alert. You must also select whether you want to be notified when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-disk-usage-ns#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.