# [Large Amount of MCDN Traffic Delivered from Akamai Intelligent Platform (AIP) - reported by maprule](https://techdocs.akamai.com/alerts-app/docs/large-amount-mcdn-traffic-delivered-akamai-intelligent-platform-aip-rpted-maprule#large-amount-of-mcdn-traffic-delivered-from-akamai-intelligent-platform-aip-reported-by-maprule)

This alert notifies you that clients are being served high levels of traffic from non-MCDN servers. It indicates that the MCDN might be over capacity and clients should be served by the AIP when the MCDN is overcapacity. This error is reported by a maprule.

You can set this alert to monitor one group.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/large-amount-mcdn-traffic-delivered-akamai-intelligent-platform-aip-rpted-maprule#available-for)

- Aura Managed CDN

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/large-amount-mcdn-traffic-delivered-akamai-intelligent-platform-aip-rpted-maprule#notification-time)

- **New Alert** - The condition is present for 15 to 20 minutes.
- **Alert Cleared** - The condition is cleared for three to six minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/large-amount-mcdn-traffic-delivered-akamai-intelligent-platform-aip-rpted-maprule#threshold-configuration)

You need to set:

- Traffic volume (in megabits per second) delivered by MCDN and AIP clusters and the minimum percentage of traffic delivered by MCDN necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/large-amount-mcdn-traffic-delivered-akamai-intelligent-platform-aip-rpted-maprule#troubleshooting)

To troubleshoot this alert:

- Log in to [Operator Portal](https://isp.akamai.com).

- Go to **Monitor** > **MCDN Content By Delivery Platform**.

- Click the gear icon.

- Click **Select None** and then select all of the clusters in your MCDN and **Akamai Intelligent Platform (AIP)**.

- Click **Submit**.

- Hover over a representative place on the graph and note the values for **Delivered over MCDN Clusters** and **Delivered over AIP**.

- Go to **Monitor** > **MCDN Platform Traffic by Maprule**.

- Click the gear icon.

- Click **Select None** and then select all of the clusters in your MCDN.

- In the **Maprule** section, deselect **Non-MCDN Maprules**.

- Click **Submit**.

- Hover over a representative place on the graph and note the traffic delivered for each maprule.