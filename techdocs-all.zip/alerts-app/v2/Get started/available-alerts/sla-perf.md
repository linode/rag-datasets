# [SLA Performance](https://techdocs.akamai.com/alerts-app/docs/sla-perf#sla-performance)

This alert notifies you that a potential SLA performance violation occurred.

The SLA performance test requests the SLA test object via the edge servers and directly from your origin server and compares the load times with previous data. When the target performance value reaches a set threshold, it fires this alert. It may indicate SLA violations which can be caused by spurious measurements, misbehaving agents, or other situations that do not constitute a valid SLA violation.

You can set this alert to monitor one SLA test.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/sla-perf#available-for)

- Media Delivery: Adaptive Media Delivery, Download Delivery, HTTP Content Delivery, HTTP Downloads, Media Services Live (HLS/HDS/DASH Ingest), Media Services Live (Smooth Ingest Enablement, Media Services Live (Stream Packaging), Media Services On Demand (Smooth Streaming Enablement), Media Services On Demand (Stream Packaging), NetStorage, Object Delivery, Performance Analytics Site Analyzer, Performance Analytics Stream Analyzer, Progressive Media, RTMP Streaming, RTMP/WMS/Quicktime Live Streaming, RTMP/WMS/Quicktime On Demand Streaming
- Security: Site Defender
- Web Performance: EdgeComputing, Edge DNS, IP Application Accelerator, Session Accelerator, Site Accelerator, Site Accelerator Fast File Upload, Site Accelerator SLA Management, Site Accelerator Third Party Optimization, Site Delivery, Terra Alta Enterprise Accelerator, Terra Alta Enterprise Accelerator Composite Application Acceleration, Terra Alta Enterprise Accelerator Fast File Upload, Terra Alta Enterprise Accelerator SLA Management, Third Party Optimization, Traffic Management, Web Application Accelerator, Web Application Accelerator Fast File Upload, Web Application Accelerator SLA Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/sla-perf#notification-time)

- **New Alert** - Up to one minute since the detection of the condition.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/sla-perf#threshold-configuration)

You need to set the target performance percentage necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/sla-perf#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.