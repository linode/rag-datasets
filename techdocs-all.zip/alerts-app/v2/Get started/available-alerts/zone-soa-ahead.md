# [Zone SOA Ahead](https://techdocs.akamai.com/alerts-app/docs/zone-soa-ahead#zone-soa-ahead)

This alert notifies you that a DNS Zone Transfer Agent (ZTA) detected that the primary name servers advertise Security Optimization Assistance (SOA) serial number lower than the one received by ZTA in a previous zone transfer.

It means that a zone received from the primary server a file in which the serial number of SOA is obsolete. This can indicate that the primary name servers were improperly updated. As a safety mechanism, the DNS ZTA refuses to do a zone transfer of such a presumed-stale zone file and DNS changes that were made on the primary name server are not updated on the DNS.

You can set this alert to monitor Groups and multiple DNS Zones or Control Groups.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/zone-soa-ahead#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/zone-soa-ahead#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/zone-soa-ahead#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/zone-soa-ahead#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.