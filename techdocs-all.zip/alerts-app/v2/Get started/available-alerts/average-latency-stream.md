# [Average Latency for a Stream](https://techdocs.akamai.com/alerts-app/docs/average-latency-stream#average-latency-for-a-stream)

This alert notifies you that the average latency for all the bit rates in a stream went above the set threshold.

You can set this alert to monitor one stream.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/average-latency-stream#available-for)

- Media Services Live 4

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/average-latency-stream#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/average-latency-stream#threshold-configuration)

You need to set the **Bitrate Identifier URL** (the ingest URL that contains the bitrate identifier) and the latency (in milliseconds) required to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/average-latency-stream#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.