# [Object Caching - 415: HTML Content Denied](https://techdocs.akamai.com/alerts-app/docs/object-caching-415-html-content-denied#object-caching-415-html-content-denied)

This alert notifies you that the percentage of connections with the HTTP 415 error code exceeded a set threshold. It means that the request failed due to the unsupported `.txt` or `.html` content.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/object-caching-415-html-content-denied#available-for)

- Object Delivery

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/object-caching-415-html-content-denied#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/object-caching-415-html-content-denied#threshold-configuration)

You need to set the percentage of failed origin connections necessary to trigger the alert. You must also select whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/object-caching-415-html-content-denied#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.