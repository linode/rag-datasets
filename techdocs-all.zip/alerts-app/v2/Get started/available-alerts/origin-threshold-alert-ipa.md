# [Origin Threshold Alert (IPA)](https://techdocs.akamai.com/alerts-app/docs/origin-threshold-alert-ipa#origin-threshold-alert-ipa)

This alert notifies you that the number of requests sent to the origin server exceeded a set threshold.

You can set this alert to monitor one srip slot.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/origin-threshold-alert-ipa#available-for)

- IP Accelerator
- Site Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/origin-threshold-alert-ipa#notification-time)

- **New Alert** - The condition is present for six to eight minutes.
- **Alert Cleared** - The condition is cleared for four to six minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/origin-threshold-alert-ipa#threshold-configuration)

You need to set the percentage of requests to the origin server which when exceeded will trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/origin-threshold-alert-ipa#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.