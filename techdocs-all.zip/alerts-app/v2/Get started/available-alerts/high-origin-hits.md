# [High Origin Hits](https://techdocs.akamai.com/alerts-app/docs/high-origin-hits#high-origin-hits)

This alert notifies you that the number of hits to the origin server exceeded a set threshold.

You can set it to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-origin-hits#available-for)

- Media Delivery: Adaptive Media Delivery, Download Delivery, HTTP Content Delivery, HTTP Downloads, Media Services Live (HLS/HDS/DASH Ingest), Media Services Live (Smooth Ingest Enablement, Media Services Live (Stream Packaging), Media Services On Demand (Smooth Streaming Enablement), Media Services On Demand (Stream Packaging), NetStorage, Object Delivery, Performance Analytics Site Analyzer, Performance Analytics Stream Analyzer, Progressive Media, RTMP Streaming, RTMP/WMS/Quicktime Live Streaming, RTMP/WMS/Quicktime On Demand Streaming
- Security: Site Defender
- Web Performance: EdgeComputing, Edge DNS, IP Application Accelerator, Session Accelerator, Site Accelerator, Site Accelerator Fast File Upload, Site Accelerator SLA Management, Site Accelerator Third Party Optimization, Site Delivery, Terra Alta Enterprise Accelerator, Terra Alta Enterprise Accelerator Composite Application Acceleration, Terra Alta Enterprise Accelerator Fast File Upload, Terra Alta Enterprise Accelerator SLA Management, Traffic Management, Web Application Accelerator, Web Application Accelerator Fast File Upload, Web Application Accelerator SLA Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-origin-hits#notification-time)

- **New Alert** - The condition is present for six to eight minutes.
- **Alert Cleared** - The condition is cleared for three to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-origin-hits#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- The number of hits per second per CP code necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-origin-hits#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.