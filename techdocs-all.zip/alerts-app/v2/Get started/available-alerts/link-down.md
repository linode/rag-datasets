# [Link Down](https://techdocs.akamai.com/alerts-app/docs/link-down#link-down)

This alert notifies you that the Direct Connect router interface is unavailable.

With Direct Connect, you set up a physical connection to a router port in a data center. This alert fires when the router interface is unavailable.

Learn more about setting up [Direct Connect Alerts](https://techdocs.akamai.com/direct-connect/docs/enable-alert-notif).