# [SureRoute Object Failure Alert](https://techdocs.akamai.com/alerts-app/docs/sureroute-object-failure-alert#sureroute-object-failure-alert)

This alert notifies you that the SureRoute test object returned the HTTP 3xx or 4xx error code.

SureRoute evaluates alternate Internet routes to use the fastest way to deliver non-cachable content from your origin server. A part of site analysis is the check of availability of a test object. If its request returns an error, SureRoute fails.

You can set this alert to monitor one CP code.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/sureroute-object-failure-alert#available-for)

- Terra Alta Enterprise Accelerator
- Site Accelerator
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/sureroute-object-failure-alert#notification-time)

- **New Alert** - The condition is present for 10 to 15 minutes.
- **Alert Cleared** - The condition is cleared for 10 to 15 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/sureroute-object-failure-alert#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/sureroute-object-failure-alert#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.