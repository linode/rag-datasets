# [Edge Errors -- HLS](https://techdocs.akamai.com/alerts-app/docs/edge-err-hls#edge-errors-hls)

This alert notifies you that a percentage of requests on edge servers that returned the HTTP 4xx and 5xx status codes reached a set threshold. You can set it to monitor multiple CP codes.

It applies only to HTTP live streaming (HLS) &mdash; a streaming protocol developed by Apple for online streaming of video or audio to iOS devices.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/edge-err-hls#available-for)

- Media Services Live (Stream Packaging)

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/edge-err-hls#notification-time)

- **New Alert** - The condition is present for six to seven minutes.
- **Alert Cleared** - The condition is cleared for six to seven minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/edge-err-hls#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- A number and a percentage of failed requests necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/edge-err-hls#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.