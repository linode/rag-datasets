# [Page Failure](https://techdocs.akamai.com/alerts-app/docs/page-failure#page-failure)

This alert notifies you that the number of agents that were unable to download the test object or page exceeded a set threshold.

You can set this alert to monitor multiple Site Analyzer tests (satests).

# [Available for](https://techdocs.akamai.com/alerts-app/docs/page-failure#available-for)

- Performance Analytics Site Analyzer

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/page-failure#notification-time)

- **New Alert** - Up to one minute since the detection of the condition.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/page-failure#threshold-configuration)

You need to set the minimum number of agents that when unable to download the test object will trigger the alert. Also, you must select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/page-failure#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.