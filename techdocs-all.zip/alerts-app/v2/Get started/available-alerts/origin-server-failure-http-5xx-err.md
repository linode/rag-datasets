# [Origin Server Failure (HTTP 5xx errors)](https://techdocs.akamai.com/alerts-app/docs/origin-server-failure-http-5xx-err#origin-server-failure-http-5xx-errors)

This alert notifies you that the number of requests to the origin server that failed for unknown reasons reached a set threshold.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/origin-server-failure-http-5xx-err#available-for)

- Adaptive Media Delivery
- Download Delivery
- HTTP Content Delivery
- HTTP Downloads
- Media Services Live (HLS/HDS/DASH Ingest)
- Media Services Live (Smooth Ingest Enablement)
- Media Services Live (Stream Packaging)
- Media Services On Demand (Smooth Streaming Enablement)
- Media Services On Demand (Stream Packaging)
- Object Delivery
- Progressive Media
- Site Accelerator
- Site Accelerator Fast File Upload
- Site Defender
- Terra Alta Enterprise Accelerator
- Terra Alta Enterprise Accelerator Fast File Upload
- Web Application Accelerator
- Web Application Accelerator Fast File Upload

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/origin-server-failure-http-5xx-err#notification-time)

- **New Alert** - The condition is present for six to eight minutes.
- **Alert Cleared** - The condition is cleared for five to seven minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/origin-server-failure-http-5xx-err#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- A percentage of failed requests and a number of connections necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/origin-server-failure-http-5xx-err#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.