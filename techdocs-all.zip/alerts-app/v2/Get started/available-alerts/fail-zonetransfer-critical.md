# [Failed Zonetransfer (Critical)](https://techdocs.akamai.com/alerts-app/docs/fail-zonetransfer-critical#failed-zonetransfer-critical)

This alert warns you that all Zone Transfer Agents (ZTA) were unable to do zone transfers to all zoneloaders. It indicates that Edge DNS is potentially serving stale DNS information.

It means that the ZTA can't synchronize the current zone files with the primary name server. It may cause redirection to websites other than those requested.

There are three possible causes for this alert:

- Your primary servers are down or unreachable.

- The firewall in front of the primary name server has firewall rules that are blocking traffic from the Zone Transfer Agent IPs.

- The wrong primary name server IP address is specified in the Edge DNS configuration on https://control.akamai.com.

You can set this alert to monitor multiple DNS zones.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/fail-zonetransfer-critical#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/fail-zonetransfer-critical#notification-time)

- **New Alert** - 10 to 12 minutes since the first failed zone transfer from the primary name server and after failed zone transfer to all zoneloaders.
- **Alert Cleared** - The condition is cleared for three to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/fail-zonetransfer-critical#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/fail-zonetransfer-critical#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.