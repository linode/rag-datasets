# [SaaS Application Request-to-User Ratio per Contract](https://techdocs.akamai.com/alerts-app/docs/saas-app-req-user-ratio-per-contract#saas-application-request-to-user-ratio-per-contract)

This alert notifies you that the request-to-user ratio varies greatly from the long-term average for the SaaS applications on a specified contract.

You can set this alert to monitor multiple contracts.

> Info: This alert can be created only by your account team.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/saas-app-req-user-ratio-per-contract#available-for)

- Ion Express
- Ion Media Advanced
- Ion Premier
- Ion Standard
- Terra Alta Enterprise Accelerator
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/saas-app-req-user-ratio-per-contract#notification-time)

- **New Alert** - The condition is present for 12 hours.
- **Alert Cleared** - The condition is cleared.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/saas-app-req-user-ratio-per-contract#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/saas-app-req-user-ratio-per-contract#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.