# [Origin SSL Transaction Failure](https://techdocs.akamai.com/alerts-app/docs/origin-ssl-transaction-failure#origin-ssl-transaction-failure)

This alert notifies you that the percentage of traffic with the Secure Sockets Layer (SSL) errors to the origin server of one of your sites reached a set threshold. It may be caused by memory usage, problems completing the SSL handshake, expired or corrupted certificates, or cipher issues. Also, it may affect the safety of transactions processed on your services.

You can set this alert to monitor multiple CP codes.

# [Available for products](https://techdocs.akamai.com/alerts-app/docs/origin-ssl-transaction-failure#available-for-products)

- Ion Premier
- Site Accelerator Fast File Upload
- Site Accelerator
- Site Defender. Site Delivery
- Terra Alta Enterprise Accelerator Fast File Upload
- Terra Alta Enterprise Accelerator
- Web Application Accelerator Fast File Upload
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/origin-ssl-transaction-failure#notification-time)

- **New Alert** - The condition is present for six to eight minutes.
- **Alert Cleared** - The condition is cleared for six to 12 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/origin-ssl-transaction-failure#threshold-configuration)

You need to set:

- A percentage and a number of failed requests necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/origin-ssl-transaction-failure#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.