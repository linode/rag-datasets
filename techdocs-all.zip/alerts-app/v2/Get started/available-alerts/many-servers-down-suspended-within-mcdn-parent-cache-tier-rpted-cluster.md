# [Too many servers down or suspended within MCDN parent cache tier - reported by cluster](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-parent-cache-tier-rpted-cluster#too-many-servers-down-or-suspended-within-mcdn-parent-cache-tier-reported-by-cluster)

This alert notifies you that the number of servers down or suspended in the MCDN parent cache tier reached a set threshold. This error is reported by a cluster.

You can set this alert to monitor one group.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-parent-cache-tier-rpted-cluster#available-for)

- Aura Managed CDN

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-parent-cache-tier-rpted-cluster#notification-time)

- **New Alert** - The condition is present for 15 to 20 minutes.
- **Alert Cleared** - The condition is cleared for three to eight minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-parent-cache-tier-rpted-cluster#threshold-configuration)

You need to set:

- The percentage of functioning servers in the parent cache tier and the server count necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected clusters or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-parent-cache-tier-rpted-cluster#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.