# [High Concurrent Streams - FLASH](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-streams-flash#high-concurrent-streams-flash)

This alert notifies you that the number of concurrent streams exceeded a set threshold. It may indicate a flash crowd on your website.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-streams-flash#available-for)

- Media Services Live (Stream Packaging)
- Media Services On Demand (Stream Packaging)
- RTMP/WMS/Quicktime Live Streaming
- RTMP Streaming
- RTMP/WMS/Quicktime On Demand Streaming

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-streams-flash#notification-time)

- **New Alert** - The condition is present for four to five minutes.
- **Alert Cleared** - The condition is cleared for four to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-streams-flash#threshold-configuration)

You need to set the number of concurrent streams necessary to trigger the alert. You must also select whether you want to be notified when at least one of the CP codes reaches the threshold or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-streams-flash#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.