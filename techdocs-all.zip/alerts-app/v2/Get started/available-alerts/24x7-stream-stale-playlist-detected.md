# [24x7 Stream Stale playlist detected](https://techdocs.akamai.com/alerts-app/docs/24x7-stream-stale-playlist-detected#24x7-stream-stale-playlist-detected)

This alert notifies you that the playlist for the configured 24x7 live stream has not been refreshed for more than five minutes.

You can set this alert to monitor up to 10 streams.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/24x7-stream-stale-playlist-detected#available-for)

- Media Services Live (HLS/HDS/DASH Ingest)

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/24x7-stream-stale-playlist-detected#notification-time)

- **New Alert** - The condition is present for four to six minutes.
- **Alert Cleared** - The condition is cleared for three to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/24x7-stream-stale-playlist-detected#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/24x7-stream-stale-playlist-detected#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.