# [Page Validation Failure](https://techdocs.akamai.com/alerts-app/docs/page-val-failure#page-validation-failure)

This alert notifies you that the number of agents that determined a test page to be invalid exceeded a set threshold.

You can set this alert to monitor multiple Site Analyzer tests (satests).

# [Available for](https://techdocs.akamai.com/alerts-app/docs/page-val-failure#available-for)

- Performance Analytics Site Analyzer

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/page-val-failure#notification-time)

- **New Alert** - Up to one minute since the detection of the condition.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/page-val-failure#threshold-configuration)

You need to set the minimum number of agents that when fail to validate the test object or page will trigger the alert. Also, you must select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/page-val-failure#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.