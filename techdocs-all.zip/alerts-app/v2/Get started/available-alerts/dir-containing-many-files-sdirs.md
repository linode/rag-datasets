# [Directory containing too many files and subdirectories](https://techdocs.akamai.com/alerts-app/docs/dir-containing-many-files-sdirs#directory-containing-too-many-files-and-subdirectories)

This alert notifies you that you are about to reach the limit of stored objects on a particular directory. The current NetStorage architecture limits the maximum number of objects that can be stored on a given directory. Once the number of objects exceeds the set limit, you may receive a quota error while trying to upload content to that directory.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/dir-containing-many-files-sdirs#available-for)

- NetStorage

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/dir-containing-many-files-sdirs#notification-time)

- **New Alert** - The condition is present for 10 to 15 minutes.
- **Alert Cleared** - The condition is cleared for three to eight minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/dir-containing-many-files-sdirs#threshold-configuration)

You need to set the percentage of the directory size that when exceeded will trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/dir-containing-many-files-sdirs#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.