# [Adaptive](https://techdocs.akamai.com/alerts-app/docs/adaptive#adaptive)

This alert uses a dynamic predictive model to alert you when traffic anomalies are above or below the predictive model. The alert identifies both daily and weekly patterns in your CP code's traffic and uses them to make predictions that take into account normal cycles of the traffic over the course of a day or week. It can be set for only one CP code.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/adaptive#available-for)

- Media Delivery: Adaptive Media Delivery, Download Delivery, HTTP Content Delivery, HTTP Downloads, Media Services Live (HLS/HDS/DASH Ingest), Media Services Live (Smooth Ingest Enablement, Media Services Live (Stream Packaging), Media Services On Demand (Smooth Streaming Enablement), Media Services On Demand (Stream Packaging), NetStorage, Object Delivery, Performance Analytics Site Analyzer, Performance Analytics Stream Analyzer, Progressive Media, RTMP Streaming, RTMP/WMS/Quicktime Live Streaming, RTMP/WMS/Quicktime On Demand Streaming
- Security: Site Defender
- Web Performance: EdgeComputing, IP Application Accelerator, Session Accelerator, Site Accelerator, Site Accelerator Fast File Upload, Site Accelerator SLA Management, Site Accelerator Third Party Optimization, Site Delivery, Terra Alta Enterprise Accelerator, Terra Alta Enterprise Accelerator Composite Application Acceleration, Terra Alta Enterprise Accelerator Fast File Upload, Terra Alta Enterprise Accelerator SLA Management, Third Party Optimization, Web Application Accelerator, Web Application Accelerator Fast File Upload, Web Application Accelerator SLA Management

# [Configuration](https://techdocs.akamai.com/alerts-app/docs/adaptive#configuration)

Here are the terms you need to know to configure the adaptive alert:

- **Anomaly** — happens when the traffic exceeds the upper or lower alert’s threshold.
- **Deviation** — a number of events when the traffic exceeds the threshold to become an anomaly. If set to 1, then if the traffic goes above or below the threshold just for one moment, it becomes the anomaly. If set to 2 or more, the traffic has to stay out of thresholds for a little longer to be considered an anomaly.
- **Polling cycle** — 5 minute period.
- **Forgiving model** — the alert is triggered less frequently, but some short anomalies aren’t detected.
- **Sensitive model** — the alert is triggered more frequently, but it may be false positive.

## [Example](https://techdocs.akamai.com/alerts-app/docs/adaptive#example)

_Configuration_:  
Alert me when 4 anomalies  
Over 3 deviations  
happen in 5 polling cycles

_Meaning_:  
Adaptive alarm will be triggered when 4 anomalies, each containing 3 consecutive deviations, occur within 25 minutes (5 x 5 minutes).

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/adaptive#notification-time)

- **New Alert** - Up to five minutes since the detection of the condition.
- **Alert Cleared** - The condition is cleared for 15 to 20 minutes.

# [Suppress a fired alert](https://techdocs.akamai.com/alerts-app/docs/adaptive#suppress-a-fired-alert)

Atypical traffic rates that occur during some events (for example, a sale or a major holiday) cause the firing of the Adaptive alert. If you don't want to be alerted about such traffic, you can suppress the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/adaptive#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.