# [All Customer Servers for Property Down](https://techdocs.akamai.com/alerts-app/docs/customer-servers-prop-down#all-customer-servers-for-property-down)

This alert notifies you when all of the servers configured to serve a particular property are found to be down. This may mean a denial of service for that property.

You can set this alert to monitor multiple properties.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/customer-servers-prop-down#available-for)

- Traffic Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/customer-servers-prop-down#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/customer-servers-prop-down#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/customer-servers-prop-down#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.