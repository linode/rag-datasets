# [Edge Errors -- Content Delivery (HTTP 4xx and 5xx errors)](https://techdocs.akamai.com/alerts-app/docs/edge-err-content-deliv-http-4xx-5xx-err#edge-errors-content-delivery-http-4xx-and-5xx-errors)

This alert notifies you that a percentage of requests from the edge servers with the HTTP 4xx and 5xx status codes reached a set threshold.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/edge-err-content-deliv-http-4xx-5xx-err#available-for)

- Adaptive Media Delivery
- Download Delivery
- HTTP Content Delivery
- HTTP Downloads
- Media Services Live (Smooth Ingest Enablement)
- Media Services Live (Stream Packaging)
- Media Services On Demand (Smooth Streaming Enablement)
- Media Services On Demand (Stream Packaging)
- Object Delivery
- Progressive Media
- Site Accelerator
- Site Accelerator Fast File Upload
- Site Defender
- Terra Alta Enterprise Accelerator
- Terra Alta Enterprise Accelerator Fast File Upload
- Web Application Accelerator
- Web Application Accelerator Fast File Upload
- Notification time

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/edge-err-content-deliv-http-4xx-5xx-err#notification-time)

- **New Alert** - The condition is present for six to seven minutes.
- **Alert Cleared** - The condition is cleared for six to seven minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/edge-err-content-deliv-http-4xx-5xx-err#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- Percentage of failed requests to trigger the alert.

- A number of all requests necessary to trigger the alert. Note that the conditions for this alert are checked every 90 seconds. If the total number of requests during the last 90 seconds doesn’t equal or exceed this value, the alert won’t be triggered.
  - Example: You set the percentage of failed requests to 1 and the total number of requests to 100. It means that the alert will be triggered only if there were at least 100 requests during the last 90 seconds, and 1 out of those 100 requests failed.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/edge-err-content-deliv-http-4xx-5xx-err#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.