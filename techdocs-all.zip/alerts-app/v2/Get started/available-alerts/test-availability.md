# [Test Availability](https://techdocs.akamai.com/alerts-app/docs/test-availability#test-availability)

This alert notifies you that the availability of the test dropped below a set threshold.

The Availability in the context of Site Analyzer is defined as the availability of the base page in the given time interval.

You can set this alert to monitor multiple Site Analyzer tests (satests).

# [Available for](https://techdocs.akamai.com/alerts-app/docs/test-availability#available-for)

- Performance Analytics Site Analyzer

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/test-availability#notification-time)

- **New Alert** - The condition is present for six to eight minutes.
- **Alert Cleared** - The condition is cleared for three to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/test-availability#threshold-configuration)

You need to set the minimum percentage availability of the tests necessary to trigger the alert. You must also select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/test-availability#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.