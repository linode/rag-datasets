# [Load Object File is Stale](https://techdocs.akamai.com/alerts-app/docs/load-object-file-stale#load-object-file-is-stale)

This alert notifies you when one of the data center load object files for a particular domain has not been refreshed for a certain amount of time. It only applies to load feedback domains.

See [Performance with load feedback](https://techdocs.akamai.com/gtm/docs/perf-load-feedback) for an overview of load objects.

You can set this alert to monitor multiple load feedback domains.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/load-object-file-stale#available-for)

- Traffic Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/load-object-file-stale#notification-time)

- **New Alert** - The condition is present for eight to nine minutes.
- **Alert Cleared** - The condition is cleared for 15 to 16 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/load-object-file-stale#threshold-configuration)

You need to set for how long the load object must not be refreshed to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/load-object-file-stale#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.