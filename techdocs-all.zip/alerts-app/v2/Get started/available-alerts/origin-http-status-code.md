# [Origin HTTP Status Code](https://techdocs.akamai.com/alerts-app/docs/origin-http-status-code#origin-http-status-code)

This alert notifies you that the percentage of hits to a particular CP code that failed with a specific HTTP error code reached a set threshold.

You can set this alert to monitor multiple CP codes and HTTP error codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/origin-http-status-code#available-for)

- Adaptive Media Delivery
- HTTP Content Delivery
- HTTP Downloads
- IBM WebSphere Application Accelerator - HN 3rd Party Applications File Transfers
- Ion Premier
- Media Services Live (Smooth Ingest Enablement)
- Media Services Live (Stream Packaging)
- Media Services On Demand (Smooth Streaming Enablement)
- Media Services On Demand (Stream Packaging)
- Progressive Media. Site Accelerator Fast File Upload
- Site Accelerator. Site Defender
- Terra Alta Enterprise Accelerator Fast File Upload
- Terra Alta Enterprise Accelerator. Traffic Management
- Web Application Accelerator Fast File Upload
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/origin-http-status-code#notification-time)

- **New Alert** - The condition is present for six to eight minutes.
- **Alert Cleared** - The condition is cleared for five to seven minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/origin-http-status-code#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- Percentage and a number of failed connections necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/origin-http-status-code#troubleshooting)

The majority of troubleshooting methods are listed in the **Troubleshooting** section on the alert's page. Here are some additional suggestions:

- Determine which URLs are generating the error codes for which you configured the alert. You can find the URLs by either:

    - Looking at your origin web server logs to find the URLs for which the origin server served the status codes to the edge server.

    - If you subscribe to Log Delivery Service, wait for the next scheduled delivery and examine the URLs for which an edge server served that status code.

- If necessary, verify that the origin servers have the object in question or that the URL links are accurate.