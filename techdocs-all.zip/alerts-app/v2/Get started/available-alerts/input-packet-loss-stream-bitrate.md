# [Input Packet Loss for a stream bitrate](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream-bitrate#input-packet-loss-for-a-stream-bitrate)

This alert notifies you that the input packet loss ratio for a selected stream bit rate reached the set threshold.

You can set this alert to monitor one stream.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream-bitrate#available-for)

- Media Services Live 4

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream-bitrate#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream-bitrate#threshold-configuration)

You need to set the percentage of input packet loss ratio required to trigger the alert and **Bitrate Identifier URL** (the ingest URL that contains the bitrate identifier) to identify the stream bit rate.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream-bitrate#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.