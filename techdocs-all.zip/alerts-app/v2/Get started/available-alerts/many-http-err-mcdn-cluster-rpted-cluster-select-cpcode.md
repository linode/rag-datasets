# [Too many HTTP errors from an MCDN cluster - reported by cluster, select CPcode](https://techdocs.akamai.com/alerts-app/docs/many-http-err-mcdn-cluster-rpted-cluster-select-cpcode#too-many-http-errors-from-an-mcdn-cluster-reported-by-cluster-select-cpcode)

This alert notifies you that clients receive too many error responses from an MCDN cluster.

In comparison to Edge error alerts that report errors for traffic served by any cluster, this error reports only errors for traffic served by clusters within your MCDN.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/many-http-err-mcdn-cluster-rpted-cluster-select-cpcode#available-for)

- Aura Managed CDN

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/many-http-err-mcdn-cluster-rpted-cluster-select-cpcode#notification-time)

- **New Alert** - The condition is present for 15 to 20 minutes.
- **Alert Cleared** - The condition is cleared for three to eight minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/many-http-err-mcdn-cluster-rpted-cluster-select-cpcode#threshold-configuration)

You need to set:

- The percentage of requests with an error and the number of requests per second necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/many-http-err-mcdn-cluster-rpted-cluster-select-cpcode#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.