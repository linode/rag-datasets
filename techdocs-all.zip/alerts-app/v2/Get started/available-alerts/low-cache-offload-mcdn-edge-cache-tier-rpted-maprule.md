# [Low cache offload in MCDN edge cache tier - reported by maprule](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-edge-cache-tier-rpted-maprule#low-cache-offload-in-mcdn-edge-cache-tier-reported-by-maprule)

This alert notifies you that the cache offload in the MCDN edge cache tier dropped below a set threshold. This error is reported by a maprule.

You can set this alert to monitor one group.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-edge-cache-tier-rpted-maprule#available-for)

- Aura Managed CDN

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-edge-cache-tier-rpted-maprule#notification-time)

- **New Alert** - The condition is present for 15 to 18 minutes.
- **Alert Cleared** - The condition is cleared for three to 18 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-edge-cache-tier-rpted-maprule#threshold-configuration)

You need to set:

- The minimal traffic volume delivered to clients (in megabits per second) and the minimum percentage of cache offload in the edge cache tier necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected maprule or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-edge-cache-tier-rpted-maprule#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.