# [Control Center Event](https://techdocs.akamai.com/alerts-app/docs/cc-event#control-center-event)

This alert informs you that a change has been made in Control Center. The monitored changes include a change to your valid domains, the uploading or activation of an EdgeSuite configuration file, or a change to Control Center users' permissions. Note that it takes up to an hour for the alert to start monitoring selected event log events.

> Info: The group that you select during the configuration indicates the group of users that can modify the alert.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/cc-event#available-for)

- Media Delivery: Adaptive Media Delivery, Download Delivery, HTTP Content Delivery, HTTP Downloads, Media Services Live (HLS/HDS/DASH Ingest), Media Services Live (Smooth Ingest Enablement, Media Services Live (Stream Packaging), Media Services On Demand (Smooth Streaming Enablement), Media Services On Demand (Stream Packaging), NetStorage, Object Delivery, Performance Analytics Site Analyzer, Performance Analytics Stream Analyzer, Progressive Media, RTMP Streaming, RTMP/WMS/Quicktime Live Streaming, RTMP/WMS/Quicktime On Demand Streaming
- Security: Site Defender
- Web Performance: EdgeComputing, Edge DNS, IP Application Accelerator, Session Accelerator, Site Accelerator, Site Accelerator Fast File Upload, Site Accelerator SLA Management, Site Accelerator Third Party Optimization, Site Delivery, Terra Alta Enterprise Accelerator, Terra Alta Enterprise Accelerator Composite Application Acceleration, Terra Alta Enterprise Accelerator Fast File Upload, Terra Alta Enterprise Accelerator SLA Management, Third Party Optimization, Traffic Management, Web Application Accelerator, Web Application Accelerator Fast File Upload, Web Application Accelerator SLA Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/cc-event#notification-time)

- **New Alert** - Up to one minute since the change has been made.
- **Alert Cleared** - This alert doesn't send this notification.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/cc-event#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/cc-event#troubleshooting)

This alert only informs about made changes, it can't be troubleshot.