# [Authorities incompatible with Sign&Serve DNSSEC](https://techdocs.akamai.com/alerts-app/docs/authorities-incompatible-sign-serve-dnssec#authorities-incompatible-with-signserve-dnssec)

This alert notifies you that some of the name server (NS) records handed out by the parent zone's authoritative servers don't point to Akamai DNS name servers.

You can set this alert to monitor multiple DNS zones.

> Info: To create this alert, you need to have the `ALERTS_DNSSEC` scope. For more information, contact your account administrator.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/authorities-incompatible-sign-serve-dnssec#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/authorities-incompatible-sign-serve-dnssec#notification-time)

- **New Alert** - Up to 15 minutes since the detection of the condition.
- **Alert Cleared** - The condition is cleared for three to 18 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/authorities-incompatible-sign-serve-dnssec#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/authorities-incompatible-sign-serve-dnssec#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.