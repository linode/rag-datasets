# [Customer Server Removed from Rotation](https://techdocs.akamai.com/alerts-app/docs/customer-server-rmd-rotation#customer-server-removed-from-rotation)

This alert notifies you when Traffic Management decides that a server doesn't meet its liveness criteria, and has therefore removed it from rotation.

This alert isn't applicable for data centers using Cloud Server Targeting. Use the Customer Data Center Down alert for Cloud Server Targeting.

You can set this alert to monitor multiple properties.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/customer-server-rmd-rotation#available-for)

- Traffic Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/customer-server-rmd-rotation#notification-time)

- **New Alert** - The condition is present for the time set by you plus two additional minutes.
- **Alert Cleared** - The condition is cleared for 14 to 17 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/customer-server-rmd-rotation#threshold-configuration)

You need to set for how long the condition must be present to fire the alert. You can set it for two to 60 minutes.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/customer-server-rmd-rotation#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.