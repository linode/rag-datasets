# [Edge High MB Delivered](https://techdocs.akamai.com/alerts-app/docs/edge-high-mb-delivered#edge-high-mb-delivered)

This alert notifies you that the total edge content delivered for the current calendar month exceeded a set threshold.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/edge-high-mb-delivered#available-for)

- Site Accelerator
- Site Accelerator Fast File Upload
- Site Defender
- Terra Alta Enterprise Accelerator
- Terra Alta Enterprise Accelerator Fast File Upload
- Web Application Accelerator
- Web Application Accelerator Fast File Upload

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/edge-high-mb-delivered#notification-time)

- **New Alert** - The condition is present for five to six minutes.
- **Alert Cleared** - The condition is cleared for 10 to 11 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/edge-high-mb-delivered#threshold-configuration)

You need to set how much the volume (in megabytes) must be exceeded to trigger the alert. Also, you must select whether you want the alert to be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/edge-high-mb-delivered#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.