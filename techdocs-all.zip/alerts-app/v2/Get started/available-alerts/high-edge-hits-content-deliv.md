# [High Edge Hits -- Content Delivery](https://techdocs.akamai.com/alerts-app/docs/high-edge-hits-content-deliv#high-edge-hits-content-delivery)

This alert notifies you when there's a sudden or gradual increase in traffic (in hits/sec) from edge servers to the client, and the rate is higher than the one specified in the alert configuration.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-edge-hits-content-deliv#available-for)

- API Acceleration

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-edge-hits-content-deliv#notification-time)

- **New Alert** - The condition is present for three to six minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-edge-hits-content-deliv#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-edge-hits-content-deliv#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.