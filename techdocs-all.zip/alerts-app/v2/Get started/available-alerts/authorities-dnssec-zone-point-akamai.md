# [Authorities for DNSSEC Zone do not point to Akamai](https://techdocs.akamai.com/alerts-app/docs/authorities-dnssec-zone-point-akamai#authorities-for-dnssec-zone-do-not-point-to-akamai)

This alert notifies you that the name server (NS) records handed out by the parent zone's authoritative servers don't point to Akamai DNS name servers.

You can set this alert to monitor multiple DNS zones.

> Info: To create this alert, you need to have the `ALERTS_DNSSEC` scope. For more information, contact your account administrator.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/authorities-dnssec-zone-point-akamai#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/authorities-dnssec-zone-point-akamai#notification-time)

- **New Alert** - Up to 15 minutes since the detection of the condition.
- **Alert Cleared** - The condition is cleared for three to 18 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/authorities-dnssec-zone-point-akamai#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/authorities-dnssec-zone-point-akamai#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.