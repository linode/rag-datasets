# [High Edge Hits](https://techdocs.akamai.com/alerts-app/docs/high-edge-hits#high-edge-hits)

This alert notifies you when the edge traffic hits per second exceeds a specified threshold, possibly indicating a surge in demand.

The **High Edge Hits** alert notifies you when there is an increase in edge server traffic that exceeds the hits/sec threshold specified in the alert configuration. The increase in traffic may be due to a variety of causes. A gradual increase over time could simply indicate the popularity of the requested content. However, requests coming from the same source, for example, Client IPs, User Agents, or URLs, may indicate an attack.

Configure the threshold criteria for this alert to a logical value sufficiently higher than typical traffic for any given time of day. Take into consideration planned events that could impact traffic.

If you receive this alert notification, you should:

- Check your origin server logs or Log Delivery Service (available by subscription) for Top Client IPs, URLs, User Agents, and Referrers to determine the nature of the high traffic.

- Review traffic patterns in your ​Akamai Control Center​ [Reports](https://techdocs.akamai.com/reporting/docs/traffic-rpts).