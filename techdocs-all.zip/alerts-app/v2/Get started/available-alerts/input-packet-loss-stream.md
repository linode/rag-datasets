# [Input Packet Loss for a Stream](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream#input-packet-loss-for-a-stream)

This alert notifies you that the input packet loss ratio for all the bit rates in a stream reached the set threshold.

You can set this alert to monitor one stream.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream#available-for)

- Media Services Live 4

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream#threshold-configuration)

You need to set the percentage of input packet loss ratio necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/input-packet-loss-stream#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.