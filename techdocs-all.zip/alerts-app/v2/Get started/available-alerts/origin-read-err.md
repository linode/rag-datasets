# [Origin Read Error](https://techdocs.akamai.com/alerts-app/docs/origin-read-err#origin-read-error)

This alert notifies you that the origin server accepted a connection but did not return any data. Such an error can be caused by a load balancer accepting connections while the origin server is down.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/origin-read-err#available-for)

- Adaptive Media Delivery
- HTTP Content Delivery
- HTTP Downloads
- IBM WebSphere Application Accelerator - HN 3rd Party Applications File Transfers
- Ion Premier
- Media Services Live (Smooth Ingest Enablement)
- Media Services Live (Stream Packaging)
- Media Services On Demand (Smooth Streaming Enablement)
- Media Services On Demand (Stream Packaging)
- Progressive Media
- Site Accelerator Fast File Upload
- Site Accelerator
- Site Defender
- Terra Alta Enterprise Accelerator Fast File Upload
- Terra Alta Enterprise Accelerator
- Web Application Accelerator Fast File Upload
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/origin-read-err#notification-time)

- **New Alert** - The condition is present for 15 to 18 minutes.
- **Alert Cleared** - The condition is cleared for five to 10 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/origin-read-err#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- A percentage of failed connections and a number of total connections required to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/origin-read-err#troubleshooting)

The majority of troubleshooting methods are listed in the **Troubleshooting** section on the alert's page. Here are some additional suggestions:

- To issue an HTTP request for the page or object, you can try one of the following:

    - Go to the origin site in a browser.

    - Use a tool like wget, curl, wfetch, or a similar tool (other than a browser) to issue an HTTP request against the origin server.

    - Telnet to port 80 on each origin server and issue an HTTP GET.

- Check for any data center connectivity issues near the origin server by doing traceroutes/pings/mtrs to the origin server. If possible, check connectivity from multiple machines in different networks and locations.

- If you have multiple origin servers and one of them is down, check to ensure that the load balancer or router is not directing any incoming requests to the down origin server.

- To obtain more detailed information as to which specific URLs generated the error, you can look at your Log Delivery Service logs if you subscribe to the service. Within the Log Delivery Service logs, look at log lines that correspond to the time the alert triggered. Log lines that reflect problems connecting to the origin server will most likely have a 500 series status code in the HTTP status column.

&nbsp;

 > Note:
 If an edge server has trouble connecting to an origin server to retrieve content that is not in cache, Akamai has several services designed to address this issue. Examples include redirecting to custom URLs upon failure, redirecting to a backup copy of your site on the NetStorage, and trying alternative paths to try to connect to the origin (SureRoute). For additional information about these services, please contact your Account Manager or Business Services Representative.
 