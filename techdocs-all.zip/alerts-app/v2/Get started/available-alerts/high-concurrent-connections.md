# [High Concurrent Connections](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-connections#high-concurrent-connections)

This alert notifies you that the number of concurrent connections for a contract went above a set threshold.

You can set this alert to monitor multiple contracts.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-connections#available-for)

- IP Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-connections#notification-time)

- **New Alert** - The condition is present for four to five minutes.
- **Alert Cleared** - The condition is cleared for four to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-connections#threshold-configuration)

You need to set a number of concurrent connections necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-connections#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.