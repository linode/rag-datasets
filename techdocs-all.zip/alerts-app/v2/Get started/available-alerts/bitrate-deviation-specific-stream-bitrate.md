# [Bitrate deviation for a specific stream bitrate](https://techdocs.akamai.com/alerts-app/docs/bitrate-deviation-specific-stream-bitrate#bitrate-deviation-for-a-specific-stream-bitrate)

This alert notifies you that the long-term average rate for a specific bit rate deviated from the expected value and reached a set threshold.

You can set this alert to monitor one stream.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/bitrate-deviation-specific-stream-bitrate#available-for)

- Media Services Live 4

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/bitrate-deviation-specific-stream-bitrate#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for 30 to 31 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/bitrate-deviation-specific-stream-bitrate#threshold-configuration)

You need to set the length of the long-term bit rate and the percentage deviation necessary to trigger the alert. You must also enter the **Bitrate Identifier URL** (the ingest URL that contains the bitrate identifier) to identify the monitored bit rate.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/bitrate-deviation-specific-stream-bitrate#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.