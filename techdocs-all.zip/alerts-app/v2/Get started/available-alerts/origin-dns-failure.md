# [Origin DNS Failure](https://techdocs.akamai.com/alerts-app/docs/origin-dns-failure#origin-dns-failure)

This alert notifies you that the number of edge servers that failed to resolve the origin hostname reached a set threshold.

Such a problem is caused by origin DNS issues that occur while retrieving content from the origin server. There are two reasons why an edge server can fail to successfully look up the origin DNS hostname:

- One or all of the origin authoritative name servers gives out the Non-existent Internet Domain Names (NXDOMAIN) response to the edge server indicating that the requested hostname doesn't exist.

- One or all of the origin authoritative name servers is down or takes a long time to respond and therefore the edge server times out when trying to resolve the origin hostname.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/origin-dns-failure#available-for)

- Adaptive Media Delivery
- HTTP Content Delivery
- HTTP Downloads
- IBM WebSphere Application Accelerator - HN 3rd Party Applications File Transfers
- Ion Premier
- Media Services Live (Smooth Ingest Enablement)
- Media Services Live (Stream Packaging)
- Media Services On Demand (Smooth Streaming Enablement)
- Media Services On Demand (Stream Packaging)
- Progressive Media
- Site Accelerator Fast File Upload
- Site Accelerator. Site Defender
- Terra Alta Enterprise Accelerator Fast File Upload
- Terra Alta Enterprise Accelerator
- Web Application Accelerator Fast File Upload
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/origin-dns-failure#notification-time)
- **New Alert** - The condition is present for six to eight minutes.
- **Alert Cleared** - The condition is cleared for five to seven minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/origin-dns-failure#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- A percentage and a number of failed connections required to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/origin-dns-failure#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.