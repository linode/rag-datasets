# [Loss of a specific stream bitrate](https://techdocs.akamai.com/alerts-app/docs/loss-specific-stream-bitrate#loss-of-a-specific-stream-bitrate)

This alert notifies you that a variant stream is missing. Variant streams are used by Apple's HTTP Live Streaming (HLS) for sorting the media contents and enabling you to switch between combinations of content.

You can set this alert to monitor one stream.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/loss-specific-stream-bitrate#available-for)

- Media Services Live 4

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/loss-specific-stream-bitrate#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/loss-specific-stream-bitrate#threshold-configuration)

You need to set the **Bitrate Identifier URL** (the ingest URL that contains the bitrate identifier) to identify the monitored bit rate and the time (in seconds) for which the variant stream must be missing to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/loss-specific-stream-bitrate#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.