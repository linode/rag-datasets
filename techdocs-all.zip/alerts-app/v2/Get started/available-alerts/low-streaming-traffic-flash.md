# [Low Streaming Traffic - FLASH](https://techdocs.akamai.com/alerts-app/docs/low-streaming-traffic-flash#low-streaming-traffic-flash)

This alert notifies you that the streaming traffic volume dropped below a set threshold. It may indicate a network outage or an origin server problem.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/low-streaming-traffic-flash#available-for)

- Media Services Live (Stream Packaging)
- Media Services On Demand (Stream Packaging)
- RTMP Streaming
- RTMP/WMS/Quicktime Live Streaming
- RTMP/WMS/Quicktime On Demand Streaming

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/low-streaming-traffic-flash#notification-time)

- **New Alert** - The condition is present for four to five minutes.
- **Alert Cleared** - The condition is cleared for four to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/low-streaming-traffic-flash#threshold-configuration)

You need to set the traffic volume (in megabits per second) necessary to trigger the alert. You must also select whether the alert should fire when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/low-streaming-traffic-flash#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.