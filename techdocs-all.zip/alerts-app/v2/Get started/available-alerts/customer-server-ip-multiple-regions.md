# [Customer Server IP in Multiple Regions](https://techdocs.akamai.com/alerts-app/docs/customer-server-ip-multiple-regions#customer-server-ip-in-multiple-regions)

This alert notifies you that a customer server IP is configured as existing in more than one region, or data center.

You can set this alert to monitor multiple properties.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/customer-server-ip-multiple-regions#available-for)

- Traffic Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/customer-server-ip-multiple-regions#notification-time)

- **New Alert** - The condition is present for five to six minutes.
- **Alert Cleared** - The condition is cleared for six to seven minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/customer-server-ip-multiple-regions#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/customer-server-ip-multiple-regions#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.