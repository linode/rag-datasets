# [API Gateway throttling limit alert](https://techdocs.akamai.com/alerts-app/docs/api-gateway-throttling-limit-alert#api-gateway-throttling-limit-alert)

This alert notifies you that the API throttling counter reached a set threshold.

You can set this alert to monitor one group.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/api-gateway-throttling-limit-alert#available-for)

- Ion Standard

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/api-gateway-throttling-limit-alert#notification-time)

- **New Alert** - Up to one minute since the detection of the condition.
- **Alert Cleared** - The condition is cleared for 30 to 31 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/api-gateway-throttling-limit-alert#threshold-configuration)

You need to set the throttling counter necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/api-gateway-throttling-limit-alert#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.