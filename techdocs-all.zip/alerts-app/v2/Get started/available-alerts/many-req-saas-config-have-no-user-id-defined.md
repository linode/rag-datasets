# [Too many requests on a SaaS configuration have no user-id defined](https://techdocs.akamai.com/alerts-app/docs/many-req-saas-config-have-no-user-id-defined#too-many-requests-on-a-saas-configuration-have-no-user-id-defined)

This alert notifies you when the percentage of requests to the origin server fails due to having no User-ID defined.

You can set this alert to monitor one network.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/many-req-saas-config-have-no-user-id-defined#available-for)

- Ion Express
- Ion Media Advanced
- Ion Premier
- Ion Standard
- Terra Alta Enterprise Accelerator
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/many-req-saas-config-have-no-user-id-defined#notification-time)

- **New Alert** - The condition is present for four to six hours.
- **Alert Cleared** - The condition is cleared for two to four hours.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/many-req-saas-config-have-no-user-id-defined#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- The percentage of failed origin server requests because of having no User-ID.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/many-req-saas-config-have-no-user-id-defined#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.