# [Low cache offload in MCDN parent cache tier - reported by cluster](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-parent-cache-tier-rpted-cluster#low-cache-offload-in-mcdn-parent-cache-tier-reported-by-cluster)

This alert notifies you that cache offload in the MCDN parent cache tier dropped below a set threshold. This error is reported by a cluster.

You can set this alert to monitor one group.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-parent-cache-tier-rpted-cluster#available-for)

- Aura Managed CDN

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-parent-cache-tier-rpted-cluster#notification-time)

- **New Alert** - The condition is present for 15 to 20 minutes.
- **Alert Cleared** - The condition is cleared for three to eight minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-parent-cache-tier-rpted-cluster#threshold-configuration)

You need to set:

- The minimal traffic volume delivered to a lower tier (in megabits per second) and the minimum percentage of cache offload in the parent cache tier necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected clusters or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/low-cache-offload-mcdn-parent-cache-tier-rpted-cluster#troubleshooting)

To troubleshoot this alert:

1. Log into [Operator Portal](https://isp.akamai.com).

2. Go to **Monitor** > **Cache Performance**.

3. Click the gear icon and select **Area** and **POP** (Points of Presence) of interest.

4. Click **Submit**.

5. Hover over a representative place on the graph and note the **Traffic Edge Hit Ratio**.

6. Click **Monitor** > **Cluster Traffic**.

7. For both graphs, **Cluster Traffic** and **Cluster Offload**, click the gear icon. For **Clusters**, select the clusters of interest.

8. On the  graphs, hover over a representative place and note the values.