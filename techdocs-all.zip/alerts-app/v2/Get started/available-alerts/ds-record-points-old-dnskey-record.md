# [DS record points to old DNSKEY record](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-old-dnskey-record#ds-record-points-to-old-dnskey-record)

This alert notifies you that a Key Signing Key (KSK) rotation is in progress for the zone and the DS record handed out by a parent zone points to the old DNSKEY record. It means that DNSSEC cannot authenticate the DNS records because the key doesn't match.

You can set this alert to monitor multiple DNS zones.

> Info: To create this alert, you need to have the `ALERTS_DNSSEC` scope. For more information, contact your account administrator.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-old-dnskey-record#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-old-dnskey-record#notification-time)

- **New Alert** - Up to 15 minutes since the detection of the condition.
- **Alert Cleared** - The condition is cleared for 20 to 35 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-old-dnskey-record#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-old-dnskey-record#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.