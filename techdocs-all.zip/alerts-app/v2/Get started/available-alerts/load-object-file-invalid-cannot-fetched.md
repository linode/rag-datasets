# [Load Object File Invalid or Cannot be Fetched](https://techdocs.akamai.com/alerts-app/docs/load-object-file-invalid-cannot-fetched#load-object-file-invalid-or-cannot-be-fetched)

This alert notifies you when one of the data center load object files for a particular domain cannot be fetched, usually because it cannot be found, it's in an invalid format, or it's missing required information. It only applies to load feedback domains.

You can set this alert to monitor multiple domains.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/load-object-file-invalid-cannot-fetched#available-for)

- Traffic Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/load-object-file-invalid-cannot-fetched#notification-time)

- **New Alert** - The condition is present for four to five minutes.
- **Alert Cleared** - The condition is cleared for 15 to 17 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/load-object-file-invalid-cannot-fetched#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/load-object-file-invalid-cannot-fetched#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.