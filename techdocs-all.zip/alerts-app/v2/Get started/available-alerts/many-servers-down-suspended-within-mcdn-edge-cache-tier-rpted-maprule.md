# [Too many servers down or suspended within MCDN edge cache tier - reported by maprule](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-edge-cache-tier-rpted-maprule#too-many-servers-down-or-suspended-within-mcdn-edge-cache-tier-reported-by-maprule)

This alert notifies you that the number of servers down or suspended in the MCDN edge cache tier reached a set threshold. This error is reported by a maprule.

You can set this alert to monitor one group.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-edge-cache-tier-rpted-maprule#available-for)

- Aura Managed CDN

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-edge-cache-tier-rpted-maprule#notification-time)

- **New Alert** - The condition is present for 15 to 20 minutes.
- **Alert Cleared** - The condition is cleared for three to eight minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-edge-cache-tier-rpted-maprule#threshold-configuration)

You need to set:

- The percentage of functioning servers in the edge cache tier and the server count necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected maprules or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/many-servers-down-suspended-within-mcdn-edge-cache-tier-rpted-maprule#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.