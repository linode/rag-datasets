# [Stream Start-up Time](https://techdocs.akamai.com/alerts-app/docs/stream-start-up-time#stream-start-up-time)

This alert notifies you that the number of agents that didn't start playing the stream within a specified time frame exceeded a set threshold.

You can set this alert to monitor multiple stream analyzer tests.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/stream-start-up-time#available-for)

- Performance Analytics Stream Analyzer

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/stream-start-up-time#notification-time)

- **New Alert** - Up to five minutes since the detection of the condition.
- **Alert Cleared** - The condition is cleared for three to eight minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/stream-start-up-time#threshold-configuration)

You need to set the number of agents and their start-up time length (in seconds) necessary to trigger the alert. You must also select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/stream-start-up-time#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.