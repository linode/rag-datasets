# [No DS record in parent zone](https://techdocs.akamai.com/alerts-app/docs/no-ds-record-parent-zone#no-ds-record-in-parent-zone)

This alert notifies you that there are no DS records handed out by the parent zone.

You can set this alert to monitor multiple DNS zones.

> Info: To create this alert, you need to have the `ALERTS_DNSSEC` scope. For more information, contact your account administrator.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/no-ds-record-parent-zone#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/no-ds-record-parent-zone#notification-time)

- **New Alert** - The condition is present for 10 to 12 minutes.

- **Alert Cleared** - The condition is cleared for three to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/no-ds-record-parent-zone#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/no-ds-record-parent-zone#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.