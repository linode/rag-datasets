# [DataStream - Upload Failures](https://techdocs.akamai.com/alerts-app/docs/datastream-upload-failures#datastream-upload-failures)

This alert notifies you of logs upload failures for your streams.

You can set this alert to monitor multiple streams.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/datastream-upload-failures#available-for)

- DataStream 2

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/datastream-upload-failures#notification-time)

- **New Alert** - The condition is present for 15 to 20 minutes.
- **Alert Cleared** - The condition is cleared for 15 to 20 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/datastream-upload-failures#threshold-configuration)

You need to set the threshold for the upload failure count.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/datastream-upload-failures#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.