# [High Traffic Origin -- HLS](https://techdocs.akamai.com/alerts-app/docs/high-traffic-origin-hls#high-traffic-origin-hls)

This alert notifies you that the origin traffic exceeded a specified threshold. You can set this alert to monitor multiple CP codes.

It applies only to HTTP live streaming (HLS) - a streaming protocol developed by Apple for online streaming of video or audio to iOS devices.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-traffic-origin-hls#available-for)

- Media Services Live (Stream Packaging)

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-traffic-origin-hls#notification-time)

- **New Alert** - The condition is present for three to four minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-traffic-origin-hls#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- The origin traffic volume (in megabits per second) per CP code necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.