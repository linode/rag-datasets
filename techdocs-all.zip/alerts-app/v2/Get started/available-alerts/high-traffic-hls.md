# [High Traffic -- HLS](https://techdocs.akamai.com/alerts-app/docs/high-traffic-hls#high-traffic-hls)

This alert notifies you that the traffic volume exceeded a set threshold. You can set this alert to monitor multiple CP codes.

It applies only to HTTP live streaming (HLS) - a streaming protocol developed by Apple for online streaming of video or audio to iOS devices.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-traffic-hls#available-for)

- Media Services Live (Stream Packaging)

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-traffic-hls#notification-time)

- **New Alert** - The condition is present for three to four minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-traffic-hls#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure** ).

- The traffic volume (in megabits per second) necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-traffic-hls#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.