# [Stale playlist detected](https://techdocs.akamai.com/alerts-app/docs/stale-playlist-detected#stale-playlist-detected)

This alert notifies you that the bit rate playlist (in the `.m3u8` file format) for the configured live stream has not been uploaded for more than five minutes.

You can set this alert to monitor up to 10 streams.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/stale-playlist-detected#available-for)

- Media Services Live (HLS/HDS/DASH Ingest)

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/stale-playlist-detected#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/stale-playlist-detected#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/stale-playlist-detected#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.