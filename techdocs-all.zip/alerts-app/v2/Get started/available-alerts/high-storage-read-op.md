# [High Storage Read Operations](https://techdocs.akamai.com/alerts-app/docs/high-storage-read-op#high-storage-read-operations)

This alert notifies you when the read operation traffic for the CP codes exceeds a specified limit.

You can set it to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-storage-read-op#available-for)

- NetStorage

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-storage-read-op#notification-time)

- **New Alert** - The condition is present for five minutes.
- **Alert Cleared** - The condition is cleared for 30 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-storage-read-op#threshold-configuration)

You need to set the total read operation in terms of requests per second. You must also select whether you want to receive a notification when at least one of the CP codes reaches the threshold or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-storage-read-op#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.