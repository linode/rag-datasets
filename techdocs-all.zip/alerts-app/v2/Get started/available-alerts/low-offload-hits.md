# [Low Offload Hits](https://techdocs.akamai.com/alerts-app/docs/low-offload-hits#low-offload-hits)

**Offload hits** is the percentage of hits from the edge servers compared to the hits from the origin server. This alert notifies you that this percentage for a selected CP code dropped below a set threshold.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/low-offload-hits#available-for)

- Adaptive Media Delivery
- Download Delivery
- HTTP Content Delivery
- HTTP Downloads
- Media Services Live (HLS/HDS/DASH Ingest)
- Media Services Live (Smooth Ingest Enablement)
- Media Services Live (Stream Packaging)
- Media Services On Demand (Smooth Streaming Enablement)
- Media Services On Demand (Stream Packaging)
- Object Delivery
- Progressive Media
- Site Accelerator
- Site Accelerator Fast File Upload
- Site Defender
- Terra Alta Enterprise Accelerator
- Terra Alta Enterprise Accelerator Fast File Upload
- Web Application Accelerator
- Web Application Accelerator Fast File Upload

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/low-offload-hits#notification-time)

- **New Alert** - The condition is present for three to four minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/low-offload-hits#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- The minimum offload hits and the maximum number of hits per second to the origin server necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/low-offload-hits#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.