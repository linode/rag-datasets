# [BOCC: High Error Rate (Multicaster-SMM) (StreamId)](https://techdocs.akamai.com/alerts-app/docs/bocc-high-err-rate-multicaster-smm-streamid#bocc-high-error-rate-multicaster-smm-streamid)

This alert notifies you that the percentage of connections with an error between a multicaster and SMM reached a set threshold.

You can set this alert to monitor multiple streams.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/bocc-high-err-rate-multicaster-smm-streamid#available-for)

- BOSS Monitor

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/bocc-high-err-rate-multicaster-smm-streamid#notification-time)

- **New Alert** - The alert is present for 15 to 20 minutes.
- **Alert Cleared** - The alert is cleared for 30 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/bocc-high-err-rate-multicaster-smm-streamid#threshold-configuration)

You need to set the percentage of connections with errors necessary to trigger the alert. You must also select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/bocc-high-err-rate-multicaster-smm-streamid#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.