# [High Page View Usage](https://techdocs.akamai.com/alerts-app/docs/high-page-view-usage#high-page-view-usage)

This alert notifies you that the percentage of page views reached a set threshold of your account's monthly allowance.

You can set it to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-page-view-usage#available-for)

- Site Accelerator
- Site Defender
- Terra Alta Enterprise Accelerator
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-page-view-usage#notification-time)

- **New Alert** - The condition is present for five to six minutes.
- **Alert Cleared** - The condition is cleared for five to six minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-page-view-usage#threshold-configuration)

You need to set the percentage of the monthly page view allowance necessary to trigger the alert. You must also select whether the alert should fire when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-page-view-usage#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.