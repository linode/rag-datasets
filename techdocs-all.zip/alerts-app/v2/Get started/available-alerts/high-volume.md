# [High Volume](https://techdocs.akamai.com/alerts-app/docs/high-volume#high-volume)

This alert notifies you if the billable edge traffic usage volume for the current calendar month-to-date exceeded a set threshold.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-volume#available-for)

- Adaptive Media Delivery
- Download Delivery
- HTTP Content Delivery
- HTTP Downloads
- Media Services Live (HLS/HDS/DASH Ingest)
- Media Services Live (Smooth Ingest Enablement)
- Media Services Live (Stream Packaging)
- Media Services On Demand (Smooth Streaming Enablement)
- Media Services On Demand (Stream Packaging)
- Object Delivery
- Progressive Media

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-volume#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for 30 to 31 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-volume#threshold-configuration)

You need to set the monthly edge volume (in megabytes) necessary to trigger the alert. Also, you must select whether the alert should fire when the threshold is reached for one of the selected CP codes or all of them combined.

 > Note: 
  Even if your contract is billed for midgress, don't include it in the threshold.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-volume#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.