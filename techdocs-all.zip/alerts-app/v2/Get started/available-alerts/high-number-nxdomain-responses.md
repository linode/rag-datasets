# [High number of NXDOMAIN responses](https://techdocs.akamai.com/alerts-app/docs/high-number-nxdomain-responses#high-number-of-nxdomain-responses)

This alert notifies you that the number of NXDOMAIN responses exceeded a set threshold. The NXDOMAIN response means that DNS could not resolve the domain name. It indicates that the domain doesn't exist.

You can set this alert to monitor multiple DNS zones.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-number-nxdomain-responses#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-number-nxdomain-responses#notification-time)

- **New Alert** - The condition is present for three to five minutes.
- **Alert Cleared** - The condition is cleared for 15 to 17 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-number-nxdomain-responses#threshold-configuration)

You need to set the number of NXDOMAIN responses per second necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-number-nxdomain-responses#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.