# [Expired Default certificate](https://techdocs.akamai.com/alerts-app/docs/expired-default-certificate#expired-default-certificate)

This alert notifies you when a Default DV certificate expires. To make sure it renews automatically, verify your DNS includes the CNAME record with the ACME validation challenge.

You can set this alert to monitor multiple Default DV certificates.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/expired-default-certificate#available-for)

- Media Delivery: Adaptive Media Delivery, Download Delivery, HTTP Content Delivery, HTTP Downloads, Object Delivery, Media Services Live (HLS/HDS/DASH Ingest), Media Services Live 4, Progressive Media, RTMP Streaming, RTMP/WMS/Quicktime Live Streaming, RTMP/WMS/Quicktime On Demand Streaming, Media Services Live (Smooth Ingest Enablement), Media Services On Demand (Stream Packaging), Media Services On Demand (Smooth Streaming Enablement)
- Security: Site Defender
- Web Performance: DataStream 2, EdgeComputing, IP Application Accelerator, Edge DNS, NetStorage, Session Accelerator, Site Accelerator, Site Accelerator Fast File Upload, Site Accelerator SLA Management, Site Accelerator Third Party Optimization, Site Delivery, Terra Alta Enterprise Accelerator, Terra Alta Enterprise Accelerator Composite Application Acceleration, Terra Alta Enterprise Accelerator Fast File Upload, Terra Alta Enterprise Accelerator SLA Management, Traffic Management, Web Application Accelerator SLA Management, Web Application Accelerator, Web Application Accelerator Fast File Upload

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/expired-default-certificate#notification-time)

- **New Alert** - The condition is present up to 5 minutes.
- **Alert Cleared** - The condition is cleared for 5 to 30 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/expired-default-certificate#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/expired-default-certificate#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.