# [DS record points to wrong DNSKEY record](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-wrong-dnskey-record#ds-record-points-to-wrong-dnskey-record)

This alert notifies you that the DS record handed out by the parent zone points to the wrong DNSKEY record for the zone. DNS resolvers with DNSSEC validation enabled could fail to resolve names in the zone, resulting in a denial of service.

You can set this alert to monitor multiple DNS zones.

> Info: To create this alert, you need to have the `ALERTS_DNSSEC` scope. For more information, contact your account administrator.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-wrong-dnskey-record#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-wrong-dnskey-record#notification-time)

- **New Alert** - The condition is present for 10 to 12 minutes.
- **Alert Cleared** - The condition is cleared for three to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-wrong-dnskey-record#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/ds-record-points-wrong-dnskey-record#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.