# [Dynamic Flash (Ingest) Stream is Unavailable](https://techdocs.akamai.com/alerts-app/docs/dynamic-flash-ingest-stream-unavailable#dynamic-flash-ingest-stream-is-unavailable)

This alert notifies you that the connection between your encoder and the entry point for a particular stream, or a set of streams, broke. This alert is only intended for constantly streaming live streams.

You can set this alert to monitor multiple streams.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/dynamic-flash-ingest-stream-unavailable#available-for)

- Media Services Live (Stream Packaging)
- Media Services Live (Smooth Ingest Enablement)
- RTMP/WMS/Quicktime Live Streaming
- RTMP Streaming
- RTMP/WMS/Quicktime On Demand Streaming

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/dynamic-flash-ingest-stream-unavailable#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/dynamic-flash-ingest-stream-unavailable#threshold-configuration)

You need to select which stream you want to monitor (primary or backup) and the time for which the stream must be down to trigger the alert. You must also select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/dynamic-flash-ingest-stream-unavailable#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.