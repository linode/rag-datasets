# [Origin Connection Failure](https://techdocs.akamai.com/alerts-app/docs/origin-connection-failure#origin-connection-failure)

This alert notifies you that the edge servers successfully performed the DNS lookup but were unable to make contact with the origin server. It could be caused by network connectivity problems or a server being down.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/origin-connection-failure#available-for)

- Adaptive Media Delivery
- HTTP Content Delivery
- HTTP Downloads
- IBM WebSphere Application Accelerator - HN 3rd Party Applications File Transfers
- Ion Premier. Media Services Live (Smooth Ingest Enablement)
- Media Services Live (Stream Packaging)
- Media Services On Demand (Smooth Streaming Enablement)
- Media Services On Demand (Stream Packaging)
- Progressive Media. Site Accelerator Fast File Upload
- Site Accelerator. Site Defender
- Terra Alta Enterprise Accelerator Fast File Upload
- Terra Alta Enterprise Accelerator
- Web Application Accelerator Fast File Upload
- Web Application Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/origin-connection-failure#notification-time)

- **New Alert** - The condition is present for six to eight minutes.
- **Alert Cleared** - The condition is cleared for five to seven minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/origin-connection-failure#threshold-configuration)

You need to set:

- A type of traffic to be monitored (**Secure**, **Non-Secure**, or **Either Non-Secure or Secure**).

- The percentage of failed connections and their number necessary to trigger the alert.

- Whether the alert should be triggered when the threshold is reached for one of the selected CP codes or all of them combined.
# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/origin-connection-failure#troubleshooting)

The majority of troubleshooting methods are listed in the **Troubleshooting** section on the alert's page. Here are some additional suggestions:

- To issue an HTTP request for the page or object, you can try one of the following methods:

    - Go to the origin site in a browser.

    - Use a tool like wget, curl, wfetch or similar tools (other than a browser) to issue an HTTP request against the origin server.

    - Telnet to port 80 on each origin server and issue an HTTP GET.

- Check for any data center connectivity
            issues near the origin server by doing traceroutes, pings, or mtrs to the origin server.
            If possible, check connectivity from multiple machines in different networks and
            locations.

- If you have multiple origin servers and one of them is down, check to ensure that the
            load balancer or router is not directing any incoming requests to the down origin
            server.

- To obtain more detailed information as
            to which specific URLs generated the error, you can look at your Log Delivery Service
            logs, if you subscribe to the service. Within the Log Delivery Service logs, look at log
            lines that correspond to the time the alert triggered. Log lines that reflect problems
            connecting to the origin server will most likely have a 500 series status code in the
            HTTP status column.