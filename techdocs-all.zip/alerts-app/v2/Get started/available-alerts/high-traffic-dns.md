# [High Traffic - DNS](https://techdocs.akamai.com/alerts-app/docs/high-traffic-dns#high-traffic-dns)

This alert notifies you that the volume of DNS traffic for a particular zone went above a set threshold.

You can set this alert to monitor multiple DNS Zones.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-traffic-dns#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-traffic-dns#notification-time)

- **New Alert** - The condition is present for three to five minutes.
- **Alert Cleared** - The condition is cleared for 15 to 18 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-traffic-dns#threshold-configuration)

You need to set the number of DNS traffic requests per second necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-traffic-dns#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.