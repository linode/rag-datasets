# [Stream Failure](https://techdocs.akamai.com/alerts-app/docs/stream-failure#stream-failure)

This alert notifies you that the number of agents unable to play the test object or page exceeded a set threshold.

You can set this alert to monitor multiple stream analyzer tests.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/stream-failure#available-for)

- Performance Analytics Stream Analyzer

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/stream-failure#notification-time)

- **New Alert** - Up to five minutes since the detection of the condition.
- **Alert Cleared** - The condition is cleared for three to eight minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/stream-failure#threshold-configuration)

You need to set the number of agents which must fail to play the stream to trigger the alert. You must also select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/stream-failure#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.