# [High Concurrent Sessions](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-sessions#high-concurrent-sessions)

This alert notifies you that the number of concurrent sessions for a contract exceeded a set threshold.

You can set this alert to monitor contracts.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-sessions#available-for)

- Session Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-sessions#notification-time)

- **New Alert** - The condition is present for four to five minutes.
- **Alert Cleared** - The condition is cleared for four to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-sessions#threshold-configuration)

You need to set a number of concurrent sessions necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-concurrent-sessions#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.