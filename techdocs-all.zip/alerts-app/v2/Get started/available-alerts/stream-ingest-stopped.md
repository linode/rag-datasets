# [Stream Ingest Stopped](https://techdocs.akamai.com/alerts-app/docs/stream-ingest-stopped#stream-ingest-stopped)

This alert notifies you that the encoder stopped uploading content for the configured live stream.

You can set this alert to monitor up to 10 streams.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/stream-ingest-stopped#available-for)

- Media Services Live (HLS/HDS/DASH Ingest)

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/stream-ingest-stopped#notification-time)

- **New Alert** - The condition is cleared for two to three minutes.
- **Alert Cleared** - The condition is cleared for three to four minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/stream-ingest-stopped#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/stream-ingest-stopped#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.