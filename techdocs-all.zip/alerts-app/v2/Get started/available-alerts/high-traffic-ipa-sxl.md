# [High Traffic -- IPA/SXL](https://techdocs.akamai.com/alerts-app/docs/high-traffic-ipa-sxl#high-traffic-ipasxl)

This alert notifies you that the traffic volume exceeded a set threshold.

You can set this alert to monitor multiple contracts.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-traffic-ipa-sxl#available-for)

- IP Accelerator
- Session Accelerator

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-traffic-ipa-sxl#notification-time)

- **New Alert** - The condition is present for four to five minutes.
- **Alert Cleared** - The condition is cleared for four to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-traffic-ipa-sxl#threshold-configuration)

You need to set the traffic volume (in megabits per second) necessary to trigger the alert.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-traffic-ipa-sxl#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.