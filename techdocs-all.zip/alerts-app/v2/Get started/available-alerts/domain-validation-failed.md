# [Domain validation failed](https://techdocs.akamai.com/alerts-app/docs/domain-validation-failed#domain-validation-failed)

This alert notifies you when a certificate cannot be issued because DNS validation failed.

You can set this alert to monitor multiple properties.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/domain-validation-failed#available-for)

- Media Delivery: Adaptive Media Delivery, Download Delivery, HTTP Content Delivery, HTTP Downloads, Media Services Live (HLS/HDS/DASH Ingest), Media Services Live (Smooth Ingest Enablement), Media Services Live (Stream Packaging),  Media Services Live 4, NetStorage, Object Delivery, Progressive Media, RTMP Streaming, RTMP/WMS/Quicktime Live Streaming, RTMP/WMS/Quicktime On Demand Streaming
- Security: Site Defender
- Web Performance: DataStream 2, EdgeComputing, Edge DNS, IP Application Accelerator, Session Accelerator, Site Accelerator, Site Accelerator Fast File Upload, Site Accelerator SLA Management, Site Accelerator Third Party Optimization, Site Delivery, Terra Alta Enterprise Accelerator, Terra Alta Enterprise Accelerator Composite Application Acceleration, Terra Alta Enterprise Accelerator Fast File Upload, Terra Alta Enterprise Accelerator SLA Management, Third Party Optimization, Traffic Management, Web Application Accelerator, Web Application Accelerator Fast File Upload, Web Application Accelerator SLA Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/domain-validation-failed#notification-time)

- **New Alert** - The condition is present for 5 to 10 minutes.
- **Alert Cleared** - The condition is cleared for 15 to 20 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/domain-validation-failed#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/domain-validation-failed#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.