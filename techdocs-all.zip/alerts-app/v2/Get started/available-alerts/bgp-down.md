# [BGP Down](https://techdocs.akamai.com/alerts-app/docs/bgp-down#bgp-down)

This alert notifies you that the Direct Connect BGP session went down.

With Direct Connect, you set up a physical connection to a router port via BGP. This alert fires when a BGP session on a Direct Connect router goes down.

Learn more about setting up [Direct Connect Alerts](https://techdocs.akamai.com/direct-connect/docs/enable-alert-notif).