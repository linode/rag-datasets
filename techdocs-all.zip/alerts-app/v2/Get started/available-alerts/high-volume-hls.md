# [High Volume -- HLS](https://techdocs.akamai.com/alerts-app/docs/high-volume-hls#high-volume-hls)

This alert notifies you if the billable edge traffic usage volume for the current calendar month-to-date exceeded a set threshold.

This alert applies only to HTTP live streaming (HLS) - a streaming protocol developed by Apple for online streaming of video or audio to iOS devices. It can monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-volume-hls#available-for)

- Media Services Live (Stream Packaging)

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-volume-hls#notification-time)

- **New Alert** - The condition is present for two to three minutes.
- **Alert Cleared** - The condition is cleared for 30 to 31 minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-volume-hls#threshold-configuration)

You need to set the monthly edge volume (in megabytes) necessary to trigger the alert. Also, you must select whether the alert should fire when the threshold is reached for one of the selected CP codes or all of them combined.

 > Note: 
  Even if your contract is billed for midgress, don't include it in the threshold.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-volume-hls#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.