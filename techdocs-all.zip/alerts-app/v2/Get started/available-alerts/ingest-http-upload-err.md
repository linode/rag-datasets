# [Ingest HTTP Upload Errors](https://techdocs.akamai.com/alerts-app/docs/ingest-http-upload-err#ingest-http-upload-errors)

This alert notifies you that the percentage of upload HTTP errors (other than 200 status code) per iOS stream ID reached the set threshold.

You can set this alert to monitor multiple streams.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/ingest-http-upload-err#available-for)

- Media Services Live (HLS/HDS/DASH Ingest)

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/ingest-http-upload-err#notification-time)

- **New Alert** - The condition is present for four to six minutes.
- **Alert Cleared** - The condition is cleared for three to five minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/ingest-http-upload-err#threshold-configuration)

You need to set a file type to be monitored and the percentage of failed connections necessary to trigger the alert. Also, you must select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/ingest-http-upload-err#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page