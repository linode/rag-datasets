# [Stream BitRate](https://techdocs.akamai.com/alerts-app/docs/stream-bitrate#stream-bitrate)

This alert notifies you that the number of agents playing a stream with a lower than a specified bit rate reached a set threshold.

You can set this alert to monitor multiple stream analyzer tests.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/stream-bitrate#available-for)

- Performance Analytics Stream Analyzer

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/stream-bitrate#notification-time)

- **New Alert** - Up to five minutes since the detection of the condition.
- **Alert Cleared** - The condition is cleared for three to eight minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/stream-bitrate#threshold-configuration)

You need to set the number of agents and their bit rate necessary to trigger the alert. You must also select when you want the alert to be active.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/stream-bitrate#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.