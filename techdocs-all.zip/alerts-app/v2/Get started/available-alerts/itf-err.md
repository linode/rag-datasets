# [Interface errors](https://techdocs.akamai.com/alerts-app/docs/itf-err#interface-errors)

This alert notifies you that the Direct Connect router is experiencing issues sending or receiving packets.

With Direct Connect, you set up a physical connection to a router port in a data center. This alert fires when the router is experiencing issues sending or receiving packets, and the number of errors has increased past a given threshold.

Learn more about setting up [Direct Connect Alerts](https://techdocs.akamai.com/direct-connect/docs/enable-alert-notif).