# [Customer Datacenter Down](https://techdocs.akamai.com/alerts-app/docs/customer-datacenter-down#customer-datacenter-down)

This alert notifies you when Traffic Management decides not to send any traffic to the data center because the servers in the data center don't meet its liveness criteria.

See [Determine server liveness](https://techdocs.akamai.com/gtm/docs/gtm-concepts#determine-server-liveness) for an overview of liveness tests.

You can set this alert to monitor multiple properties.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/customer-datacenter-down#available-for)

- Traffic Management

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/customer-datacenter-down#notification-time)

- **New Alert** - The condition is present for four to five minutes.
- **Alert Cleared** - The condition is cleared for five to six minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/customer-datacenter-down#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/customer-datacenter-down#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.