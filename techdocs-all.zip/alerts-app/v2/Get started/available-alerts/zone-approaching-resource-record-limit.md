# [Zone Approaching Resource Record Limit](https://techdocs.akamai.com/alerts-app/docs/zone-approaching-resource-record-limit#zone-approaching-resource-record-limit)

This alert notifies you when an Edge DNS zone has grown in resource records up to nearly the limit allowed for the zone. The default limit is 100,000 records.

You can set this alert to monitor multiple DNS Zones.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/zone-approaching-resource-record-limit#available-for)

- Edge DNS

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/zone-approaching-resource-record-limit#notification-time)

- **New Alert** - The condition is present for six to nine minutes.
- **Alert Cleared** - The condition is cleared for three to six minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/zone-approaching-resource-record-limit#threshold-configuration)

None required

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/zone-approaching-resource-record-limit#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.