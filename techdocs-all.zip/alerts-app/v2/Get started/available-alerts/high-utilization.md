# [High Utilization](https://techdocs.akamai.com/alerts-app/docs/high-utilization#high-utilization)

This alert notifies you that the Direct Connect router utilization exceeded a defined threshold.

With Direct Connect, you set up a physical connection to a router port in a data center. This alert fires when the Direct Connect router utilization exceeds a defined threshold for an extended period of time.

Learn more about setting up [Direct Connect Alerts](https://techdocs.akamai.com/direct-connect/docs/enable-alert-notif).