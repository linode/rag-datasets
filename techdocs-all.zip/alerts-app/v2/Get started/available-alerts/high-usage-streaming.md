# [High Usage -- Streaming](https://techdocs.akamai.com/alerts-app/docs/high-usage-streaming#high-usage-streaming)

This alert notifies you that the total streaming bandwidth for the current calendar month exceeded a set threshold.

You can set this alert to monitor multiple CP codes.

# [Available for](https://techdocs.akamai.com/alerts-app/docs/high-usage-streaming#available-for)

- Media Services Live (Stream Packaging)
- Media Services On Demand (Stream Packaging)
- RTMP Streaming
- RTMP/WMS/Quicktime Live Streaming
- RTMP/WMS/Quicktime On Demand Streaming

# [Notification time](https://techdocs.akamai.com/alerts-app/docs/high-usage-streaming#notification-time)

- **New Alert** - The condition is present for five to six minutes.
- **Alert Cleared** - The condition is cleared for five to six minutes.

# [Threshold configuration](https://techdocs.akamai.com/alerts-app/docs/high-usage-streaming#threshold-configuration)

You need to set the monthly streaming volume (in megabytes) necessary to trigger the alert. Also, you must select whether the alert should fire when the threshold is reached for one of the selected CP codes or all of them combined.

# [Troubleshooting](https://techdocs.akamai.com/alerts-app/docs/high-usage-streaming#troubleshooting)

Follow the instructions from the **Troubleshooting** section on the alert's page.