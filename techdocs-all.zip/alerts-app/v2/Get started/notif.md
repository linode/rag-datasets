# [Notifications](https://techdocs.akamai.com/alerts-app/docs/notif#notifications)

When you create an alert, you can set who needs to be notified if that alert fires.

The designated recipients receive two notifications:

- **New Alert**. Sent when the threshold is reached or crossed and the event exists for a specific time. This notification provides all available information about the alert. Because of the large amount of data on the network, the alerting system reports only the occurrence of the alert and not its cause. The possible reasons for the alert are outlined in the alert's description and it's enough for further historical investigation.

- **Alert Cleared**. Sent when the alert condition is cleared. This message shows the data from the last time the alert was active, so you can see the values above the threshold.

You can get the notifications in two ways:

- **Via email**. The Alerts application sends a detailed description of the alert.

- **Via email-to-text**. The Alerts application sends basic alert information.

They are sent with a delay caused by the time necessary for the data retrieval process Akamai must perform to monitor the alert conditions. The time between detecting the alert status change and sending the notification differs for each alert. To learn about the precise times, read the alerts' descriptions.

All messages are confidential and encrypted with the Secure Sockets Layer (SSL) protocol.