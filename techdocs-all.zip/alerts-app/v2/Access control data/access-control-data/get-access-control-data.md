# [List access control data](https://techdocs.akamai.com/alerts-app/docs/get-access-control-data#list-access-control-data)
