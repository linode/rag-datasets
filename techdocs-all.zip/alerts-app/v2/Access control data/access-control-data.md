# [Access control data](https://techdocs.akamai.com/alerts-app/docs/access-control-data#access-control-data)
