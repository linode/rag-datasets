# [List active alerts](https://techdocs.akamai.com/alerts-app/docs/get-active-alert-firings#list-active-alerts)
