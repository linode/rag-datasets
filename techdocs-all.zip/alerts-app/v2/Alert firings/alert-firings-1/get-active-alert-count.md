# [Count active alerts](https://techdocs.akamai.com/alerts-app/docs/get-active-alert-count#count-active-alerts)
