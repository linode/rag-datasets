# [Alerts API v2](https://techdocs.akamai.com/alerts-app/docs/alerts-api-v2#alerts-api-v2)
