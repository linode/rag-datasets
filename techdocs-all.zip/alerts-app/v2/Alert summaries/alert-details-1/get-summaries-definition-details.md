# [Get alert details](https://techdocs.akamai.com/alerts-app/docs/get-summaries-definition-details#get-alert-details)
