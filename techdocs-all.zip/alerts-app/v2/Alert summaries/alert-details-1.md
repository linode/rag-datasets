# [Alert details](https://techdocs.akamai.com/alerts-app/docs/alert-details-1#alert-details)
