# [List alert summaries](https://techdocs.akamai.com/alerts-app/docs/get-summaries#list-alert-summaries)
