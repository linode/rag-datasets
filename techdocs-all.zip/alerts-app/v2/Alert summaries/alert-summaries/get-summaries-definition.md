# [Get an alert summary](https://techdocs.akamai.com/alerts-app/docs/get-summaries-definition#get-an-alert-summary)
