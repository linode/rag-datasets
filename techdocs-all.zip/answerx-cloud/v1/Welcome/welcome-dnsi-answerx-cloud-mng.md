# [Welcome to DNSi AnswerX Cloud/Managed and SPS Shield](https://techdocs.akamai.com/answerx-cloud/docs/welcome-dnsi-answerx-cloud-mng#welcome-to-dnsi-answerx-cloudmanaged-and-sps-shield)

DNSi AnswerX is an intelligent, carrier-grade, recursive DNS (rDNS) product and service that is designed to manage DNS traffic. Featuring subscriber awareness, a high performance policy engine and extensible language, a resilient architecture, and the ability to process millions of transactions per second, DNSi AnswerX can help lower network costs and secure critical DNS infrastructure. Subscriber awareness allows customers to offer value-added service options—such as parental controls and malware detection and prevention—while enhancing the customer’s ability to deliver better, faster service to subscribers. 

To provide the flexibility to deploy and use DNSi AnswerX in a way that best matches your cost and operational needs, Akamai offers a choice of several deployment models:

- [**DNSi AnswerX SPS Shield**](https://techdocs.akamai.com/answerx-cloud/docs/sps-shield-ovw) is a cloud service that's based on Akamai’s cloud recursive DNS resolver and DNSi AnswerX Cloud technology. SPS Shield enables Internet Service Providers (ISPs) and Mobile Network Operators (MNOs) to offer essential security services to their small and midsize businesses (SMBs) and residential subscribers without IT integration. 
- [**DNSi AnswerX Cloud**](https://techdocs.akamai.com/answerx-cloud/docs/ax-cloud-ovw) is a separate cloud service that's managed and maintained by Akamai technical experts using Akamai’s network. This practice has the advantage of requiring few customer resources. The configuration uses Akamai's rack space, power, and other related equipment. The service is configured individually per customer and executes in performant locations.
- [**DNSi AnswerX Managed**](https://techdocs.akamai.com/answerx-cloud/docs/ax-cloud-ovw) is similar to Cloud and extends Akamai's network onto the carrier’s network. As dedicated capacity for a single customer within the carrier’s network, the system provides subscribers with faster resolution times.
- [**DNSi AnswerX Licensed**](https://control.akamai.com/apps/download-center/#/products/9;name=DNSi-AnswerX) runs on the carrier’s network and Akamai provides system support.

The roles most commonly responsible for managing DNSi AnswerX Cloud/Managed and SPS Shield are  site administrators, project managers, and technical support people.

# [Developer tools](https://techdocs.akamai.com/answerx-cloud/docs/welcome-dnsi-answerx-cloud-mng#developer-tools)

- [DNSi AnswerX Reputation Knowledge Server (RKS) API](https://techdocs.akamai.com/answerx-cloud/reference/api) 
- [SPS Shield: SIA Configuration API](https://techdocs.akamai.com/etp-config/reference/api)
- [SPS Shield: SIA Reporting API](https://techdocs.akamai.com/etp-reporting/reference/api) 

# [Tips and best practices](https://techdocs.akamai.com/answerx-cloud/docs/welcome-dnsi-answerx-cloud-mng#tips-and-best-practices)

- Find answers with [​Akamai Control Center​ Administration Support](https://control.akamai.com/apps/support-ui/#/contact-support)
- Learn more in the [Akamai Network Operator Community](https://community.akamai.com/customers/s/topic/0TO0f000000duepGAA/network-operator-community?language=en_US)

# [What's new](https://techdocs.akamai.com/answerx-cloud/docs/welcome-dnsi-answerx-cloud-mng#whats-new)

- [Release notes](https://techdocs.akamai.com/answerx-cloud/changelog)