# [Check service status](https://techdocs.akamai.com/answerx-cloud/docs/get-health-check#check-service-status)
