# [Service instances](https://techdocs.akamai.com/answerx-cloud/docs/service-instances#service-instances)
