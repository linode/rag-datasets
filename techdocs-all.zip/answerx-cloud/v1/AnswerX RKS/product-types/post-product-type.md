# [Update tables by product type](https://techdocs.akamai.com/answerx-cloud/docs/post-product-type#update-tables-by-product-type)
