# [Delete a row by product type](https://techdocs.akamai.com/answerx-cloud/docs/delete-product-type#delete-a-row-by-product-type)
