# [Get table data by product type](https://techdocs.akamai.com/answerx-cloud/docs/get-product-type#get-table-data-by-product-type)
