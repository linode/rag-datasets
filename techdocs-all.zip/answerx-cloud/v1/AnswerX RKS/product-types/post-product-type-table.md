# [Add or update a row by product type](https://techdocs.akamai.com/answerx-cloud/docs/post-product-type-table#add-or-update-a-row-by-product-type)
