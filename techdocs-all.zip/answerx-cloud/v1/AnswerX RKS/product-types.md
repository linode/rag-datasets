# [Product types](https://techdocs.akamai.com/answerx-cloud/docs/product-types#product-types)
