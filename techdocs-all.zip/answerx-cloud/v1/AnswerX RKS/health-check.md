# [Health check](https://techdocs.akamai.com/answerx-cloud/docs/health-check#health-check)
