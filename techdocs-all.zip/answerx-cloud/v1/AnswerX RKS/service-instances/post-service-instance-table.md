# [Add or update a row by service instance](https://techdocs.akamai.com/answerx-cloud/docs/post-service-instance-table#add-or-update-a-row-by-service-instance)
