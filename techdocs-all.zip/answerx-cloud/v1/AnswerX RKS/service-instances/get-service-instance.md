# [Get table data by service instance](https://techdocs.akamai.com/answerx-cloud/docs/get-service-instance#get-table-data-by-service-instance)
