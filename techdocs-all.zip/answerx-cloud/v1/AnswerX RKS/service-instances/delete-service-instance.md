# [Delete a row by service instance](https://techdocs.akamai.com/answerx-cloud/docs/delete-service-instance#delete-a-row-by-service-instance)
