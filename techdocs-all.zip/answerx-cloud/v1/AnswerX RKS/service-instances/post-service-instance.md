# [Update tables by service instance](https://techdocs.akamai.com/answerx-cloud/docs/post-service-instance#update-tables-by-service-instance)
