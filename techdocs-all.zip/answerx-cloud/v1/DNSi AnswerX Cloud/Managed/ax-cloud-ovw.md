# [Overview](https://techdocs.akamai.com/answerx-cloud/docs/ax-cloud-ovw#overview)

This section describes how to configure, customize, monitor, and report on two DNSi AnswerX deployment models: DNSi AnswerX Cloud and DNSi AnswerX Managed. 

# [DNSi AnswerX Cloud ](https://techdocs.akamai.com/answerx-cloud/docs/ax-cloud-ovw#dnsi-answerx-cloud)

DNSi AnswerX Cloud is an Internet cloud service that is managed and maintained by using Akamai’s network. This practice has the advantage of requiring few customer resources. The configuration uses Akamai's rack space, power, and other related equipment. The service is configured individually per customer and executes in performant locations.

DNSi AnswerX Cloud is a good choice for operators seeking to completely outsource DNS infrastructure but still deliver premium levels of internet performance and reliability as well as service differentiation. Offered as a fully managed service to network operators and ISPs, the network operator directs subscriber DNS queries to DNSi AnswerX resolvers located within the Akamai Intelligent Network, the world's premier distributed cloud services platform. DNSi AnswerX Cloud offers high-speed name resolution and highly accurate end-user mapping to ensure rapid delivery of Internet content. 

DNSi AnswerX Cloud also makes an excellent disaster recovery solution for operators who have existing on-net DNS infrastructure, but realize that a DNS outage could cause serious consequences related to customer satisfaction and its reputation as a service provider. With DNSi AnswerX Cloud for disaster recovery, if a primary DNS outage occurs, Internet communications would continue uninterrupted, with DNS queries redirected to the DNSi AnswerX Cloud platform.

# [DNSi AnswerX Managed ](https://techdocs.akamai.com/answerx-cloud/docs/ax-cloud-ovw#dnsi-answerx-managed)

DNSi AnswerX Managed is similar to Cloud and extends Akamai's network onto the carrier’s network. It is a dedicated installation of Akamai’s DNSi AnswerX recursive DNS (rDNS) resolver that is fully managed by Akamai. As dedicated capacity for a single customer within the carrier’s network, the system provides subscribers with faster resolution times.