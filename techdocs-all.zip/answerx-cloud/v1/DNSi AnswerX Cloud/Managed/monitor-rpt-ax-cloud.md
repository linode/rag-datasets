# [Monitor and report on health and metrics](https://techdocs.akamai.com/answerx-cloud/docs/monitor-rpt-ax-cloud#monitor-and-report-on-health-and-metrics)

# [Report types](https://techdocs.akamai.com/answerx-cloud/docs/monitor-rpt-ax-cloud#report-types)
You can monitor the health and metrics of your DNSi AnswerX Cloud/Managed services by creating reports on ​Akamai Control Center​. Here's a description of each report type.

- **Request vs Response**. Recursive DNS requests versus responses. Shows how much traffic your network is receiving. Increased request and response volume indicates an increase in network traffic. If the **Responses** value dips significantly below **Requests**, this behavior might indicate an issue that should be closely evaluated. 

    Roll over the chart to see the precise number of requests and responses at a given time. This report shows the total activity and service performance for the number of queries during a predetermined time interval that is proportional to the **Select Time Period** value. For example, if you set **Select Time Period** to **Past 1 Day**, the **Data Granularity** value is **Every Five Minutes**. In contrast, if you set **Select Time Period** to **Past 1 Month**, the **Data Granularity** value is **Every Day**.

- **Request**. Recursive DNS requests  by region. Shows the number of DNS requests by different autonomous systems (AS) regions. Use this information to assist in determining what volume of DNS requests are originating from different AS regions. For an explanation of the numeric color-coded region values, speak with your Akamai account manager.

- **Response**. Recursive DNS responses by region. Also shows DNS responses by caching status and response type. Use these views to see how many requests are serviced from a resolver's cache or how many responses were positive (requested domain could be resolved) or negative (requested domain could not be resolved). For an explanation of the color-coded numeric region values in the key at the bottom of the chart, speak with your Akamai account manager.

- **Response Time SLA**. Responses by response speed or response time. Also shows the average and minimum DNS response times. The latter information is representative of how quickly requests are resolved on average and how quickly the fastest requests are resolved.

- **Service Availability SLA**. Service availability and response volume. Shows the availability of a service over time and the volume of requests processed by the service. Evaluate this report to see the amount of time a service is available and to correlate service availability with volume of responses served.
 > Note: Response Time SLA and Service Availability SLA reports
  The **Response Time SLA** and **Service Availability SLA** reports are important in showing how well DNSi AnswerX is performing as a function of contractually agreed-upon metrics.

- **Top Usage**. Shows the top source IPs consuming the service capacity and the top domains these source IPs are requesting.  Also shows the top domains blocked and top domains allowed, and the top IPs requesting blocked and allowed domains.

# [Create a report](https://techdocs.akamai.com/answerx-cloud/docs/monitor-rpt-ax-cloud#create-a-report)

1. Log in to [​Control Center​​](https://control.akamai.com/apps/home-page/#/home) using your Akamai account.

    > > Note: 
    >
    > If you need a username and password, contact your account manager.

1. On the left side of the top menu bar, from the **Search** list, select **Accounts**. 

1. In the **Search** field, start to type your account name, which frequently starts with the first few letters of your company name. Your account name should appear as a suggested value under the search field. Select it. 

1. Go to ☰ > **DNS SOLUTIONS** > **Recursive DNS for ISPs**.
    If you have both a Cloud and Managed contract for your account, the **AnswerX Product Types** dialog opens, and you are prompted to select a product type. 
1. Select **Cloud** or **Managed**.

    The **AnswerX Recursive DNS** page corresponding to your product selection opens. Near the bottom of the page are two sections: **Configure Policy** and **Usage Reporting**. 
    
1. Click **Usage Reporting**.

1. From the **Reports** menu, select from the following available [reports](https://techdocs.akamai.com/answerx-cloud/docs/monitor-rpt-ax-cloud#report-types):
    - **Request vs Response**
    - **Request**
    - **Response**
    - **Response Time SLA**
    - **Service Availability SLA**
    - **Top Usage**

    After you select a report, it appears in the chart view below. 

8. To customize the chart view for a report, select filter options. Depending on the report type, you can change the graphic type and filter on time period, region, response type, data granularity, and other items. 

    The chart view is dynamically updated as you select filter options. Rolling over each report chart provides more detailed information about the data. A color-coded key at the bottom of each report provides additional details. 

1. To print a report, or to save the report or its data to a file, click the **Chart context menu** () and select from the following options:
    - **View in full screen**
    - **Print chart**
    - **Download PNG image**
    - **Download JPEG image**
    - **Download PDF document**
    - **Download SVG vector image**
    - **Download CSV**
    - **Download XLS**