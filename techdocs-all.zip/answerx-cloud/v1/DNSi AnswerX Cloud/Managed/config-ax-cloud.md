# [Configure DNSi AnswerX Cloud/Managed](https://techdocs.akamai.com/answerx-cloud/docs/config-ax-cloud#configure-dnsi-answerx-cloudmanaged)
