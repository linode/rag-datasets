# [Configure log delivery](https://techdocs.akamai.com/answerx-cloud/docs/config-lds-ax-cloud#configure-log-delivery)

DNS administrators can find value in reviewing resolver log data, such as traffic to malware domains that can identify
infected clients on the network. This section describes how to configure and use the ​Akamai Control Center​ Log Delivery Service (LDS). 

For additional information, including reference help for the Akamai Log Delivery Service API, see [Log Delivery Service](https://techdocs.akamai.com/log-delivery/docs) (login required).

# [View an LDS configuration](https://techdocs.akamai.com/answerx-cloud/docs/config-lds-ax-cloud#view-an-lds-configuration)
1. Log in to [​Control Center​​](https://control.akamai.com/apps/home-page/#/home) using your Akamai account.

1. Select the account that you want to access. 
    1. On the left side of the top menu bar, from the **Search** list, select **Accounts**. 
    1. In the **Search** field, start to enter your account name. As you start to type, a list of suggestions will appear below the text field from which you can select.

1. Go to ☰ > **COMMON SERVICES**  > **Log delivery**.
    The **Log delivery service** page opens.

1. To see a list of existing log delivery subscriptions for DNSi AnswerX Cloud/Managed, from the **View by** list, select **AnswerX**.
    The table below is filtered to include objects associated with the service.  

1. To view the configuration details associated with an object in the table, complete one of the next steps:
    - Click the object ID or object name.
    - From the **Action** menu () associated with the object, select **View**.
    
    The **Configuration details** dialog opens.

1. When you are done viewing the configuration information, close the dialog.

# [Create a new LDS configuration](https://techdocs.akamai.com/answerx-cloud/docs/config-lds-ax-cloud#create-a-new-lds-configuration)

1. Complete steps 1-4 in [View an LDS configuration](https://techdocs.akamai.com/answerx-cloud/docs/config-lds-ax-cloud#view-an-lds-configuration) above to log in to ​Control Center​​, search for your account, go to the **Log delivery** page, and filter the objects table to see a list of DNSi AnswerX Cloud/Managed objects.

1. In the table row of the object that you want to create a new LDS configuration for, click the **Action** menu () and select the appropriate step:
    - To create a new log delivery configuration for an object that doesn't have an existing configuration, select **Start a log delivery** > **New**.
    - To create a new log delivery configuration for an object that has an existing configuration, select **Shadow** > **New**.

    The **Create a configuration for: ** *objectID*-*objectName* wizard opens to the **Log Configuration** page.

1. Fill in the following information.

     
     Field/Option
     | Description
       
     ---|---  
     
     
     
     
     
       
         **Start date**
         **End date**
       
       | 
         
             
                 * **Start date**. Affects both the start of log collection and log delivery. Log collection begins within 6-8 hours of the start date, and the first delivery is scheduled within two days. 
                     
                 * **End date**. Set to either an actual end date, or an indefinite date by selecting the **Indefinite end date** checkbox. If you set a specific end date, you might get a few empty deliveries before the deliveries end. 
                 
             **Note:** The **Start date** and **End date** values are unrelated to the timestamps of individual log lines; these dates refer to log collection and delivery only.
             **Example:** 12/31/2021
                 
               
               
             
             
             
               
                 **Log format**
               
               | Select a log format from the list.
               
               
             
             
             
               
                 **Log identifier string**
               
               | A unique label that is prepended to the log filename. If you have multiple LDS configurations, the string makes it easier to distinguish between them. 
             Log identifier strings are limited to alphanumeric characters, are case sensitive, and cannot exceed 80 characters. **Example:** If the log identifier string is CompanyProduct, the log filename will be in this format:  CompanyProduct_1.w3c_S.202201019999-9999-0.png
               
               
             
             
             
             
             **Type**
             
             | 
                   Select one of these options:
                   
                       
                 * **Aggregate by log arrival time**. Specifies that you want to receive log data in the order in which it arrives from the edge servers. This is the fastest way to get log data, but it is more difficult to process. For example, a delivery that covers a 24-hour period usually contains some data from the previous several days. 
             You must also select a value from the **Delivery frequency** list to specify the frequency at which you want to receive log data. 
                       
                 * **Aggregate by hit time**. Specifies that you want to receive most of the hits for each GMT calendar day in a single delivery. Complete the following fields:
                            
                                
                     * **Approximate delivery threshold**. You must select a value from this list to specify the threshold at which you would like the log data sent. The higher you set the threshold, the longer you'll wait for your log data to be sent. 
                                  
                     * **Deliver residual data**. Optional. If you select this checkbox, residual data is sent at regular intervals after each day.
                              
                     
                 
                 
               
               
               
               

4. Click **Next**. 
    The **Delivery** page of the **Create a configuration for: **  *objectID*-*objectName* wizard opens.

5. Fill in the following information.

               
               
               Field/Option
               | Description
                 
               ---|---  
               
               
               
               
               
                 
                   **Type** of log delivery**
                 
                 | 
                   Select one of the following options:
                   
                       
                 * **FTP**. Secure delivery type for high log volume. If you have your own log storage infrastructure, FTP is a good choice. Complete the following fields:
                         
                              
                     * **Machine**. FTP server name. 
                                
                     * **Login** , **Password**. Login ID and password.
                                
                     * **Directory**. Directory where you want the logs delivered. To save logs in the FTP user's default directory, leave this field empty. 
                                
                     * **Test**. Optional. To run an FTP connection test, click this button. The test can take up to 30 seconds to complete.
                                
                     * **Send via Secure FTP**. Optional. To use encrypted Secure FTP (SFTP), select this option. LDS with SFTP uses port 22.
                            
                        
                       
                 * **Akamai NetStorage 4**. Provides secure delivery directly to your NetStorage. Complete the following fields:
                           
                               
                     * **Akamai NetStorage 4** list. Select your Group name | Domain | CP code from the list.
                                 
                     * **Directory**. Enter the directory where the logs should be delivered.
                             
                       
                       
                 * **Email**. Use for smaller deliveries or testing. Select this option if you expect your log files to be relatively small. Not a good choice for large volumes of logs or as a permanent solution because your email server might have issues receiving very large log files. Complete the following field:
                           
                               
                     * **Email address**. Email address of your mail server.
                             
                   
               
                 
                 
               
               
               
                 
                   **Approximate message size**
                 
                 | Select the approximate message size from the list.
                 
                 
               
               
               
                 
                   **Encoding**
                 
                 | 
                     
                         
                 1. From the menu, select **GPG Encrypted**. 
                              **Note:** DNSi AnswerX supports GPG encrypted encoding only. GPG encoding encrypts the log files and requires a private GPG key. 
                         
                 2. Create the private GPG key by opening a Support case on ​Control Center​​. From the main menu, go to **SUPPORT > Support cases > Create case**. 
                            Allow up to 10 days for the key to be distributed, signed, and deployed in the Akamai network. 
                        
                 3. When you receive the key, manually upload it.
                    
                
                
              
              
              
              
              **Enter a key
              | 
                  
                   
                 1. Click the **here** link below this field to download an Akamai public GPG key. 
                   
                 2. Open the downloaded key file and copy the contents into this field, being sure to include the following text at the start and end of the key file:
                   -----BEGIN PGP PUBLIC KEY BLOCK-----
                   -----END PGP PUBLIC KEY BLOCK----- .
                   
                
                
              
              
              
              

6. Click **Next**.
    The **Contact Details** page of the **Create a configuration for: ** *objectID*-*objectName* wizard opens.

7. In the **Email address(es)** field, enter one or more email addresses to send an alert to if the log files cannot be delivered. Delimit multiple email addressed by commas. 
    > > Note: 
    >
    > Ensure that these email addresses are checked on a daily basis. 

8. Click **Finish**.

# [Update an LDS configuration](https://techdocs.akamai.com/answerx-cloud/docs/config-lds-ax-cloud#update-an-lds-configuration)

1. Complete steps 1-4 in [View an LDS configuration](https://techdocs.akamai.com/answerx-cloud/docs/config-lds-ax-cloud#view-an-lds-configuration) above to log in to ​Control Center​​, search for your account, go to the **Log delivery** page, and filter the objects table by your **AnswerX** service.
 
1. On the **Log delivery service** page, in the filtered list of object IDs for **AnswerX**, click the **Action** menu () and select **Change settings**.  
The **Change setttings for: ** *objectID*-*objectName* wizard opens to the **Log Configuration** page.

1. Navigate through the wizard pages to make your desired changes. For assistance in updating the fields, you can use the in-product help as well as the detailed description of each field in [Create a new LDS configuration](https://techdocs.akamai.com/answerx-cloud/docs/config-lds-ax-cloud#create-a-new-lds-configuration) above.  

1. When you have completed your changes, click **Finish**.  

# [Configure granular log delivery](https://techdocs.akamai.com/answerx-cloud/docs/config-lds-ax-cloud#configure-granular-log-delivery)

The fastest delivery time for the Log Delivery Service is 30 minutes. If you need faster delivery times, a service configuration is available to post and retrieve logs by using the DNSi AnswerX Reputation Knowledge Server (RKS) API. To configure this delivery alternative, contact your Akamai account manager.