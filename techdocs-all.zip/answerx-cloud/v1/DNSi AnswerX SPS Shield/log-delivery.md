# [Log delivery](https://techdocs.akamai.com/answerx-cloud/docs/log-delivery#log-delivery)

​Akamai Control Center​'s log delivery service allows an SPS Shield administrator to manage log delivery for SPS Shield.

The log delivery service lets you send SPS Shield logs to an email address or an FTP location. By default, a log delivery configuration is available for SPS Shield. However, you need to enable the configuration to begin delivering logs. For instructions, see [Log Delivery Service](https://techdocs.akamai.com/log-delivery/docs) (login required).

You can also perform additional tasks on a log delivery configuration. For example, you can view or change log delivery settings.

To access the log delivery service, go to ☰  > **COMMON SERVICES** > **Log delivery**.