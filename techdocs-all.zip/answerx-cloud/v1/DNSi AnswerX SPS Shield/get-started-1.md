# [Get started](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#get-started)

To get started:

1. [Learn about SPS Shield](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#learn-about--). Review the main features and components of SPS Shield.

1. [Set up SPS Shield](https://techdocs.akamai.com/answerx-cloud/docs/set-up-sps). Complete these steps to set up SPS Shield.   

1. [Set up a dashboard](https://techdocs.akamai.com/answerx-cloud/docs/setup-dashboard).  Create a dashboard with widgets that allow you to track events, traffic,  risky applications, and more across your organization. 

# [Learn about SPS Shield ](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#learn-about-sps-shield)

Learn about the main features and components of SPS Shield.

## [Locations](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#locations)
A location is a public IP address or a named collection of public IP addresses that belong to a region or geographic area in your network, such as a CIDR block for an office branch or your company headquarters. For more on locations, see [About locations](https://techdocs.akamai.com/answerx-cloud/docs/create-locations#about-locations).

## [Policies](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#policies)
A policy is a group of settings that define how SPS Shield handles known or suspected threat events and access control events. It’s also where you enable or configure other important features of SPS Shield.  For more on policies, see [About policies](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#about-policies).

## [Lists](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#lists)
SPS Shield allows you to create two broad categories of lists: block lists and exception lists. For more on lists, see [Create a list](https://techdocs.akamai.com/answerx-cloud/docs/create-list).

## [Access Control](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#access-control)
You can define the websites, web applications, and sensitive data that your users are allowed to access. For more on access control, see [About access control](https://techdocs.akamai.com/answerx-cloud/docs/configure-access-control#about-application-visibility-and-control).

## [Dashboard](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#dashboard)
Use the Dashboard to apply interactive widgets that allow you to view and track DNS traffic, events, and other activity across your organization. For details, see [Dashboard](https://techdocs.akamai.com/answerx-cloud/docs/dashboard).

## [Reports](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#reports)
View data on events and DNS activity. You can also schedule a daily or weekly report to show alerts, events, or other data. For more information, see [Events](https://techdocs.akamai.com/answerx-cloud/docs/events), [Activity](https://techdocs.akamai.com/answerx-cloud/docs/activity), and [Scheduled reports](https://techdocs.akamai.com/answerx-cloud/docs/scheduled-reports).

## [Roles](https://techdocs.akamai.com/answerx-cloud/docs/get-started-1#roles)
Roles include permissions that let you act on objects in ​Control Center​​. These roles are available for SPS Shield. Contact your ​Control Center​​ administrator to assign one of these roles:

| Role | Permission | Description |
|---|---|---|
| Super Administrator | etpAdmin | Can perform all operations, view all reports, and see all reporting data in SPS Shield. |
| Report Viewer | etpReportViewer | Can view reports and reporting data in SPS Shield. A report viewer cannot view configuration settings. |
| Viewer | etpViewer | Has read-only privileges. A viewer can view report data and configuration settings. |