# [Create a policy](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#create-a-policy)

While SPS Shield includes a default policy, you can configure a policy to define how your company handles known or suspected threats.

To perform this task, you need to be an SPS Shield administrator.

To create a policy:

1. In the Threat Protection menu of Enterprise Center, select **Policies** > **Policies**.

1. On the Policies page, click the plus sign icon.

1. Complete the **Name** and **Description** fields.

1. In the Policy Type menu, select **DNS Only**. 

1. To use a predefined template, select one of these templates and click **Continue**:

    - **Strict**. Contains settings that block known and most suspected threat categories. Select this template to apply settings that are a best practice for a policy.

    - **Monitor-only**. Logs and reports threats but it does not block them. This template is ideal for testing or assessing policy impact before using the Strict template.

   - **Custom**. Lets you define policy actions for known and suspected threats.

1. To assign a location or sub-location, click the link icon for locations or sub-locations, and select one or more. Then click **Associate**.

1. Configure basic settings:

    1. Click the **Settings** tab.

    1. In the Browsing Restrictions section, complete the steps for these fields:

        - **Safe Search**. Toggle on to block explicit results from Google and Bing searches.

        - **YouTube**. Select **Strict** or **Moderate** to enable YouTube Restricted Mode. Otherwise, select **Unrestricted** to allow unrestricted access to YouTube content.

    1. In the Other Settings section, toggle **Forward Public IP to Origin** to forward the user's public IP address to authoritative DNS servers and web servers. This setting identifies the geolocation of clients. 

1. Define policy actions for a threat category. Click the **Threat** tab and complete the action based on threat type:

    1. **Known**. If you want to assign the same policy action to all known threat categories, select an action in the **Action** column. Otherwise, make sure the Known option is expanded to show the threat categories.

        - For each threat category, select an action. For more information, see [Policy actions](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#policy-actions).

        - If you select Block, select a specific response to the user. The **Response to User** column is available when the Block action is selected.

    1. **Suspected**. If you want to assign the same policy action to all suspected threat categories, select an action in the **Action** column. Otherwise, make sure the Suspected option is expanded to show the threat categories and complete the fields as described in the previous step.

    1. **Risky**. If you want to assign the same policy action to all risky categories, select an action in the Action column. Otherwise, make sure the Risky option is expanded to show categories, and select an action for the individual categories.

1. Configure access control:

    1. Click the **Access Control** tab.

    1. Click the **AUP & Shadow IT** tab and complete the steps described in [Configure application visibility and control](https://techdocs.akamai.com/answerx-cloud/docs/configure-access-control#configure-application-visibility-and-control).

1. To add a list to the policy, see [Add a block list to a policy](https://techdocs.akamai.com/answerx-cloud/docs/create-list#add-a-block-list-to-a-policy) or [Add an exception to a policy](https://techdocs.akamai.com/answerx-cloud/docs/create-list#add-an-exception-list-to-a-policy).

1. Click **Save**. If you want to save and deploy the policy, click **Save and Deploy**. 

**Next steps**

If you haven’t deployed the policy, make sure you deploy it to the SPS Shield network. For instructions see [Deploy configuration changes](https://techdocs.akamai.com/answerx-cloud/docs/deploy-configuration-changes).

# [About policies](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#about-policies)

A policy is a group of settings that define how SPS Shield handles known or suspected threat events and access control events. You assign a policy to a location or sub-location. A location is a region or geographic area in your network such as a corporate field office. You can assign a different policy to each location or sub-location, or you can assign multiple locations to the same policy. You cannot assign more than one policy to a location or sub-location.

To configure a policy, you need to be an SPS Shield administrator. 

In a policy configuration, you define the policy action and the response to users.  The Threat tab allows you to select an action and response based on a threat category or type, while the Custom Lists tab allows you to set these settings for a block list or exception list. You can add or remove a list from a policy. For more information on threat categories, see [Threat categories](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#threat-categories). For more information on lists, see [Create a list](https://techdocs.akamai.com/answerx-cloud/docs/create-list).

A policy is also where you configure access control settings, including application visibility and control (AVC).  AVC allows you to control access to websites, web applications, and the specific operations that you can perform in a web application. You can design a policy that is based on risk level, categories, applications, and more. For more information, see [About application visibility and control](https://techdocs.akamai.com/answerx-cloud/docs/configure-access-control#about-application-visibility-and-control).

When creating or modifying a policy, an administrator can select a template to help define policy actions for threat categories in the Threat tab. You can use a security template as a starting point to your configuration. For more information, see [Security templates](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#security-templates).

## [Policy settings](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#policy-settings)

A policy is also where you enable these features:

- **SafeSearch**. SafeSearch allows you to block or prohibit adult and explicit content from Google and Bing search results. For more information, see [SafeSearch and YouTube Restricted Mode](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#safesearch-and-youtube-restricted-mode).

- **YouTube Restricted Mode**. You can restrict access to YouTube video content. For more information, see [SafeSearch and YouTube Restricted Mode](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#safesearch-and-youtube-restricted-mode).

- **Forward Public IP to Origin**. This setting forwards the user's public IP address to authoritative DNS servers and web servers. This setting identifies the geolocation of clients.

 > Note: 
  To encrypt DNS requests, Mozilla Firefox enables DNS over HTTPS (DoH). However, this feature causes traffic to bypass SPS Shield. To avoid interfering with your network security solutions, Firefox checks to see whether a DNS filtering solution is already in place by requesting the canary domain `use-application-dns.net`. SPS Shield responds with a NXDOMAIN to signal that this feature is not needed in your corporate network. For more information on Firefox and DoH, see this Mozilla knowledge base [article](https://support.mozilla.org/en-US/kb/configuring-networks-disable-dns-over-https).

An enterprise can create a maximum of 100 policies. If your organization requires more policies, contact your Akamai representative.

## [Threat categories](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#threat-categories)

By default, each policy is configured with threat categories. Threat categories classify domains and IP addresses that Akamai confirmed or suspects are malicious or risky. The domains and IP addresses that are included in these categories are updated automatically as new threats are identified. If SPS Shield determines that a suspected threat for a category is malicious, the threat is added to the list of known threats in that category.

Risky domains are newly registered, discovered, and used for potentially malicious activity.

For known and suspected threats, SPS Shield includes these threat categories:

- **Malware**. Domains and IP addresses used to host malicious software.

- **Phishing**. Domains and IP addresses used to host phishing websites that gather user credential information.

- **C&C**. Domains and IP addresses used by malicious C&C servers.

- **DNS Exfiltration**. Domains that serve as a communication channel over DNS. This channel may be used to steal sensitive data or circumvent traditional access restrictions by allowing malware to communicate outside the network over the DNS protocol.

For risky domains, SPS Shield includes these threat categories:

- **Adware**. Domains that display malicious content in advertisements.

- **Coin Mining**. Domains that are used for mining cryptocurrency.

- **Newly Registered**. Domains that were recently registered.

- **Newly Seen**. Domains that were recently visited by users.

- **Potentially Harmful**. Domains that appear to be harmful to an enterprise network.

- **DNS Tunneling**. Domains that are used to hide and transmit malicious data in a DNS tunnel.

The default actions and alert settings that are assigned to these threat categories are recommended. For more information on policy actions, see [Policy actions](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#policy-actions).

When defining policy actions for the DNS exfiltration category, consider this configuration:

- Assign the monitor policy action to suspected DNS exfiltration threats. The monitor action allows SPS Shield to analyze suspected domains and subdomains. If SPS Shield determines that a domain or subdomain is a threat, it's added to the list associated with the known DNS exfiltration category.

- Configure known DNS exfiltration threats with the block policy action to ensure these known threats are not accessible. By default, the strict policy template assigns this action to known DNS exfiltration threats.

If there are domains and IP addresses that you don't want SPS Shield to analyze, add them to an exception list. After you add an exception list to a policy, the list is configured with the bypass policy action. For more information, see [Exception lists](https://techdocs.akamai.com/answerx-cloud/docs/create-list#exception-lists).

## [Security templates](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#security-templates)

To implement policy best practices, an administrator can apply a security template to configure policy actions for threat categories.

You can use these templates as a starting point to a policy configuration. After you select one of these preset templates, you can then change any of the applied settings such as policy actions, response to user, and more to define settings that best fit your network and your company's security policy. When you do this, the policy indicates that you are using a custom template.

These templates only apply to the categories in the Akamai Security tab. They do not configure settings to other areas of the policy, such as custom lists.

You can select from these templates:

- **Strict**. Includes strict policy actions to make sure that threats are blocked from your network. This template includes these settings:

    - All known threat categories are assigned the block policy action. Most of these block actions are assigned the Error page response to user.

    - For known and suspected DNS exfiltration threats, a refused response is configured as the response to the user.

    - A monitor action is assigned to suspected malware and phishing threats.

- **Monitor-only**. Assigns the monitor action to all known and suspected threat categories. This template logs and reports threats but it does not block them. The Monitor-only template is ideal for testing or assessing policy impact before using the Strict template.

## [Policy actions](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#policy-actions)

SPS Shield performs actions on detected or suspected threats based on the policy configuration. As an SPS Shield administrator, you can select policy actions for a threat category, list, and AVC configuration.

When designing your policy, you can select from actions that detect or prevent threats. Some organizations may use a phased approach to first configure the policy to detect threats before assigning the block action. Note:

- **Threat Detection**. Occurs when the monitor action is assigned. This threat response does not stop traffic. Security events are detected and reported.

- **Threat Prevention**. Occurs when the block action is assigned. This action prevents requests that threaten your network. When the block action is selected, you can select the response to the user. For example, as part of the block action, you can select that users receive an error page.

If domains and IP addresses are configured in multiple lists with conflicting actions, SPS Shield selects the action based on this priority:

1. Bypass
1. Block
1. Monitor
1. Allow

For more information on policy action conflicts, see [Policy conflicts](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#policy-conflicts).

### [Bypass](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#bypass)

With this action, requests bypass SPS Shield and resolve to the origin IP address. This action is automatically assigned to custom exception lists. 

### [Block](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#block)

This policy action denies the request. When this action is selected in a policy, the administrator can select the response or the type of block that the user experiences.

These responses are available for a block action:

  - **Error Page**. User is shown an error message based on the threat violation. 

- **Custom Response**. Request is redirected to the IP address of the custom response. Events are logged in the Threat Events report.

- **Refused Response**. User is shown a browser-specific error message. 

### [Monitor](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#monitor)

Administrators can assign the monitor action to a threat category, list, and access control feature. This action is also available when configuring risk, categories, operations, and applications for an AVC configuration. For more information about  AVC, see [About application visibility and control](https://techdocs.akamai.com/answerx-cloud/docs/configure-access-control#about-application-visibility-and-control).

With this policy action, requests generally resolve to the origin and a user is able to access the website they requested. This action generates a threat or access control event in SPS Shield.

 > Note: 
  Select the Monitor action for lists in the default policy. The default policy is associated with the Unidentified IPs location, a location open to the Internet. If you select another action, a malicious user may suspect that your organization blocks specific domains.

### [Allow](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#allow)

This action resolves requests to the origin.

This action is available for the Risky threat categories, block lists, and for application visibility and control settings. 

## [Policy conflicts](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#policy-conflicts)

Policy conflicts may occur if multiple lists are assigned to a policy and those lists contain matching or overlapping domain names, IP addresses, or URLs. When conflicts exist, SPS Shield uses this logic to determine the policy action:

### [Based on List Type](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#based-on-list-type)

All lists that are created by administrators (block and exceptions lists) are prioritized over other lists in SPS Shield. This means that the action associated to domains or URLs in block or exception lists prevail over the action associated to the same domain or URL in any of these lists:

- **SPS Shield Security lists**. This includes the domains, IP addresses, and URLs associated with SPS Shield threat categories, such as malware, phishing, command & control, and more.

- **Microsoft 365**. Domains and IP addresses associated with Microsoft apps and services, such as Microsoft office apps, Outlook, cloud storage, and more.

- **Acceptable use policy and AVC**. Domains, IP addresses, and URLs for websites and applications. These websites and applications correspond to the AUP and AVC configuration in a policy.

### [Based on Longest Domain/URL Match](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#based-on-longest-domainurl-match)

If the same domain is specified in multiple custom lists or SPS Shield lists using different suffix lengths, SPS Shield enforces the policy action assigned to the longest matching address.

 > Note: 
  If the same domain or URL is found in a custom block or exception list and in an SPS Shield list, the policy action of the custom list takes priority.

For example, if these lists are assigned to the same policy and a user goes to **foo.bar.com**, the Monitor action prevails, because it satisfies the longest matching address.

- List 1 is set to Block **bar.com**.

- List 2 is set to Monitor **foo.bar.com**.

### [Based on Priority of Action](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#based-on-priority-of-action)

If the same domains, IP addresses, and URLs are configured in multiple custom lists or in multiple Akamai lists with conflicting actions, SPS Shield selects the action based on this priority:

1. Bypass
1. Block
1. Monitor
1. Allow

For example, if these lists are assigned to the same policy and a user goes to **bar.com**, the *Bypass* action prevails, because it has higher priority.

- List 1 is set to Block **bar.com**.

- List 2 is set to Bypass **bar.com**.

## [SafeSearch and YouTube restricted mode](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#safesearch-and-youtube-restricted-mode)

An SPS Shield administrator can enable SafeSearch in a policy to block and prohibit adult or explicit content from search results that are completed with Google and Bing search engines. When end users in locations assigned to this policy complete searches with Google or Bing, this feature creates a canonical name (CNAME) record.

These conditions apply:

- For `www.google.com`, SPS Shield creates a CNAME to `forcesafesearch.google.com`.

- For `www.bing.com`, SPS Shield creates a CNAME to `strict.bing.com`.

This means end users are routed to `forcesafesearch.google.com` and `strict.bing.com` when performing searches with these search engines.

Similarly, in a policy configuration, you can also enable YouTube restricted mode. This feature prevents users from accessing video content that contains mature content, language, situations, and more. You can select from these modes:

- **Strict**. Provides access to a limited collection of video content. This is the most restricted mode.

- **Moderate**. Provides some restricted access but is less strict than Strict mode. Moderate mode allows users to access a larger collection of video content.

- **Unrestricted**. Provides access to all YouTube content. This option is selected by default.

SPS Shield creates a CNAME for these hostnames:

- `www.youtube.com`

- `m.youtube.com`

- `youtubei.googleapis.com`

- `youtube.googleapis.com`

- `www.youtube-nocookie.com`

For Strict YouTube Restricted mode, these domains are a CNAME for `restrict.youtube.com`. For Moderate YouTube Restricted mode, these domains are a CNAME for `restrictmoderate.youtube.com`.

# [Acceptable use policy](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#acceptable-use-policy)

In addition to configuring how threats are handled, a policy is also where your organization controls access to websites and web applications. SPS Shield includes categories for websites that you can block within an enterprise.

Acceptable use policy categories classify requested websites. Depending on the action that's associated with a category, the policy defines whether traffic to domains in a category is allowed, scanned by SPS Shield, monitored by SPS Shield, or blocked in your network. For a list and description of all AUP categories, see [Acceptable use policy categories](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#acceptable-use-policy-categories).

With AVC, you can add an AUP category to the policy and select a policy action. You can also see the web applications that are associated with each AUP category. To learn more about AVC, see [About application visibility and control](https://techdocs.akamai.com/answerx-cloud/docs/configure-access-control#about-application-visibility-and-control).

You can:

- **Bypass a category**. This action allows websites or web applications in the associated category to bypass SPS Shield.

    You may want to select the bypass action for categories that are associated with sensitive information such as the Finance & Investing and the Healthcare categories. This action prevents SPS Shield from inspecting this traffic.

- **Select an operating mode**. The Operating Mode menu in the policy defines the mode that SPS Shield uses for traffic by default. You can select: 

    - **Walled Garden**. Blocks all traffic unless it’s configured with the Allow action.
 
    - **DNS Protection**. Protects DNS traffic based on the policy. 

SPS Shield includes AUP categories that you should consider blocking in your network:

- **Anonymizers**. This category is made up of services that allow users in your corporate network to bypass enterprise security settings. These services may include a personal VPN or an anonymizing proxy.

- **File Sharing**. Category for file sharing services or applications such as Dropbox, Google Drive, and OneDrive. These services allow users to download and upload a large number of files to your network, potentially creating a backdoor to your organization's network.

If your organization uses a custom response, you can associate a custom response to a blocked action. As part of the block action, traffic to blocked websites and web applications is forwarded to the custom response. Information about the machine that made the request is recorded. Keep in mind that this data is not reported in SPS Shield. To learn more about custom responses, see [Configure a custom response](https://techdocs.akamai.com/answerx-cloud/docs/configure-custom-response).

## [Acceptable use policy categories](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#acceptable-use-policy-categories)

Acceptable use policy categories classify requested websites. Depending on the action that's associated with a category, the policy defines whether traffic to websites in these categories is allowed, monitored by SPS Shield, or blocked in your network.

AUP categories are configured in a policy as part of access control and AVC. You add AUP categories to a policy and select an action for these categories. For more information, see [Configure access control](https://techdocs.akamai.com/answerx-cloud/docs/configure-access-control).

If there is a website that you don't want directed to SPS Shield, make sure you configure these domains in an exception list. An exception list is automatically assigned the bypass action in a policy. For more information, see [Exception lists](https://techdocs.akamai.com/answerx-cloud/docs/create-list#exception-lists).
| Category | Description |
|---|---|
| Abortion | Websites that are in favor of or against abortion. This includes websites that describe the procedure, provide information on where to obtain one, and give testimonials on the topic. |
| Alcohol & Tobacco | Websites that promote, sell, or provide information related to the consumption of alcohol or the use of tobacco and tobacco-related products. |
| Anonymizers | Websites that provide anonymous access to other websites through a proxy. These proxies avoid URL filtering and monitoring. You should block this category to prevent end users from bypassing enterprise security. |
| Auctions | Websites that offer online auctions. |
| Blogging | Websites that are blogs or host and publish blogs. These websites contain regularly posted entries that share views, commentary, or personal content. Blogs often include photos and multimedia. |
| Business & Economy | Websites focused on business firms, marketing, management, economics, and entrepreneurship. This includes corporate websites and websites dedicated to other consumer services. |
| Chat Site | Websites that enable users to chat in real time through chat rooms, online conferences, video chat, or instant messaging. |
| Child Abuse / Exploitation | Websites that contain obscene, harmful, and sexually explicit or suggestive content involving minors. This content includes pornographic visual depictions in images, videos, and other media. |
| Computer & Internet Info | Websites related to computers that provide technical information. Websites in this category focus on hardware, software, SaaS, Internet services, or more. |
| Computer & Internet Security | Websites that discuss or provide information on computers and Internet security. |
| Confirmed Spam Sources | Websites that are known spam sources. |
| Content Delivery Networks | Websites that deliver content and data such as images, videos, and media files as a result of a content delivery network. |
| Criminal Skills | Websites that provide resources, information, or equipment to commit crimes and avoid prosecution. |
| Cult and Occult | Websites for religious movements, groups, or sects that are exploitative or unorthodox. This category also contains websites focused on the practice of magic to interpret and influence events. |
| DNS-over-HTTPS Providers | Websites of DNS-over-HTTPS (DoH) providers. DoH encrypts DNS requests and prevents a threat actor from manipulating DNS data. While DoH protects DNS traffic, you should block this category to prevent end users from bypassing SPS Shield security. |
| Dead Sites | Websites that cannot be categorized into an AUP category. These websites do not respond to HTTP queries. |
| Drugs | Websites that sell, supply, promote, or advocate for the abuse or illegal use of drugs. These websites also provide information on the cultivation, manufacture, or distribution of drugs, pharmaceuticals, intoxicating plants, chemicals, and any drug-related equipment. |
| Dynamic Content | Websites that dynamically generate content based on URL or other information from the web request. |
| Educational Institutes | Websites for schools and institutions at all educational levels. This category includes websites with content that's designed for students, administrators, and teachers such as enrollment or course information. |
| Entertainment & Arts | Websites related to the arts, including film, television, music, books, theater, and more. This includes websites for museums, art galleries, and artists. |
| Fashion & Beauty | Websites focused on glamor, beauty, cosmetics, fashion, and clothes. This includes websites for publications on these subjects. |
| File Sharing | Websites with clients, protocols, and other resources that allow users to download and share files with others. These websites may also enable users to stream unauthorized content such as movies, TV shows, and more. |
| Finance & Investing | Websites that allow users to access, research, and manage their finances and investments. These websites are used for online banking, credit cards, personal and financial portfolios, and more. |
| Forums & Message Boards | Websites that host online communities and allow end users to engage in discussions on a variety of topics. These websites include moderated or unmoderated web forums, message boards, online question and answer sites, and more. |
| Gambling | Websites that promote gambling and allow users to gamble or place bets. Websites in this category may teach gambling, predict race winners, show lottery numbers, allow users to register for gambling tournaments, and more. |
| Games | Websites related to the development, promotion, review, download, and overall play of online, PC, handheld, and console video games. |
| Gore | Websites that promote or feature excessive, graphic, or deliberate violence against humans or animals. Websites may include real or animated scenes of violence, extremely violent video games, horror media and entertainment, and more. |
| Government | Websites that contain information on the government, government agencies, and services. This includes local, county, state, and national government websites. |
| Hacking | Websites with resources that allow hackers to gain unauthorized access and compromise a system or network with computer programming. |
| Hate | Websites that promote or feature discriminatory, hostile, intolerant, and aggressive content with the intent to denigrate or disparage an individual or group based on race, religion, gender, nationality, ethnicity, sexual orientation, and other involuntary characteristics. These sites may use alleged scientific or accredited methods to justify this content. |
| Healthcare | Websites related to human health, including disease or illness, treatment, nutrition, and fitness. These websites are also dedicated to healthcare facilities, health insurance, pharmaceuticals, and more. |
| Home & Garden | Websites that sell products for the home, including decor, tools for maintenance and gardening, electronics, and more. |
| Hunting & Fishing | Websites focused on hunting or fishing as a sport or recreational activity. |
| Image & Video Search | Websites that are related to photography and host digital photos. |
| Individual Stock Advice & Tools | Websites that promote or facilitate stock trading and the management of investment assets. This includes websites that contain information on financial investment news, strategies, and quotes. |
| Internet Portals | Websites that are a gateway to other content and services on the Internet. |
| Job Search | Websites that assist with job searches, provide job information, and offer resources for locating employment. Websites in this category also help employers find candidates. |
| Keyloggers & Monitoring | Websites that log keystrokes and are known to monitor a user's Internet activity. |
| Kids | Websites that are designed to provide a safe Internet experience for young children and adolescents. |
| Legal | Websites focused on the practice of law, legal issues, and research, as well as law enforcement. This category also includes the official websites of law firms. |
| Lingerie | Websites that promote, review, or sell lingerie or intimate apparel. |
| Local Information | Websites that feature or promote restaurants, local areas of interest, tourist attractions, city guides, and more. |
| Marijuana | Websites that advertise or officially sell cannabidiol (CBD). This category excludes websites that promote CBD or marijuana for recreational use. |
| Military | Websites dedicated to the military, armed forces, military history, and military personnel. This category also includes websites dedicated to services for veterans, soldiers, and their families. |
| Motor Vehicles | Websites that sell, manufacture, review, promote, or discuss motorized vehicles and their related products. |
| Music | Websites that stream, sell, and allow users to download music. This category also includes websites that provide information on musical artists, song lyrics, performances, and more. |
| News & Media | Websites that communicate the news. This category includes websites for newspapers, public broadcasting stations, radio stations, and more. |
| Nudism and Naturism | Websites that depict the naked body but are not pornographic or sexual in intent. For example, websites in this category may show the naked body in art form. This category also contains websites that feature or promote nudism or a nudist lifestyle. |
| Online Greeting Cards | Websites for online greeting cards. |
| Parked Domains | Websites that host limited content and may contain advertisements to generate revenue. These websites are usually owned by domain name registrars, domain brokers, or Internet advertising publishers. |
| Pay to Surf | Websites that pay users to find and review content on the Internet. |
| Peer to Peer | Websites that enable users to illegally share and transmit digital content. |
| Personals & Dating | Websites focused on establishing romantic relationships or marriage. These websites may offer online dating services, professional matchmaking and matrimonial services, tips for dating, and more. |
| Plagiarism | Websites that offer, sell, or promote free academic writing services. |
| Political Advocacy | Websites focused on politics or philosophy where a particular viewpoint is expressed. |
| Pornography Websites | Websites that contain sexually explicit material meant to incite sexual excitement or interest. |
| Real Estate | Websites related to the rent and purchase of real estate or other property. This category also includes websites on mortgages, real estate agents, tips on selling a home, property improvement, and more. |
| Recreation & Hobbies | Websites focused on hobbies and recreational activities for enthusiasts and amateurs. This includes websites that provide information on associations, forums, and publications for these interests, such as outdoor activities, crafts, and collecting. |
| Reference & Research | Websites for personal, professional, and educational research. Websites in this category include online dictionaries, library catalogs, scientific information, and more. |
| Religion | Websites dedicated to religious subjects, practices, services, and houses of worship. |
| Search Engines | Websites that search the Internet for information, images, video content, and more based on provided keywords and phrases. |
| Self-Harm | Websites that promote, normalize, or glamorize the repetitive and deliberate ways to inflict harm to oneself. This category also contains websites that advocate or glorify suicide and promote methods for committing suicide. |
| Sex Education | Websites that contain information about reproduction, sexual development, sexual orientation, contraceptives, sexually transmitted diseases, and other topics related to sex. |
| Shareware & Freeware | Websites that offer free software, utilities, media, and other content for legal download. |
| Shopping | Websites that allow consumers to purchase goods and services from retailers or sellers. |
| Spam URLs | Websites or URLs from spam messages. |
| Sports | Websites that analyze, promote, or provide information about competitive sports or sports fans. |
| Spyware & Adware | Websites associated with vendors of spyware or adware. These websites may gather information about the user, display unsolicited advertising, and download unwanted software to the user's machine. |
| Streaming Websites | Websites that feature and transmit live or on-demand audio or video content over the Internet. This includes websites that sell, deliver, and stream content to users. |
| Training & Tools | Websites focused on developing or attaining a formal education or vocational skills. Websites in this category offer online courses, software training, and more. |
| Translation | Websites used for translation that allow users to see content or URL pages in other languages. |
| Travel | Websites related to travel, including booking a trip, travel agencies, reserving hotels, and more. |
| Virtual Community | Websites that promote social networking and have online communities where users interact and communicate with one another. |
| Weapons Related | Websites that promote and provide information on various types of weapons, such as knives and guns. This category includes websites that sell knives, guns, and firearm accessories. It also includes websites that provide instructions on making weapons for hand-to-hand combat or martial arts. |
| Web Advertisements | Websites that host advertisements to attract consumers and increase web traffic. |