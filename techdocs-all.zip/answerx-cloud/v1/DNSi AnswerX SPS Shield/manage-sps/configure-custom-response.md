# [Configure a custom response](https://techdocs.akamai.com/answerx-cloud/docs/configure-custom-response#configure-a-custom-response)

From the Custom Response page, you can create and manage a custom response configuration. A custom response configuration allows you to direct suspicious traffic to a machine in your network where activity is recorded. Information about the user device that made the request is captured to discover the internal IP addresses of infected machines on the corporate network.

Data collected by a custom response device is not recorded in SPS Shield. 

In a policy, you can select to use a custom response with the block action. This means that blocked traffic is directed to the custom response.  If the proxy is not enabled and you are configuring AVC, you can associate a custom response to a block action. For more information, see [Application visibility and control](https://techdocs.akamai.com/answerx-cloud/docs/configure-access-control#about-application-visibility-control).

When configuring a custom response, you enter the IP address information of the machine that you plan to use.

You need to be an SPS Shield super administrator to perform this task.

To configure a custom response:

1. In the Threat Protection menu of Enterprise Center, select **Policies** > **Custom Responses**.

1. Click the plus sign icon. The Add Custom Response dialog appears.

1. In the **Name** field, enter a name for the custom response.

1. In the **Description** field, enter a description.

1. In the **IP V4** and **IP V6** fields, enter the IP address information for the custom response device or machine.

1. Click **Save**.