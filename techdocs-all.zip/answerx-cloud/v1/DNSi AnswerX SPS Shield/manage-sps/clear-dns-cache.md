# [Clear DNS cache](https://techdocs.akamai.com/answerx-cloud/docs/clear-dns-cache#clear-dns-cache)

SPS Shield DNS servers cache domains to quickly resolve requests. If a domain resolves to a new IP address, you can clear the domain from SPS Shield DNS servers. After you complete this task, the domain can then resolve to the correct IP address.

To clear the DNS cache: 

1. In the Threat Protection menu of Enterprise Center, select **General Settings** > **Clear DNS Cache**.

1. In the provided field, enter the domain.

1. Click **Clear DNS Cache**. The operation completes in two to three minutes.