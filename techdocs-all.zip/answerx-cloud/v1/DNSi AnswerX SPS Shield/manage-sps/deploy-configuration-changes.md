# [Deploy configuration changes](https://techdocs.akamai.com/answerx-cloud/docs/deploy-configuration-changes#deploy-configuration-changes)

You can deploy these features when you save them or you can deploy them at a later time from the list of pending changes:

- Locations
- Policies
- Lists

The **Pending Changes** tab shows saved changes that are currently pending deployment.

The Pending Changes window includes this information:

- Specific settings that were added or modified. Depending on the modification, the Pending Changes window shows the original and new setting values.

- The user who created or modified the setting.

- Configuration changes that are related to the applied settings. For example, if you modify a policy and associate a new location to the policy, this change also impacts a location configuration. As a result, a change to the specific location is also visible in the list of pending changes.

If you're a super administrator, you can deploy all configuration changes or a specific change. For example, you could deploy changes associated with a component such as locations or you can select a specific change.

The deploy operation for a location, policy, or list,  completes in 20-30 seconds. 

A super administrator can revert changes to return to the settings that were previously deployed.  Keep in mind that if multiple administrators modified the same item, such as a specific policy or location, a revert operation automatically removes all pending changes that are associated with it.

As part of the deployment process, administrators need to confirm their changes. This process involves commenting on the deployed changes. These comments are logged on the Deployment History tab where an administrator and any SPS Shield user can track the changes that were deployed to the network. The list of changes and the administrators who made them are shown in the deployment history.

# [Deploy configuration changes](https://techdocs.akamai.com/answerx-cloud/docs/deploy-configuration-changes#deploy-configuration-changes)

If you do not deploy configuration changes when you save them in SPS Shield , they are in a pending state until you deploy them.

You need to be an SPS Shield  administrator to perform this task. 

To deploy configuration changes to the SPS Shield network: 

1. From any page, click **Pending Changes**.

1. Review the changes. If necessary, expand the details for a category of settings to view the associated changes. For example, if locations are listed, you can click the arrow icon to show the specific location changes submitted by you or another administrator.

1. Select the specific changes that you want to deploy.

1. Click **Deploy**.

1. Enter a comment to describe the changes included in the deployment, and click **Deploy**. A progress bar in the Pending Changes window shows when the process is complete.

# [View deployment history](https://techdocs.akamai.com/answerx-cloud/docs/deploy-configuration-changes#view-deployment-history)

After any deployment, you can view the changes, the administrator who made them, and any comment that was provided with the deployed changes.

To view deployment history:

1. In the Threat Protection menu of Enterprise Center, select **General Settings** > **Deployment History**.

1. Locate the history that you want to view based on time of deployment, administrator who deployed the changes, and the provided comment.

1. Expand the history to view changes. Depending on the changes submitted, there may be additional sections that you can expand to view modified settings.

# [Revert configuration changes](https://techdocs.akamai.com/answerx-cloud/docs/deploy-configuration-changes#revert-configuration-changes)

You can revert a configuration change that is currently in a pending state. If you revert a change in a configuration area where multiple administrators made a modification, all changes pending for that configuration area are reverted.

You need to be an SPS Shield administrator to perform this task. A super administrator can revert any pending change. 

To revert configuration changes:

1. Click **Pending Changes**.

1. Go the change that you want to revert. If necessary, expand the details to view the changes associated with a specific SPS Shield  component. For example, if Locations are listed, you can click the arrow icon to show the specific location changes that were submitted by you or another administrator.

1. Select the change or changes that you want to revert.

1. Click **Revert**.

1. Click **Revert** to confirm the revert operation.