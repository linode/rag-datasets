# [Set up SPS Shield](https://techdocs.akamai.com/answerx-cloud/docs/set-up-sps#set-up-sps-shield)

These steps are required for your SPS Shield implementation.

To begin using SPS Shield:

1.  Log in to SPS Shield.

    1. Log in to ​Control Center​​ (https://control.akamai.com).
    1. In the Account menu, select the account or contract you need.
    1. Go to  ☰ > **ENTERPRISE SECURITY** > **Enterprise Center**.
    1. Select **Threat Protection** from the navigation menu to access SPS Shield features. 

1. Create locations.

    A location is a public IP address or a named collection of public IP addresses that belong to a region or geographic area in your network, such as a CIDR block for an office branch or your company headquarters.

    You need to create a location with the public IP addresses that apply to regions in your network. For more information, see [About locations](https://techdocs.akamai.com/answerx-cloud/docs/create-locations#about-locations) and [Create a location](https://techdocs.akamai.com/answerx-cloud/docs/create-locations).

1. Set up your organization’s policies.

    A policy is a group of settings that define how SPS Shield handles known or suspected threats. It’s also where you can define access control, as well as other SPS Shield features. 

    You need to assign the policy to the location you created. For more information, see [About policies](https://techdocs.akamai.com/answerx-cloud/docs/create-policy#about-policies) and [Create a policy](https://techdocs.akamai.com/answerx-cloud/docs/create-policy).

1.  Make sure you deploy your locations and policies. 
    
    For more information, see [Deploy configuration changes](https://techdocs.akamai.com/answerx-cloud/docs/deploy-configuration-changes).

1.  Forward DNS traffic to SPS Shield.

    You need to forward external DNS traffic from your enterprise DNS server or Active Directory (AD) server to SPS Shield. For more information, see [Configure DNS forwarding](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding).

1.  Configure the enterprise firewall to allow or block specific domains and ports.

    For more information, see [Configure your firewall](https://techdocs.akamai.com/answerx-cloud/docs/configure-your-firewall).

1.  Set up the SPS Shield dashboard.

    SPS Shield includes a dashboard that you can customize with widgets to track events, DNS activity, and more. For more information, see [Dashboard](https://techdocs.akamai.com/answerx-cloud/docs/dashboard).