# [Configure DNS forwarding](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarding)

DNS forwarding allows you to forward requests from a local DNS server to a recursive DNS server outside the corporate network. This configuration is necessary for your SPS Shield  implementation. By directing your enterprise's external DNS traffic to SPS Shield, the requested domains are checked against SPS Shield threat intelligence.

Depending on your network topology and how DNS servers communicate within your organization's network, you may only need to configure the primary DNS servers to forward requests to SPS Shield.

This table lists instructions for common DNS server products. Refer to the instructions for your organization's DNS server product.

> Info: SPS Shield offers a 100% uptime service level, as defined in the corresponding Service Level Agreement. If your organization is concerned with connectivity between your forwarding DNS name server and  Akamai, you can configure your DNS name server to resolve domains. In most cases, this is done by allowing your DNS name server to use root hints for the resolution.

| Product | Procedure |
|---|---|
| Microsoft Windows Server 2008 R2 Microsoft Windows Server 2016 | [Configure DNS forwarders on Microsoft Windows Server 2008 R2 and 2016](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarders-on-microsoft-windows-server-2008-r2-and-2016) |
| BIND | [Configure DNS forwarding on BIND](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarding-on-bind) |
| Blue Coat Proxy SG | [Configure DNS forwarding on Blue Coat ProxySG](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarding-on-blue-coat-proxysg) |
| Palo Alto Networks | [Configure a DNS proxy on a Palo Alto Networks firewall](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-a-dns-proxy-on-a-palo-alto-networks-firewall) |
| Citrix NetScaler | [Configure DNS recursion on Citrix NetScaler](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-recursion-on-citrix-netscaler) |
| Infoblox | [Configure DNS forwarders on Infoblox](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarders-on-infoblox) |
| Cisco Routers | [Configure split-DNS forwarding on Cisco routers](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-split-dns-forwarding-on-cisco-routers) |
| Unbound | [Configure DNS forwarding on Unbound](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarding-on-unbound) |

Before you begin, make sure that you note the primary and secondary IP addresses of your SPS Shield recursive servers. To learn how to view this information in SPS Shield, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

# [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information)

You can view the IPv4 and IPv6 address information for the primary and secondary Akamai DNS recursive servers that are assigned to your enterprise. Traffic is forwarded to these servers.  The IP address information is available in the Connection Info dashboard widget. By default, you can view the widget in the Threat Overview dashboard. However, you can also add the widget to any dashboard you create.

To view DNS server information:

1. In the Enterprise Center navigation menu, select **Dashboard**.

1. In the dashboard drop-down menu, select the **Threat Overview** dashboard.

1. Go to the **Connection Info** widget.
    You can add this widget to a custom dashboard. To add the Connection Info widget to a new dashboard, see [Add a dashboard](https://techdocs.akamai.com/answerx-cloud/docs/dashboard#add-a-dashboard).

# [Configure DNS forwarders on Microsoft Windows Server 2008 R2 and 2016](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarders-on-microsoft-windows-server-2008-r2-and-2016)

**Before you begin**

- Note the IP addresses of the SPS Shield recursive DNS servers. For more information, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

- Confirm that you have a root hints file configured. The root hints file contains the list of root DNS servers that AD contacts for recursion.

Complete this procedure to configure DNS forwarding on the Microsoft Windows Server 2008 R2 and 2016. You can configure DNS forwarding with the Windows Server graphical user interface or the command line.

## [Graphical user interface](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#graphical-user-interface)

To configure DNS forwarders on Windows using the graphical user interface:

1. Click **Start** and then **Administrative Tools**. Click **DNS**.

1. Right-click the DNS server that you want to configure as a forwarder.

1. In the **Action** menu, select **Properties**.

1. Click the **Forwarders** tab.

1. Click **Edit**.

1. In the **Edit Forwarders** dialog, enter the primary IP address of the SPS Shield recursive DNS server and press Enter.

1. Enter the secondary IP address of the SPS Shield recursive DNS server and press Enter.

1. If other servers are listed as forwarders, delete this information. The primary and secondary recursive DNS servers should be the only forwarders listed.

1. To change the number of seconds that a DNS server waits for a response before it tries the IP address of the other DNS server, enter a new value in the **Number of seconds before forward queries times out** field.

1. Click **OK**.

1. Enable the **Use roots hints if no forwarders are available** option. This option ensures that DNS servers in a root hints file resolve the name locally.

1. In the properties dialog, click **OK**.

## [Command line interface](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#command-line-interface)

To configure DNS forwarding on Windows using the command line interface:

1. Open a command prompt. Run the command prompt as an administrator.

1. Type this command and press Enter:

    `dnscmd 
 /ResetForwarders 
 [/TimeOut 
] /noslave`

    where:

       -  <*ServerName*> is the hostname or IP address of the DNS server. To specify the DNS on your local computer, you can type `(.)`

       -  <*PrimaryIPaddress *> is one or more IP addresses of the DNS servers where you are forwarding queries. In this case, enter the SPS Shield server IP addresses. Separate each IP address with a space.

       -  <*Time*> is the value that you want to configure for the time out setting in seconds. The default time out value is five seconds.

    For more information, see [Microsoft documentation](https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/dnscmd).

    >> Note:
    > 
    > The /noslave parameter indicates that the server will use the root hints file to resolve requests locally if it cannot reach SPS Shield.
    >

# [Configure DNS forwarding on BIND](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarding-on-bind)

**Before you begin**

Note the IP addresses of the SPS Shield recursive DNS servers. For more information, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

To configure the BIND DNS server to forward DNS queries to SPS Shield:

1. Open a command prompt or terminal.

1. If you are using a Secure Shell (SSH), enter `ssh username@server`.

    where:

      - *username* is the username to access the server remotely.

      - *server* is the hostname or IP address of the server.

1. Change the directory to `etc/bind`.

1. Open the **named.conf.options** file to edit it.

1. In the forwarders area, enter the IP addresses of the SPS Shield DNS servers.

    Make sure that you enter the IP addresses in the { } symbols.

    >> Note:
    > 
    > If this BIND server is also a secondary authoritative server for internal zones and you do not want to forward these queries to SPS Shield, you can configure those zones with a blank forwarders list by adding forwarders {} to the internal zone settings in the configuration file. This ensures that recursion for subdomains occurs in the internal zone only.

1. Save and close the file.

**Next steps**

Restart the BIND daemon. In the terminal, enter this command:

`sudo service bind9 restart`

# [Configure DNS forwarding on Blue Coat ProxySG](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarding-on-blue-coat-proxysg)

**Before you begin**

Note the IP addresses of the SPS Shield recursive DNS servers. For more information, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

To configure Blue Coat ProxySG to forward requests to SPS Shield:

1. In the ProxySG Management Console, click the **Configuration** tab.

1. In the navigation menu, click ** Network** > **DNS**.

1. In the DNS fields, enter the primary and the secondary IP addresses of the SPS Shield recursive servers.

1. Click **Apply**.

**Next steps**

Complete these steps to perform a DNS resolution test:

1. Establish an SSH connection to the ProxySG appliance.

1. Enter this command and press Enter:

    `SG>test dns 
`

    where <*domain*> is a domain you want to resolve for this test.

# [Configure a DNS proxy on a Palo Alto Networks firewall](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-a-dns-proxy-on-a-palo-alto-networks-firewall)

**Before you begin**

Note the IP addresses of the SPS Shield recursive DNS servers. For more information, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

To configure a DNS proxy on a Palo Alto Networks firewall:

1. In the Palo Alto Networks firewall, go to **Network** > **DNS Proxy**.

1. Click **Add**.

1. Select the interface or interfaces where the DNS proxy is enabled.

1. In the **Inheritance Source** list, select **none**.

1. In the **Primary** field, enter the primary IP address of the SPS Shield recursive server.

1. In the **Secondary** field, enter the secondary IP address of the SPS Shield recursive server.

1. To configure static DNS entries that are cached and resolved locally, in the Static Entries tab, click **Add** and:

    1. In the **Name** column, enter a name to identify the entry

    1. In the **FQDN** column, enter the Fully Qualified Domain Name that you want the firewall to resolve locally

    1. In the **Address** column, enter the associated IP address or addresses

1. To configure DNS caching, in the **Advanced** tab, select **Cache**. By default, the DNS proxy populates values for the cache size and timeout.

1. Click **OK**.

# [Configure DNS recursion on Citrix NetScaler](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-recursion-on-citrix-netscaler)

**Before you begin**

Note the IP addresses of the SPS Shield recursive DNS servers. For more information, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

Complete one of these procedures to configure a recursive DNS server on Citrix NetScaler. You can configure DNS recursion on the NetScaler graphical or command line interface.

> Info: In NetScaler, DNS recursion applies to a local DNS server configuration only. This functionality is not available in an Authoritative Domain Name Server (ADNS) configuration.

## [Graphical user interface](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#graphical-user-interface)

To configure DNS recursion on Citrix NetScaler using the graphical user interface:

1. In the navigation menu, click **Traffic Management** > ** DNS**.

1. Click **Change DNS Settings**.

1. In the Change DNS Settings dialog:

    1. Select **Enable recursion**.

    1. To enable caching, select **Records caching**.

    1. Click **OK**.

1. In the expanded navigation menu for DNS, select **Name Servers**.

1. Click **Add**.

1. In the Create Name Server dialog:

    1. Make sure that ** IP address** is selected.

    1. In the** IP Address** field, enter the IP address of the primary SPS Shield recursive server.

    1. Select **Local**.

    1. Click **Create**.

1. To add the secondary SPS Shield recursive server, repeat steps 5 and 6.

1. Repeat steps 5 and 6 to add a recursive DNS server that will resolve requests if NetScaler cannot reach SPS Shield.

## [Command line interface](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#command-line-interface)

To configure DNS recursion on Citrix NetScaler using the command line interface:

1. Establish an SSH connection to the NetScaler appliance.

1. To configure an SPS Shield DNS server as a DNS nameserver, enter this command and press Enter:

    `add dns nameserver 
 -local`

     where <*IP address*> is the IP address of the SPS Shield recursive DNS server.

1. To enable DNS recursion, enter this command and press Enter:

    `set dns parameter -recursion ENABLED -cacheRecords YES`

1. Repeat step 2 to add a recursive DNS server that will resolve requests if NetScaler cannot reach SPS Shield.

# [Configure DNS forwarders on Infoblox](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarders-on-infoblox)

**Before you begin**

Note the IP addresses of the SPS Shield recursive DNS servers. For more information, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

To configure DNS forwarders on Infoblox:

1. From the main navigation menu, click **Data Management** and then select the **DNS** tab.

1. Depending on the Infoblox view:

    - In a **Grid** view,  expand the Toolbar on the right side of the application and select **Grid DNS Properties**.

    - In a **Members** view, click the **Members** tab. Select the member and then click the edit icon.

    - In a **DNS** view, click the **Zones** tab. Select the appropriate DNS view and click the edit icon.

1. Click **Forwarders** and in the panel that appears click the add icon.

1. In the provided field, enter the IP address of the primary SPS Shield recursive DNS server.

1. Click **Save & Close**.

**Next steps**

If prompted to restart services, click **Restart**.

# [Configure split-DNS forwarding on Cisco routers](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-split-dns-forwarding-on-cisco-routers)

**Before you begin**

Note the IP addresses of the SPS Shield recursive DNS servers. For more information, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

To separate the DNS resolution of internal domains from external domains, configure split-DNS forwarding with Cisco routers. This lets you use the local DNS server for internal domain resolution for internal applications or resources while directing external domain requests to SPS Shield.

To configure split-DNS forwarding on Cisco routers:

1. Log in the Cisco router:

    1. Open a command prompt or terminal window.

    1. Enter this command:

        `telnet 
`

        where <*IP address*> is the IP address of router.

    1. Enter your username and press Enter.

    1. When prompted for your password, enter your password.

1. Enter this command to access global configuration settings:

    `configure terminal`

1. Configure the DNS server configuration on the router to send requests to SPS Shield. Enter this command:

    `ip name-server 
 
`

    where:
      - <*SPS Shield_primaryIP*> is the IP address of the primary SPS Shield recursive DNS server.

      - <*SPS Shield_secondaryIP*> is the IP address of the secondary SPS Shield recursive DNS server.

1. Configure DNS forwarding:

    1. Enter this command to define the default DNS view:

        ` ip dns view default`

    1. Enter this command to define DNS forwarding for incoming DNS requests:

        `dns forwarder 
 
`

        where:

          - <*SPS Shield_primaryIP*> is the IP address of the primary SPS Shield recursive DNS server.

          - <*SPS Shield_secondaryIP*> is the IP address of the secondary SPS Shield recursive DNS server.

    1. Enter this command to define an internal DNS view:

        `ip dns view internal_dns`

    1. Enter this command to forward internal requests to your organization's internal DNS server:

        `dns forwarder 
 
`

        where:

          - <*Internal_DNS_IP1*> is the IP address of your internal DNS server.

          - <*Internal_DNS_IP2*> is the IP address of your secondary internal DNS server.

1. Enter this command to configure a list of internal domains that you want the internal DNS server to resolve.

    `ip dns name-list 
 permit 
`

    where:

      - <*number*> is a number ranging from 1 to 500 that identifies the list.

      - <*domain*> is a domain. Regular expressions and regular expression pattern-matching characters are supported.

1. Execute these commands to configure DNS views or to specify the parameters that define how DNS queries are handled. In this step, you'll also configure a list of DNS views.

    1. Enter this command to define conditions for a view list.

        `ip dns view-list conditional`

    1. Enter this command:

        `view internal_dns 10`

    1. Enter this command:

        `restrict name-group 1`

    1. Enter this command:

        `view default 99`

1. Enter these commands to enable the view list on the router and the DNS service.

    `ip dns server view-group conditional`

    `ip dns server`

# [Configure DNS forwarding on Unbound](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#configure-dns-forwarding-on-unbound)

**Before you begin**

- Note the IP addresses of the SPS Shield recursive DNS servers. For more information, see [View DNS server information](https://techdocs.akamai.com/answerx-cloud/docs/dns-forwarding#view-dns-server-information).

- Confirm that you have a root hints file configured . The root hints file (`root.hints`) contains DNS servers that your enterprise DNS server can contact if it's unable to reach SPS Shield.

To configure DNS forwarding on an Unbound DNS server:

1. Log in to the Unbound server.

1. From a terminal window, use a Linux text editor such as vi or Vim to open the `unbound.conf` file.

    >> Note:
    > 
    > The `unbound.conf` is usually copied to `/usr/local/etc/unbound/unbound.conf`  but it also can be located in  `/etc/unbound/unbound.conf` or `/etc/unbound.conf`.

1. Locate the `forward-zone`area of the file.

1. Under `forward-zone`, enter this information:

    `forward-zone:
               name: "."
               forward-addr: 

               forward-addr: 
`

    where:

    - <*SPS Shield_primary_IP*> is the IP address of the primary SPS Shield recursive server.

    - <*SPS Shield_secondary_IP*> is the IP address of the secondary SPS Shield recursive server.

1. In the configuration file, enter this information to direct Unbound to the root hints file when Unbound is unable to reach SPS Shield.

    `root-hints: root.hints`

1. Save these changes.