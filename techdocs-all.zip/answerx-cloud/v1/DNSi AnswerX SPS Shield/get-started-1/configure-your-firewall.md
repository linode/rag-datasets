# [Configure your firewall](https://techdocs.akamai.com/answerx-cloud/docs/configure-your-firewall#configure-your-firewall)

You need to configure your enterprise firewall to allow or block specific domains and ports. For instructions, see the product documentation for your organization's enterprise firewall.

To configure your firewall, update your enterprise firewall to allow traffic to these domains and ports required for specific SPS Shield features:
| Hostname | Description | Protocol | Port | Direction |
|---|---|---|---|---|
| *.akamai.com or Any IP | Network Time Protocol (NTP) | UDP | 123 | Outbound |
| <ul><li><*SPSDNS_IPv4_1*> <li><*SPSDNS_IPv4_2*></ul></li>OR<ul><li><*SPSDNS_IPv6_1*> <li><*SPSDNS_IPv6_2*></ul></li>where: <ul><li><*SPSDNS_IPv4_1*> and <*SPSDNS_IPv4_2*> are the primary and secondary IPv4 addresses of the SPS Shield DNS servers. <li><*SPSDNS_IPv6_1*> and <*SPSDNS_IPv6_2*> are the primary and secondary IPv6 addresses of the SPS Shield DNS servers.</ul></li>These DNS servers are assigned to your SPS Shield account. Only allow the IPv6 server addresses if your organization uses IPv6. | SPS Shield DNS Servers | UDP | 53 | Outbound |
| *<config_ID>*.dot.akaetp.net where *<config_ID>* is the configuration ID. | Domain for DNS over TLS (DoT) | TCP | 853 | Outbound |
| *<config_ID>*.doh.akaetp.net where *<config_ID>* is the configuration ID. | Domain for DNS over HTTPS (DoH) | TCP | 443 | Outbound |

 
If you want to prevent users from bypassing SPS Shield and connecting directly to open recursive DNS servers on the Internet, block this port:
| Hostname | Description | Protocol | Port | Direction |
|---|---|---|---|---|
| All | Port where DNS servers listen for queries | TCP / UDP | 53 | Outbound |