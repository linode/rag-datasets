# [Analyze reports](https://techdocs.akamai.com/answerx-cloud/docs/analyze-reports#analyze-reports)

You can use SPS Shield report to analyze events, DNS activity, and learn more about threats. These reports are available:

- **Dashboard**: You can create a dashboard with widgets that let you track events, DNS activity, risky applications, and more across your organization. The dashboard gives administrators and report viewers the ease of viewing data at a glance. For more information, see [Dashboard](https://techdocs.akamai.com/answerx-cloud/docs/dashboard). 

- **Events**: SPS Shield  contains reports that let you analyze threat events and access control events. For more information, see [Events](https://techdocs.akamai.com/answerx-cloud/docs/events). 

- **Activity**: You can view the DNS Summary activity report to view high-level information about DNS activity in your network. This report shows the top domains, top locations, total queries, and more. For more information, see [Activity](https://techdocs.akamai.com/answerx-cloud/docs/activity). 

- **Indicator search**: Lets you search for threat information based on domain, threat name, or application name. For more information, see [Indicator search](https://techdocs.akamai.com/answerx-cloud/docs/indicator-search). 

- **Scheduled reports**: Run a report to view data on on all events, threat events, access control events, and more. For more information, see [Scheduled reports](https://techdocs.akamai.com/answerx-cloud/docs/scheduled-reports).