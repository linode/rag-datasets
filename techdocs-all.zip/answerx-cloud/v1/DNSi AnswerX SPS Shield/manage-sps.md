# [Configure and manage SPS Shield](https://techdocs.akamai.com/answerx-cloud/docs/manage-sps#configure-and-manage-sps-shield)

To use SPS Shield, you configure and manage these components.

- **Locations**. A location is a public IP address or a named collection of public IP addresses that belong to a region or geographic area in your network, such as a CIDR block for an office branch or your company headquarters. You can create a locations and sub-locations. For more information, see [Create a location](https://techdocs.akamai.com/answerx-cloud/docs/create-locations). 

- **Policies**. A policy lets you define how threats are handled and what websites or web applications your users are allowed to access. For more information, see [Create a policy](https://techdocs.akamai.com/answerx-cloud/docs/create-policy) and [Manage a policy](https://techdocs.akamai.com/answerx-cloud/docs/manage-policy). 

- **Lists**. You can create a block lists to block domains, IP addresses, and top-level domains that you want to block or monitor. You can also create exception lists to define the domains or IP addresses that bypasses SPS Shield policy. You assign lists to a policy.  For more information, see [Create a list](https://techdocs.akamai.com/answerx-cloud/docs/create-list). 

- **Access control**. In a policy, you can define access to web applications and websites. For more information, see [Configure access control](https://techdocs.akamai.com/answerx-cloud/docs/configure-access-control). 

You can also:

- **Encrypt DNS queries with DoT or DoH**. By default, DNS queries from the Internet are not encrypted and are available in plaintext as they travel from a client to a DNS resolver. DNS over TLS (DoT) and DNS over HTTPS (DoH)  are protocols that allow you to encrypt these queries. For more information, see [Encrypt DNS queries with DoT or DoH](https://techdocs.akamai.com/answerx-cloud/docs/configure-dot-doh). 

- **Configure a custom response**. Allows you to direct suspicious traffic to a machine in your network where activity is recorded. Information about the user device that made the request is captured to discover the internal IP addresses of infected machines on the corporate network. You can assign a custom response to blocked threats in a policy. For more information, see [Configure a custom response](https://techdocs.akamai.com/answerx-cloud/docs/configure-custom-response).