# [Overview](https://techdocs.akamai.com/answerx-cloud/docs/sps-shield-ovw#overview)

DNSi AnswerX SPS Shield, a service based on Akamai’s cloud recursive DNS resolver solution and DNSi AnswerX Cloud technology, is part of the Security and Personalization Services (SPS) product family that provides web protection to small and midsize businesses (SMBs) and residential customers. It is a cloud-based service that enables Internet Service Providers (ISPs) and Mobile Network Operators (MNOs) to offer an essential security service to their SMBs and residential subscribers without IT integration. SPS Shield enables these providers to leverage the power of their networks to protect every SMB and residential customer from online threats such as malware, phishing, and bots.

# [Features](https://techdocs.akamai.com/answerx-cloud/docs/sps-shield-ovw#features)
- **Network-wide protection against malware, phishing, botnet, and spam**. SPS Shield protects end users from domains that are known or suspected to host malware, or that are used to carry out phishing attacks. By partnering closely with Akamai’s Internet security team and with the broader Internet security community, real-time updates are instantly disseminated to all SPS Shield service nodes, providing end users safe and secure access to the Internet.

- **Continuously updated threat intelligence**. Threat feeds used by SPS Shield are created by specialized systems that process massive volumes of live streamed DNS data from around the world every day. Dynamic updates ensure subscribers get continuous protection. Providers can also incorporate local threat intelligence.

- **Allow or block domain policy lists**. SPS Shield lets providers allow or block access to specific domains or IP addresses. You apply these lists to a policy. 

- **Create a policy that defines how threats are handled**. Providers can create a policy that contains policy actions for known or suspected threats such as malware, phishing, and command and control communication. 

- **Define access to websites and applications**. In a policy, you can allow, block, or monitor access to websites and applications based on risk level, category, or a specific application.

- **Customize a dashboard.** You can create a dashboard with widgets to track events and DNS activity.

- **Log delivery**. Akamai Log Delivery Service (LDS) provides server logs for the services that providers use. Akamai’s infrastructure is constantly gathering log entries from thousands of edge servers around the world. LDS creates a copy of these logs and delivers them based on a predetermined schedule.

- **Content filtering options**. Providers can offer different levels of web-filtering restrictions to their subscribers. Dedicated DNS service IP addresses and up to four dedicated DNS servers are associated with each option. Providers can remotely update subscribers' customer premises equipment (CPE) to point their DNS to the appropriate Akamai hosted service or dedicated IP.

# [Benefits to providers (ISPs and MNOs)](https://techdocs.akamai.com/answerx-cloud/docs/sps-shield-ovw#benefits-to-providers-isps-and-mnos)
- Simple integration effort and easy onboarding protects every provider network wide. Does not require IP tracking or operations support system/business support system (OSS/BSS) integration.
- Cloud-based solution speeds time to market and minimizes start-up investment.
- Foundational web defenses differentiate internet services beyond speed and reliability.
- Complete control over business model and pricing.
- Can be easily bundled with existing broadband services.
- Entry-level offering puts providers on a path to upsell revenue-generating services.
- Service-level agreement (SLA)-backed service.
- Access to service log data.

# [Benefits to end users (SMBs and residential subscribers)](https://techdocs.akamai.com/answerx-cloud/docs/sps-shield-ovw#benefits-to-end-users-smbs-and-residential-subscribers)
- Web defenses without any software or hardware installation.
- Instant protection against malware, phishing, botnet and spam threats.
- Optional preconfigured web filters block access to unwanted content.
- Network-wide protection.
- All devices are automatically covered.
- Essential web filtering.
- Continuously updated threat intelligence protects against today's agile exploits.