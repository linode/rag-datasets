# [DNSi AnswerX Reputation Knowledge Server (RKS) API](https://techdocs.akamai.com/answerx-cloud/docs/rks-api#dnsi-answerx-reputation-knowledge-server-rks-api)
