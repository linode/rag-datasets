# [Get revocation list identifier count information](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-revocation-list-meta#get-revocation-list-identifier-count-information)
