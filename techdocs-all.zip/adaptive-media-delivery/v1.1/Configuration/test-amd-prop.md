# [Test your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#test-your-amd-property)

Thorough testing of your application delivery from the Akamai edge network is required for every application.

One purpose of testing is to make sure that all existing content functionality is preserved. Another key task is to check the configuration because incorrect configuration settings can break various functions on your site or application. Additionally, Adaptive Media Delivery should increase the performance and availability of your content; testing provides a baseline for the increased performance and to test against settings that might yield further gains.

> Info: If you have existing testing procedures for application and content releases, you should follow them when testing edge network content delivery.

The test plan you use should at least accomplish the following:

- Stream your media assets to your chosen player.

- Perform critical and common functions with playback such as start, stop, and seek.

- If applicable, view images and download media.

- Recreate functions and transactions that a typical end user would perform.

# [HTTPS custom certificates: Push the edge certificate to staging](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#https-custom-certificates-push-the-edge-certificate-to-staging)

If you're going to use a custom certificate for the end user to edge server connection, you need to push it to the staging network before you test your HTTPS delivery.

By default, when you create a CPS-managed certificate, it is automatically deployed to the production network. To test the cert, you need to manually push it to the staging network. This is done in [Certificate Provisioning System](https://techdocs.akamai.com/cps/docs/deploy-stage-before-prod-testing).

# [Set up for testing](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#set-up-for-testing)

To actually set up for testing, you need to complete multiple tasks.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-testing-workflow-v1.png)

## [Activate your property on the Staging network](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#activate-your-property-on-the-staging-network)

To perform actual testing of your AMD property, you need to activate it on the Staging network in ​Akamai Control Center​.

1. Select the appropriate Control Center account using the drop-down in the top right.

1. Access Property Manager configurations associated with the selected Control Center account. Go to ☰ > **CDN** > **Properties**.

1. Filter the results of the Property Groups table by inputting the desired AMD property name in the **Filter by Property or Hostname** field.

1. Click the **Property Name**.

1. In the **Manage Versions and Activations** content panel, click the applicable **Version <#>** link to access it for testing.

1. Click the **Activate** tab.

1. Click **Activate v<#> on Staging**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-test-staging-v1.png)

8. Any warnings carried over from the configuration will be displayed as **Validation Messages**. You can click **Cancel** and edit the Configuration to acknowledge them.

1. Optionally, add descriptive **Notes** and/or use the **Notify via email** field to define e-mail address(es) that will receive notifications in the event of a Property file change (separate multiple entries with a comma--",")

1. Click the **Activate v<#> on Staging** button.

1. Monitor the **Activate** tab to track progress. You can also click the **"View Details"** link to review settings and information regarding the Property. The version should be active in the testing environment in about ten minutes.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-test-staging-monitor-v1.png)

## [Point your browser to edge servers](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#point-your-browser-to-edge-servers)

For testing, set up your local browser to target an applicable edge server to access your property.

1. Select the appropriate Control Center Account. Use the top-right pull-down in the header to select the account.

1. Access Property Manager configurations associated with the selected Control Center Account. Go to ☰ > **CDN** > **Properties**.

1. Filter the results of the Property Groups table by inputting the desired AMD property name in the **Filter by Property or Hostname** field.

1. Click the **Property Name**.

1. In the **Manage Versions and Activations** content panel, click the applicable **Version <#>** link to access it in the **Property Manager Editor.**

1. In the **Property Hostnames** content panel, locate and make note of the **Edge Hostname**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-test-staging-edge-hostname-v1.jpg)

7. Look up that hostname's IP address, and copy it to your clipboard using one of these methods:

    - **Windows**: Open a new command prompt, and perform an "nslookup" of your edge hostname.
    - **Linux/macOS**: Open a new terminal, and perform a "dig" of your edge hostname.

8. Open your local hosts file in a text editor. Based on your operating system, you may be able to find your host file as follows:

    - **Windows**: Navigate to `\system32\drivers\etc\hosts`
    - **Linux/macOS**: Navigate to `/etc/hosts`

> Info: The above paths are only examples of where this file might be found. Please see the relevant user documentation for the location of the Hosts file for your selected operating system.

9. At the end of the hosts file, add an entry for your website that includes the edge hostname's IP address (which you found in Step 7) and your property's domain, for example: `1.2.3.4 www.techpubs-video.com`.

1. Save and close your hosts file. All requests from your computer to your domain will now go to an edge server.

    - This applies to your local system, only.
    - To undo the redirection to the edge server, remove the new entry from your hosts file.

## [Confirm that your machine is pointed to an edge server](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#confirm-that-your-machine-is-pointed-to-an-edge-server)

Verify that you've properly pointed your system to our edge servers to begin testing.

Making a request to Akamai​ staging edge servers adds the HTTP response header `X-Akamai-Staging`. The value sent with this header is `ESSL` for requests to the staging network. (It's `EdgeSuite` for HTTP requests.)

After your browser points to the staging edge servers, make a test request against the new property configuration on the staging network, and then check for the `X-Akamai-Staging` response header to see if the response is coming from the staging network.

1. Close all browser windows, reopen your browser, and clear the browser cache.

1. Go to a page you want to test.

1. Access Network and make a request to the page.

    - **Chrome**. Press **Ctrl+Shift+I** (Windows) or **Command+Opt+I** (macOS) for the developer tools, and click the **Network** tab.
    - **Firefox**. Press **Ctrl+Shift+I** (Windows) or **Command+Opt+E** (macOS). This takes you to the Network tool.
    - **Internet Explorer/Microsoft Edge**. Press **F12**, and then press **Ctrl+4** to open the Network utility.

4. Click the first file listed.

1. Take a look at the response headers. If you see either `X-Akamai-Staging: ESSL` you know that your request is going to the staging edge server. (You should see `X-Akamai-Staging: EdgeSuite` for HTTP.)

1. Check for the `X-Cache` entry.

    ```
    HTTP/1.1 200 OK
    Server: Apache/2.4.9 (Unix) OpenSSL/1.0.1-fips
    Last-Modified:Wed, 26 Jun 2013 18:28:37 GMT
    ETag: "6795-3j012d0468q42"
    Accept-Ranges: bytes
    Content-Length: 13162
    Content-Type: image/gif
    Cache-Control: max-age=603241
    Expires: Mon, 14 Apr 2021 16:48:38 GMT
    Date: Mon, 07 Apr 2021 17:04:37 GMT
    X-Cache: TCP_MEM_HIT from b128-48-122- 38.deploy.akamaitechnologies.com (AkamaiGHost/6.15.0.3-12528292) (-)
    X-Cache-Key: /L/16428/676192/4j/orign-example.com/KMK/ samplepicture.gif?348531
    Connection: keep-alive
    ```

7. Use this table to interpret the results.

Did the page load as expected? | Is the X-Cache entry present? | Result  
 ---|---|---  
 Yes | Yes | Success! You're ready to test.  
 No | Yes | You reached an edge server, but something isn't working. The value of the X-Cache entry might help you identify the problem.  
 Yes | No | You reached the origin server, not the edge server. Check the entry you added to your hosts file.  
 No | No | You have not reached either the edge or your origin server. Check the entry you added to your hosts file.

# [Test the configuration on staging](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#test-the-configuration-on-staging)

Test your content just as you would if you were testing on the origin server.

> Warning: When developing tests, don't use edge hostnames to request content. Edge hostnames are only used to resolve requests to your property hostname, to get your content from the edge network.

1. Check key functionality, such as logging in, playback, and so on.

1. Once you're satisfied that your property works, remove the entry you added to your local hosts file, when you set up to [point your browser to edge servers](#point-your-browser-to-edge-servers). 

1. Save your hosts file.

1. On macOS 10.6 and later, flush your DNS cache again with the `dscacheutil -flushcache` command.

# [What's next](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#whats-next)

If the testing is successful, you can push the property and, if applicable, the associated custom edge certificate, to the ​Akamai​ [production network](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live).