# [Finalize your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#finalize-your-amd-property)

Once you've defined all Rules and Behaviors for your property, you need to address any noted conflicts or issues.

1. Review the settings in all Behaviors and ensure that they are set as desired.

1. Access the message center tab to review the messages there. Click the **up triangle** to display messages:

    - **Ensure that there are no errors**. Review any listed errors and resolve them in the applicable behaviors until **0 Errors** is displayed.

    - **Acknowledge all warnings**. This includes any behavior you may have customized outside of what's predefined as its best practice. If desired, perform any necessary actions to resolve a warning. Otherwise, click **Hide Message** to dismiss it.

3. Collapse the message center tab, using the **down triangle**.

1. Review all other settings for your AMD property and ensure they're set as required.

1. Scroll to the bottom of the page and click **Save**.

Here's an example of the message center tab, with all errors resolved, but multiple warnings displayed.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-finalize-v1.png)

