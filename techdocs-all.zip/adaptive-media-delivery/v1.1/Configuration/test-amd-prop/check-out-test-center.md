# [Check out Test Center](https://techdocs.akamai.com/adaptive-media-delivery/docs/check-out-test-center#check-out-test-center)

If you already have a property in place, successfully delivering media to your end users, a change to that property could negatively impact or even break delivery. We've always recommended that you thoroughly test any changes you make on our staging network before going live to production. Testing this way typically required setting up a manual environment to do so. Now, Akamai offers Test Center.

# [What is Test Center?](https://techdocs.akamai.com/adaptive-media-delivery/docs/check-out-test-center#what-is-test-center)

Test Center is a testing tool that checks the effect configuration changes will have on your web property. It helps you ensure that your changes aren't behaving unexpectedly before you activate them in production. It helps prevent issues caused by misconfiguration and insufficient testing and increases your confidence in the safety and correctness of your changes. 

The application lets you run two types of tests:

- **Functional testing**. This lets you check if the configuration changes work as expected. 
- **Comparative testing**. This lets you compare the behavior of your hostnames between the current and new configurations.

It was designed as an addition to your existing tests and workflows, and not as their replacement. It's available as a user interface in [​Akamai Control Center​](https://techdocs.akamai.com/test-ctr/docs) and as an [API](https://techdocs.akamai.com/test-ctr/reference/api).