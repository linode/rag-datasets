# [Player integration requirements](https://techdocs.akamai.com/adaptive-media-delivery/docs/player-intgr-req#player-integration-requirements)

AMD is designed for use with standard media players, such as an Open Source Media Framework (OSMF) player, JWPlayer, Flowplayer, HLS.js, and DASH.js. For the most part, modifications to the player are not necessary to deliver content through AMD.

There are some requirements you should be aware of.

# [Do you need token authentication in your player?](https://techdocs.akamai.com/adaptive-media-delivery/docs/player-intgr-req#do-you-need-token-authentication-in-your-player)

If you use token authentication to secure the links to your content, you may need to modify your player to support the token exchange that takes place between Akamai edge servers and your player. These changes vary depending on the format of the content you're serving. The requirements are the same for both live and on-demand delivery.

Format | Requirements  
 ---|---  
 **DASH (via DASH.js)** | If you are using DASH.js for playback of Dynamic Adaptive Streaming for HTTP (DASH) content, you'll need to make some modifications to DASH.js to include support for token authentication. 1\. Import JS MIN Lib. 
     
     script src="akamai-dashjs/dist/akamai-dashjs.min.js"
     
 
 1\. Create an instance of `MediaPlayer` and extend `RequestModifier` with `AkamaiRequestModifier` before you call initialize on MediaPlayer.js. 
     
     var player = dashjs.MediaPlayer({}).create();
     player.extend("RequestModifier", AkamaiRequestModifier, false);
     player.initialize(videoEl, null, true);
     
 
 ***We offer a DASH support player** * You can access a player supported for use with DASH and AMD at: 
.  
 **HLS** | You don't need to modify a player to support token authentication for Apple HTTP Live Streaming (HLS) format media.  
 **HDS** | To support token authentication for HTTP Dynamic Streaming (HDS) content, you'll need to incorporate some changes to the native OSMF player. These changes account for the transfer of the token as a query string parameter in requests from the player. Contact your account representative for additional details.

# [Are you using prepackaged streams?](https://techdocs.akamai.com/adaptive-media-delivery/docs/player-intgr-req#are-you-using-prepackaged-streams)

This applies if you're delivering your streams from prepackaged files, as opposed to pre-segmented files. For example, if your content is comprised of contiguous fragmented MP4 files and not individual MP4 chunks, you'll need to append the `pkz=1` query parameter to the playback URL:

```

/manifest.f4m?pkz=1
```

 > Note: 
 If you're using prepackaged DASH content, follow what's covered for DASH (via DASH.js) in the previous table.