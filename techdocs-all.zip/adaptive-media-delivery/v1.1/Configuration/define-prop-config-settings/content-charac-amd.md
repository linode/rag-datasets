# [Content Characteristics & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#content-characteristics-amd)

This behavior lets you define specific information about your content to optimize its delivery.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-cont-char-settings-v1.png)

# [Catalog Size](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#catalog-size)

Use this to set the overall volume of objects to be delivered through this property.

- **Small**. Select if all of your content is less than 100G.
- **Medium**. Select this if all of your content 100G to 1TB.
- **Large**. Select this is all of your content ranges from 1TB to 100TB.
- **Extra Large**. Select this if all of your content is greater than 100TB.
- **Unknown** (Default). Select this if you don't know the volume.

# [Content Type](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#content-type)

If you're delivering a specific type of content with this property, you can select it here to help optimize delivery.

- **Standard Definition**. This is typically 480i/p or 720p.
- **High Definition**. This is typically 1080i or 1080p.
- **Ultra High Definition (4K)**
- **Other**. Select this if your use case isn't available for selection, or it is a combination of the available selections.
- **Unknown** This is the default. Leave it set to this if you're unsure of the specific content type. AMD will still try to optimize delivery based on the request.

# [Popularity Distribution](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#popularity-distribution)

Select how often the content is requested:

- **Long Tail**. This applies if most of the traffic volume consists of a small number of requests for content that has a relatively long life.
- **Popular**. This applies if most of the traffic volume consists of a large number of requests for content that has a relatively short life.
- **Other**. Select this if your use case isn't available for selection, or it is a combination of the available selections.
- **Unknown**. This is the default. Select this if you're not sure of the popularity level for the content to be delivered by this property. AMD will still try to optimize delivery based on the request.

# [Origin Object Size](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#origin-object-size)

Use this to set a range for the size of the objects delivered through this property:

- **Less than 1MB**. Partial object caching *is not* applied.
- **1-10MB**. Partial object caching *is not* applied.
- **10-100MB**. Partial object caching is automatically enabled with this setting.
- **Greater than 100 MB**. Partial object caching is automatically enabled with this setting.
- **Unknown**. Select this if you're unsure of the specific object size, or you don't have a fixed size for target content. Partial object caching is automatically enabled with this setting for objects greater than 10 MB in size.

## [Partial object caching](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#partial-object-caching)

Partial object caching is part of our large file optimization support. It increases origin server offload by caching in chunks, instead of as a single, composite object. Partial object caching is required for the delivery of "large files"—those in excess of 10 MB in size. It's automatically enabled if you select any of these as your **Origin Object Size**:

- **10-100 MB**.
- **Greater than 100 MB**.
- **Unknown**. Partial object caching is applied for an object that is greater than 10 MB in size, if the object falls into what you've selected for **Content Type**. For example, if you've selected "High Definition" as your Content Type, partial object caching is enabled if a file of that type is requested that's over 10MB in size.

If you set Origin Object Size to **Less than 1MB** or **1-10MB**, partial object caching is not enabled. If a request is made through this configuration for a larger file, a 403 error is returned.

If you specify a large file setting, but your origin never actually serves files in that size range, the Akamai platform makes additional requests to the origin. This can impact overall performance and access. This happens because the edge server requests the first byte of each object to determine if the minimum object size criteria has been met&mdash;at least 10MB. Once that check fails, the server simply re-requests the entire object from the origin.

We recommend that you verify the size of your delivery objects on your origin, and select the appropriate size to ensure that partial object caching is enabled or disabled, as necessary.

> Success: You may want partial object caching for on demand video, but not for live. Typically, on-demand format video files require a large file setting and partial object caching because these tend to be larger, composite files. Live video, which tends to be distributed as smaller, individual segments doesn't require partial object caching, so the smaller file settings should be selected as the **Origin Object Size**. This may not apply to all environments, which is why we recommend that you verify your media file size requirements.

# [Enable \](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#enable)

You can select from multiple switch buttons, for the various media formats supported for use&mdash;**Enable HLS** (HTTP Live Streaming for iOS), **Enable HDS** (HTTP Dynamic Streaming for Adobe Flash), **Enable DASH** (Dynamic Adaptive Streaming over HTTP) and **Enable Smooth** (for Microsoft Smooth Streaming). Set the switch to **Yes** for each format to be supported by this property. Additional options for each format include the following:

- **Fragment/Segment Duration**. Select the desired fragment or segment duration for the selected media format.
- **Origin Object Size**. Use this to set a range for the size of media objects delivered through this property&mdash;Less than 1MB, 1-10MB, 10-100MB, or Unknown (This is the default, and should be left as the selected setting if you are not sure of the size of objects to be delivered).

# [Best practices settings applied by default](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#best-practices-settings-applied-by-default)

Akamai automatically applies various best practices settings to coincide with the Content Characteristics behavior in your property configuration. You don't need to manually define these via individual behaviors, because Akamai presets them for optimal performance.

Feature | Setting applied  
 ---|---  
 **Optimized For** |  AMD is optimized for streaming video on demand (VoD) using these media formats: \- **CMAF** \- **DASH** \- **HDS** \- **HLS** \- **Smooth**   
 **Streaming Format Identification** |  Your property supports various formats. AMD applies best practices settings for each, when you select them in this behavior. They're also used to generate logging and reporting information. \- **DASH** : \- **Manifest**. mpd \- **Segments**. dash, divx, ismv, m4s, m4v, mp4, mp4v, sidx, webm, mp4a, m4a, isma \- **HDS** : \- **Manifest**. f4m, f4x, drmmeta, and bootstrap \- **Fragments**. f4f and Seg-Frag URL structure \- **HLS** : \- **Manifest**. m3u8, m3u, m3ub, and key \- **Segments**. ts, aac, and mp4 \- **Smooth** : \- **Manifest**. /manifest/ \- **Fragments**. /QualityLevels/Fragments/ The following points also apply: \- **CMAF is supported for use with *live* media in your AMD property**. You can set it up to distribute live media via our Media Services Live (MSL) product. You need to first package your HLS, DASH, or both as CMAF. Then, you need to set up a Media Services Live stream and select the **CMAF (HLS & DASH)** Input Format. Finally, you'd select **DASH**, **HLS**, or **Both** here in this behavior. For full details on this workflow, see the [Media Services Live user docs](https://techdocs.akamai.com/msl/docs/setup-media-services-live-origin). \- **With CMAF, logging and reporting information is displayed as the specific format of the request manifest**. So, it'll be either HLS or DASH. \- **Did you enable both DASH and HLS in this behavior**? If you did, AMD identifies the file format as DASH.   
 **Segment Durations** |  The property automatically applies these segment durations when you select the applicable media format. This is also used for logging and reporting data. \- **DASH**. The segment duration is set to six (6) seconds \- **HDS**. The segment duration is set to six (6) seconds \- **HLS**. The segment duration is set to 10 seconds \- **Smooth**. The segment duration is set to two (2) seconds   
 **Basic HTTP Settings** |  These basic HTTP-specific settings are applied: \- HTTP version 1.1 \- Transfer / Chunked encoding between Edge and client \- Allow GET/HEAD Methods   
 **Cross Origin Resource Sharing (CORS)** |  The following CORS headers are included with the following values: \- **Access-Control-Allow-Origin = *** \- **Access-Control-Allow-Credentials = true** \- **Access-Control-Allow-Methods = GET, OPTIONS, POST** \- **Access-Control-Allow-Headers = origin,range,hdntl,hdnts** \- **Access-Control-Expose-Headers = Server,range,hdntl,hdnts** \- **Access-Control-Max-Age = 86400**  
 **GZIP Content Compression** |  The GZIP compression-related settings are automatically applied: \- **Automatically enabled for origin to edge**. This only applies if the `Accept-Encoding header` is sent in the request to the origin. \- **Automatically enabled for edge to client**. This only applies if the `Accept-Encoding` header is received from the client.   
 **Caching** |  These caching-related settings are applied: \- **The Remove VARY header is sent from origin**. This enables content caching. \- **Positive caching policy for response codes**. 200, 203, 300, 301, 302 and 410 \- **Positive Caching Time to Live (TTL)**. 365 days \- **Negative caching for response codes**. 204, 305, 404, and 405 \- **Negative caching TTL** : \- **NetStorage as your origin**. 30 seconds \- **All other origins**. One (1) second   
 **Content Type** |  Based on the selected media format file type, the `Content Type` header is formatted to include this information: \- **m3u8, m3u, or m3ub**. `Content Type: "application/x-mpegURL"` \- **ts**. `Content Type: "video/MP2T"` \- **webvtt or vtt**. `Content Type: "text/vtt"` \- **f4m, f4f, or f4x**. `Content Type: "video/f4m"` \- **mpd**. `Content Type: "application/dash+xml"` \- **dash, divx, mp4, mp4v, m4s, or m4v**. `Content Type: "video/mp4"` \- **web**. `Content Type: "video/webm"` \- **mp4a or m4a**. `Content Type: "audio/mp4"` \- **isma**. `Content Type: "audio/mp4"` \- **ismv**. `Content Type: "video/mp4"` \- **aac**. `Content Type: "audio/aac"` \- **sidx or init**. *No content type is added.* 

# [Content characteristics and mixed mode configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#content-characteristics-and-mixed-mode-configuration)

This is a "use case-based" behavior that's automatically included in the Default Rule and used to optimize delivery. You need to apply settings for this behavior in the Default Rule. However, with Mixed Mode Configuration for AMD (MMC), you can also include it in another rule and apply different match criteria to have separate requests use different content characteristics optimizations. 

For more details, see [Mixed Mode & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd).