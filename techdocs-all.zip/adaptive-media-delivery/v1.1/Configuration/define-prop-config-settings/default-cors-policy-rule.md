# [The Default CORS Policy Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#the-default-cors-policy-rule)

Cross-Origin Resource Sharing (CORS) is an HTTP-header-based tool that's used to locate other origin servers that an end user's browser can use to get your content. CORS uses a "preflight check" mechanism: A request is made to the origin server where the cross-origin content is stored, to make sure the request is allowed. If it's allowed, the browser sends various headers that indicate the HTTP method and headers to be used in the actual request.

If you have CORS set up in your environment—via scripts in ths `XMLHttpRequest` object on your site or app, or through some other mechanism—the **Modify Outgoing Response Header** behaviors in this rule are set up to modify various `Access-Control` response headers, to indicate what's supported after the CORS preflight check. *This effectively sets the HTTP method and headers that a browser can use in a CORS request*.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-default-cors-v1.png)

- **Access-Control-Allow-Origin**. This modifies this header value to "*****" to get the header to acknowledge all origin servers. This way, this header won't inadvertently block access to an origin that may host your content. 

- **Access-Control-Allow-Methods**. This modifies this header to ensure that only the GET, POST, and OPTIONS methods are allowed in a request from the browser.

- **Access-Control-Allow-Headers**. This header indicates which HTTP headers can be used during the request from a browser. This modifies this header so that only [`origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Origin), [`range`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Range), `hdntl`, `hdnts`, `CMCD-Request`, `CMCD-Object`, `CMCD-Status`, and `CMCD-Session` request headers are supported. The `hdntl` and `hdnts` headers are Akamai-specific headers used in the delivery of media content. All of the `CMCD-` headers are used to support [Common Media Client Data](#about-common-media-client-data).

- **Access-Control-Expose-Headers**. This header indicates which response headers should be available to a script running in the requesting browser. This modifies this header so that only the [`Server`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Server), `range`, `hdntl`, `hdnts`, `Akamai-Mon-Iucid-Ing`, `Akamai-Mon-Iucid-Del`, and `Akamai-Request-BC` headers are supported. The `Akamai-Mon-Iucid-Ing` and  `Akamai-Mon-Iucid-Del` headers are included to support Akamai client-side analytics. `Akamai-Request-BC` allows for CORS support with the [Breadcrumbs](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-breadcrumbs) feature with AMD.

- **Access-Control-Allow-Credentials**. This modifies this header to set it to `true`. When a request requires credentials for content, a browser will only pass the preflight check if the Access-Control-Allow-Credentials value is `true`. Credentials are cookies, authorization headers, or TLS client certificates. For example, with this value set to true, if your origin server requires credentials (a cookie) to access cross-origin content, and no cookie is present, the "credential check" fails. The response is then ignored by the browser and the content is not returned.

- **Access-Control-Max-Age**. This header determines how long the results of a preflight check can be cached. This sets it to `86400` seconds which equals 24 hours.

> Success: For best performance, we recommended that you leave this rule and all of its behaviors in the configuration. But, none of its settings are mandatory.

# [About Common Media Client Data](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#about-common-media-client-data)

An end user's media player has an understanding of playback behavior that a content delivery network (CDN) can't anticipate from server-side data alone. To help with this, we offer support for "Common Media Client Data (CMCD)." This is an open specification created by the Consumer Technology Association (CTA). Media players can use it to send playback information to Akamai (and other CDNs) for storage in logs:

* **The logs can help with troubleshooting**. More data = more help fixing problems. Akamai customer support can quickly access this log data to help reduce troubleshooting time.

* **Log data is available in DataStream 2**. You can configure and steer the data destination to a location where his business application visualization and analysis are carried out.

# [Send CMCD data from the Client](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#send-cmcd-data-from-the-client)

CMCD client data can be sent to Akamai using either of these methods:

* **As a custom HTTP request header**.
* **As an HTTP query argument**.

There are guidelines laid out in the [CMCD specification](https://cdn.cta.tech/cta/media/media/resources/standards/pdfs/cta-5004-final.pdf). Look to it for the latest recommendations on transmitting information in your requests. 

> Info: A single request shouldn't include both CMCD headers and query arguments. If one does, Akamai ignores the query argument.

# [Set up your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#set-up-your-amd-property)

You'll need to make sure your property is set up properly to receive CMCD data, based on how the client is sending it.

## [Use custom CMCD headers](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#use-custom-cmcd-headers)

You can incorporate support for CMCD headers in multiple ways.

Method | Description |  **Create a new AMD property**  |  If this is a new property, support for CMCD is automatically added to the [Default CORS Policy Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule). The `CMCD-Request`, `CMCD-Object`, `CMCD-Status`, and `CMCD-Session` request headers are included in the Select Header Name field for the Modify Outgoing Response behavior, that's set up for the **Access-Control-Allow-Headers**.  ![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-cmcd-v1.jpg)  
 ---|---  
 **Create a new version of an existing AMD property**  |  If the property contains the Modify Outgoing Response Header behavior, either standalone or as part of the [Default CORS Policy Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule), Akamai will *automatically* add the `CMCD-Request`, `CMCD-Object`, `CMCD-Status`, and `CMCD-Session` request headers if the following apply: * **Action** is set to **Modify** or **Add**. * **Select Header Name** is set to **Access-Control-Allow-Headers**. * **New Header Value** is _not_ set to *****. This is a wildcard indicating _all_ headers.   
 **Add a separate instance of Modify Outgoing Response Header behavior**  |  If you're not employing the Default CORS Policy rule, you can include the Modify Outgoing Response Header behavior in another rule. If this is the case, this behavior's settings need to be set as follows: * **Action**. Set this to **Modify** or **Add**. The former will *replace* any Access-Control-Allow-Headers in a request with what's set in NewHeader Value. The former will *add* what's set there to any Access-Control-Allow-Headers received in a request. * **Select Header Name**. Set this to **Access-Control-Allow-Headers**. * **New HeaderValue**. Enter the CMCD headers: `CMCD-Request`, `CMCD-Object`, `CMCD-Status`, and `CMCD-Session`. 

## [Use query arguments](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#use-query-arguments)

If you'd prefer to use query arguments, you don't need to add any specific functionality to your property. Just ensure that requests from the player *don't include* CMCD headers, as they'll take precedence. To help with this, you could also make sure that:

* **The Default CORS Policy rule doesn't apply**. Ensure that this rule is either removed from your property or that the Modify Outgoing Response behavior, that's set up for the **Access-Control-Allow-Headers** is removed or disabled.

* **The Modify Outgoing Response behavior doesn't apply**. Ensure that there isn't an instance of this behavior anywhere in your property, that includes the CMCD headers as **Access-Control-Allow-Headers**.

-->