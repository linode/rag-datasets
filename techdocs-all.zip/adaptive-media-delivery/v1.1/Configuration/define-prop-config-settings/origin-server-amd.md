# [Origin Server & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-server-amd#origin-server-amd)

An origin server is a physical location that Akamai uses to get your actual content. This behavior is required in all properties that retrieve content from an origin.

![](https://techdocs.akamai.com/ion/img/origin-server-generic-v1.jpg)

# [This behavior in the Default Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-server-amd#this-behavior-in-the-default-rule)

Origin Server is a mandatory behavior in the Default Rule. An error message is revealed if you delete it, and you need to re-add it. However, you can include an *additional instance* of the Origin Server behavior in a custom rule outside of the Default Rule. This lets you override what's set in the Default Rule in favor of an alternate origin for various purposes: authorization requests, redirects for downloads, access-denials, failover settings, redirects for special user agents, language settings, or for other needs.

# [How to configure this behavior](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-server-amd#how-to-configure-this-behavior)

You can set up different types of origin server and there are prerequisites you need to meet before you start applying settings in this behavior. To help with this, we've set up start-to-finish workflows:

- [The NetStorage origin server workflow](https://techdocs.akamai.com/property-mgr/docs/the-netstorage-origin-server). Here, you use Akamai's NetStorage service to serve as your origin. It helps automate some of the more complex processes required to set up an origin and integrate it with your Adaptive Media Delivery property.

- [The custom origin server workflow](https://techdocs.akamai.com/property-mgr/docs/the-custom-origin-public). Follow this workflow if you have your own origin server that holds all of your website or app content that you want to deliver to your end users.

- [The third-party origin server workflow](https://techdocs.akamai.com/property-mgr/docs/the-third-party-origin). Take a look at this workflow if you're using a third-party cloud provider, such as Amazon Web Services or Google Cloud Storage to serve as your origin server.