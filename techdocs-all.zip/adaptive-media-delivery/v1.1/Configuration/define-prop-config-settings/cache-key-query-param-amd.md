# [Cache Key Query Parameters & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/cache-key-query-param-amd#cache-key-query-parameters-amd)

This behavior controls whether the query string or portions of it are used to differentiate objects in cache.

This behavior is automatically included in the Default Rule for a property configuration for AMD. Unlike other behaviors that are automatically included in this rule, it's not required. While we recommend you set it in the Default Rule, so that it will apply to all requests, you can remove it from this rule.

# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/cache-key-query-param-amd#before-you-begin)

Before you work with this behavior and all caching-related behaviors, Akamai recommends that you read, [Learn about caching](https://techdocs.akamai.com/property-mgr/docs/know-caching) in the Property Manager help. It'll help you better understand caching and how it works within the Akamai network.

# [Set up for AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/cache-key-query-param-amd#set-up-for-amd)

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-cache-key-query-enable-v1.png)

The default setting for this behavior is **Exclude all parameters**. This means that all requests for the same URL are served from a single cache entry *regardless of the query string in a request*. For example, these two requests would be served from the same object in cache:

```
http://mymedia.com/directory/manifest?token=1234598765
http://mymedia.com/directory/manifest?token=9876512345
```

This setting tells Akamai to only consider the URL without the query string when looking in the cache. Using the examples above, that would be:

```
http://mymedia.com/directory/manifest
```

Is the default **Exclude all parameters** setting appropriate for your content? If not, pick the appropriate setting for your environment to have Akamai optimize delivery by incorporating use case-based provisioning.

> Warning: NetStorage doesn't honor query strings. If you're using it as your origin server, this needs to be set to **Exclude all parameters**.

Other available options include:

Behavior | Description | Parameters | Exact Match |  **Include all parameters (preserve order from request)**  |  All of the query string parameters in a request are included, and they're applied in the order they exist in the request.  |  N/A  |  N/A   
 ---|---|---|---  
 **Include all parameters (reorder alphabetically)**  |  All of the query string parameters in a request are included, but they're reordered alphabetically and then applied.  |  N/A  |  N/A   
 **Include only specified parameters...**  |  Only specific query strings are included, and all others are ignored.  |  Enter the query string parameters you want *included in* the cache key. Matches are determined by prefix-matching each query string. If the query parameter with its value (`name=value&`) contains an item in this list (for example, `name`, `name=`, `name=value`, or `name=value&`), then the parameter and value are *included*. It must also exactly match the case from the request URL, regardless of any other case-sensitivity settings.  |  #### Yes To honor a query string in a request, its name needs to be exactly what's set in Parameters. For example, if you input `firststring` and `secondstring` in Parameters, and set this to *Yes*, query string arguments are only accepted if they use the names `firststring` or `secondstring`—`?firststring=`, `?secondstring=', or `?firststring=&secondstring;=`.  ![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-include-only-spec-param-yes-v1.jpg) #### No The individual strings you set in Parameters are included for a request if their name matches a portion of the name in the actual request. For example, assume you included `x-string` and `y-string` as Parameters and set this to "No." If a request includes the query string `?x-strings=1234&a-string;=5678&y-string;=91011`, both the `x-strings` and `y-string` values are included, and the `a-string` value is ignored.  ![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-include-only-spec-param-no-v1.jpg)  
 **Exclude only specified parameters**  |  Specific query strings are excluded, and all others are applied.  |  Enter the query string parameters you want *excluded from* the cache key. Matches are determined by prefix matching each query string. If the query parameter with its value (`name=value&`) contains an item in this list (for example, `name`, `name=`, `name=value`, or `name=value&`), then the parameter and value are *excluded*. It needs to also exactly match the case from the request URL, regardless of any other case-sensitivity settings.  |  #### Yes To exclude a query string from a request, its name needs to be exactly what's set in Parameters. For example, if you enter `firststring` and `secondstring` in Parameters, and set this to *Yes*, query string arguments are only excluded if they use the names `firststring` or `secondstring`—`?firststring=`, `?secondstring=', or `?firststring=&secondstring;=`.  ![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-exclude-only-spec-param-yes-v1.jpg) #### No The individual strings you set in Parameters are excluded from a request if their name matches a portion of the name in the actual request. For example, assume you included `x-string` and `y-string` as Parameters and set this to "No." If a request includes the query string `?x-strings=1234&a-string;=5678&y-string;=91011`, both the `x-strings` and `y-string` values are excluded, and the `a-string` value is included.  ![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-exclude-only-spec-param-no-v1.jpg)

# [Be careful when changing the cache key](https://techdocs.akamai.com/adaptive-media-delivery/docs/cache-key-query-param-amd#be-careful-when-changing-the-cache-key)

If you change the cache key globally or for too many objects on a property that is already active&mdash;that is, if you create a new version that has a different cache key for all content&mdash;you can create problems for your origin when you activate the new version on production. When you change the cache key, you invalidate cached content that's using the existing cache key. Akamai edge servers will request new objects from your origin *at a level that can create severe spikes in bandwidth*.

If you need to change the cache keys on an active configuration, you should limit the changes: send them out a few changes at a time over an expanded time frame.