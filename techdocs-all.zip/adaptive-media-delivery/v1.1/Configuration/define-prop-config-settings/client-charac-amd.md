# [Client Characteristics & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-charac-amd#client-characteristics-amd)

This behavior offers options you can use to optimize delivery to requesting Clients.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-client-char-v1.png)

# [Client Location](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-charac-amd#client-location)

Select a location that is *geographically closest* to the clients accessing content through this property configuration, to optimize the delivery. This is one aspect of what we consider optimization via use case-based provisioning.

 > Note: 
 If you're unsure of your client's locations, leave this set to **Unknown**. If you select an inappropriate geographic region, it could negatively affect delivery.

# [Client characteristics and mixed mode configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-charac-amd#client-characteristics-and-mixed-mode-configuration)

This is a "use case-based" behavior that's automatically included in the Default Rule and used to optimize delivery. You need to keep this behavior in the Default Rule and apply settings. But, with mixed mode configuration for AMD (MMC), you can also include it in *another* rule and apply different match criteria to have separate requests use different client characteristics optimizations. For more details, see [Mixed Mode & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd).