# [Go live with AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#go-live-with-amd)

Once all of the configuration steps and testing are complete, you can go live to begin delivering your content.

# [Change the DNS record to point to your configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#change-the-dns-record-to-point-to-your-configuration)

Before you can fully activate your AMD property in the production ("live") network, you need to change the existing DNS record for your site or application to be a CNAME record that points to the edge hostname. Once you modify the DNS record, it's typically only a matter of hours until your content is served via the Akamai edge network.

Here are some DNS record examples:

DNS Record | Example | Notes |  Generic DNS record  |  `www.example.com . IN A 1.2.3.4`  |  Where `1.2.3.4` is the IP address of your origin server   
 ---|---|---  
 Non-secure record pointing to Edge network  |  |  N/A   
 A secure, HTTPS record pointing to Edge network  |  `www.example.com . IN CNAME www.example.com.edgekey.net`  |  N/A 

Here are some examples of the DNS records required to deliver objects from the content delivery network. You need to replace `example` with the actual hostname(s) of your content to determine the DNS records that should be created.

## [Example #1: Non-secure "www" Site](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#example-1-non-secure-www-site)

- **Origin-server Hostname**. `origin-www.example.com IN A {IP of origin servers}`
- **Edge Hostname**. `www.example.com.akamaized.net`
- **Production Hostname**. `www.example.com. IN CNAME www.example.com.akamaized.net`

## [Example #2: Secure "www" Site](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#example-2-secure-www-site)

- **Origin-server Hostname**. `origin-www.example.com IN A {IP of origin servers}`
- **Edge Hostname**. `www.example.com.edgekey.net`
- **Production Hostname**. `www.example.com . IN CNAME www.example.com.edgekey.net`</td>

## [Example #3: Non-secure Image Hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#example-3-non-secure-image-hostname)

- **Origin-server Hostname**. `origin-images.example.com IN A {IP of origin servers}`
- **Edge Hostname**. `images.example.com.akamaized.net`
- **Production Hostname**. `images.example.com. IN CNAME images.example.com.akamaized.net`

# [How long does the DNS change take?](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#how-long-does-the-dns-change-take)

This depends on the time to live (TTL) set on the existing DNS record for your site. This is commonly set to one day, which means it would take up to 24 hours before your end users are directed to the Edge network.

To shorten the cut-over to the Edge network, you can reduce your DNS TTL in advance of the change, and increase it to the normal TTL after the change.

You can switch your application to the Edge network at any time after completing the activation steps and testing. No additional activation or monitoring is required.

# [Troubleshooting](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#troubleshooting)

If you notice a problem after switching your content to the edge network:

1. Roll back the DNS change to point your website or application back to your servers.

1. Report the problem to Akamai.

This helps you and Akamai identify the problem in a controlled environment without affecting live end users.

# [Activate your property on the Production network](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#activate-your-property-on-the-production-network)

The final step in the process is to push your AMD property to the production ("live") network to distribute your content to end users.

> Info: This process assumes that the target AMD property has already been activated on the Staging network, for use in [testing](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop). *You must push a property to Staging before you can push it to Production*.

1. Select the appropriate Control Center Account. Use the top-right pull-down in the header to select the account.

1. Access Property Manager configurations associated with the selected Control Center Account. Go to ☰ > **CDN** > **Properties**.

1. Filter the results of the Property Groups table by inputting the desired AMD property name in the **Filter by Property or Hostname** field.

1. Click the **Property Name**.

1. At this stage, you have one of two choices in activating your property:

    - **Activate the Staging Version**: This entails accessing the version of the Property currently on the Staging network and activating it on Production. In the **Manage Versions and Activations** content panel, locate the **Version #** of the property currently in Staging (the one created for Testing) and click it.

    - **Create a New Version of the Property**: This entails "cloning" the Staging network Property to create a new Version, and activating that version on Production (in order to maintain the version on the Staging network). To accomplish this, perform the following:

        1. In the **Active Staging Version** content panel, click **New Version**. This clones the property as **Property Name v#+1** (for example, www.example.com v2).

        1. If desired, review and modify the settings in the property.

        1. Click **Save**.

6. Select the **Activate** tab.

1. Click **Activate v<#> on Production**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-activate-production-v1.png)

8. Any warnings carried over from the configuration will be displayed as **Validation Messages**. You can click **Cancel** and edit the property to acknowledge them.

 > Note: 
 If you've created a new version of the property, an additional warning message is displayed here noting that this "new version:" has not been activated on Staging for testing. Click this message's checkbox to acknowledge and dismiss this warning.

9. Optionally, add descriptive **Notes** and use the **Notify via email** field to define email address(es) that will receive notifications in the event of a property file changes. Separate multiple entries with a comma&mdash;"**,** ")

1. Click **Activate v<#> on Production**.

1. Monitor the **Activate** tab to track progress. You can also click **View Details** to review settings and information regarding the property.