# [Update your origin configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/update-origin-config#update-your-origin-configuration)

If you're using your own custom origin to house your content for delivery, you may need to update it to work with your AMD property. For example, you might need to modify infrastructure settings such as session stickiness and load balancing.

> Info: Are you using NetStorage?. If you're using NetStorage as your origin server, the processes explained here *don't apply*.

# [Disable the origin server access control list (ACL)](https://techdocs.akamai.com/adaptive-media-delivery/docs/update-origin-config#disable-the-origin-server-access-control-list-acl)

If you have a client IP-based ACL on your origin servers, you need to disable it before beginning delivery of your content or application through the Akamai edge network. Once your application is delivered through the network, *your origin servers will no longer see the real client IP addresses and will block all requests*. If you need to maintain a client IP ACL, you can specify the list in your edge server configuration.

> Info: You can skip this if you don't have a client request ACL on your origin servers.

# [Use compatible load balancing](https://techdocs.akamai.com/adaptive-media-delivery/docs/update-origin-config#use-compatible-load-balancing)

Not all load-balancing algorithms are compatible with content delivery services. Incompatible systems include those based on client IP addresses, SSL session identifiers, or least-used connections to specific servers.

This is because more than one edge server can accept end-user requests in the same session and then forward them to the origin server. So, your origin server may see the different edge servers as different clients. In addition, your origin server will receive requests from a much smaller number of clients, once you switch to the edge network, as the requests are routed through Edge servers.

If you've been using load balancing based on client IP addresses or least-used connections, you need to change the load-balancing algorithm when using the edge network. Compatible algorithms are random or round-robin load distributions replicating session data across all origin servers.

# [Adjust your intrusion detection settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/update-origin-config#adjust-your-intrusion-detection-settings)

Using edge network services may trigger aggressively configured intrusion detection systems. This happens because requests from many end users are aggregated through a smaller number of edge servers, potentially making it seem like a single end user is making multiple requests for the same content.