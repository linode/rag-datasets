# [Other recommended tasks](https://techdocs.akamai.com/adaptive-media-delivery/docs/other-rcmd-tasks#other-recommended-tasks)

These tasks deal with monitoring and maintaining applications. They're recommended, but you don't have to complete them to implement your AMD property. We recommend you review these tasks and determine which ones best suit your needs.

# [Activate log delivery](https://techdocs.akamai.com/adaptive-media-delivery/docs/other-rcmd-tasks#activate-log-delivery)

Edge network logs can help you troubleshoot content and configuration problems. You can receive Edge server logs of all requests for your content in a standard log file format. These logs are aggregated from data from all Edge servers, sorted by time, and can be delivered with specified frequency to a specific email address, or sent to your FTP servers.

Log delivery is not enabled by default. If you need edge network logs, you need to activate it in ​Akamai Control Center​.

> Warning: It takes 24-48 hours for log delivery to start from the time you activate it. Keep this in mind when configuring log delivery. Make sure it's completely set up *before* delivering any actual content from the Akamai edge network. Logs can't be collected retroactively.

1. Access [​Control Center​​](https://control.akamai.com/apps/home-page/#/home) and log in using a **User ID** and **Password** that have been configured for access to AMD.
1. Select ☰ > **COMMON SERVICES** > **Log Delivery**.
1. Type *Adaptive* in the *Filter* field to filter results in the table to only AMD. 
1. Locate the applicable **ID** (CP code) or **Object Name** associated with your instance of AMD. 
1. Click the **...** in the Action column and select **Start a log delivery** > **New**.
1. Follow the wizard to set up log delivery.

> Info: Are you using NetStorage?. If your edge network services include logs delivery via FTP to your NetStorage account, specify the NetStorage FTP upload account in the Log Delivery settings. The NetStorage account information is included in your service activation package. You can also look it up in ​Akamai Control Center​.\n\nWhen you use NetStorage for log delivery, it's important to manage the content. If you don't remove excess log files, you may see large overage charges as the files take up more and more space. You can remove the log files after you download them, or you can set up automatic purging rules through the NetStorage interface on ​Control Center​​.

## [Test log delivery](https://techdocs.akamai.com/adaptive-media-delivery/docs/other-rcmd-tasks#test-log-delivery)

Edge network logs are delivered in standard log formats, such as W3C Extended log format. But, if you're currently using your own server logs for reporting or data analysis, you should verify that edge network logs are fully compatible with your log processing application. Test the first log files you receive from the edge network through your regular log processing application or workflow, and adjust them if necessary.

## [Additional details on log delivery](https://techdocs.akamai.com/adaptive-media-delivery/docs/other-rcmd-tasks#additional-details-on-log-delivery)

For complete details on log delivery and its use, see the [Log Delivery Service documentation](https://techdocs.akamai.com/log-delivery/docs).

# [Create additional administrator accounts](https://techdocs.akamai.com/adaptive-media-delivery/docs/other-rcmd-tasks#create-additional-administrator-accounts)

An administrator account for ​Akamai Control Center​ is provided to you in your account information after you initially provision AMD. As an administrator, you can create additional accounts with this, or lesser levels of access. Creating additional administrator-level accounts allows multiple people to log on and perform administrator-level tasks.

See the [Identity and Access Management documentation](https://techdocs.akamai.com/iam/docs) for instructions on adding new users.