# [Define property configuration settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-config-settings#define-property-configuration-settings)

The Property Configuration Settings content panel contains the rules for your property. Rules consist of match criteria and behaviors. If a request meets the conditions in a rule's match criteria, the behaviors in that rule are applied.

When you select a **Rule**, its match criteria and behaviors are displayed. Click each rule to view and manage its settings.

# [Understand property rule and behavior logic](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-config-settings#understand-property-rule-and-behavior-logic)

Property Manager applies a specific logic with the application of rules and the behaviors they contain. When setting up rules, remember these points:

![](https://techdocs.akamai.com/adaptive-media-delivery/img/property-mgr-rule-priority-v1.jpg)

- **The Default Rule is required and applies to all requests**.

- **Rule logic "trickles down"**. Rules stack and the last rule listed is read first. If a request does not meet the match criteria in the last rule, the second-to-the-last rule is checked next, and so on. Consider this when applying the same behaviors in multiple rules. For example, assume you've set up two optional rules with unique match criteria, along with the Default Rule that applies to all requests. They all contain the same behavior. If the match criteria in the second (last) rule isn't matched by a request, the first rule is checked. If that criteria isn't matched, what's set in the Default Rule is used for the request.

- **The Default Rule is applied to all requests**. Any behaviors included in the Default Rule, but not in an optional rule are applied to requests, too. However, if you set up the same behavior in an optional rule, and that rule's match criteria is met, *that* behavior's settings are used, rather than what's in the Default Rule.

- **Several of the behaviors in the Default Rule are required**. You can't delete certain behaviors from the Default Rule, and you have to configure them. If you want certain requests to use different settings for these behaviors, you can include them in an optional rule and set up different match criteria for these requests.