# [View AMD reports](https://techdocs.akamai.com/adaptive-media-delivery/docs/view-reports#view-amd-reports)

You can monitor and identify key trends of your Adaptive Media Delivery (AMD) traffic.

# [Use the user interface](https://techdocs.akamai.com/adaptive-media-delivery/docs/view-reports#use-the-user-interface)

Akamai offers easy-to-use interfaces in [Akamai Control Center](https://control.akamai.com). 

1. Go to ☰ > **MEDIA** > **Media delivery reports**.

1. From the drop-down at the top left, select **Adaptive Media Delivery > Realtime** or **Adaptive Media Delivery > Historical** to view tabbed reports.

You can customize these reports as needed.

- [Realtime > Realtime tab](https://techdocs.akamai.com/media-delivery-rpts/docs/the-realtime-tab-amd). The Realtime report displays various data for AMD at a latency of under 15 minutes. Each data point on the widget has a resolution time of five minutes.

- [Historical > Traffic tab](https://techdocs.akamai.com/media-delivery-rpts/docs/traffic-tab-amd). Traffic reports provide information on the number of hits, the bandwidth at which the media was available, and information on volume and hits per Content Provider (CP) code.

- [Historical > Performance tab](https://techdocs.akamai.com/media-delivery-rpts/docs/perf-tab-amd). Performance reports provide insights into the rate at which data is delivered and the volume and percentage of download requests.

- [Historical > Availability tab](https://techdocs.akamai.com/media-delivery-rpts/docs/availability-tab-amd). Availability reports provide details on responses at the Edge, origin, and by CP code, country, and autonomous system number (ASN).

- [Historical > URLs tab](https://techdocs.akamai.com/media-delivery-rpts/docs/urls-tab-amd). The URLs report provides details on the number of requests for a stream at the Akamai edge, midgress, and origin. Data is gathered on a daily basis.

- [Historical > Unique Viewers tab](https://techdocs.akamai.com/media-delivery-rpts/docs/unique-viewers-tab-amd). This report gives you information on the number of unique viewers accessing your media. This information is available by operating system (OS), geographic region (geo), device, and by CP code.

- [Historical > Manifest Personalization tab](https://techdocs.akamai.com/media-delivery-rpts/docs/manifest-personalization-tab-amd). This report shows requests for content that's been configured for delivery through the Manifest Personalization behavior in AMD.

- [Historical > URLs Legacy tab](https://techdocs.akamai.com/media-delivery-rpts/docs/urls-legacy-tab-amd). The URLs Legacy report lets you review historical data on a per-URL basis for one or more CP codes, over a range of time you specify. The period of time defaults to the current day.

- [Historical > Proxy Protection tab](https://techdocs.akamai.com/media-delivery-rpts/docs/proxy-prot-tab-amd). These reports show how Akamai's Enhanced Proxy Detection (EPD) service has applied proxy detection and location spoofing protection when delivering your AMD content.

- [Historical > Content Protection tab](https://techdocs.akamai.com/media-delivery-rpts/docs/content-prot-tab-amd). This report shows if Akamai's token-based Access Revocation service has detected marked authentication tokens in requests, and then blocked access to your AMD content.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-reports-generic-widget-v1.jpg)

# [Use the API](https://techdocs.akamai.com/adaptive-media-delivery/docs/view-reports#use-the-api)

Akamai offers the [Media Delivery Reports API](https://techdocs.akamai.com/media-delivery-rpts/reference/media-delivery-reports) that you can call to generate customized reports to meet your specific need.