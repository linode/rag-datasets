# [Welcome to Adaptive Media Delivery](https://techdocs.akamai.com/adaptive-media-delivery/docs/welcome-adaptive-media-deliv#welcome-to-adaptive-media-delivery)

Adaptive Media Delivery (AMD) is optimized for adaptive bit rate streaming to provide a high-quality, secure viewing experience across a broad variety of network types—fixed or mobile—at varying connection speeds. Built on the Akamai Intelligent Platform™, AMD provides superior scalability, reliability, availability, and reach.

AMD securely delivers prepared, pre-segmented HTTP-based live and on-demand streaming media.
[block:html]
{
  "html": "
\n
\n  
\n  **
Error**
: The video's URL was inaccessible.\n
\n
"
}
[/block]
# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/welcome-adaptive-media-deliv#before-you-begin)

- [Familiarize yourself with key concepts and terms](https://techdocs.akamai.com/property-mgr/docs/key-concepts-terms)
- [Review supported media formats](https://techdocs.akamai.com/adaptive-media-delivery/docs/supported-media-formats) 
- [Get your unique information](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-environ-info) 
- [Understand the request flow](https://techdocs.akamai.com/adaptive-media-delivery/docs/understand-the-request-flow) 
- [Prepare your environment](https://techdocs.akamai.com/adaptive-media-delivery/docs/prepare-your-environment) 

# [Set up AMD ](https://techdocs.akamai.com/adaptive-media-delivery/docs/welcome-adaptive-media-deliv#set-up-amd)

- [Create a new AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop)
- [Define Property Hostnames](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-hn)
- [Define Property Configuration Settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-config-settings)
- [Finalize your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop)

# [Test and go live](https://techdocs.akamai.com/adaptive-media-delivery/docs/welcome-adaptive-media-deliv#test-and-go-live)

- [Test your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop) 
- [Go \"live\" with your property](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live)

# [Optional features and use cases](https://techdocs.akamai.com/adaptive-media-delivery/docs/welcome-adaptive-media-deliv#optional-features-and-use-cases)

You can include several optional features and use case-specific workflows in your Adaptive Media Delivery property. See the ***Optional features*** section for detailed walkthroughs.

# [Developer tools](https://techdocs.akamai.com/adaptive-media-delivery/docs/welcome-adaptive-media-deliv#developer-tools)

AMD works in conjunction with several APIs. See the [Adaptive Media Delivery APIs reference](https://techdocs.akamai.com/adaptive-media-delivery/reference/api) for details.

# [What's new](https://techdocs.akamai.com/adaptive-media-delivery/docs/welcome-adaptive-media-deliv#whats-new)

- [Release notes](https://techdocs.akamai.com/adaptive-media-delivery/changelog)