# [Protocol Downgrade for Standard TLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#protocol-downgrade-for-standard-tls)

Property Manager offers a behavior named, "Protocol Downgrade (HTTPS Downgrade to Origin)." It's used to downgrade from Standard TLS (L1) or the Akamai shared certificate hostname security to HTTP for the connection between the <
> edge and your origin server.

# [How it works](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#how-it-works)

You'd add this behavior if you're using a Standard TLS certificate (HTTPS L1) or the Akamai shared certificate in your property hostname, and you want to serve static objects to the end-user client over HTTPS, but fetch them from the origin via HTTP. This eliminates the need for a secure certificate on your origin server, for requests that originate with a Standard TLS or shared certificate.

# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#before-you-begin)

Before you set up this behavior, review the points here to familiarize yourself with its various features and limitations.

- **No PII**. You can't deliver personally identifiable information (PII) if using these behaviors. See [No personally identifiable information (PII)](https://techdocs.akamai.com/adaptive-media-delivery/docs/no-personally-identifiable-information-pii) for more information.

- **A downgrade is restricted to GET, HEAD, and OPTIONS methods**.

- **This behavior doesn't allow whole site downgrades**. For example, you can't use these behaviors to downgrade delivery of the full site, "www.mymediasite.com" from your origin.

- **Limits based on file extension**. There are no limits on downgrade based on file extension with this behavior.

- **Forward request content restrictions**. Certain content can be restricted, based on your delivery security:

    - **Query strings**. If your origin delivers assets that incorporate query strings, they're left as is.

    - **Cookies and Referer Information**. The forward HTTP request to the origin will be stripped of all cookies and referer information

- **You can include all headers in a downgraded request, except these**:

    - `Origin`
    - `Referer`
    - `Cookie`
    - `Cookie2`
    - `sec-*`
    - `proxy-*`

# [Add the Protocol Downgrade (HTTPS Downgrade to Origin) behavior](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#add-the-protocol-downgrade-https-downgrade-to-origin-behavior)

The process to add this behavior varies, based on a new or existing AMD property.

## [Add it to a new AMD  property](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#add-it-to-a-new-amd-property)

> Info: This process doesn't cover all of the steps required to properly set up a new AMD property. It only reveals the steps necessary to add the Protocol Downgrade (HTTPS Downgrade to Origin) behavior. See [Define property configuration settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-property-configuration-settings) for more details on creating a AMD property.

1. Determine the level of security you want for access requests to your property:

    - **Standard TLS**. First, you need to [create a new certificate](https://techdocs.akamai.com/cps/docs/create-edit-certs) using the Akamai Certificate Provisioning System. You'll need to complete the entire process and wait for the certificate to provision before continuing. (You'll receive an email when the cert is ready.) There are some specific considerations:

        - When you enter certificate information](https://techdocs.akamai.com/cps/docs/enter-cert-info), ensure that you add all of your applicable vanity domain names, as either the Common Name (CN) if you're only using one, or as a combination of a CN and SANs, if you're including multiple domain names.

        - When you [select network settings](https://techdocs.akamai.com/cps/docs/select-network-settings) for the cert, select **Standard TLS**.  

    - **Akamai shared certificate hostname**. This lets you quickly create a secure hostname that automatically incorporates a secure, shared certificate for access. There are no additional requirements if this is your chosen secure access method.

2. [Create a new AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop) using Property Manager.

1. Create a property hostname, based on your selected level of security:

    - [I'm using Standard TLS](https://techdocs.akamai.com/property-mgr/docs/add-hn-custom-cert#general-availability). Include the hostnames that you associated with the Standard TLS certificate you created.

    - [I'm using the Akamai shared certificate](https://techdocs.akamai.com/property-mgr/docs/use-akamai-shared-cert). There are no additional requirements here.

4. In the Property Configuration Settings options, click **Add Behavior**.

1. In the *Search available behaviors* field, input "Protocol Downgrade" to filter the listed behaviors. Ensure that you select **Protocol Downgrade (HTTPS Downgrade to Origin)** from the list.

1. The new behavior is added to your configuration. Set the Status slider to **On**.

## [Add it to an existing AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#add-it-to-an-existing-amd-property)

You can apply the Protocol Downgrade (HTTPS Downgrade to Origin) behavior to an existing AMD property, provided that configuration meets various requirements.

### [The property must deliver securely (HTTPS)](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#the-property-must-deliver-securely-https)

To support Protocol Downgrade (HTTPS Downgrade to Origin), an existing AMD property must be set up to deliver content securely, via HTTPS. The following apply:

- **Standard TLS (L1)**. *This is supported*. You just need to add the behavior.

- **Shared Certificate hostname**: *This is supported*. You just need to add the behavior.

- **Enhanced TLS (L3)**. *This is NOT supported*. You can migrate your configuration to Standard TLS (L1) if PCI compliance is not a concern in your environment. (It is not supported with Standard TLS.)  Otherwise, you can work with your Account Representative to implement the legacy Protocol Downgrade behavior.

- **No security**. This would apply if your current configuration delivers exclusively via HTTP and you need to convert to HTTPS, but want to keep the connection from your origin to the end user as HTTP. Here, you can apply security to this configuration (Standard TLS or Shared certificate hostname) and then apply this behavior. This would be similar to adding the behavior to a new property.

### [Implementation](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#implementation)

1. In the Property Configuration Settings options, click **Add Behavior**.

1. In the *Search available behaviors* field, input "Protocol Downgrade" to filter the listed behaviors. Ensure that you select **AMD** from the list.

1. The new behavior is added to your configuration. Set the Status slider to ** On**.

# [The Cache Key Sharing behavior might be necessary](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade-to-a-new-configuration#the-cache-key-sharing-behavior-might-be-necessary)

Once you enable protocol downgrade in your AMD property, a warning message is added to the Errors/Warnings/Notes Messages Display at the bottom of the Property Manager Editor UI. Click the up triangle () to display messages.

As a result of the change from HTTPS to HTTP, the cache key will change. You should add this behavior and set it to "**On**," if your origin can't handle the excessive additional requests that this change may require.

> Info: This applies to adding Protocol Downgrade (HTTPS Downgrade to Origin) to both new and existing properties.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-cache-key-query-v1.jpg)

