# [Enable Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#enable-token-authentication)

To enable Token Authentication ("Token Auth"), you need to apply specific settings in the Segmented Media Protection behavior in your AMD property.

# [Set up Token Auth](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#set-up-token-auth)

1. Set the **Token Authentication** slider to **On**.

1. Set the **Encryption Key**. Enter a hexadecimal value to  serve as a "trusted shared secret." Comprise it of an even number of characters, but don't exceed 32 total characters. For example: "eee7e9157f81b2f6d471bf2c". You can also click the cycle button (  ) to automatically generate a proper value.

1. Make note of this value. You use this value as the `Key` when generating the token.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-segmented-media-prot-ta-v1.jpg)

4. Don't enable your AMD property on the production network, or test it on staging just yet. Review the optional features you can add to your property, below. Then, you need to [generate a token and apply it to your content](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content).

## [Set Advanced Options (optional)](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#set-advanced-options-optional)

Click the **Show Advanced Options** switch button to reveal additional options.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-adv-options-ta-v1.jpg)

### [Transition key](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#transition-key)

This serves as a backup "trusted shared secret." Input one manually or auto-generate one using the cycle button (  ). If the token provided by the end-user request is not valid based on the primary **Encryption Key**, AMD checks the token using *this key*. This ensures that users aren't denied access if you're rotating the primary key. (This assumes that you've transitioned to generating your tokens with the Transition Key for some period of time before updating the Encryption key value here.)

### [Salt](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#salt)

This adds an additional "input" during generation of the token to strengthen security. Manually input a value or auto-generate one using the cycle button (  ). As a best practice, don't override the default value.

### [Request Headers for Session Token Salt](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#request-headers-for-session-token-salt)

This allows you to include additional end-user-specific properties to strengthen the relationship between the session token and playback session. These properties are communicated via a salt value that AMD generates using various request headers that you specify here. The following apply to these headers:

- Each header name you specify must consist of alphanumeric characters or hyphens.
- A specified header must exist in player requests for your content to be used in the salt.
- If a header is included in a request and it's not specified here, it's ignored, and it's not used to generate the salt.

Typical values include what's discussed in the table that follows.

Header | Description  
 ---|---  
 `User-Agent` | The resulting session token-protected URL can't be shared and played on a device with a different User-Agent (OS/Browser).  
 `X-Playback-Session-Id` | The following apply to the resulting session token-protected URL: 
     * It can't be shared and played on two identical Apple devices or browsers.
     * It can't be shared and played between Apple and non-Apple devices, and vice versa. This is similar to the `User-Agent` header.  
 `Origin` | The resulting session token-protected URL can only be played by a Javascript-based player from your intended website (for example, hls.js).

 > Note: 
 Use either **Salt** or **Request Headers for Session Token Salt**, *but not both*. If you do define both, the **Salt** is used, and what is set for **Request Headers for Session Token Salt** is ignored.

### [Salts and Long Token Validation](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#salts-and-long-token-validation)

Token Auth verifies the long token found in an HTTP cookie, even if the current request is for an HLS master manifest. This is because the system can't recognize an .m3u8 file as either a master or variant playlist file. This can result in some corner case issues:

- **The long token can be invalidated by a browser update**. The HTTP cookie that holds the long token has a time to live (TTL) of 24 hours. If a browser updates between two consecutive playback sessions during this TTL, the long token is invalidated because there's a different string in the User-Agent request header.

- **Using "Request Headers for Session Token Salt" can invalidate the long token**. If you use this option, you're incorporating request headers that can change frequently between consecutive playback sessions. If this happens, the long token in an HTTP cookie may be invalid.

We've implemented a fix for these cases. When the long token is read from the HTTP cookie and the verification fails, the system falls back to the short token for verification. However, if the long token is read from any other source, and the long token verification fails, the system continues to deny the request with an HTTP 403.

**Where was the long token read from for the incoming request?** | How is your "Salt" set up? | Long Token Validation Result  
 ---|---|---  
 **The HTTP cookie** | 
     * **I used the "Salt" field**. You've defined a unique value to serve as your Salt. 
     * **I used the "Request Headers for Session Token Salt" field**. You've set up one or more request headers for use in creating the Salt. The defaults are `User-Agent`, `X-Playback-Session-Id` and `Origin`.
     * **I have a legacy implementation**. The `User-Agent` request header is set up for you to generate the Salt.
 | **Fallback**. If long token validation fails, validation falls back to the short token, if present.  
 **The Query String** | Same as above. | **Failure**. An HTTP 403 error is returned if long token validation fails.  
 **The URL Path** | Same as above. | Same as above.  
 **The Request Header** | Same as above. | Same as above.

## [Add Field Carry-Over (optional)](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#add-field-carry-over-optional)

Use these options to enable the security controls and fields you want to be carried over from the access token into the session token. These allow for better access control and analysis.

Review this information to determine if including a field benefits your delivery.

Field | Description | Benefit/Drawback  
 ---|---|---  
 **Session-Id** (Enabled by default) | Enable this to carry-over the `session_id` from the access token to the session token. | This allows for tracking and counting unique playback sessions for a URL that is protected by a session token. **Note:** This needs to remain enabled if you want to use [Access Revocation](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-based-access-rev).  
 **Data/Payload** | Once enabled, information is carried over from the `data/payload` field in the access token to the session token. | This allows access to opaque data for log analysis for a URL that is protected by a session token.  
 **IP** | Once enabled, the `ip` field is carried over from the access token to the session token. This limits access to requesting client access to the specific `ip` address included in the token. | Only enable this if the IP address used by the player will not change during the playback session. For example, if you're working with mobile clients, they may switch from Wi-Fi to cellular (or vice versa), so the IP address for that device would vary during playback. So, you probably wouldn't want to enable this field for carry-over.  
 **ACL** | Once enabled, the `acl` field is carried over from the access token to the session token. This limits requesting client access to the specific URL or path set in the `acl` field. | Only enable this if the base path for the master playlist and the variant/bitrate playlists and segments are the same. Playback can fail if this is not the case.

## [Add "cookie-less" Token Auth for HLS (optional)](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#add-cookie-less-token-auth-for-hls-optional)

During the Token Auth process, multiple tokens are created and exchanged between the end user and Akamai. We create one of these tokens&mdash;a session token&mdash;and by default, it's returned to the end user as an HTTP cookie. However, some devices and browsers don't support cookies.

To address this, we offer "cookie-less" token auth via the **Token in URI** option. Rather than sending the session token as a cookie, the master manifest is modified to embed this token in the URL path of requests for the bit rate manifest and segments. So, once you enable Token in URI, a browser or device only needs to support the following to use Token Auth:

- **Support for HLS** (An HLS player should support the bare minimum HLS specification.)
- **Support fetching of objects via HTTP**

 > Note: 
 This only applies to requests for HLS-format media. All other formats use standard, cookie-based Token Auth. However, the **Encryption key**, and any Advanced Options you apply (**Transition key**, **Salt** or **Request Headers for Session Token Salt** ) via Token Authentication settings are common for all formats.

### [Procedure](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#procedure)

1. Ensure that **Token in URI** is **On**.

1. By default, the **HLS Master Manifest Files** field contains various common file names that represent HLS Master Manifest files. You can add or remove filenames as necessary.

    - **Filenames can contain alphanumeric and dot characters**.
    - **You can use wildcards in a filename**. Use an asterisk to serve as a wildcard to establish a range of filenames.
    - **Ensure that the filenames you input can be differentiated from the variant manifest files**.

 > Note: 
 If you don't specify a proper master manifest filename or wildcard equivalent, a request can result in HTTP 403. (If a master manifest is included in a client request that isn't specified here, that request is answered with an HTTP 403.)

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-cookieless-ta-v1.jpg)

### [Limitations on use](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#limitations-on-use)

The following limitations apply to the use of the Token in URI functionality:

- **HLS streams that do not incorporate a master manifest are not supported**. This shouldn't be an issue, due to the nature of an adaptive bitrate stream. These streams already include renditions in different bitrates, resolutions and codecs, and this information is communicated in the master manifest.

- **Absolute segment URLs for HLS segments are not supported**. This function modifies the master manifest to embed the session token in the URL of the media playlists. So, the media/variant playlist must use relative segment URLs. (The session token cascades down to the segments.) This reduces overall cost and results in better performance. However, the URLs for the segments must be *relative*in the bit rate manifest file. The following segment types are affected:

    - **Media segments**.
    - **Ad segments**.
    - **Media initialization segments for HLS** This applies to the ones that are indicated via the #EXT-X-MAP tag.

Generally, this shouldn't be a concern because the bitrate manifest and its corresponding segments are traditionally served from the same origin.

- **Multi-CDN is not supported, and other delivery configurations are limited**. This is due to the session token that this functionality sets in the URL path of variant playlists and segments. They can't be served from a different Content Delivery Network. They also can't be served from a different Akamai delivery configuration that does not have Token in URI *enabled*.

- **If your manifests have multiple Akamai-served hostnames in their contents, the Encryption key(s) *must be the same across each one**.