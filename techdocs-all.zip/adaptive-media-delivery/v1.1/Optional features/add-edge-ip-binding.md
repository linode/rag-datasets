# [Edge IP Binding & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-edge-ip-binding#edge-ip-binding-amd)

Edge IP Binding (EIPB) lets you deliver traffic from a small, static set of IP addresses in a scalable manner. You can add EIPB to accomplish the following:

- **Support zero-rated billing**. Are you looking to offer specific traffic at no cost to end users, or prevent specific delivery from counting against a data cap? More on this below.

- **Identify content provider traffic based on the source IP**. This helps when you can't perform a deep packet inspection.

- **Provide a single or a limited number of source IP addresses**. This would help if your infrastructure systems are too complex and need a single or very limited number of source IPs.

- **Eliminate frequent updates to IP address ranges**. This applies if your business support or operations support systems can't handle frequent updates.

- **Provide simplicity and scale**. This can help remove the need for additional domains or additional IPs.

In addition to "EIPB," Edge IP Binding is also sometimes referred to as "EIP" or "EIPBinding."

# [How to add Edge IP Binding to your property](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-edge-ip-binding#how-to-add-edge-ip-binding-to-your-property)

You add EIPB in Property Manager by enabling it in a property hostname to edge hostname association in your AMD property. However, there are other considerations and requirements, all of which are covered in the [Edge IP Binding documentation](https://techdocs.akamai.com/edge-ip-binding).

> Warning: You also have access to the [Use Case-based Edge Mapping](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-use-case-based-edge-mapping) feature when setting up these associations. You *can't* apply it and Edge IP Binding in the same property hostname.