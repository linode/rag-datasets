# [Configure Breadcrumbs](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-breadcrumbs#configure-breadcrumbs)

To add support for breadcrumbs, you need to apply various settings in a new or existing property configuration.

# [Add Breadcrumbs](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-breadcrumbs#add-breadcrumbs)

You need to add the Breadcrumbs behavior to your AMD property.

1. Create a new AMD property, or edit an existing one using Property Manager.

1. In the Property Configuration Settings options, click **Add Behavior**.

1. In the *Search available behaviors*field, input **Breadcrumbs** to filter the listed behaviors, and select it from the list.

1. The new behavior is added to your configuration. Set the Enable Breadcrumbs switch to **On**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/breadcrumbs-behavior-v1.jpg)

# [The Opt Mode](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-breadcrumbs#the-opt-mode)

Use the Opt Mode slider to conditionally **Opt-IN** or **Opt-OUT** of breadcrumbs support on a per request basis, using a specific query string.

- **Opt-OUT**. By default, breadcrumbs data *is included*in the response. Set this way, you can add the `ak-bc=off`query string to an individual request to block breadcrumbs data from a response.

- **Opt-IN**. By default, breadcrumbs data *is not included*in the response. You can optionally add the `ak-bc=on`query string to a request to include it in the response.

Review this table to understand how the query strings are applied, based on your Opt Mode setting.

Query string parameter | Opt-Mode setting | Is Breadcrumbs data included in response? | Description  
 ---|---|---|---  
 `ak-bc=on` | Opt-IN | Yes | By default, Opt-IN blocks breadcrumbs data from all responses. By including this query string, the response for this request will contain breadcrumbs data.  
 Opt-OUT | Yes | The `ak-bc=on` parameter and "Opt-OUT" setting in your property configuration are redundant values.  
 `ak-bc=off` | Opt-IN | No | The `ak-bc=off` parameter and "Opt-IN" setting in your property configuration are redundant values.  
 Opt-OUT | No | By default, Opt-OUT includes breadcrumbs data in all responses. By including this query string, breadcrumbs data will be left out of the response to this request.  
 None | Opt-IN | No | If no parameter is included, the "opt-IN" method responses *will not include* breadcrumbs data in all responses. (You need to include the query parameter in a request to "Opt-IN" and receive the data.)  
 Opt-OUT | Yes | If no parameter is included, the "Opt-OUT" method *includes*Breadcrumbs data in all responses. (You need to include the query parameter in a request to "Opt-OUT" of receiving the data.)

# [Why would I "opt-IN" or "opt-OUT?"](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-breadcrumbs#why-would-i-opt-in-or-opt-out)

You can simply have Breadcrumbs enabled in your property configuration and set Opt Mode to **Opt-OUT** to have breadcrumbs applied for all requests that match your rule criteria. Breadcrumbs include a specific header in the response to a requesting player. So, this increases the number of bytes delivered. Plus, a player just may not want (or support) the breadcrumbs response header. So, you can still have Breadcrumbs enabled and include opt-IN or opt-OUT to let the individual players determine how to handle the responses on a per-request basis.

# [Are you using an XHR-based player?](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-breadcrumbs#are-you-using-an-xhr-based-player)

If so, ensure that the "Access-Control-Expose-Headers" contains the name of the Breadcrumbs response header.

1. Click the **Default CORS Policy** rule.

1. Locate the Modify Outgoing Response Header entry with its Select Header Name set to **Access-Control-Expose-Headers**.

1. Add **Akamai-Request-BC** to the list to include this header.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/breadcrumbs-modify-outgoing-response-header-v1.jpg)

# [Cache Key Query Parameters considerations](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-breadcrumbs#cache-key-query-parameters-considerations)

With Breadcrumbs, the player can send query parameters to control the opt-IN or opt-OUT aspects of receiving associated data in the response header. *This parameter is not supported for use in the cache key*. So, if you're including the Cache Key Query Parameters behavior, ensure that opt-IN and opt-OUT are *left out*.