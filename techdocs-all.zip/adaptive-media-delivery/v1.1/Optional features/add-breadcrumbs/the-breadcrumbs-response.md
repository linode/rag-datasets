# [The Breadcrumbs response](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-breadcrumbs-response#the-breadcrumbs-response)

The Breadcrumbs response header that's sent to a player includes various sub-fields of data.
| Sub-field key | Sub-field value | Details |
|---|---|---|
| `a` | `<Component IP>` | The IP address of the node/host currently processing the request. This can be an edge server or an origin. **Note**: If the node or host is not either of these two types, it's excluded. |
| `b` | `<Request ID>` | A unique identifier assigned to the request. This helps Akamai support teams quickly pull the relevant log line in the request. |
| `k` | `<Request End Time>` | The number of milliseconds between the time the connection is accepted and the breadcrumb was gathered. This time includes the initial metadata parsing time, if metadata hadn't been loaded, as well as the metadata application time for this request, if they occurred between request acceptance and generation of the breadcrumb. |
| `l` (lower case L) | `<Turn around time>` | The time in milliseconds between receipt of the end of the request headers and when the breadcrumb was gathered. This includes the time it takes to fetch the object from another server in the case of a miss, or to perform (synchronous) validation of the object's freshness if the object was in cache. In both of these cases, there's a forward request corresponding to the client request. This time also may include the time to fetch the object from disk, perform ESI processing, and compute response headers. |
| `m` | `<DNS LookUp Time>` | The delta between the start of the request and the completion of the DNS lookup. |
| `n` | `<Component Geo>` | Geographic detailsfor the node or host currently processing the request. |
| `o` | `<Component ASN>` | The autonomous system number of the current node or host. |
| `{variable letters}` | `<Component Letter>` | These are letter identifiers for the Akamai network component that was involved during that phase of the request. Your Akamai account representative can use this value to determine where in the request phase the breadcrumb was gathered. Component letters include the following: <ul> <li><code>c</code>. This is at the cache parent with an error range of 10000-19999.</li> <li><code>g</code>. This is at the edge ghost with an error range of 20000-29999.</li> <li><code>p</code>. This is at the peer ghost with an error range of 70000-79999.</li> <li><code>o</code>. This is at the origin with an error range of 80000-89999.</li> <li><code>w</code>. This applies to Cloud Wrapper with an error code of 90000-99999.</li> </ul> |

# [Example 1: When served from within Akamai](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-breadcrumbs-response#example-1-when-served-from-within-akamai)

In this example, the request flow is **Edge** to **Peer**. So, the Breadcrumbs format would be in this order, with each enclosed in brackets, and separated with commas:

1. **Edge**: `[{component-ip},{request-id},{component-letter},{component-geo},{component-asn}]`
1. **Peer**: `[{component-letter},{component-geo},{component-asn}]`:

```
[a=12.34.567.89,b=12345678,c=g,n=US_CA_SANJOSE,o=20940],[c=p,n=US_CA_SANJOSE,o=55155]
```

# [Example 2: When served from an origin](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-breadcrumbs-response#example-2-when-served-from-an-origin)

In this example, the request flow is **Edge** to **Cache** to **Origin**. So, the Breadcrumbs format would be in this order, with each enclosed in brackets, and separated with commas:

1. **Edge**: `[{component-ip},{request-id},{component-letter},{component-geo},{component-asn}]`
1. **Cache**: `[{component-letter},{component-geo},{component-asn}]`
1. **Origin**: `[{component-ip},{component-letter}]`

```
[a=12.34.567.89,b=12345678,c=g,n=US_CA_SANJOSE,o=20940],[c=c,n=US_CA_SANJOSE,o=55155],[a=987.654.321.09,c=o]
```