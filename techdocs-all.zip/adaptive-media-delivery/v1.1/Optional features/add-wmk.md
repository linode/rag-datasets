# [Watermarking & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-wmk#watermarking-amd)

When a valid user requests content, watermarking distributes segments of content based on a pattern that’s unique to that user. If your content is pirated or redistributed, you can analyze the content and extract the user’s watermarking pattern to identify the user that originally leaked the content.

# [How watermarking works](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-wmk#how-watermarking-works)

Watermarking responds to segment requests from an end user with either an "A" or "B" encoded variant and the resulting sequence of segments forms a unique pattern. This pattern is determined by a watermarking token (WMT) that's included in each request.

If your stream is shared with unauthorized users, you or your watermarking vendor can forensically analyze the segments to extract the unique pattern. You or your watermarking vendor can then identify the source of the leak by searching a database that maps patterns to authorized users.

Below is a simplified example of how the Akamai platform uses a variant path based on the watermarking pattern in the WMT. The end user doesn't know that variant segments have been retrieved from different sources and his viewing experience is seamless.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-add-wmk-flow.jpg)

# [Work with a third-party watermarking vendor](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-wmk#work-with-a-third-party-watermarking-vendor)

The watermarking vendor’s role is to generate and store watermarking patterns for you in a WMT, as well as preprocess your content into "A" and "B" variants and place it onto the origin using a strict naming convention. More on this in [Set up a watermarking vendor](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-a-watermarking-vendor).

# [What AMD >> does](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-wmk#what-amd-does)

AMD parses, verifies, and acts on the WMT supplied by the client application during segment requests. Akamai edge servers verify the token and then map requests for an "A" or "B" variant based on the sequence number of the segment, and the user’s specific watermarking pattern.

We also offer various, optional settings you can apply to further protect the WMT during transport. More on this in [Set up watermarking in your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-watermarking-in-your-amd-property).

# [The client application's role](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-wmk#the-client-applications-role)

Your client application ("player") needs to get the WMT from the watermarking vendor and then pass it along with each request to Akamai. This is explained more in [Set up your player for watermarking](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-your-player-for-watermarking).

# [Watermarking and other content protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-wmk#watermarking-and-other-content-protection)

We offer several services to protect your content, including geographic restrictions such as [Content Targeting Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot) and [Enhanced Proxy Detection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-enhanced-proxy-detn), access restrictions like [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth) and transport security with [Media Encryption](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-media-enc), and secure (HTTPS) delivery via [Enhanced or Standard TLS](https://techdocs.akamai.com/property-mgr/docs/serve-content-over-https). However, these can't help if your content has already been compromised.

*Watermarking isn't specifically used to protect your content—it's used to identify the source that compromised it.*