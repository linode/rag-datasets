# [Live & on-demand: Different Property Hostnames](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-and-on-demand-different-property-hostnames#live-on-demand-different-property-hostnames)

Here, you set up two separate Property hostname to Edge hostname associations ("Property hostnames") and include them to target live or on demand content, based on specific rule match criteria.

# [1 - Get your live media set up](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-and-on-demand-different-property-hostnames#1-get-your-live-media-set-up)

To start, you need to work with Media Services Live to set up your live media.

1. [Create your Media Services Live (MSL) streams](https://techdocs.akamai.com/msl/docs/create-your-media-services-live-streams) for the live media you want to distribute.

1. [Configure an origin for your live streams](https://techdocs.akamai.com/msl/docs/config-origin-stream). During this process, you'll need to make note of the **Primary Hostname** value.

# [2 - Set up the property hostnames](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-and-on-demand-different-property-hostnames#2-set-up-the-property-hostnames)

We need a new AMD property with two property hostnames: one for distribution of the Live content, and a second one for the VoD content. We also want to employ Standard TLS security for access. For this example, we set up the following:

- **baseball-highlights-live-media.com**. The Property hostname for the *live*content.
- **baseball-highlights-ondemand-media.com**. The Property hostname for the *VoD*content.

 

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-mmc-diff-prop-hostnames-v1.jpg)

The steps that follow outline what you need to do to create the property hostnames for this use case.

1. You need Standard TLS certificates set up for each property hostname. These can take a while to provision, so you should [create](https://techdocs.akamai.com/cps/docs/create-edit-certs) them before you create the AMD property. You need to include your Property hostnames as a CN or SAN in each respective certificate: "baseball-highlights-live-media.com" for the live content certificate, and "baseball-highlights-ondemand-media.com" for the VoD content certificate.

1. [Create](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop) a new AMD property in ​Akamai Control Center​.

1. [Set up](https://techdocs.akamai.com/property-mgr/docs/add-hn-custom-cert#general-availability) two separate, Standard TLS Property Hostname to Edge hostname associations, one for "baseball-highlights-live-media.com" (for the live media) and one for "baseball-highlights-ondemand-media.com." Select **Use Case**, and set as follows, per hostname:

    - **baseball-highlights-live-media.com**. **Live**
    - **baseball-highlights-ondemand-media.com**. **On Demand**

# [3 - Configure the Default Rule for Live Media](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-and-on-demand-different-property-hostnames#3-configure-the-default-rule-for-live-media)

At this phase, you need to [set up the Default Rule](http://google.com) to accommodate live media using Media Services Live (MSL). To support MSL, configure the behaviors in the Default Rule as follows:

Behavior | Options  
 ---|---  
 **Origin Server**  |  Set the following options: \- **Origin Type**. **Media Services Live**
 \- **MSL Origin**. This is the **Primary Hostname** you noted while [configuring an origin for your live streams in MSL](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-and-on-demand-different-property-hostnames).  
 **Segmented Media Delivery Mode**  |  Set the following options: \- **Mode**. **Live**, with the Show Advanced Options slider set to **Yes**. \- **Live Type**. Either **Linear** or **Event**, based on your need. \- **Segment Access Time Mode**. If you know the Segment Access Time, and wish to set a specific value, this should be at **Configurable** with a numerical duration set, along with the applicable time increment of days, hours, minutes, and seconds from the drop-down menu. Otherwise, set this to **Unknown**.  
 **Origin Characteristics**  |  Set the following options: \- **Origin Location**. The region that best represents the location of the encoder distributing the MSL content. \- **Authentication Method**. **Akamai Origins - Auto, Others - None**.   
 **Content Characteristics**  |  Set the following options: \- **Catalog Size**. **Other**. \- **Content Type**. The desired output quality for your live video, **Standard Definition**, **High Definition**, **Ultra High Definition (4K)**, **Other**, or **Unknown**. \- **Popularity Distribution**. **Other**. \- **Enable HLS/HDS/DASH/CMAF**. **Yes** to enable compatible stream types, and **No** to disable incompatible types. \- **Segment/Fragment Duration**. The duration, in seconds for each segment or fragment (**2s**, **4s**, **6s**, **8s**, or **10s**). With Origin Object Size set to **Unknown** for each.   
 **Client Characteristics**  |  Set **Client Location** to the geographic region that best represents the clients that will be accessing your Live content. 

# [4 - Add a new rule for VoD requests](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-and-on-demand-different-property-hostnames#4-add-a-new-rule-for-vod-requests)

This new rule uses the VoD property hostname in its match criteria.

1. In the Property Configuration Settings click **Add Rule**.

1. Ensure **Blank Rule Template** is selected (default) and click **Insert Rule**.

1. Click the gear icon in the New Rule and select **Edit Name**. Input the desired name (for example, "VoD Delivery Rule") and press **Enter**.

1. Click **Add Match** and set the fields as follows:

    - **Hostname**
    - **is one of**
    - **Select Items**. Click this field and input the Property hostname for the VoD content (for example, " baseball-highlights-ondemand-media.com").

5. Click **Add Behavior**.

1. Type "origin" in the Search available behaviors field to filter results, select **Origin Server**, and click **Insert Behavior**. Set the options in this behavior as follows:

    - **Origin Type**: NetStorage
    - **NetStorage Account**: Click to select the NetStorage account associated with the Storage Group that houses the VoD content to be delivered.

7. Repeat steps 5-6, to add the **Origin Characteristics**, **Segmented Media Delivery Mode**, **Content Characteristics** (optional), and **Client Characteristics** (optional) behaviors.

Behavior | Options  
 ---|---  
 **Origin Characteristics**  |  Set the following options: \- **Origin Location**. Set this to the geographic location that corresponds to the NetStorage Account you set in the Origin Server behavior. \- **Authentication Method**. **Akamai Origins - Auto, Others - None**. > Info: These settings assume you've set the Origin Type to \   
 **Segmented Media Delivery Mode**  |  Set Mode to **On Demand**.   
 **Content Characteristics**  |  Set these options to best fit the VoD content you're delivering to your end users, to optimize its delivery. > Info: You could leave this behavior out of this rule to use the options you've set for it in the Default Rule. However, your VoD content may have different optimization requirements than your Live content. See [Content Characteristics and AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd) for detailed information on this behavior.   
 **Client Characteristics**  |  Set **Client Location** to the geographic region that best represents the clients that will be accessing your VoD content. > Info: Only include this behavior if you want to use a different setting than what you've applied for Client Location in the Default Rule. (The Default Rule applies to all requests, so you don't have to include this behavior if you're happy with what's set there.) 

# [What happens next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-and-on-demand-different-property-hostnames#what-happens-next)

First, you need to [complete](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop) creation of the AMD property, optionally [test](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop) it, and finally [promote](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live) it to production for use.

Once live in production, request logic for your content works as follows:

- **Any request that includes the URL `baseball-highlights-live-media.com` will deliver *live*content**. The match criteria you set in the VoD Delivery Rule is unique to requests to "baseball-highlights-ondemand-media.com," so all of the settings applied in the VoD Delivery Rule are *ignored*, and what you've set in the Default Rule is applied, to deliver the live content.

- **Any request that includes the URL `baseball-highlights-ondemand-media.com` will deliver VoD content**. The VoD Delivery Rule exists last in the property, so it's checked *first*. Since the match criteria in this rule has been triggered, all of its behaviors are applied. However, the Default Rule applies to *all*requests. So, the following also apply:

    - **With duplicate behaviors in both the VoD Delivery Rule and Default Rule, what's in the VoD Delivery Rule is used**. For example, you set up "NetStorage" as your Origin Server for VoD, and "On Demand" for your Segmented Media Delivery Mode, so those are used for requests to "baseball-highlights-ondemand-media.com." Also, if you added the Content Characteristics behavior in this rule, *its*settings are used in place of what you've set for that behavior in the Default Rule.

    - **If you've set behaviors in the Default Rule that aren't in the VoD Delivery Rule, they're applied**. For example, if you left out the Client Characteristics behavior from the VoD Delivery Rule, what you set in the Default Rule is used.

 > Note: 
 The above points apply to all behaviors in either rule, not just the use case-based behaviors.