# [Optimize via different Client Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-client-characteristics#optimize-via-different-client-characteristics)

In this simple scenario, we want to apply different Client Characteristics for Video on Demand (VoD) requests, based on the Client IP associated with the request.

# [Overview](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-client-characteristics#overview)

We'll be fielding requests to a single, secure property hostname, `baseball-highlights-media.com` for the VoD content. Several CIDR blocks will be called out to use specific Client Characteristics, while requests from all other client IPs will use what's set in the Default Rule.

For ease of use in this scenario, NetStorage is used as the origin for all requests.

# [Phase 1: Create the Property hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-client-characteristics#phase-1-create-the-property-hostname)

We need a new AMD property with one Property hostname for the distribution of content, and we'll be delivering the content via HTTP.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-optimize-client-char-v1.jpg)

The steps that follow outline what you need to do to create the Property hostname for this use case.

1. You need Standard TLS certificates set up for each property hostname. These can take a while to provision, so you should [create](https://techdocs.akamai.com/cps/docs/create-edit-certs) them before you create the AMD property. You need to include your Property hostnames as a CN or SAN in each respective certificate: "baseball-highlights-live-media.com" for the live content certificate, and "baseball-highlights-ondemand-media.com" for the VoD content certificate.

1. [Create](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop) a new AMD property in ​Akamai Control Center​.

1. [Set up](https://techdocs.akamai.com/property-mgr/docs/add-hn-custom-cert#general-availability) a Standard TLS Property Hostname to Edge hostname association for "baseball-highlights-media.com."

# [Phase 2: Add a new rule for specific Client IP requests](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-client-characteristics#phase-2-add-a-new-rule-for-specific-client-ip-requests)

For certain requesting clients, we want to ensure delivery is quicker. So, we're incorporating this rule to target requests from various CIDR blocks to use specific Client Characteristics behavior settings.

1. In the Property Configuration Settings click **Add Rule**.

1. Ensure **Blank Rule Template** is selected and click **Insert Rule**.

1. Click the gear icon in the New Rule and select **Edit Name**. Input the desired name (for example, "VoD Delivery Client IPs") and press **Enter**.

1. Click **Add Match** and set the fields as follows:

    - **Client IP**
    - **is one of**
    - **Select Items**. Click this field and input a range of CIDR blocks that represent IP addresses in the desired geographic location.

5. Click **Add Behavior**.

1. Type "client" in the Search available behaviors field to filter results, select **Client Characteristics**, and click **Insert Behavior**. For this example, we'll set the options in this behavior to optimize the delivery of lower-resolution content as follows:

    - **Client Location**. Select the geographic region that best represents the CIDR blocks you set for the match criteria.

# [Phase 3: Configure the Default Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-client-characteristics#phase-3-configure-the-default-rule)

Now, you configure the Default Rule to handle all other requests, as well as settings you want to be applied to *all* requests. For example, we'll configure "NetStorage" as the Origin Server for all requests here. Access it and set the use case-based behaviors here as follows:

Behavior | Options  
 ---|---  
 **Origin Characteristics** | Set the following options:
       * **Origin Location**. Set this to the geographic location that corresponds to the NetStorage Account you set in the Origin Server behavior.
       * **Authentication Method**. Akamai Origins - Auto, Others - None  
 **Segmented Media Delivery Mode** | Set the following options:
       * **Mode**. On Demand  
 **Content Characteristics** | Set these options to best fit the VoD content you're delivering to your end users, to optimize its delivery. See [Content Characteristics and AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd) for complete details on this on this behavior.  
 **Client Characteristics** | Set the following options:
       * **Client Location**. Select the geographic region that best represents *all other* clients that will be accessing the VoD content.

# [What happens next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-client-characteristics#what-happens-next)

First, you need to [complete](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop) creation of the AMD property, optionally [test](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop) it, and finally [promote](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live) it to production for use.

Once live in production, request logic for your content works as follows:

- **A request to `http://baseball-highlights-media.com` from within a specified CIDR block**. The VoD Delivery Client IPs rule exists last in the property, so it's checked *first*. Since the request originated from an IP address in a CIDR block named in this rule, its Client Characteristics setting is used. The Default Rule applies to *all*requests, so its remaining use case-based behavior settings are used.

- **A request to `http://baseball-highlights-media.com` from *outside* the specified CIDR blocks**. The Client Characteristics setting in the Default Rule is used for these requests. And, all of the remaining use case-based behavior settings are also applied.

 > Tip: 
 You could implement multiple instances of the "VoD Delivery Client IPs" rule (to a maximum of 6) for other geographic regions, and add more CIDR blocks to further expand this scenario.