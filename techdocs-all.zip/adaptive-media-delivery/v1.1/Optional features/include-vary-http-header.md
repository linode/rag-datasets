# [Include the Vary HTTP header](https://techdocs.akamai.com/adaptive-media-delivery/docs/include-vary-http-header#include-the-vary-http-header)

Do you need to include Vary HTTP headers for your content? AMD automatically strips these headers out of requests to support caching for faster delivery.

Many web servers add Vary HTTP headers to content by default. This header lets applications vary content based on the browser in use, or other client properties. Unfortunately, this makes it difficult to cache content for quicker delivery. As a [best practices setting](https://techdocs.akamai.com/adaptive-media-delivery/docs/best-practices-use-case-based-prov), AMD assumes that all content is cacheable and automatically removes the Vary HTTP header to allow for caching.

# [Enable Vary HTTP headers](https://techdocs.akamai.com/adaptive-media-delivery/docs/include-vary-http-header#enable-vary-http-headers)

If you need to include them, you can change the default setting that blocks them by adding the **Remove Vary Header** behavior to a rule in your property.

1. Determine how you want to apply this behavior:

    - **I want it to apply to all requests**. Perform the remaining steps in this process in the Default Rule, because it applies to all requests.

    - **I want it to apply it to specific requests**. Create a new rule and define the applicable Match criteria for requests in that rule. Then, perform the remaining steps to add this behavior to that rule.

1. Click the **Add Behavior** button.

1. Type "Remove" in the *Search available behaviors* field to filter the behaviors listed.

1. Select the **Remove Vary Header** behavior, and click the **Insert Behavior** button.

1. Set the **Remove Vary Header** slider to **Off**.

As a result, content is treated as *uncacheable*. Instead, AMD assumes the Vary HTTP header contains instructions specific to the particular type of client.

AMD can cache the associated object if the Vary HTTP header contains only `Accept-Encoding` and `Gzip` is present in the Content-Encoding header.