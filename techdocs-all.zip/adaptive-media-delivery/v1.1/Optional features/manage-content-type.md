# [Content-Type header in the response & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#content-type-header-in-the-response-amd)

When AMD recognizes a supported file, it automatically defines it as a media file based on the Content-Type header that’s included in the response. You can change this.

The default approach applies a fixed content type value via metadata, in an attempt to optimize the delivery of media assets via AMD. Since AMD sets this to a standard, fixed value, it doesn't have to read from the Content-Type header on your origin and generate individual Content-Type headers in the responses. Reading from this header with each request could delay delivery a negligible amount of time.

What if you need to customize your Content-Type header in your responses? A typical Content-Type header indicates the original media type of the requested resource. You can get this header to report this in the response, or you can apply other unique information. You do this by including optional behaviors in your AMD property and configuring them appropriately.

# [The Modify Outgoing Response Header behavior](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#the-modify-outgoing-response-header-behavior)

You can manually set the desired Content-Type using the Modify Outgoing Response Header (MORH) behavior.

1. Click **Add Rule**. The MORH behavior isn’t supported for use in the Default Rule.

1. Select **Blank Rule Template** from the list.

1. Click **Add Match**.

1. In Criteria, set the "If" match parameters to:

    - **File Extension**, **Filename**, **Path**, **Hostname**, or **Variable Match**
    - **is one of**

1. Input an applicable value in the Select Items field, based on the type of match criteria you selected. For example, if you set this to **Filename**, and you want to target your manifest file, you could input “**manifest.m3u8**.”

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-morh-match-v1.jpg)

6. Click **Add Behavior**.

1. In Search available behaviors, type "modify" and select Modify Outgoing Response Header from the list.

1. Click **Insert Behavior**.

1. Set Action to **Modify** and Select Header Name to **Content-Type**.

1. In Header Value, enter what you want to be included in the Content-Type header in the response. For example, if you’ve set this rule up to look for requests for your manifest.m3u8 file, you could set this to return the MIME type for a `ts` segment, `video/mp2t`.

1. Repeat this process to add more rules for different content types. Each specific content type needs to be set up in its own rule.

# [Example use case](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#example-use-case)

In this example, we'll set up three separate rules to report three separate content types.

## [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#before-you-begin)

This process uses the hostname match criteria in one of the rules. Before we can apply this, we need to define a separate property hostname in an AMD property. So, we’d need two property hostnames set up for this scenario:

- **The primary property hostname**. Requests to the URL defined here will be resolved to handle the majority of the requests. We’re using the URL, “baseball-videos.com” for this property hostname. The first two rules in this example will apply to requests from this hostname.

- **The secondary property hostname**. This hostname is used to handle requests for specific media. We’ll apply it in a separate rule to manage the content-type response via the MORH behavior. We’ve used “baseball-videos-legacy-windows.com” for this property hostname.

## [Set up process](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#set-up-process)

1. Click **Add Rule**.

1. Click **Add Match** and set the criteria to **File Extension** and **is one of**.

1. Use the Select Items field to select the file extension. We'll pick **ts** for an MPEG transport stream.

1. Click **Add Behavior**.

1. In Search available behaviors, type "**modify**" and select **Modify Outgoing Response Header** from the list.

1. Click **Insert Behavior**.

1. Set Action to **Modify** and set Select Header Name to **Content-Type**.

1. Set the New Header Value. The default MIME type for ts files is `video/mp2t`, so we input that here.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-morh-multiple-ts-v1.jpg)

> Info: If you don't see the file type you want in the Select Items drop-down, you can manually input the desired file extension without the period. You can also use a custom New Header Value, if you don't want to enter the default MIME type for a file format. What you input will be included in the Content-Type header in the response.

9. Click **Add Rule** again, to add another rule beneath the one you just set up.

1. Click **Add Match** and set the criteria to **File Extension** and is **one of**.

1. Use the *Select Items* field to select the file extension. We'll pick **m4v** for an MPEG-4 video container format.

1. Repeat **steps 4 - 7** to add the Modify Outgoing Response Header behavior to this rule.

1. Set the New Header Value. The default MIME type for `m4v` files is `video/mp4`, so we input that here.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-morh-multiple-m4v-v1.jpg)

14. Click **Add Rule** again.

1. Click **Add Match** and set the criteria to **Hostname** and is **one of**.

1. Use the *Select Items* field to specify the hostname. We’ve set up the property hostname using the URL, “baseball-videos-legacy-windows.com.” So, we set that here.

1. Repeat **steps 4 - 7** to add the Modify Outgoing Response Header behavior to this rule.

1. Set the New Header Value. End users targeting this URL are requesting Windows Advanced Systems Format video, including `asf`, `wma`, and `wmv` format media. So, we’ll set this to the default MIME type for these formats, which is `video/ms-asf`.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-morh-multiple-asf-v1.jpg)

You can continue to add more rules to your property in this fashion and customize them for other file types. When a request comes in that matches any of these criteria, the Content-Type header will be returned in the response and look something like this:

### [Requests for a .ts segment file](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#requests-for-a-ts-segment-file)
```
{
  "codes": [
    {
      "code": "Content-Type: video/mp2t",
      "language": "text"
    }
  ]
}
```
### [Requests for an .m4v file](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#requests-for-an-m4v-file)
```
{
  "codes": [
    {
      "code": "Content-Type: video/mp4",
      "language": "text"
    }
  ]
}
```
### [Request to the hostname, baseball-videos-legacy-windows.com](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#request-to-the-hostname-baseball-videos-legacy-windowscom)
```
{
  "codes": [
    {
      "code": "Content-Type: video/ms-asf",
      "language": "text"
    }
  ]
}
```
# [Existing AMD properties and MORH](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#existing-amd-properties-and-morh)

With past versions of the MORH behavior, you couldn't modify the Content-Type header in your AMD property. You got an error message when you tried to do so.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-old-morh-behavior-v1.jpg)

Now, you can update an existing AMD property to a new version and add this support.

# [The Default CORS Policy rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/manage-content-type#the-default-cors-policy-rule)

[This rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule) is added by default in your AMD property. It contains several instances of the same Modify Outgoing Response Header behavior, pre-populated with values to optimize delivery. Akamai recommends that you leave this rule in your property, and don't change its settings.

If you want to manage your Content-Type header, use a different rule, as described in the previous sections.