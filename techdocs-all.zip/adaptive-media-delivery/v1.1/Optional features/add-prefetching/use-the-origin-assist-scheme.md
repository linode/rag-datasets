# [Use the origin-assist scheme](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#use-the-origin-assist-scheme)

With this prefetching scheme, when Akamai fetches an object from an origin, the response includes a new header that lists the next object in the sequence. Akamai can read this information and prefetch this object.

Basically, Akamai relies on assistance from your "intelligent" origin to trigger prefetching.

# [What Origin Type can I use?](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#what-origin-type-can-i-use)

When defining your origin server for your property, only certain origin types can be used with prefetching. In the Origin Server behavior set the **Origin Type** to either of the following:

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-prefetch-origin-type-v1.jpg)

- **Your Origin** &mdash;**Supported**. To use your own custom origin.

- **Media Services Live (MSL)** &mdash;**Supported, with limitations**. Select this if you're using Media Services Live (MSL) as your origin. Currently, only Apple HTTP Live Streaming (HLS) format media is supported for this use case with AMD.

- **NetStorage** &mdash;**Not supported**. Currently, you can't use NetStorage as your origin if you want to use Prefetching.

 > Note: 
 If you're using Media Services Live as your origin, you can use Prefetching and DVR requests are still supported. While the DVR functionality uses NetStorage, the information used by the origin-assist scheme is not coming from NetStorage, it's coming from the specific origin you set up to support the scheme.

# [How an origin triggers prefetching](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#how-an-origin-triggers-prefetching)

Akamai sends specific information to your origin to initiate prefetching. Your origin must include a properly formatted response header after this request, to trigger prefetching.

## [Phase 1: Akamai tells your origin prefetching is enabled](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#phase-1-akamai-tells-your-origin-prefetching-is-enabled)

Akamai handles a player request for content and sends a *prefetch request header* to your origin, telling it that prefetching is enabled:

```
CDN-Origin-Assist-Prefetch-Enabled: 1
```

## [Phase 2: Your origin responds to Akamai with what to prefetch](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#phase-2-your-origin-responds-to-akamai-with-what-to-prefetch)

Your origin needs to use the Akamai request header to trigger prefetching. Your origin must send a *prefetch response header* that tells Akamai what should be prefetched. This response header must be comprised of the absolute or relative path to the object to be prefetched, followed by the `Content-Length` header stating the length of the complete prefetch response header.

```
CDN-Origin-Assist-Prefetch-Path: 

Content-Length: x
```

Akamai creates the full URL for the object to be prefetched by using:

- The player-requested URL of the current object, and

- The relative or absolute path listed in the prefetch response header.

### [Absolute path examples](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#absolute-path-examples)

Specify an absolute path by prefacing it with forward-slash (/"///"). This tells Akamai to use the exact path specified.

URL of player that initiated the request | Value of the response header from the origin that's used to trigger prefetch | URL of a request prefetched from Akamai  
 ---|---|---  
 `https://property-hostname/some/1234/video-100k/pl.m3u8` | `/hls/live/1234/video-100k/seg1.ts` | `https://property-hostname-from-player-request/hls/live/1234/video-100k/seg1.ts`  
 `https://property-hostname/thing/1234/video-100k/seg1.ts` | `/hls/live/1234/video-100k/seg2.ts` | `https://property-hostname-from-player-request/hls/live/1234/video-100k/seg2.ts`

 > Note: 
 In these examples, both `property-hostname` and `property-hostname-from-player` are the HTTP/1.1 "Host" header as seen by Akamai.

### [Relative path examples](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#relative-path-examples)

Specify a relative path by leaving out the forward-slash (/"/\/") from the beginning of the path. Akamai uses the forward path of the current request, minus the filename as the base path when creating the prefetch URL path.

URL of player that initiated the request | Value of the response header from the origin that's used to trigger prefetch | URL of a request prefetched from Akamai  
 ---|---|---  
 `https://property-hostname/some/1234/video-100k/pl.m3u8` | `video-100k/seg1.ts` | `https://property-hostname/some/1234/video-100k/seg1.ts`  
 `https://property-hostname/thing/1234/video-100k/seg1.ts` | `seg2.ts` | `https://property-hostname/some/1234/video-100k/seg2.ts`

 > Note: 
 In these examples, `property-hostname` is the HTTP/1.1 "Host" header as seen by Akamai.

### [Example 1: Include a single "prefetchable" path per response header](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#example-1-include-a-single-prefetchable-path-per-response-header)

The origin uses individual instances of the prefetch response header to include a single object to be prefetched.

```
CDN-Origin-Assist-Prefetch-Path: /hls/live-streaming/fifa/france-croatia/video-1000k/pl.m3u8
Content-Length: x
```

If multiple objects are to be prefetched, then one response header per prefetchable URL can be returned by origin. Ensure that all response headers use the same name. The order of these headers determines the order Akamai follows to request each object.

```
CDN-Origin-Assist-Prefetch-Path: /hls/live-streaming/fifa/france-croatia/video-1000k/pl.m3u8
CDN-Origin-Assist-Prefetch-Path: /hls/live-streaming/fifa/france-croatia/audio/pl.m3u8
Content-Length: x
```

 > Note: 
 Middle layer proxies may not preserve this ordering of response headers, and content may not be delivered in the desired order.

### [Example 2: Include multiple "prefetchable" paths in a single response header](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#example-2-include-multiple-prefetchable-paths-in-a-single-response-header)

The origin uses a single instance of the prefetch response header to include a comma-separated list of multiple objects to be prefetched.

```
CDN-Origin-Assist-Prefetch-Path: /hls/live-streaming/fifa/france-croatia/video-1000k/pl.m3u8,/hls/live-streaming/fifa/france-croatia/audio/pl.m3u8
Content-Length: x
```

The order of the paths listed determines what is prefetched first. Since this is only a single response header, the issue with middle layer proxies doesn't apply.

## [Phase 3: Akamai requests the prefetched object for the player](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme#phase-3-akamai-requests-the-prefetched-object-for-the-player)

With a "prefetch object" determined by the response header from your origin, Akamai requests it, as if it was requested by the player. To allow your origin to differentiate a prefetch request from a regular request all prefetch requests from Akamai use the same request header:

```
CDN-Origin-Assist-Prefetch-Request: 1
```

Once Akamai receives the prefetch object, it caches it until the player requires it.

Along with sending the prefetch object to Akamai, you can also have your origin send a new response header to prefetch the next object in the queue, if applicable.