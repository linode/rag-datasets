# [What can be prefetched](https://techdocs.akamai.com/adaptive-media-delivery/docs/what-can-be-prefetched#what-can-be-prefetched)

An adaptive bit rate stream, such as HLS and DASH consists of multiple object types that are requested by a player in a specific order. You can use this behavior to prefetch these objects to speed up delivery to end users.

# [What's the typical flow for an HLS stream?](https://techdocs.akamai.com/adaptive-media-delivery/docs/what-can-be-prefetched#whats-the-typical-flow-for-an-hls-stream)

This discusses the object types you can usually find in an HLS stream, and the order they're presented in a request.

Object | What's triggered next in a prefetch | Additional details  
 ---|---|---  
 **Master Playlist (.m3u8)** | One or more variant Playlists (.m3u8). | N/A  
 **Variant Playlist (.m3u8)** | One or more segments belonging to the current variant playlist. The segment to prefetch depends on the play position of the player, and this can be difficult to determine for a VoD stream. For Live streams, this is *typically* one of the last three segments in the variant playlist. | For the typical HLS stream, segments have the following extensions:
     * .ts for video, video + audio
     * .aac, .ac3, .ec3 for audio-only
     * .vtt, .webvtt, .mp4, etc. for subtitles
 For the newer HLS streams with CMAF segments, the extensions are:
     * .mp4, .m4v, etc. for video
     * .mp4, .m4a, etc. for audio
     * .vtt, .webvtt, .mp4 for subtitles
 **Note:** These are not definitive, complete lists. There are a lot of supported extensions, and some are non-standard. This is to support various one-off workflows you may have in place.  
 **Variant Playlist (.m3u8)** | Zero or one `init` segment (described via the `#EXT-X-MAP` tag), that belongs to the current variant playlist. | The `init` segments are present *almost*exclusively for CMAF segments, and the typical extensions are:
     * .mp4
     * .m4v
     * .m4a  
 **Segment** | The segment that follows next in the video/audio/subtitle presentation time. | N/A

# [What's the typical flow for a DASH stream?](https://techdocs.akamai.com/adaptive-media-delivery/docs/what-can-be-prefetched#whats-the-typical-flow-for-a-dash-stream)

This discusses the object types you can usually find in a DASH stream, and the order they're presented in a request.

Object | What's triggered next in a prefetch | Additional details  
 ---|---|---  
 **Manifest File (.mpd)** | `init` segments for audio and video followed by actual audio and video segments. Unlike HLS, there are no bit rate-specific playlists, and content is always demuxed, so right after fetching the MPD file, the player typically requests two segments: one for video and another for audio. | N/A  
 **Init segment** | One or more content segments. | N/A  
 **Segment** | The segment that follows next in the video/audio/subtitle presentation time. | N/A