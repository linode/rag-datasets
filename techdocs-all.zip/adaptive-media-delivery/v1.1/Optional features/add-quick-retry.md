# [Quick Retry & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-quick-retry#quick-retry-amd)

Quick retry detects slow forward throughput while fetching a streaming media object and attempts a different forward connection path to try to avoid congestion.

# [How to get quick retry](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-quick-retry#how-to-get-quick-retry)

Quick retry is available to all AMD customers. It doesn't require a separate contract line item. Its availability in your AMD property can vary, based on the property's status:

- **For a *new* AMD property**. Quick Retry is automatically added to the Default Rule for all new AMD property configurations, and it's enabled by default.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-quick-retry-v1.jpg)

- **For an *existing* AMD property**. If you already have an AMD property, you can add it to the applicable rule. A message is displayed for existing properties recommending that you add it for best performance.

# [Supported media formats](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-quick-retry#supported-media-formats)

Currently, this includes the following:

- Apple HTTP Live Streaming (HLS)
- Dynamic Adaptive Streaming over HTTP (DASH)

Quick retry also offers support for low latency with live media. Specific [recommendations and requirements](https://techdocs.akamai.com/adaptive-media-delivery/docs/caveats-and-known-issues-with-quick-retry#low-latency-live-streams-and-quick-retry) apply to its use.

# [The default forward throughput is 5 Mbps](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-quick-retry#the-default-forward-throughput-is-5-mbps)

Once you enable quick retry, the target forward throughput is set to five (5) Mbps. When the transfer rate drops below this rate during a connection attempt, quick retry is enabled and a different forward connection path is used. The 5 Mbps throughput is the accepted quality standard for HLS format media.

 > Note: 
 Quick retry isn't enabled for high bit rate streams above the 5 Mbps default. For example, 4K and 8K streams don't support quick retry. If you're exclusively delivering high bit rate content, contact your Akamai account rep to manually configure a higher throughput.

# [Quick Retry Override](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-quick-retry#quick-retry-override)

If you need a larger or smaller default forward throughput, work with your Akamai account rep to add the **Quick Retry Override** behavior to your AMD  property. Your rep can set a new **Default Target Forward Throughput** to a value between two (2) and 50 Mbps.

## [Rule ordering and Quick Retry Override](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-quick-retry#rule-ordering-and-quick-retry-override)

You can include the Quick Retry and Quick Retry Override behaviors in separate rules in your property to apply the override for specific request match conditions. You may receive an error or warning message if your rule ordering conflicts. These use cases describe various rule ordering scenarios and offer potential workarounds.

Scenario settings | Detail  
 ---|---  
 **Default Rule** : 
     * Quick Retry with Enable set to "**On**." 
     * Quick Retry Override included.
 | In this scenario, we're looking to have Quick Retry applied to all requests, but we want to override the default forward throughput from 5 Mbps to a unique value.
     * **Validation** : **_None_**. This scenario is supported.  
 **Default Rule** : 
     * No Quick Retry
     * **Match Rule 1** : 
       * Quick Retry Override is included.
 | In this scenario, we're looking to have Quick Retry applied to all requests, but we want to override the default forward throughput from 5 Mbps to a unique value, but only for requests that match on a specific criteria.
     * **Validation** : **_Error_**.
     * **Cause** : You've included the Quick Retry Override behavior in the property and the Quick Retry behavior is also required. This is because you've left the Quick Retry behavior out of the property or removed it.
     * **Fix** : Add the Quick Retry behavior to the Default Rule and set Enable to "**On**." All requests _except_ those that meet the match criteria in Match Rule 1 will have Quick Retry applied.  
 **Default Rule** : 
     * Quick Retry with Enable set to "**Off**."
     * **Match Rule 1** : 
       * Quick Retry Override is included.
 | In this scenario, we're looking to have Quick Retry applied to all requests, but we want to override the default forward throughput from 5 Mbps to a unique value, but only for requests that match on a specific criteria.
     * **Validation** : **_Warning_**. 
     * **Cause** : The Quick Retry Override behavior also needs the Quick Retry behavior enabled. You've set up a separate rule with different match criteria to apply Quick Retry Override, but the Quick Retry behavior in the Default rule is disabled.
 in the Quick Retry behavior in the Default Rule. All requests _except_ those that meet the match criteria in Match Rule 1 will have Quick Retry applied.  
 **Default Rule** : 
     * Quick Retry with Enable set to "**On**."
     * **Match Rule 1** : 
       * Quick Retry with Enable set to "**Off**."
       * Quick Retry Override is included.
 | In this scenario, we're looking to have Quick Retry use the default forward throughput of 5 Mbps for the majority of your requests, via the Default Rule. However, we also want to override the default forward throughput to a unique value, for requests that match on a specific criteria we set in Match Rule 1.
     * **Validation** : **_Warning_**.
     * **Cause** : The Quick Retry Override behavior also needs the Quick Retry behavior enabled. In this case, Quick Retry and Quick Retry Override have been added for a specific match criteria in Match Rule 1, but Enable is set to "Off" for Quick Retry, causing a conflict.
     * **Fix** : Set Enabled for Quick Retry in Match Rule 1 to "**On** ". Requests that match on its criteria will apply Quick Retry, using the custom Default Target Throughput set in Quick Retry Override. All other requests will use the default throughput of 5 Mbps, per the Quick Retry behavior set in the Default Rule.  
 **Default Rule** : 
     * Quick Retry with Enable set to "**On**."
     * **Match Rule 1** : 
       * Quick Retry with Enable set to "**Off**."
       * Quick Retry Override is included. 
         * **Match Rule 1a** Quick Retry with Enable set to "**On**."
 |  In this scenario, we're looking do these things:
     1. If requests to Match Rule 1 meet its specific criteria, apply Quick Retry, but use the unique default target forward throughput that's set in its instance of Quick Retry Override.
     2. If requests meet the criteria set in Match Rule 1a, apply Quick Retry and use the _same_ unique default target forward throughput set in Match Rule 1. (This lets us set up a separate match criteria to use the same throughput, without having to contact an Akamai account rep to add it to a new rule.)
     3. All other requests will use the default forward throughput via the Quick Retry behavior in the Default Rule.
 Current settings are causing a conflict.
     * **Validation** : **_Warning_**.
     * **Cause** : The Quick Retry Override behavior also needs the Quick Retry behavior enabled. In this case, both Match Rule 1 and Match Rule 1a are looking to the Quick Retry Override behavior in Match Rule 1, but its instance of the Quick Retry behavior is set to "**Off**.
     * **Fix** : Set Enabled for Quick Retry in Match Rule 1 to "**On** ".  
 **Default Rule** : 
     * Quick Retry with Enable set to "**Off**." 
     * **Match Rule 1** : 
       * Quick Retry Override is included.
     * **Match Rule 2** : 
       * Quick Retry with Enable set to "**On**."
 | In this scenario, we're looking to accomplish these things:
     1. If requests come in that match the criteria set in Match Rule 2, always apply Quick Retry using the default target forward throughput of 5 Mbps.
     2. Look at all other requests and if they match the criteria set in Match Rule 1, apply the unique default target forward throughout set in its instance of Quick Retry Override. Otherwise, use the standard default target forward throughput of 5 Mbps.
 This can't be accomplished with the current scenario settings.
     * **Validation** : **_Warning_**.
     * **Cause** : The Quick Retry Override behavior also needs the Quick Retry behavior enabled. In this case, Match Rule 1 is looking to the Quick Retry behavior in the Default Rule, but Enable is set to "**Off**.
     * **Fix** : Set Enabled for Quick Retry in the Default Rule to "**On** ".  
 **Default Rule** : 
     * Quick Retry with Enable set to "**On**."
     * **Match Rule 1** : 
       * Quick Retry with Enable set to "**Off**."
       * **Match Rule 1a** : 
         * Quick Retry Override is included.
 | In this scenario, we're looking to set up two separate rule match criteria to apply Quick Retry with Quick Retry Override for specific requests. We want all other requests to apply Quick Retry using the default target forward throughput of 5 Mbps.
     * **Validation** : **_Warning_**.
     * **Cause** : Match Rule 1 can't be applied unless the match criteria in its child counterpart, Match Rule 1a is also met. Match Rule 1a is subsequently looking to Match Rule 1 for its required instance of the Quick Retry behavior, and it's currently disabled.
     * **Fix** : Set Enabled for Quick Retry in the Match Rule 1 to "**On** ".