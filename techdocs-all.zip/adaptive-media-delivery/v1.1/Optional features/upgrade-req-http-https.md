# [HTTP to HTTPS Upgrade & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/upgrade-req-http-https#http-to-https-upgrade-amd)

You can add the HTTP to HTTPS Upgrade behavior to your property if you want to convert HTTP (non-secure) requests from your clients to secure HTTPS for the remainder of the request flow.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/http-https-upgrade-v1.jpg)

A complete request flow involves three total entities:

- The client making the request
- The Akamai edge server, where your property is read
- The origin where the target content is hosted

![](https://techdocs.akamai.com/adaptive-media-delivery/img/http-https-upgrade-flow-v1.jpg)

With this behavior added, all requests in the flow *after the initial client request* are converted from HTTP to HTTPS to secure them.

# [Get access to HTTP to HTTPS Upgrade](https://techdocs.akamai.com/adaptive-media-delivery/docs/upgrade-req-http-https#get-access-to-http-to-https-upgrade)

You need to have this added to your contract to access the appropriate behavior in Property Manager. Contact your account representative to add this functionality.

# [Add HTTP to HTTPS Upgrade](https://techdocs.akamai.com/adaptive-media-delivery/docs/upgrade-req-http-https#add-http-to-https-upgrade)

Once you have it added to your contract, you can add this behavior to your AMD property by performing the following:

1. Create a new AMD configuration, or edit an existing one using Property Manager.

1. In the Property Configuration Settings options, click **Add Behavior**.

1. In the *Search available behaviors* field, input **Add HTTP** to filter the listed behaviors, and select **Add HTTP to HTTPS Upgrade** from the list.

# [Set up your origin to support HTTPS](https://techdocs.akamai.com/adaptive-media-delivery/docs/upgrade-req-http-https#set-up-your-origin-to-support-https)

> Info: Are you using NetStorage?. This doesn't apply if you're using NetStorage as your origin. Akamai sets origin security automatically for NetStorage when you add the HTTP to HTTPS Upgrade behavior.

You don't need to do anything to actually configure this behavior. Just adding it to your property enables the conversion. However, if you're using a custom origin, you also need to:

- Properly configure your origin for HTTPS transfer

- Apply the appropriate options in the [Verification](https://techdocs.akamai.com/property-mgr/docs/configure-unique-origin#verification-settings) settings in the Origin Server behavior.

# [Additional considerations](https://techdocs.akamai.com/adaptive-media-delivery/docs/upgrade-req-http-https#additional-considerations)

- The upgrade is to Standard TLS (HTTPS L1). To use Enhanced TLS (if you're transferring PII), you need to create and provision an Enhanced TLS certificate, edit your property to set Security Options, and define a Property hostname to Edge hostname association.

- This behavior uses 443 as the forward for all products other than Adaptive Media Delivery, Download Delivery, and Object Delivery.