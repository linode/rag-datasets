# [Method 1: One to one](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-1-one-to-one#method-1-one-to-one)

This method implements Use Case-based Edge Mapping (UCEM) to optimize the delivery of on-demand media ("VOD") using a single property hostname.

# [Create a new Property Hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-1-one-to-one#create-a-new-property-hostname)

In this example, we're using Property Manager to create a new property configuration for AMD to define a new property hostname to edge hostname association ("property hostname") to enable the appropriate use case.

1. Create a new [secure property hostname](https://techdocs.akamai.com/property-mgr/docs/serve-content-over-https). In this example, we're using "myvideos-vod.com" as the hostname.

1. When you reach the Mapping Solution phase of the wizard, ensure **Use Case** is selected and set Segmented Media Mode to **VOD**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ucem-one-to-one-v1.jpg)

> Info: If you also have Edge IP Binding on your contract, it's revealed here, too. You can't use both UCEM and Edge IP Binding in the same property hostname.

3. Look at your new property hostname and verify that "VOD" has been applied as the Use Case. If it has, the edge hostname that's used by this property hostname has been set to use an optimal edge map for delivery of on-demand content.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ucem-one-to-one-use-case-vod-v1.jpg)

## [Did you create your hostname using Edge Hostname Editor?](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-1-one-to-one#did-you-create-your-hostname-using-edge-hostname-editor)

If you used the [Edge Hostname Editor](https://techdocs.akamai.com/edge-hostnames/docs) in ​Akamai Control Center​, you also need to know the *complete name* of your edge hostname. Follow the same process discussed above, using the Use Case feature to select **VOD**. In the next window, click the pencil icon () and choose **Select existing**. You're shown a list of existing edge hostnames, filtered by the specified IP Version. Locate and select the edge hostname that has "VOD" set as its use case.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ucem-one-to-one-edge-hostname-v1.png)

# [Segmented Media Mode use case vs. the Segmented Media Delivery Mode behavior](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-1-one-to-one#segmented-media-mode-use-case-vs-the-segmented-media-delivery-mode-behavior)

In this method, you set up a property hostname and apply the "Segmented Media Mode" use case. However, there's also the mandatory Segmented Media Delivery Mode behavior in the Default Rule... what's the difference?

- **The Segmented Media Mode use case**. This is specifically used to determine the optimized edge map for use in delivering the selected media mode. This only applies to requests that are directed to the edge hostname applied in that specific property hostname. For example, if you create another property hostname and don't apply the use case, requests to its edge hostname won't be optimized to a specific edge map.

- **The Segmented Media Delivery Mode behavior**. This is used to apply other delivery-related optimizations for the selected mode. For this use case, you need to set Segmented Media Delivery Mode to **On Demand**. This is to match the UCEM setting and avoid a [mismatch](https://techdocs.akamai.com/adaptive-media-delivery/docs/mismatch-issues-and-ucem) condition.

# [What's next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-1-one-to-one#whats-next)

This is the simplest example of UCEM for AMD. Requests to the new edge hostname set in the Property Hostname use the optimized edge map for on-demand content and deliver that content based on how you configure rules and behaviors. So, continue to [create](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-config-settings) your property configuration to apply settings in the behaviors in the Default Rule (and subsequent rules, if applicable).

Once you've completed and saved the property configuration, you need to:

- Activate it on the Staging network and (optionally) [test it](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop).

- Activate it on the Production network and [go live](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live). At this phase, you update your DNS record to CNAME your vanity hostname to the edge hostname you created, so that requests to it are resolved to the edge hostname.