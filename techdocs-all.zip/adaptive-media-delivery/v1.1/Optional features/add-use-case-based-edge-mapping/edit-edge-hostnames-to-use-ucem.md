# [Edit edge hostnames to use UCEM](https://techdocs.akamai.com/adaptive-media-delivery/docs/edit-edge-hostnames-to-use-ucem#edit-edge-hostnames-to-use-ucem)

Existing edge hostnames can be edited to modify Use Case-based Edge Mapping (UCEM) settings, but caveats apply.

You may need to edit your edge hostname for multiple reasons:

- You want to add UCEM support to an existing property configuration that doesn't currently have it.
- You want to change the current UCEM setting for an edge hostname.

# [How to edit an edge hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/edit-edge-hostnames-to-use-ucem#how-to-edit-an-edge-hostname)

While you can edit various edge hostname settings via Property Manager or Edge Hostname Editor, *you can't modify anything related to edge map usage*. Changing map usage may have a significant impact on performance for existing configurations.

In special circumstances, your UCEM settings can be modified with assistance from Akamai. Contact your account representative for details.

> Warning: Do you have multiple property configurations set up to use the same edge hostname? If so, review each configuration to ensure that editing the edge hostname won't negatively impact it.
