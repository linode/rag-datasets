# [Content Targeting Protection & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#content-targeting-protection-amd)

Content targeting ("geo protection") allows you to permit or deny access to your content based on region-specific values associated with the requesting client.

For example, you can add the Content Targeting - Protection behavior and configure it to deny access to clients in a specific geographic region ("geo protection"), or only allow requests coming from a specific set of IP addresses.

# [Where Geo Protection fits into the content protection spectrum](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#where-geo-protection-fits-into-the-content-protection-spectrum)

There are multiple levels of access and protection. Geo protection fits in as follows:

- **No protection - Open Access**. Anyone can access your content

- ***Level 1: Geo Protection***.

- **Level 2: Token Auth**. An encrypted token in the request is compared against a token you've associated with your content. You can add it to your property using the [Token Authentication & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth) options in the Segmented Media Protection behavior.

- **Level 3: HTTPS Protection**. [Configure](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-hn) your AMD property to access and send content via secure delivery.

- **Level 4: Media Encryption**. Your content is encrypted. Only requests that include the proper decryption key can decode it for access. You can add it to your property using the [Media Encryption](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-media-enc) options in the Segmented Media Protection behavior.

- **Most protection: DRM Encryption**. This prevents access to only those clients that have been authorized to have a DRM license for the playback environment or content, including additional rights management rules.

# [How do I get access to Content Targeting - Protection?](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#how-do-i-get-access-to-content-targeting-protection)

You need to have this added to your contract to access the appropriate behavior in Property Manager. Contact your account representative to add this functionality.

# [Add Content Targeting - Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#add-content-targeting-protection)

Once you have it added to your contract, you can add Content Targeting - Protection to your AMD property by performing the following:

1. Create a new AMD property, or edit an existing one using Property Manager.

1. In the Property Configuration Settings options, click **Add Behavior**.

1. In the *Search available behaviors* field, input **Content Targeting** to filter the listed behaviors, and select **Content Targeting - Protection** from the list.

1. The new behavior is added to your property. Set the Enable Content Targeting switch to **On**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-content-target-prot-enable-v1.jpg)

Once enabled, you can apply Content Targeting - Protection in multiple ways.

# [Apply Geo Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#apply-geo-protection)

Worldwide, IP addresses are unique to a specific geographic location. This functionality uses this concept, and leverages the geographic location of the end-user system attempting to access your content, and either allows or deny access to it, based on the IP address.

To implement this protection, set the Enable Geo Protection slider to **On** and define the following settings:

- **Mode**. Select the desired operator:

    - **Allow...**. This *grants access* to clients that fall within the settings you apply.
    - **Deny...**. This *blocks* clients that fall within the settings you apply.

- **Countries**. Click this field and select an entire country that you want to be allowed or denied access. Each is followed by its two-letter country designation. For example, "US" represents the United States, \\ and "BR" represents Brazil. Repeat this to add additional countries.

- **Regions**. Click this field and select a specific country and corresponding region that should be allowed or denied access. For example, you can select individual states within the United States, provinces in Canada and China, etc. Objects are listed alphabetically, by country first, and then region. Each is followed by its two-letter country designation and abbreviated region. For example, "United States - California"  is represented as "US-CA." Repeat this to add more regions.

- **DMAs (United States, only)**. Click this field to select a "Designated Market Area." Repeat to add additional DMAs. A DMA is a specific region in which the population can receive the same (or similar) internet media offerings. Current entries are based on the proprietary Nielsen Media Research DMA regions. You can request specific DMA data from Nielsen, at [http://www.nielsen.com/intl-campaigns/us/dma-maps.html](http://www.nielsen.com/intl-campaigns/us/dma-maps.html).

- **Override GEO Controls for these IPs/CIDR blocks**. With your operator set to 'Deny...", input an IP address/CIDR block that exists within your specified Countries or Regions. This overrides the "Deny..." setting, allowing access to that specific IP address/CIDR Block. Repeat as necessary to add additional IP address/CIDR blocks. *You can have a maximum of 160 entries in this field*.

 > Note: 
 The **"Override GEO Controls..."** functionality only works to override a "Deny..." **Mode** setting for individual IP addresses within a specified country or region. It can't be used to override a mode of "Allow..." For example, you can't use it to allow a region, and specifically block an individual IP address. Use the IP Access functionality to configure this.

- **Redirect request instead of Deny**. Set this slider to **On** and input a complete page address in the **Redirect URL** field to serve as a deny destination. *This URL cannot be longer than 2000 total characters*. If an access attempt is denied, it is redirected to this address:

    - **"Allow..." Mode**. Any request outside what you have specifically configured here is denied and sent to this redirect URL.

    - **"Deny..." Mode**. A request that matches any value you have defined here is denied and sent to this redirect URL.

 > Note: 
 The requesting client needs to handle HTTP 302 on manifest requests to support this functionality. You also need to have a page set up and accessible via the noted URL to serve as the deny destination.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-geo-protection-v1.jpg)

# [Apply IP Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#apply-ip-protection)

This functionality lets you provide individual IP addresses or classless inter-domain routing (CIDR) blocks that should be allowed or denied access to your content.

To implement this protection, set the Enable IP Protection slider to **On** and define the following settings:

- **Mode**. Select the desired operator:

    - **Allow...**. This *grants access* to clients that fall within the settings you apply.
    - **Deny...**. This *blocks* clients that fall within the settings you apply.

- **IP Addresses/CIDR Blocks**. Click this field, input a valid IP address or CIDR block to be allowed or denied access, and click the (new item) entry to add it. Repeat to add more entries.

- **Redirect request instead of Deny**. Set this slider to **On** and input a complete page address in the **Redirect URL** field to serve as a deny destination. *This URL cannot be longer than 2,000 total characters*. If an access attempt is denied, it is redirected to this address:

    - **"Allow..." Mode**. Any request outside what you have specifically configured here is denied and sent to this redirect URL.
    - **"Deny..." Mode**. A request that matches any value you have defined here is denied and sent to this redirect URL.

 > Note: 
 The requesting client must be able to handle 302 on manifest requests to support the above functionality. It also requires that you have a page setup and accessible via the noted URL to serve as the deny destination.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-ip-protection-v1.jpg)

# [Apply Referrer Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#apply-referrer-protection)

You may have granted various outside websites access to your players or content. For example, you may have used a link on a page on a page outside your site. Unauthorized sites may attempt to hijack these links and publish them to their own site. Use this to specifically name qualified referrer website URLs to block these referrers from accessing your content.

To add this protection, set the Enable Referrer Protection slider to **On** and define the following settings:

- **Mode**. Select the desired operator:

    - **Allow...**. This *grants access*to clients that fall within the settings you apply.
    - **Deny...**. This *blocks* clients that fall within the settings you apply.

- **Referrer Domains**: Click this field, input a referrer domain and click the (new item) entry to add it. Repeat to add additional domains. *A Referrer Domain cannot exceed 256 total characters*. Domains can be input using the following formats:

- **Full Domain**. Input as `www.address.com`. Don't include `http(s)://`.

- **Domain Prefaced with a Period (" . ")**.  For example, this could be `.address.com`. The period serves as a form of wildcard, indicating that all domains that end in `.address.com` are allowed.

    - **Redirect request instead of Deny**. Set this slider to **On** and input a complete page address in the **Redirect URL** field to serve as a deny destination. *This URL cannot be longer than 2000 total characters*. If an access attempt is denied, it is redirected to this address:

    - **"Allow..." Mode**. Any request outside what you have specifically configured here is denied and sent to this redirect URL.
    - **"Deny..." Mode**. A request that matches any value you have defined here is denied and sent to this redirect URL.

 > Note: 
 The requesting client must be able to handle 302 on manifest requests to support the above functionality. It also requires that you have a page set up and accessible via the noted URL to serve as the deny destination.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-referrer-protection-v1.jpg)

# [Protection precedence](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#protection-precedence)

You can combine the protections offered with Content Targeting - Protection. If you do, you need to realize that various operations and settings take precedence over another, in the event of a conflict. This is in place to ensure that lighter protections are executed first, versus heavier ones. So that internal servers spend fewer cycles to serve a request.

## [Individual protection precedence](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#individual-protection-precedence)

Each individual protection is applied in the following order, lighter to heavier, with the first taking the highest precedence:

1. IP Protection
1. Referrer Protection
1. Geo Protection

## [A "Deny" setting takes precedence over an "Allow" setting](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#a-deny-setting-takes-precedence-over-an-allow-setting)

Using the protection order defined above, if a Mode of **Deny...** set for one protection conflicts with a Mode of **Apply...** set for lower protection, *the Deny takes precedence*. For example, assume you set IP Address Protection to **Deny...** a specific IP address, and then set Geo Protection to **Allow...** the Country that includes that IP address. *That individual address will still be denied access*.

## [The last "Redirect" takes precedence](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#the-last-redirect-takes-precedence)

If you have enabled and configured the **Redirect request instead of Deny** for any of the protections, and a conflict occurs, the last redirect is applied. "Last" is based on the order defined in [Individual protection precedence](#individual_protection_precedence).

- If IP Protection applies a redirect, and Referrer Protection is set to "Deny..." a conflicting address, *the request is denied*.

- If IP Protection applies a redirect, and Referrer Protection also applies a redirect, *the redirect set for Referrer Protection is applied in the event of a conflict*.

- If IP Protection applies a redirect, Referrer Protection applies redirect, and GEO Protection is set to "Deny..." a conflicting address, *the request is denied*.

- If IP Protection applies a redirect, Referrer Protection applies a redirect, *and* Geo Protection applies a redirect, *the redirect set for Geo Protection is applied in the event of a conflict*.