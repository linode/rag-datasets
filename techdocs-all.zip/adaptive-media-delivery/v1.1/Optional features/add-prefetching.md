# [Prefetching & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-prefetching#prefetching-amd)

Prefetching positions target media content at the edge in anticipation of requests by end users. This reduces the time to deliver that content. Prefetching extracts data from the current request or response and determines the next object that should be requested. For example, when a specific segment in a media clip is requested by a player, you can prefetch the next segment to the Edge to expedite its delivery.

> Info: Are you using NetStorage?. If you're using NetStorage as your origin server in your AMD property, Prefetching can't be used.

# [A high-level flow of Prefetching](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-prefetching#a-high-level-flow-of-prefetching)

1. The media player makes a request for `{object-1}`.

1. AMD handles the request by forwarding it to your origin.

1. Your origin returns the requested object, `{object-1}`, back to AMD.

    - The origin response also includes headers to prefetch `{object-2}`. The value of this header is either an absolute URL path or a relative URL path that's relative to `{object-1}`.

4. AMD returns `{object-1}` to player and this completes the request/response flow for `{object-1}`.

1. Since the response from your origin also included prefetch response headers for `{object-2}`, AMD triggers prefetching.

    - AMD creates an HTTP/S request for `{object-2}` and forwards it to your origin. This is called a "prefetch request." AMD includes a preconfigured request header in it, that tells your origin that it's a prefetch request.

6. Your origin returns `{object-2}` to AMD.

    - *The origin response could include a response header to prefetch `{object-3}` to continue the prefetching process.*

7. AMD caches `{object-2}`.

    - *AMD doesn't trigger prefetching for `{object-3}`*. This is because `{object-2}` was already prefetched from your origin (and you don't want a never-ending recursive prefetch cycle).

8. The player makes a request for `{object-2}`.

1. AMD fetches `{object-2}` from its cache and returns it in the response to the player.

    - If the origin response for `{object-2}` included prefetch response headers for `{object-3}`, AMD triggers prefetching of `{object-3}`, and the process can continue.

# [What's supported?](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-prefetching#whats-supported)

**Streaming Formats** |   
     * Apple HTTP Live Streaming (HLS)
     * Adobe HTTP Dynamic Streaming (HDS)
     * Dynamic Adaptive Streaming over HTTP (DASH)
     * Microsoft Smooth Streaming (MSS)  
 ---|---  
 **Live or Video on Demand (VoD)** | Both  
 **Origin Server** | There may be limitations on use for certain **Origin Types** when setting up the Origin Server in your property:
     * **Your Origin**. No limitations.
     * **Media Services Live**. Only HLS streaming format is supported.
     * **NetStorage**. Not supported.
 See [Use the origin-assist scheme](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-the-origin-assist-scheme) for complete details.

# [Add Segmented Media Streaming - Prefetch](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-prefetching#add-segmented-media-streaming-prefetch)

Add this behavior to your AMD property by performing the following:

1. Create a new AMD property, or edit an existing one using Property Manager.

1. In the Property Configuration Settings options, click **Add Behavior**.

1. In the *Search available behaviors* field, input **Segmented Media** to filter the listed behaviors, and select **Segmented Media Streaming - Prefetch** from the list.

1. The new behavior is added to your configuration. Set the Enable Origin-Assisted Prefetch switch to **On**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-seg-media-prefetch-v1.jpg)

