# [Watermarking with Access Revocation](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-with-access-revocation#watermarking-with-access-revocation)

You can use third-party Watermarking-based piracy detection services along with our Access Revocation feature to revoke access to a live session that's been flagged as a piracy source. This requires a mapping between the Watermark and the authentication ("auth") token.

# [What is Access Revocation?](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-with-access-revocation#what-is-access-revocation)

Access Revocation lets you include auth tokens in a "revocation list." Requests that include these tokens are blocked from accessing your content. You generate a token revocation list using the Access Revocation API, include identifiers associated with the offending auth token in the list, and then apply that revocation list in your AMD property.

# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-with-access-revocation#before-you-begin)

This workflow requires three services for your AMD property configuration. You need to work with your account representative to ensure you have them on your contract:

- **Watermarking**.
- **Access Revocation**.
- **Segmented Media Protection**. This is a recommended behavior and should be available by default.

# [Understand the "roles"](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-with-access-revocation#understand-the-roles)

There are multiple roles in this workflow:

- **The content provider**. The owner of the content being requested. The content provider makes the decision to use watermarking.

- **The service provider**. The entity that’s responsible for distributing content for the content owner. The service provider typically works with the watermarking vendor to generate watermarking tokens.

- **The watermarking vendor**. This is a third-party, supported vendor that sets up your content as well as generates and issues the watermarking tokens used in the process.

- **The end user**. The individual using a player or client app to request the content.

> Info: If you’re a content owner and don’t have a separate service provider, you also take on that role to add watermarking.

# [The workflow](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-with-access-revocation#the-workflow)

1. The content provider establishes a relationship with the service provider to distribute watermarked content.

1. The service provider generates an auth token to protect the target content. A `session_id` is set up in that token.

1. When an end user requests the URL to play content, the service provider interfaces with the watermarking vendor to request a watermarking token (WMT) for the end user. The WMT contains a unique "watermark ID" for that specific end user.

1. The watermarking vendor returns the WMT to the service provider.

1. The service provider maintains a mapping between the `session_id` and the watermark ID.

1. The end user's player uses the playback URL that was retrieved from the service provider, to start playback by fetching content from Akamai.

1. When the watermarking vendor detects piracy or re-streaming, they pull the watermark ID from the content and communicate it to the service provider.

1. At this point, either the watermarking vendor or the service provider can revoke access, using the `session_id` that was set in the auth token.

# [How to revoke access](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-with-access-revocation#how-to-revoke-access)

Here, we revoke access by generating a revocation list based on the `session_id` in an auth token that's been mapped to a “bad” WMT. You need to create a revocation list and add the offending auth token's `session_id` to it to mark it for revocation.

> Info: This process assumes that you are the content provider.

1. Work with a [supported watermarking vendor](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-a-watermarking-vendor#supported-watermarking-vendors) to set up your content and the WMTs.

1. [Enable Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication) in your AMD property, and also [apply cookie-less token auth](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication#add-cookie-less-token-auth-for-hls-optional). Note the Encryption Key value you set.

1. [Generate a token](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content) for access to your content, and include a `session_id` in that token.

1. [Add a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list-2) using the Access Revocation API, and store its `id`. This is also referred to as the "revocation-listId.")

1. Use the `revocation-listId` to [set up Access Revocation](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-based-access-rev#now-enable-the-revocation-list-in-property-manager) in your AMD property in Property Manager.

1. [Set up watermarking in your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-watermarking-in-your-amd-property) in Property Manager.

1. [Set up your player for watermarking](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-your-player-for-watermarking).

1. As requests for content begin, and a bad WMT is identified, either the service provider or the watermarking vendor needs to store the `session_id` that's been mapped to the watermarking ID in that WMT.

1. Either the service provider or the watermarking vendor can [revoke the token](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list-ids-2) via the API, using its `session_id`.