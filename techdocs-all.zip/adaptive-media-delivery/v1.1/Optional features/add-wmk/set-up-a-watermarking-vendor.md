# [Set up a watermarking vendor](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-a-watermarking-vendor#set-up-a-watermarking-vendor)

You need to work with a supported third-party watermarking vendor to properly set up your content as well as generate and issue the watermarking tokens used in the process.

# [Supported Watermarking vendors](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-a-watermarking-vendor#supported-watermarking-vendors)

Currently, the following vendors are supported for use:
| Vendor | Live | Video on demand |
|---|---|---|
| **Content Armor** | ✓ | ✓ |
| **FriendMTS** | ✓ | ✓ |
| **INKA** | X | ✓ |
| **Irdeto** | ✓ | ✓ |
| **Nagra** | ✓ | ✓ |
| **Synamedia** | ✓ | ✓ |
| **Verimatrix** | X | ✓ |
| **Viaccess-Orca** | ✓ | ✓ |

# [Watermarking vendor responsibilities](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-a-watermarking-vendor#watermarking-vendor-responsibilities)

> Info: Because the actual process can vary based on your selected watermarking vendor, only an overview of what's required is discussed here, as well as additional topics that discuss requirements.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/watermarking-flow-v1.jpg)

Watermarking works by using multiple "variant versions" of the same media content and delivering segments from each, in a unique pattern that is determined by a watermarking token (WMT). The WMT is included in each segment request from an end user. Akamai verifies the WMT is valid and delivers the appropriate variant segment.

You need to work with your chosen watermarking vendor to perform various services:

- **Preprocess your content for watermarking**. You'll need to have your source content "preprocessed" into variants. You then need to work with the vendor to get this content to the appropriate place on your origin server. The process and requirements for this vary, based on the media format in use, HLS vs. DASH.

- **Create and issue the WMT**. The vendor also needs to generate the unique pattern for playback of the variants and secure it within the WMT. (For example, this pattern is set up as a claim in a JavaScript web token.)

- **Gather watermarking data**. After your watermarking vendor completes the previous two services, you need to configure your AMD property in Property Manager to support watermarking. You may need to work with the vendor to get some of the values you need to apply. These values are discussed in Set up watermarking in your AMD property.