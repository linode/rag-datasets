# [Cloud Access Manager & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-cloud-access-manager#cloud-access-manager-amd)

If you're using a third-party cloud provider for your origin, either Interoperability Google Cloud Platform or Amazon Web Services, consider using Cloud Access Manager to streamline client authentication.

In a typical transaction, you need to include a signature in the request so that your cloud provider recognizes the client. The signature contains an access key supplied by your cloud provider. That key consists of a unique access identifier and a secret access key. You include both of these values when setting up your AMD property in ​Akamai Control Center​. When receiving the request, a cloud provider calculates the signature and compares it to the one sent in the client request. If they match, the request is considered authentic. If they don't match, the request is denied. While this standard method works, it has some drawbacks:

- You need to set up the mechanism to inject the signature into a client request.

- This requires that you proxy through your origin, which can delay the request.

- The access identifier and secret access key are openly visible to anyone that can see your AMD property in ​Akamai Control Center​.

# [What is Cloud Access Manager?](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-cloud-access-manager#what-is-cloud-access-manager)

Cloud Access Manager lets you privately create your access keys and protects them. You add them to your AMD property using a name you define, and the access identifier and secret key are hidden. Cloud Access Manager uses the Akamai Intelligent Platform to route origin requests directly to your cloud provider. Akamai edge servers inject access key authentication on the forward origin path for you. This can decrease cost, bandwidth requirements, and the number of hits to your origin during peak times.

Work with your Akamai account representative to ensure Cloud Access Manager is available on your contract.

# [Set up Cloud Access Manager](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-cloud-access-manager#set-up-cloud-access-manager)

1. Start by getting [authentication details from your cloud provider](https://techdocs.akamai.com/cloud-access-mgr/docs/get-auth-details).

1. Use Cloud Access Manager to [create an access key](https://techdocs.akamai.com/cloud-access-mgr/docs/create-access-key).

1. Configure settings in the [Origin Characteristics & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-charac-amd) for your AMD property to sign requests with your access key:

    - **Origin Location**. Select the geographical location of your origin server to optimize access to it. If you aren't sure about your server location, you can leave it as Unknown.

    - **Authentication Method**. Select the third-party cloud provider that you use as your origin, either Amazon Web Services or Interoperability Google Cloud Storage.

    - **Encrypted Storage**. Set to **Yes**. This lets you refer to access keys you created that are securely stored in Cloud Access Manager. If you disable this option, the Origin Characteristics behavior stores the authentication details unencrypted.

    - **Access Key**. Select the access key that you want to use to sign requests to a cloud origin. This field lists only active access keys that you created in Cloud Access Manager, that match your property's authentication method selected in the Origin Characteristics behavior.

    - **Region (Amazon Web Services, only)**. Enter the code of the AWS region that houses your AWS service.

    - **Service Endpoint (Amazon Web Services, only)**. Enter the code of your AWS service. This is the segment or its part that precedes `amazonaws.com` or a region code in your AWS service endpoint. For example, s3 is the service code for this service endpoint: `https:// account-id.s3-control.eu-north-1.amazonaws.com`. See [AWS Service Endpoints](https://docs.aws.amazon.com/general/latest/gr/rande.html#view-service-endpoints) and [Service Endpoints and Quotas](https://docs.aws.amazon.com/general/latest/gr/aws-service-information.html).

# [Best practices for Cloud Access Manager](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-cloud-access-manager#best-practices-for-cloud-access-manager)

Consider these points when authenticating via a third-party cloud provider.

- You should only use a property akamaized hostname with third-party cloud authentication to either retrieve objects from the origin, or for read-only bucket operations.

- We recommend that you use two separate sets of cloud provider Access Keys, with one dedicated to GET operations and another intended for POST, PUT, or DELETE operations. For all GET operations, set them up to use a property via Property Manager; for POST, PUT, and DELETE operations, you should use the APIs or SDKs offered by the associated cloud provider.

- You should regularly rotate the cloud provider Access Keys. This reduces the likelihood of unauthorized diversion of confidential information.

- Currently, only the `Authorization`header is supported. If you're using query string parameters with this authentication, each query parameter in the incoming client request must be sorted alphabetically, and URL encoded.

# [More information](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-cloud-access-manager#more-information)

For complete details, see the [Cloud Access Manager documentation](https://techdocs.akamai.com/cloud-access-mgr/docs/welcome-cloud-access-mgr).