# [Sample usage: add and enable a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/docs/sample-usage-add-and-enable-a-revocation-list#sample-usage-add-and-enable-a-revocation-list)

This quick example shows how to create and apply all of the components used in a revocation list, so you can revoke tokens.

1. [Generate a token and apply it to your content](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content). Extract the token's `session_id` value for use later in this process.

1. [Add a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list) to establish a new list. Make note of the `name` you set for it.

1. [Create a new AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop), or access an existing one in Property Manager on [Control Center](https://control.akamai.com).

1. [Enable Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication) via the Segmented Media Protection behavior in an applicable rule. 

1. Set **Advanced Options** to **On**. 

1. In the Field Carry-Over options, ensure **Session-Id** is set to **Yes**.

1. Set the **Token Revocation** slider to **On**.

1. In the **Revocation List Name** drop-down, select the revocation list you created with the API.

1. Save the AMD property and activate it on the production network to start delivering your media.

1. [Revoke tokens](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list-ids-2) to add one or more offending tokens to the revocation list. This blocks requests that include them from access.