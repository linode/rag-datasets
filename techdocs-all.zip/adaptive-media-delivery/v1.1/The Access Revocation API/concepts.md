# [Concepts](https://techdocs.akamai.com/adaptive-media-delivery/docs/concepts#concepts)

Familiarize yourself with some of the common terms used in this API.

- **Revocation list**. A revocation list provides a way to logically group token identifiers to block their use. For example, you could create a revocation list for a specific event to block specific tokens from accessing content. The revocation list resource also has properties describing its association with a contract. Revocation lists contain the `identifiers` collection.

- **Identifiers**. This collection contains the token identifiers that you've included in a revocation list. The token identifier refers to the **Session-Id** set for the token in Property Manager. You can view this value by reviewing your AMD property in Property Manager&mdash;either using Control Center or [PAPI](https://developer.akamai.com/api/core_features/property_manager/vlatest.html#segmentedcontentprotection).

- **Token**. This refers to the `session_id` set when you define the access token for use with Token Authentication. The `session_id` serves as the *token identifier* referenced throughout this documentation.

- **Property**. This refers to the Akamai Resource Locator (ARL) properties assigned to the AMD property that has Access Revocation enabled. These properties consist of the unique ARL file ID, the AMD property's unique ID, and the AMD property's name.

- **Metadata**. In the context of this API, this refers to the current number of tokens named in a revocation list as well as the total number of tokens the revocation list can contain.