# [Get started](https://techdocs.akamai.com/adaptive-media-delivery/docs/api-get-started#get-started)

# [About Access Revocation](https://techdocs.akamai.com/adaptive-media-delivery/docs/api-get-started#about-access-revocation)

You can optionally protect your content with [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth). It generates unique tokens that Akamai validates to grant access to your media. Access Revocation lets you recognize tokens that have been hijacked and flag them to block requests that include them. Use the Access Revocation API to generate a “revocation list” of these tokens. You can also set a time to live for this revocation period to automatically “unrevoke” these tokens, or you can manually remove them from a revocation list. The API also lets you review your revocation lists and Access Revocation settings.

# [Meet some prerequisites](https://techdocs.akamai.com/adaptive-media-delivery/docs/api-get-started#meet-some-prerequisites)

To configure the Access Revocation API for the first time:

- Ensure that your contract includes the` AdaptiveMediaDelivery::AccessRevocation` engineering product:

    1. Access [​Akamai Control Center​](https://control.akamai.com/). 

    1. Select ☰ > **Show all services** (at the bottom).

    1. Under INTERNAL LINKS at the bottom, select **Advanced search**.

    1. Click the search field, and select **in:Accounts** then select **by:Engineering** product.

    1. Type **AdaptiveMediaDelivery** and look for the `AdaptiveMediaDelivery::AccessRevocation` entry:

        - **If you see it**. You're ready to go.

        - **If you don't see it**. Reach out to your Akamai account team for help getting it added to your contract.

- Review [Create authentication credentials](https://techdocs.akamai.com/developer/docs/set-up-authentication-credentials). You use the Identity and Access Management tool in Akamai ​Control Center​​ to set up credentials to access any Akamai API, as well as gather some information you’ll need:

    - Set up client tokens for access. These tokens appear as custom hostnames that look like this: `https://akzz-XXXXXXXXXXXXXXXX-XXXXXXXXXXXXXXXX.luna.akamaiapis.net`.

    - Verify you have the API service named **Token Authentication as a Service (TaaS)** in the Identity and Access Management tool, and its access level is set to **READ-WRITE**. This gives you access to all of the operations in this API.

- Get your `contractId`. Several operations in this API require this value. You can find your `contractId` using the Contract API:

    1. [List contracts](https://developer.akamai.com/api/core_features/contract/v1.html#getcontracts). If you only have one, you’re done. Store this as your `contractId`. If you have more than one, make note of these values and continue.

    1. [List products per contract](https://developer.akamai.com/api/core_features/contract/v1.html#getproductspercontract). Set the {contractId} variable to one you’ve noted.

    1. Look for a `marketingProductId` of Token Authentication as a Service or TaaS in the response. If you find it, this contract has Access Revocation enabled, and you can use this `contractId`.

> Info: If you’re not sure of the right contract to use, or you see Access Revocation on more than one contract, check with your local administrator or contact your account representative.

- You need to perform tasks in a specific order, and they require separate tools.

    1. Create a new AMD property or use an existing one.

    1. Create an Access Revocation list. *You use this API to do this.*

    1. Apply the revocation list in your AMD property.

    1. Add tokens to your revocation list to block them from access. *You use this API to do this.*

    You can use either the Property Manager interface in ​Control Center​​ or the [Property Manager API](https://developer.akamai.com/api/core_features/property_manager/v1.html) (PAPI) to perform the first and third tasks. Akamai recommends using the Property Manager interface, and that's what's covered here.

- You typically can't use Access Revocation if you have a unique Token Authentication scenario. A unique scenario is one that's set up by your Akamai account team. It's custom and outside the default scenarios you can define using settings in the [Segmented Media Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth) behavior. If you have a unique scenario, contact your account team to see if you can use Access Revocation.