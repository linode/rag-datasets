# [Prepare your environment](https://techdocs.akamai.com/adaptive-media-delivery/docs/prepare-your-environment#prepare-your-environment)

Before you can set up your Adaptive Media Delivery property to deliver content there are some things you need to do.

# [Prepare your edge certificate](https://techdocs.akamai.com/adaptive-media-delivery/docs/prepare-your-environment#prepare-your-edge-certificate)

This certificate protects the first stage of the [request flow](https://techdocs.akamai.com/adaptive-media-delivery/docs/understand-the-request-flow)—the request from an end user (client) that's received by Akamai edge servers. In some cases, you may need to create this certificate before you create your property.

This process isn't unique to Adaptive Media Delivery. Have a look at the [Property Manager user docs](https://techdocs.akamai.com/property-mgr/docs/prepare-your-edge-certificates) for full details.

# [Prepare your origin server](https://techdocs.akamai.com/adaptive-media-delivery/docs/prepare-your-environment#prepare-your-origin-server)

An origin server is a physical location that houses your deliverable content. This accounts for the second stage of the [request flow](https://techdocs.akamai.com/adaptive-media-delivery/docs/understand-the-request-flow)—the request from edge servers to your origin to get your deliverable content. Before you can add your origin server to your request flow, you need to set some things up for your origin, collect key information about your origin, and decide how you want ​Akamai to interact with it.

This process isn't exclusive to Adaptive Media Delivery, either. Full details on the setup of your origin can be found in the [Property Manager docs](https://techdocs.akamai.com/property-mgr/docs/prepare-your-origin-server), too.