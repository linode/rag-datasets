# [Delivery concepts and terms](https://techdocs.akamai.com/adaptive-media-delivery/docs/key-concepts-and-terms#delivery-concepts-and-terms)

If this is the first time you're configuring Akamai edge network delivery services, you may want to familiarize yourself with some of the common concepts and terms used with the process.

We keep a separate glossary of these terms for consistency and ease of access from our multiple delivery products:

[Akamai delivery concepts and terms](https://techdocs.akamai.com/property-mgr/docs/key-concepts-terms)
