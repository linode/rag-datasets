# [OpenAPI schema](https://techdocs.akamai.com/adaptive-media-delivery/docs/openapi-schema#openapi-schema)
