# [Errors](https://techdocs.akamai.com/adaptive-media-delivery/docs/api-errors#errors)

When the API encounters an error, it responds with an error code and an error message that provides details that can be useful for debugging.

This shows a typical error response when you try to access a non-existent `revocation-listId`.
```
{
  "codes": [
    {
      "code": "{\n  \"type\": \"resource-not-found\",\n  \"title\": \"Resource Not Found\",\n  \"instance\": \"0a037412-6aac-4c7f-9e45-b29fb874db86\",\n  \"status\": 404,\n  \"detail\": \"Resource Not Found (details=[No revocation list exists with given ID 123.])\"\n}",
      "language": "json"
    }
  ]
}
```
For details on information contained in the error responses, refer to [Error response syntax](https://techdocs.akamai.com/developer/docs/error-responses).