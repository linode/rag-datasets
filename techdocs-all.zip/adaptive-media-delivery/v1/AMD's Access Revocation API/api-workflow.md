# [API workflow](https://techdocs.akamai.com/adaptive-media-delivery/docs/api-workflow#api-workflow)

There are several things you can do with the Access Revocation API, key among them is creating a revocation list and adding tokens to it that you want blocked. Here are the basic steps to get this done:

1. [Generate a token and apply it to your content](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content). Extract the token's `session_id` value for use later in this process.

2. [Add a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list) to establish a new list. Store the `name` you set for it. 

3. Create a new AMD property. You can use the [Property Manager API (PAPI)](https://techdocs.akamai.com/property-mgr/reference/onboard-a-custom-cert-property) for this.

4. [Enable token authentication](https://techdocs.akamai.com/property-mgr/reference/latest-segmented-content-protection) via the `segmentedContentProtection` behavior in an applicable rule. You need to set at least these values:

   - `enabled`. Set to `true`.

   - `key`. You need to [generate an access token](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content#1---generate-the-access-short-token) to be used. This is the secret "key" value you used when generating it.

   - `useAdvanced`. Set to `true`.

   - `sessionId`. Set to `true`.

   - `tokenRevocationEnabled`. Set to `true`.

5. Save the AMD property and [activate it on the staging](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop) network to test it. When you're satisfied, [activate it on the production](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live) network to start delivering your media.

6. [Revoke tokens](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list-ids) to add one or more offending tokens to the revocation list. This blocks requests that include them from access.

# [Sample usage: add and enable a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/docs/api-workflow#sample-usage-add-and-enable-a-revocation-list)

This quick example shows how to create and apply all of the components used in a revocation list, so you can revoke tokens.

1. [Generate a token and apply it to your content](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content). Extract the token's `session_id` value for use later in this process.

2. [Add a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list) to establish a new list. Store the `name` you set for it. 

3. [Create a new AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop), or access an existing one in Property Manager on [Control Center](https://control.akamai.com).

4. [Enable Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication) via the Segmented Media Protection behavior in an applicable rule. 

5. Set **Advanced Options** to **On**. 

6. In the Field Carry-Over options, ensure **Session-Id** is set to **Yes**.

7. Set the **Token Revocation** slider to **On**.

8. In the **Revocation List Name** drop-down, select the revocation list you created with the API.

9. Save the AMD property and activate it on the production network to start delivering your media.

10. [Revoke tokens](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list-ids) to add one or more offending tokens to the revocation list. This blocks requests that include them from access.