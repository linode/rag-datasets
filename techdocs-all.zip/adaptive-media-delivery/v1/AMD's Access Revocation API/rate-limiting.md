# [Rate limiting](https://techdocs.akamai.com/adaptive-media-delivery/docs/rate-limiting#rate-limiting)

The Access Revocation API imposes a rate limiting constraint of 60 requests per minute to ensure even distribution of system resources. Exceeding the limit results in a 429 error response.

The API responds with these HTTP headers to provide context over how close it's getting to the limit:

- `X-RateLimit-Limit`: 60 requests per minute.

- `X-RateLimit-Remaining`: Number of remaining requests allowed during the period.

- `X-RateLimit-Next`: Once the `X-RateLimit-Limit` has been reached, this represents the time you can issue another individual request. The `X-RateLimit-Remaining` gradually increases and becomes equal to `X-RateLimit-Limit` again.