# [API summary](https://techdocs.akamai.com/adaptive-media-delivery/docs/api-summary#api-summary)

See the API's various operations for details on their request parameters and response data.

| Operation | Method | Endpoint |
| :--- | :--- | :--- |
| Access Revocation |||
|  [List revocation lists](https://techdocs.akamai.com/adaptive-media-delivery/reference/get-revocation-lists) | `GET` | `/revocation-lists` |
|  [Add a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list) | `POST` | `/revocation-lists` |
|  [Delete a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/reference/delete-revocation-list) | `DELETE` | `/revocation-lists/​{revocationListId}` |
|  [List identifiers](https://techdocs.akamai.com/adaptive-media-delivery/reference/get-revocation-list-ids) | `GET` | `/revocation-lists/​{revocationListId}/​identifiers` |
|  [Revoke tokens](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-revocation-list-ids) | `POST` | `/revocation-lists/​{revocationListId}/​identifiers/​add` |
|  [Unrevoke tokens](https://techdocs.akamai.com/adaptive-media-delivery/reference/post-unrevoke-revocation-list-ids) | `POST` | `/revocation-lists/​{revocationListId}/​identifiers/​remove` |
|  [Get an identifier](https://techdocs.akamai.com/adaptive-media-delivery/reference/get-revocation-list-token) | `GET` | `/revocation-lists/​{revocationListId}/​identifiers/​{tokenId}` |
|  [Get a revocation list's identifier count](https://techdocs.akamai.com/adaptive-media-delivery/reference/get-revocation-list-meta) | `GET` | `/revocation-lists/​{revocationListId}/​meta` |
|  [List revocation list ARL properties](https://techdocs.akamai.com/adaptive-media-delivery/reference/get-revocation-list-properties) | `GET` | `/revocation-lists/​{revocationListId}/​properties` |