# [Get started](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-started#get-started)

# [Ensure you can use Access Revocation](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-started#ensure-you-can-use-access-revocation)

You typically can't use Access Revocation if you already have a unique Token Authentication scenario. A unique scenario is one that's set up by your Akamai account team. It's custom and outside the default scenarios you can define using settings in the [Segmented Media Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth) behavior. If you have a unique scenario, contact your account team to see if you can use Access Revocation.

# [Get Access Revocation on your contract](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-started#get-access-revocation-on-your-contract)

You can check by following these steps:

1. Access [​Akamai Control Center​](https://control.akamai.com/). 

2. Select ☰ > **ACCOUNT ADMIN** > **Contracts**.

3. Click your **Contract ID** in the table.

4. Type `adaptive media` in the _Filter_ field and look for the `AdaptiveMediaDelivery::AccessRevocation` in the Engineering Product Name column:

   - **If you see it**. You're ready to go.

   - **If you don't see it**. Reach out to your Akamai account team for help getting it added to your contract.

# [Set up authentication credentials](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-started#set-up-authentication-credentials)

You use the Identity and Access Management tool in Akamai ​Control Center​​ to [set up an API client](https://techdocs.akamai.com/developer/docs/set-up-authentication-credentials). An API client consists of several values your API client uses to authenticate calls to Akamai APIs. While you're creating your API client, you'll need to do the following:

1. **Verify you have the API service**. In Identity and Access Management, you'll come to the **API client for you** interface. Click **Show additional details** and look for the **TaaS** entry in the APIs table and make sure its access level is set to **READ-WRITE**. This gives you access to all operations in this API. If you don't see it, or it's set to READ-ONLY access, talk to your company's Akamai administrator to get your user updated, or reach out to your Akamai account team.

2. **Gather values**. In the Credentials section, make note of the `client_secret`, `host`, `access_token`, and `client_token` values.

 > Warning: The `client_secret` is only revealed once
  This value is only revealed after you first create an API client. _You can't come back to this interface to get it._ So, make sure you make note of it for use. You can use the **Download** or **Copy credential** buttons in the interface to save all of your values.

# [Get your `contractId`](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-started#get-your-contractid)

Several operations in this API require this value. You can find your `contractId` using the Contract API:

1. [List contracts](https://techdocs.akamai.com/contract-api/reference/get-contract-ids). If you only have one, you’re done. Store this as your `contractId`. If you have more than one, make note of these values and continue.

2. [List products per contract](https://techdocs.akamai.com/contract-api/reference/get-contract-product-summaries). Set the {contractId} variable to one you’ve noted.

3. Look for a `marketingProductId` of Token Authentication as a Service or TaaS in the response. If you find it, this contract has Access Revocation enabled, and you can use this `contractId`.

 > Note: 
  If you’re not sure of the right contract to use, or you see Access Revocation on more than one contract, check with your local administrator or contact your account representative.