# [Create a new AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop#create-a-new-amd-property)

To set up AMD, you first need to create a new property in ​Akamai Control Center​.

1. Select the appropriate ​Akamai Control Center​ account using the drop-down in the top right.

1. Open the application. Go to ☰ > **CDN** > **Properties**. Click **New Property**.

1. Click **Create Property** in the **Adaptive Media Delivery** card.

1. In the **Property Name** field, enter a name for your property. This serves as the filename for the property and how it's displayed throughout Property Manager.

> Success: To make things easy, you can use your site's hostname for this value. Make note of the value you set for future reference.

5. Select the appropriate Group to use for the property. The group selected must have Adaptive Media Delivery included on the contract associated with it.

1. Click **Next**.

# [Review property version information](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop#review-property-version-information)

After you add a new property, this is the first panel you'll see. It shows information regarding the AMD property, as well as settings used to define HTTPS (secure) or HTTP (non-secure) delivery.

You can view the contract associated with the configuration, see its current status on each of the edge network environments (Production&mdash;live, vs. Staging&mdash;test), include **Version Notes** for the configuration, and set the desired delivery method:

- **Standard TLS ready**. Select this if you want to use basic (non-PCI-compliant) HTTPS or non-secure HTTP delivery.

- **Enhanced TLS or Shared Cert**. Select this if you want to use a higher level of security (PCI-compliant) or Akamai's shared certificate for secure (HTTPS) delivery.

You fully configure the actual delivery method when you define property hostnames.

# [What's next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop#whats-next)

Now, you use the Property Manager Editor to define the property:

- [Define Property Hostnames](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-hn). Associate your site's hostname with an edge hostname so requests can access the Akamai network.

- [Define Property Configuration Settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-config-settings). Set up the rules and behaviors that are applied to requests.