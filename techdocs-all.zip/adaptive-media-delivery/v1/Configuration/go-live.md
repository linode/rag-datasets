# [Go live with AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#go-live-with-amd)

Once all of the configuration steps and testing are complete, you can go live to begin delivering your content.

# [1. Activate on production](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#1-activate-on-production)

The first step in the process is to push your AMD property to the production ("live") network to distribute your content to end users.

 > Note: 
  This process assumes that the target AMD property has already been activated on the Staging network, for use in [testing](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop). _You need to push a property to Staging before you can push it to Production_.

1. If necessary, access the target property on [​Akamai Control Center​](https://control.akamai.com):

   a. Use the drop-down in the top right to select the ​Control Center​​ account you used to create the AMD property.

   b. Go to ☰ > **CDN** > **Properties**.

   c. Enter the name of your property in the _Filter by Property or Hostname_ field.

   d. Click the **Property Name** to open it.

2. Click the **Version \<#>** for the property you want to activate.

3. Select the **Activate** tab.

4. Click **Activate v\<#> on Production**. The **Activate** window opens.

5. Any warnings carried over from the configuration will be displayed as **Validation Messages**. You can click **Cancel** and edit the property to acknowledge them.

6. Optionally, add descriptive **Notes** and use the **Notify via email** field to define email address(es) that will receive notifications in the event of a property file changes. Separate multiple entries with a comma—"**,** ")

7. Click **Activating v\<#> on Production**.

8. Monitor the **Activate** tab to track progress. You can also click **View Details** to review settings and information regarding the property.

# [2. Point to your configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#2-point-to-your-configuration)

This process can vary, based on the type of hostname you're using in your AMD property.

## [Custom certificate hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#custom-certificate-hostname)

You need to change the existing DNS record of your hostname to be a CNAME record that points to the edge hostnameYou need to change the existing DNS record for your content to be a CNAME record that points to the edge hostname. Once you modify the DNS record, it's typically only a matter of minutes until your content is served via the Akamai edge network.

Here are some DNS record examples:

Below are some examples of the DNS records required to deliver objects from a content delivery network. You need to replace `www.example.com` with the actual domain used to access your content.

### [Standard TLS-secured hostname example](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#standard-tls-secured-hostname-example)

- **Origin-server Hostname**. `origin-example.com IN A {IP address of the origin server}`

- **Edge Hostname**. `www.example.com.edgesuite.net`

- **Production Hostname**. `www.example.com. IN CNAME www.example.com.edgesuite.net`

### [Enhanced TLS-secured hostname example](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#enhanced-tls-secured-hostname-example)

- **Origin-server Hostname**. `origin-example.com IN A {IP address of the origin server}`

- **Edge Hostname**. `www.example.com.edgekey.net`

- **Production Hostname**. `www.example.com. IN CNAME www.example.com.edgekey.net`

### [How long does the DNS change take?](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#how-long-does-the-dns-change-take)

This depends on the time to live (TTL) set on the existing DNS record for the hostname in question. This is commonly set to one day, which means it would take up to 24 hours before your end users are directed to the Edge network. To shorten this, you could reduce your DNS TTL in advance of the change, and increase it to the normal TTL after the change. 

You can switch your application to the edge network at any time after completing the activation steps and testing. No additional activation or monitoring is required.

## [Shared certificate hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#shared-certificate-hostname)

You use the shared certificate hostname itself in the URLs of your content, in place of your origin server hostname. You could set up your player to make requests starting with the Shared certificate hostname URL and add any path elements as they exist on your origin server. For example, assume you have your player accesses a video clip on your origin server: 

```
origin-example.com/media/video-1.m4v
```

You'd update your player to access it using the shared certificate edge hostname, instead:

```
example-com.akamaized.net/media/video-1.m4v
```

Now, when the player requests your content, the request is sent to the Akamai edge network where your AMD property is read. What you have configured in it — including what's set in the [Origin Server](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-server-amd) behavior — is used to access and deliver your content.

# [Troubleshooting](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live#troubleshooting)

If you notice a problem after switching your content to the edge network:

1. Roll back any changes:

   - **Custom cert edge hostname**. Make a DNS change to point back to your origin servers.

   - **Shared certificate hostname**. Revert your player to request content directly from your origin server.

2. Report the problem to Akamai.

This helps you and Akamai identify the problem in a controlled environment without affecting live end users.