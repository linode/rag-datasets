# [Recommended behaviors in the Default Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/rcmd-behs-default-rule#recommended-behaviors-in-the-default-rule)

We automatically add various recommended behaviors to your configuration within the Default Rule, which applies to all requests. They're optional but recommended.

- **You can leave them in the Default Rule**. This is recommended so that they apply to all requests.

- **You can move it out of the Default Rule**. Mouse over the behavior and click the x icon. Then, you can add it to an optional rule, and set specific match criteria.

- **You can delete the behavior**. Mouse over the behavior and click the x  icon.

Review details for each of these behaviors and apply settings as desired.

# [Segmented Media Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/rcmd-behs-default-rule#segmented-media-protection)

Segmented Media Protection (SMP) lets you add token authentication and media encryption protection to the delivery of your media content.

The securities offered with SMP are implemented on the fly during content delivery when client requests are managed by your AMD property. SMP is a single behavior that lets you configure multiple securities:

- [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth). Only end users that have been properly authenticated can access your streams. This is accomplished by generating, exchanging, and verifying "shared secret" tokens between AMD and the end user's player.

- [Media Encryption](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-media-enc) (HLS Format Media, Only). This encrypts your content and provides secure access keys to end users. Ideally, you should also use Token Authentication to ensure these secure keys are only delivered to end users that have also been authenticated.

# [Auto Domain Validation and AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/rcmd-behs-default-rule#auto-domain-validation-and-amd)

This behavior enables the automatic renewal of Standard TLS Domain Validated certificates.

With Domain Validation (DV), the applicable certificate authority (CA) validates that you have control of the domain. (DV is the lowest level of validation.) The Certificate Provisioning System supports DV certificates issued by Let's Encrypt, an automated, and open CA that is run for public benefit. Certificate expiration is typically as follows:

- Akamai-managed DV certificates expire in 90 days.

- Renewals for Akamai-managed DV certificates start 16 days prior to expiration.

- A third-party, customer-supplied, DV certificate can expire whenever the applicable certificate authority determines it expires; this behavior is not necessary for customer-supplied DV certificates.

## [When should I include this behavior?](https://techdocs.akamai.com/adaptive-media-delivery/docs/rcmd-behs-default-rule#when-should-i-include-this-behavior)

If you are using Standard TLS DV certificates for the hostnames in this property, you should include this behavior to enable automatic renewal of the certificate. If you leave this behavior out, the certificate could expire, and HTTPS traffic will be served with certificate errors.

 > Note: 
  This behavior isn't required if you're using an Enhanced TLS certificate to secure requests with your [property hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-hn).

## [How is this behavior supported?](https://techdocs.akamai.com/adaptive-media-delivery/docs/rcmd-behs-default-rule#how-is-this-behavior-supported)

You can include this behavior in your property in multiple ways. Consider these points when adding it:

- **You can include it in the Default Rule**. In this case, it is applied to all requests for all resources associated with this property.

- **You can include it in a supplemental rule**. This allows you to set up a custom rule that only applies to specific requests for resources associated with this property. This rule must use only the "Hostname" condition match criteria.

- **You can include it in multiple rules**. Rule priority applies, with rules lower in the order taking precedence.

- **There might be an issue if an incoming request matches another "redirect" behavior**. Assume that the incoming request matches another behavior you have in your property that results in a redirect operation similar to what applies to this behavior. If so, the operation that takes precedence depends on where the behavior is in the property.

- **Are you using a similar behavior in another rule?** If so, ensure that behavior exists in a rule that is higher in the rule order so that it can take precedence.

- **You should test your configuration**. Test it on staging by making a request to `www.yourdomain.com/well-known/acme-challenge/some_random_token`.