# [The Default CORS Policy Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#the-default-cors-policy-rule)

Cross-Origin Resource Sharing (CORS) is an HTTP-header-based tool that's used to locate other origin servers that an end user's browser can use to get your content. CORS uses a "preflight check" mechanism: A request is made to the origin server where the cross-origin content is stored, to make sure the request is allowed. If it's allowed, the browser sends various headers that indicate the HTTP method and headers to be used in the actual request.

# [How it works](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#how-it-works)

If you have CORS set up in your environment—via scripts in ths `XMLHttpRequest` object on your site or app, or through some other mechanism—the **Modify Outgoing Response Header** behaviors in this rule are set up to modify various `Access-Control` response headers, to indicate what's supported after the CORS preflight check. _This effectively sets the HTTP method and headers that a browser can use in a CORS request_.

- **Access-Control-Allow-Origin**. This modifies this header value to "**\***" to get the header to acknowledge all origin servers. This way, this header won't inadvertently block access to an origin that may host your content. 

- **Access-Control-Allow-Methods**. This modifies this header to ensure that only the GET, POST, and OPTIONS methods are allowed in a request from the browser.

- **Access-Control-Allow-Headers**. This header indicates which HTTP headers can be used during the request from a browser. This modifies this header so that only [`origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Origin), [`range`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Range), `hdntl`, and `hdnts` request headers are supported. The `hdntl` and `hdnts` headers are Akamai-specific headers used in the delivery of media content.

- **Access-Control-Expose-Headers**. This header indicates which response headers should be available to a script running in the requesting browser. This modifies this header so that only the [`Server`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Server), `range`, `hdntl`, `hdnts`, `Akamai-Mon-Iucid-Ing`, `Akamai-Mon-Iucid-Del`, and `Akamai-Request-BC` headers are supported. The `Akamai-Mon-Iucid-Ing` and  `Akamai-Mon-Iucid-Del` headers are included to support Akamai client-side analytics. `Akamai-Request-BC` allows for CORS support with the [Breadcrumbs](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-breadcrumbs) feature with AMD.

- **Access-Control-Allow-Credentials**. This modifies this header to set it to `true`. When a request requires credentials for content, a browser will only pass the preflight check if the Access-Control-Allow-Credentials value is `true`. Credentials are cookies, authorization headers, or TLS client certificates. For example, with this value set to true, if your origin server requires credentials (a cookie) to access cross-origin content, and no cookie is present, the "credential check" fails. The response is then ignored by the browser and the content is not returned.

- **Access-Control-Max-Age**. This header determines how long the results of a preflight check can be cached. This sets it to `86400` seconds which equals 24 hours.

 > Tip: 
  For best performance, leave this rule and all of its behaviors in the configuration. But, none of its settings are mandatory.

# [Support for Common Media Client Data (CMCD)](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule#support-for-common-media-client-data-cmcd)

Do you want to support CMCD with your media player? If so, you may need to apply settings in this behavior to properly support it. Have a look at [Common Media Client Data](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd) for full details.