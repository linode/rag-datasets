# [Client Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-charac-amd#client-characteristics)

This behavior incorporates use case-based provisioning to optimize delivery to requesting clients.

# [Client Location](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-charac-amd#client-location)

Select a location that is _geographically closest_ to the clients accessing content through this property configuration, to optimize the delivery. If you set a region that is closer to your clients, delivery is typically faster.

 > Note: 
  If you're unsure, leave this set to **Unknown**. If you select an inappropriate geographic region, it could negatively affect delivery.

# [About mixed-mode configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-charac-amd#about-mixed-mode-configuration)

This is a "use case-based" behavior that's used to optimize delivery. You need to keep this behavior in the Default Rule and apply settings. But, with mixed mode configuration for AMD, you can also include it in a child rule and apply different match criteria to have separate requests use different client characteristics optimizations. For more details, see [Mixed Mode & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd).