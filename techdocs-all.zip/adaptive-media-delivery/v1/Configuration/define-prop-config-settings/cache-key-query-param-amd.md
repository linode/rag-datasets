# [Cache Key Query Parameters](https://techdocs.akamai.com/adaptive-media-delivery/docs/cache-key-query-param-amd#cache-key-query-parameters)

This behavior controls whether the query string or portions of it are used to differentiate objects in cache.

This behavior is automatically included in the Default Rule for a property configuration for AMD. Unlike other behaviors that are automatically included in this rule, it's not required. While we recommend you set it in the Default Rule, so that it will apply to all requests, you can remove it from this rule.

# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/cache-key-query-param-amd#before-you-begin)

Before you work with this behavior and all caching-related behaviors, Akamai recommends that you read, [What you need to know about caching](https://techdocs.akamai.com/property-mgr/docs/know-caching) in the Property Manager help. It'll help you better understand caching and how it works within the Akamai network.

# [Implementation](https://techdocs.akamai.com/adaptive-media-delivery/docs/cache-key-query-param-amd#implementation)

The default setting for this behavior is **Exclude all parameters**. This means that all requests for the same URL are served from a single cache entry _regardless of the query string in a request_. For example, these two requests would be served from the same object in cache:

```
http://mymedia.com/directory/manifest?token=1234598765
http://mymedia.com/directory/manifest?token=9876512345
```

This setting tells Akamai to only consider the URL without the query string when looking in the cache. Using the examples above, that would be:

```
http://mymedia.com/directory/manifest
```

Is the default **Exclude all parameters** setting appropriate for your content? If not, pick the appropriate setting for your environment to have Akamai optimize delivery by incorporating use case-based provisioning.

 > Warning: NetStorage doesn't honor query strings
  If you're using it as your origin server, this needs to be set to **Exclude all parameters**.

Other available options include:

# [Be careful when changing the cache key](https://techdocs.akamai.com/adaptive-media-delivery/docs/cache-key-query-param-amd#be-careful-when-changing-the-cache-key)

If you change the cache key globally or for too many objects on a property that is already active—that is, if you create a new version that has a different cache key for all content—you can create problems for your origin when you activate the new version on production. When you change the cache key, you invalidate cached content that's using the existing cache key. Akamai edge servers will request new objects from your origin _at a level that can create severe spikes in bandwidth_.

If you need to change the cache keys on an active configuration, you should limit the changes: send them out a few changes at a time over an expanded time frame.