# [Content Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#content-characteristics)

This behavior lets you define specific information about your content to optimize its delivery.

# [Catalog Size](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#catalog-size)

Use this to set the overall volume of objects to be delivered through this property.

- **Small**. Select this if your content is less than 100G.
- **Medium**. Select this if your content ranges from 100G to 1TB.
- **Large**. Select this if your content ranges from 1TB to 100TB.
- **Extra Large**. Select this if your content is greater than 100TB.
- **Unknown** (Default). Select this if you don't know the volume. AMD will still try to optimize delivery based on the request.

# [Content Type](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#content-type)

If you're delivering a specific type of content with this property, you can select it here to help optimize delivery.

- **Standard Definition**. This is typically 480i/p or 720p.
- **High Definition**. This is typically 1080i or 1080p.
- **Ultra High Definition (4K)**
- **Other**. Select this if your use case isn't available for selection, or it is a combination of the available selections.
- **Unknown** This is the default. Leave it set to this if you're unsure of the specific content type. AMD will still try to optimize delivery based on the request.

# [Popularity Distribution](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#popularity-distribution)

Select how often the content is requested:

- **Long Tail**. This applies if most of the traffic volume consists of a small number of requests for content that has a relatively long life.
- **Popular**. This applies if most of the traffic volume consists of a large number of requests for content that has a relatively short life.
- **Other**. Select this if your use case isn't available for selection, or it is a combination of the available selections.
- **Unknown**. This is the default. Select this if you're not sure of the popularity level for the content to be delivered by this property. AMD will still try to optimize delivery based on the request.

# [Origin Object Size](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#origin-object-size)

Use this to set a range for the size of the objects delivered through this property:

- **Less than 1MB**. Partial object caching _is not_ applied.
- **1-10MB**. Partial object caching _is not_ applied.
- **10-100MB**. Partial object caching is automatically enabled with this setting.
- **Greater than 100 MB**. Partial object caching is automatically enabled with this setting.
- **Unknown**. Select this if you're unsure of the specific object size, or you don't have a fixed size for target content. Partial object caching is automatically enabled with this setting for objects greater than 10 MB in size.

## [Partial object caching](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#partial-object-caching)

Partial object caching is part of our large file optimization support. It increases origin server offload by caching in chunks, instead of as a single, composite object. Partial object caching is required for the delivery of "large files"—those in excess of 10 MB in size. It's automatically enabled if you select any of these as your **Origin Object Size**:

- **10-100 MB**.
- **Greater than 100 MB**.
- **Unknown**. Partial object caching is applied for an object that is greater than 10 MB in size, if the object falls into what you've selected for **Content Type**. For example, if you've selected "High Definition" as your Content Type, partial object caching is enabled if a file of that type is requested that's over 10MB in size.

If you set Origin Object Size to **Less than 1MB** or **1-10MB**, partial object caching is not enabled. If a request is made through this configuration for a larger file, a 403 error is returned.

If you specify a large file setting, but your origin never actually serves files in that size range, the Akamai platform makes additional requests to the origin. This can impact overall performance and access. This happens because the edge server requests the first byte of each object to determine if the minimum object size criteria has been met—at least 10MB. Once that check fails, the server simply re-requests the entire object from the origin.

We recommend that you verify the size of your delivery objects on your origin, and select the appropriate size to ensure that partial object caching is enabled or disabled, as necessary.

 > Tip: You may want partial object caching for on demand video, but not for live
  Typically, on-demand format video files require a large file setting and partial object caching because these tend to be larger, composite files. Live video, which tends to be distributed as smaller, individual segments doesn't require partial object caching, so the smaller file settings should be selected as the **Origin Object Size**. This may not apply to all environments, which is why we recommend that you verify your media file size requirements.

# [Enable \](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#enable)

You can select from multiple switch buttons, for the various media formats supported for use—**Enable HLS** (HTTP Live Streaming for iOS), **Enable HDS** (HTTP Dynamic Streaming for Adobe Flash), **Enable DASH** (Dynamic Adaptive Streaming over HTTP) and **Enable Smooth** (for Microsoft Smooth Streaming). Set the switch to **Yes** for each format to be supported by this property. Additional options for each format include the following:

- **Fragment/Segment Duration**. Select the desired fragment or segment duration for the selected media format.
- **Origin Object Size**. Use this to set a range for the size of media objects delivered through this property—Less than 1MB, 1-10MB, 10-100MB, or Unknown (This is the default, and should be left as the selected setting if you are not sure of the size of objects to be delivered).

# [Best practices settings applied by default](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#best-practices-settings-applied-by-default)

Akamai automatically applies various best practices settings to coincide with the Content Characteristics behavior in your property configuration. You don't need to manually define these via individual behaviors, because Akamai presets them for optimal performance.

# [Content characteristics and mixed mode configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd#content-characteristics-and-mixed-mode-configuration)

This is a "use case-based" behavior that's automatically included in the Default Rule and used to optimize delivery. You need to apply settings for this behavior in the Default Rule. However, with Mixed Mode Configuration for AMD (MMC), you can also include it in another rule and apply different match criteria to have separate requests use different content characteristics optimizations. 

For more details, see [Mixed Mode & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd).