# [Add optional rules](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-optal-rules#add-optional-rules)

You can add rules via the **Add Rule** button to include match criteria and behaviors outside of what's included automatically in the Default Rule for your AMD property configuration.

Optional rules available in the Property Manager catalog vary, based on the following:

- **What's included with the AMD product**. Plus, any additional rules related to services you've added to your contract.

- **Whether you're using NetStorage as your origin, or you have your own custom origin**. Some rules aren't available if you're using NetStorage as your origin server. When this is the case, it's noted in its description.

# [How do I add optional rules?](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-optal-rules#how-do-i-add-optional-rules)

Click **Add Rule** and select the desired rule template from the list. For example, select **Blank Rule Template** from the list and click **Insert Rule**. This template lets you manually set your match criteria and behaviors to suit a specific request type.

There are a lot of optional rules you can add to your property. So, it's outside the scope of this document to describe them all.

- Some that apply specifically to AMD are detailed in the *Optional features* category in this documentation. You can add this functionality in the Default Rule or in an optional rule, based on your match criteria requirements.

- Details on other optional rules can be found in the online help in the Property Manager Editor UI in ​Akamai Control Center​. Each rule template offers a description in the Add New Rule window. You can also add a rule, mouse over its panels, and click the individual ? help links for more information.

Adding and configuring behaviors to an optional rule follows the same process discussed in [Optional behaviors in the Default Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/optal-behs-default-rule).

# [Remember rule order precedence and match criteria](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-optal-rules#remember-rule-order-precedence-and-match-criteria)

One of the key benefits of additional rules is that you can set up specific match criteria that must be met in a request, unlike the "Default Rule" which applies to all requests. If you add a new rule, it's read first and applied *before* the Default Rule. Overall, the last rule displayed in the list is applied first, and all subsequent rules are applied, ending with the Default Rule.

For example, you could set up a new rule and apply match criteria to target a specific property hostname and add the Prefetching behavior. Only requests to that property hostname will use Prefetching. Plus, all of the behaviors you've set in the Default Rule would be also be applied. This is because its behaviors apply to all requests. A request to any other property hostnames configured in your property would skip this rule, and only use the behaviors set in the Default Rule.