# [Optional behaviors in the Default Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/optal-behs-default-rule#optional-behaviors-in-the-default-rule)

You can add more behaviors using the **Add Behavior** button.

These are behaviors outside of what's included automatically as mandatory or recommended behaviors in the Default Rule. Optional behaviors available in the Property Manager catalog vary, based on the following:

- **What's included with the AMD product**. Plus, any additional behaviors you've added to your contract.

- **Whether you're using NetStorage as your origin, or you have your own custom origin**. Some of the behaviors are not available if you're using NetStorage as your origin server. When this is the case, it's noted in its description.

# [How to add optional behaviors](https://techdocs.akamai.com/adaptive-media-delivery/docs/optal-behs-default-rule#how-to-add-optional-behaviors)

There are a lot of optional behaviors you can add to your property. Click **Add behavior** in the Default Rule to select from a catalog. For details on their setup, review these points:

- Several that apply specifically to AMD are detailed in the _Optional features_ category in this documentation.

- Information on other optional behaviors can be found in the online help in the Property Manager Editor UI in ​Akamai Control Center​. Add a behavior, mouse-over it, and click the ? help links.

# [Optional behaviors "best practice" optimized for AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/optal-behs-default-rule#optional-behaviors-best-practice-optimized-for-amd)

These are the behaviors that are automatically included in the Default Rule, in the background. You don't see them as an actual behavior in the rule. They've been optimized for best performance with AMD:

- **Allow All Methods on Parent Servers**
- **Cache HTTP Error Response**
- **Cache HTTP Redirects**
- **Caching**
- **Content Compression**
- **LDS (Log Request Details)**
- **Large File Optimization**
- **Remove Vary Header** (Set to "On")
- **Tiered Distribution**

You can optionally add any of these behaviors, but if you do, what you set in them overrides what Akamai considers best practices. This may negatively impact the delivery of your content. Ensure that you need a custom setting to meet your environmental needs before you do so. When you add one of these optimized behaviors, you'll see a warning message.