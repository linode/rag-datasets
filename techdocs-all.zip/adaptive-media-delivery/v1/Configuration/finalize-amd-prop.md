# [Finalize your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#finalize-your-amd-property)

Run through these required and optional processes to finish the set up of your AMD property.

# [Review errors and warnings](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#review-errors-and-warnings)

Once you've defined all Rules and Behaviors for your property, you need to address any noted conflicts or issues.

1. Review the settings in all Behaviors and ensure that they are set as desired.

2. Access the message center tab to review the messages there. Click the **up triangle** to display messages:

   - **Ensure that there are no errors**. Review any listed errors and resolve them in the applicable behaviors until **0 Errors** is displayed.

   - **Acknowledge all warnings**. This includes any behavior you may have customized outside of what's predefined as its best practice. If desired, perform any necessary actions to resolve a warning. Otherwise, click **Hide Message** to dismiss it.

3. Collapse the message center tab, using the **down triangle**.

4. Review all other settings for your AMD property and ensure they're set as required.

5. Scroll to the bottom of the page and click **Save**.

Here's an example of the message center tab, with all errors resolved, but multiple warnings displayed.

# [Player integration requirements](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#player-integration-requirements)

AMD is designed for use with standard media players, such as an Open Source Media Framework (OSMF) player, JWPlayer, Flowplayer, HLS.js, and DASH.js. For the most part, modifications to the player are not necessary to deliver content through AMD.

There are some requirements you should be aware of.

## [Do you need token authentication in your player?](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#do-you-need-token-authentication-in-your-player)

If you use token authentication to secure the links to your content, you may need to modify your player to support the token exchange that takes place between Akamai edge servers and your player. These changes vary depending on the format of the content you're serving. The requirements are the same for both live and on-demand delivery.

## [Are you using prepackaged streams?](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#are-you-using-prepackaged-streams)

This applies if you're delivering your streams from prepackaged files, as opposed to pre-segmented files. For example, if your content is comprised of contiguous fragmented MP4 files and not individual MP4 chunks, you'll need to append the `pkz=1` query parameter to the playback URL:

```
/manifest.f4m?pkz=1
```

 > Note: 
  If you're using prepackaged DASH content, follow what's covered for DASH (via DASH.js) in the previous table.

# [Update your origin server's configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#update-your-origin-servers-configuration)

If you're using your own custom origin to house your content for delivery, you may need to update it to work with your AMD property. For example, you might need to modify infrastructure settings such as session stickiness and load balancing.

 > Note: Are you using NetStorage?
  If you're using NetStorage as your origin server, the processes explained here _don't apply_.

## [Disable the origin server access control list (ACL)](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#disable-the-origin-server-access-control-list-acl)

If you have a client IP-based ACL on your origin servers, you need to disable it before beginning delivery of your content or application through the Akamai edge network. Once your application is delivered through the network, _your origin servers will no longer see the real client IP addresses and will block all requests_. If you need to maintain a client IP ACL, you can specify the list in your edge server configuration.

 > Note: 
  You can skip this if you don't have a client request ACL on your origin servers.

## [Use compatible load balancing](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#use-compatible-load-balancing)

Not all load-balancing algorithms are compatible with content delivery services. Incompatible systems include those based on client IP addresses, SSL session identifiers, or least-used connections to specific servers.

This is because more than one edge server can accept end-user requests in the same session and then forward them to the origin server. So, your origin server may see the different edge servers as different clients. In addition, your origin server will receive requests from a much smaller number of clients, once you switch to the edge network, as the requests are routed through Edge servers.

If you've been using load balancing based on client IP addresses or least-used connections, you need to change the load-balancing algorithm when using the edge network. Compatible algorithms are random or round-robin load distributions replicating session data across all origin servers.

## [Adjust your intrusion detection settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#adjust-your-intrusion-detection-settings)

Using edge network services may trigger aggressively configured intrusion detection systems. This happens because requests from many end users are aggregated through a smaller number of edge servers, potentially making it seem like a single end user is making multiple requests for the same content.

# [Other recommended tasks](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#other-recommended-tasks)

These tasks deal with monitoring and maintaining applications. They're recommended, but you don't have to complete them to implement your AMD property. We recommend you review these tasks and determine which ones best suit your needs.

## [Activate log delivery](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#activate-log-delivery)

Edge network logs can help you troubleshoot content and configuration problems. You can receive Edge server logs of all requests for your content in a standard log file format. These logs are aggregated from data from all Edge servers, sorted by time, and can be delivered with specified frequency to a specific email address, or sent to your FTP servers.

Log delivery is not enabled by default. If you need edge network logs, you need to activate it in ​Akamai Control Center​.

 > Warning: 
  It takes 24-48 hours for log delivery to start from the time you activate it. Keep this in mind when configuring log delivery. Make sure it's completely set up _before_ delivering any actual content from the Akamai edge network. Logs can't be collected retroactively.

1. Access [​Control Center​​](https://control.akamai.com/apps/home-page/#/home) and log in using a **User ID** and **Password** that have been configured for access to AMD.
2. Select ☰ > **COMMON SERVICES** > **Log Delivery**.
3. Type _Adaptive_ in the _Filter_ field to filter results in the table to only AMD. 
4. Locate the applicable **ID** (CP code) or **Object Name** associated with your instance of AMD. 
5. Click the **...** in the Action column and select **Start a log delivery** > **New**.
6. Follow the wizard to set up log delivery.

 > Note: Are you using NetStorage?
  If your edge network services include logs delivery via FTP to your NetStorage account, specify the NetStorage FTP upload account in the Log Delivery settings. The NetStorage account information is included in your service activation package. You can also look it up in ​Akamai Control Center​.
  When you use NetStorage for log delivery, it's important to manage the content. If you don't remove excess log files, you may see large overage charges as the files take up more and more space. You can remove the log files after you download them, or you can set up automatic purging rules through the NetStorage interface on ​Control Center​​.

### [Test log delivery](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#test-log-delivery)

Edge network logs are delivered in standard log formats, such as W3C Extended log format. But, if you're currently using your own server logs for reporting or data analysis, you should verify that edge network logs are fully compatible with your log processing application. Test the first log files you receive from the edge network through your regular log processing application or workflow, and adjust them if necessary.

### [Additional details on log delivery](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#additional-details-on-log-delivery)

For complete details on log delivery and its use, see the [Log Delivery Service documentation](https://techdocs.akamai.com/log-delivery/docs).

## [Create additional administrator accounts](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop#create-additional-administrator-accounts)

An administrator account for ​Akamai Control Center​ is provided to you in your account information after you initially provision AMD. As an administrator, you can create additional accounts with this, or lesser levels of access. Creating additional administrator-level accounts allows multiple people to log on and perform administrator-level tasks.

See the [Identity and Access Management documentation](https://techdocs.akamai.com/iam/docs) for instructions on adding new users.