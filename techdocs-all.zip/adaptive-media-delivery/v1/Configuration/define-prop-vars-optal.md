# [Define property variables (optional)](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-vars-optal#define-property-variables-optional)

Variable support gives you more control over your configuration. It's typically implemented for more complex properties.

The configuration of property variables isn't unique to AMD, and it's not required to set up your AMD property. See [Variable support](https://techdocs.akamai.com/property-mgr/docs/var-ov) in the Property Manager user documentation for more details. You can also discuss possible integration with your account team.