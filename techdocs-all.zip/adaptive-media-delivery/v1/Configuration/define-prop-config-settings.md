# [Define property configuration settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-config-settings#define-property-configuration-settings)

The Property Configuration Settings content panel contains the rules for your property. Rules consist of match criteria and behaviors. If a request meets the conditions in a rule's match criteria, the behaviors in that rule are applied.

When you select a **Rule**, its match criteria and behaviors are displayed. Click each rule to view and manage its settings.

# [Understand property rule and behavior logic](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-config-settings#understand-property-rule-and-behavior-logic)

Property Manager applies a specific logic with the application of rules and the behaviors they contain. When setting up rules, remember these points:

- **The Default Rule is required and applies to all requests**. However, if you set up the same behavior in an optional rule, and that rule's match criteria is met, _that_ behavior's settings are used, rather than what's in the Default Rule.

- **Rule logic "trickles down"**. More specific rule wins over a less specific one. In other words, child settings win over parent settings.

- **Several of the behaviors in the Default Rule are required**. You can't delete certain behaviors from the Default Rule, and you have to configure them. If you want certain requests to use different settings for these behaviors, you can include them in an optional rule and set up different match criteria for these requests.

For more details on how business rules execute, see [Property Configuration logic](https://techdocs.akamai.com/property-mgr/docs/config-best-practices).