# [Test your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#test-your-amd-property)

While it's not required, you should thoroughly test your AMD property on the Akamai edge network. By testing, you can make sure that playback functionality works properly.  

- If you've set anything incorrectly, you could break various functions on your site or application.

- Adaptive Media Delivery should increase the performance and availability of your streaming media. By testing, you set a baseline for increased performance, which may let you improve content delivery even more.

 > Note: 
  If you have existing testing procedures for application and content releases, you should also follow them when testing edge network content delivery.

# [1. Check your certificate](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#1-check-your-certificate)

When you set up your edge hostname in your AMD property, how did you secure the connection to it? Did you apply a custom certificate or set it up using a secure certificate hostname? Depending on how you did this, you'll need to gather some information.

## [The custom edge certificate](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#the-custom-edge-certificate)

This applies if you used Akamai's Certificate Provisioning System (CPS) to create a custom certificate for your property.

### [The certificate needs to be on staging](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#the-certificate-needs-to-be-on-staging)

By default, Akamai pushes a new custom certificate ("cert") to the production network to help speed up renewals. We recommended that you [push it to the staging network](https://techdocs.akamai.com/property-mgr/docs/prepare-your-edge-certificates#custom-certificates-with-cps) for testing. If you didn't do this, your cert may already be on the production network. If this is the case, you can't move it to staging until it's up for renewal. 

You can check the provisioning status of your certificate:

1. Access [Akamai Control Center](https://control.akamai.com), login with an admin-level user and go to **☰ > CDN > Certificates**.

2. Select the **Active** tab. Look for your certificate in the table based on the domain you included as the Common Name in your cert:

   - **You found it**. Your cert is live on production. You can't use it for testing.

   - **You didn't find it**. Your cert may not have been pushed to production yet. Continue to the next step.

3. Select the **In Progress** tab.

4. Locate your cert in this table, based on its **Common Name**. 

5. Check what's listed under In Progress:

   - **If you see _Yes_ under Always test on Staging before deployment**. Your certificate is deploying to the staging network. If you see  under Deploying to Staging, it's finished.

   - **If you see _No_ under Always test on Staging before deployment**. Continue to the next step.

6. Click **No** under **Always test on Staging before deployment**. 

7. Set Test Certificate to **Yes** and click **Submit**. When the cert is available on staging, the person set as the Administrator Contact for the cert will get an email.

 > Note: Is your custom cert already on production?
  You can [force early renewal](https://techdocs.akamai.com/cps/docs/force-early-renewal), or you can create and apply a new custom certificate. You'll need to follow the steps above to set up that certificate for testing.

## [The shared certificate hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#the-shared-certificate-hostname)

This is Akamai's quick method to configure a secure connection to our edge network. It applies Standard TLS security to the connection. Once you create this form of edge hostname, you'll need to use a fixed URL that's set in it to access your content through your AMD property.

You'll need the following:

- **The domain path to content on your origin server**. This is the URL that you can use to actually access your content on your origin server. For example, what your player uses now to access your media, outside of the Akamai network.

- **The full URL that's created for this edge hostname**. We cover how to get this value later on in the process.

# [2. Activate on staging](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#2-activate-on-staging)

To perform actual testing of your AMD property, you need to activate it on the Staging network in ​Akamai Control Center​.

1. If necessary, access the target property on [​Akamai Control Center​](https://control.akamai.com):

   a. Use the drop-down in the top right to select the ​Control Center​​ account you used to create the property.

   b. Go to ☰ > **CDN** > **Properties**.

   c. Enter the name of your property in the _Filter by Property or Hostname_ field.

   d. Click the **Property Name** to open it.

2. Click the **Version \<#>** for the property you want to activate.

3. Click the **Activate** tab. The **Activate** window opens.

4. Click **Activate v\<#> on Staging**. The **Staging Network Activation** window opens. Set these options:

   - **Fast Activation**. To speed up activation, make sure this is set to **On**.

   - **Validation Messages**. Error, warning, and information messages are carried over. If you still have any error messages (), you need to correct these. Click **Cancel** at the bottom of the window, then select the **Edit** tab. Click the **\<#> Errors \<#> Warnings \<#> Notes** tab at the bottom of the page. Review each **Error** message and resolve the issue. Click **Save** and then click the **Activate** tab to come back to this process.

   - **Override block of hostname moves**. Akamai applies a temporary block on a hostname that's been moved, in order to check its validity. Enabling this skips this temporary block. For example, this would apply if you've just moved your property from another account. Note that this can increase the number of hits to your origin server.

   - **Notes**. You can include a description of this version's activation.

   - **Notify via email**. This defaults to the email address set for the active ​Control Center​​  user. You can change it or add more. Separate multiple addresses with a comma (","). 

5. Click **Activating v\<#> on Staging**.

6. With Fast Activation, your property should be ready in the **Estimated Activation Time** listed. This can be as quick as three minutes. Now, you can:

   - **Monitor the Activate tab to track progress**. 

   - **Click Activation Details to review settings and information regarding the Property.**

   - **Wait for the confirmation email**. Any email set in **Notify via email** will get an email when the activation is complete.

 > Tip: These are just the basics
  To learn more about activation on Akamai networks, check out [How activation works](https://techdocs.akamai.com/property-mgr/docs/how-activation-works).

# [3. Point to edge servers](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#3-point-to-edge-servers)

Temporarily set up your local browser to target an edge server to access your property.

 > Warning: Do this every time you test
  Akamai's staging network is intended for testing. So, it can change over time. You should always perform the process here to resolve the IP address for your staging edge hostname, before you start a new round of testing. Don't use a past address, and don't use the same address for an extended period of time.

1. If necessary, access the target property on [​Akamai Control Center​](https://control.akamai.com):

   a. Use the drop-down in the top right to select the ​Control Center​​ account you used to create the property.

   b. Go to ☰ > **CDN** > **Properties**.

   c. Enter the name of your property in the _Filter by Property or Hostname_ field.

   d. Click the **Property Name** to open it.

2. Click the **Version \<#>** for the property you just activated on Staging.

3. In the **Property Hostnames** content panel, locate and make note of the **Edge Hostname**.

   **Custom certificate edge hostname example**:

   
   
   

   **Shared certificate hostname example**:

   
   
   

4. Append `-staging` to the edge hostname you noted.

   

5. Look up that hostname's IP address, and copy it to your clipboard.

   

6. Open your local `hosts` file in a text editor. 

   

 > Note: 
  See your operating system's user documentation for the default location of the Hosts file.

7. At the end of the hosts file, add an entry for the actual domain to your content that includes the edge hostname's IP address. For example, assume the IP address `1.23.45.78` was returned after looking up your edge hostname's address. Using the examples provided in this process, this entry could look like this: 

   - **Custom cert edge hostname**. `1.23.45.78 www.example.com`

   - **Shared cert edge hostname**. `1.23.45.78 example-com.akamaized.net`

8. Save and close your hosts file. All requests from your computer to your domain will now go to an edge server.

   - This applies to your local system, only.

   - To undo the redirection to the edge server, remove the new entry from your hosts file.

9. If you're using macOS X, run this command to flush your DNS cache: 

   ```
   sudo killall -HUP mDNSResponder
   ```

# [4. Install an extension](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#4-install-an-extension)

Akamai delivers Pragma headers with its content. To support these for testing, you need to install a modify headers extension on your browser.  

1. In your browser app, search for "modify header extension for [your browser]" to find the best one.

2. Follow the instructions in the extension to set up a header as follows:

   - **Header name**: Pragma

   - **Header value**:

     ```
     akamai-x-cache-on, akamai-x-cache-remote-on, akamai-x-check-cacheable, akamai-x-get-cache-key, akamai-x-get-extracted-values, akamai-x-get-nonces, akamai-x-get-true-cache-key, akamai-x-get-client-ip
     ```

3. Save and enable the header.

# [5. Check your connection](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#5-check-your-connection)

You need to verify that you've properly pointed your system to our edge servers to begin testing. When you make a request to the Akamai​, staging edge servers add the HTTP response header `X-Akamai-Staging`.

After your browser points to the staging edge servers, make a test request against the new property configuration on the staging network, and then check for the `X-Akamai-Staging` response header to see if the response is coming from the staging network.

1. Close all browser windows, reopen your browser, and clear the browser cache.

2. Access the Network functionality in your browser:

   - **Chrome**. Right-click (**Command+click** on macOS) in the browser window and select **Inspect**. Click the **Network** tab. (You may need to click **>>** to reveal it in the toolbar.)

   - **Edge**. Press **F12**, and then press **Ctrl+4** to open the Network utility.

   - **Firefox**. Press **Ctrl+Shift+I** (Windows) or **Command+Opt+E** (macOS). This takes you to the Network tool.

   - **Safari**. If necessary, select **Safari > Preferences**, click **Advanced**, then enable **Show Develop menu in menu bar**. Select **Developer > Show Web Inspector** and select the **Network** tab. 

3. Access the URL for your target content, based on what you included in your hosts file.

4. In the Network tab, click the first file listed.

5. Take a look at the response headers. If you see either of these entries, you know your request is going to the staging edge server:

   - `X-Akamai-Staging: ESSL`. This indicates you're on Akamai's Enhanced TLS network.

   - `X-Akamai-Staging: EdgeSuite`. This indicates you're on Akamai's Standard TLS network. (This applies for shared certificate hostnames, too.)

6. Check for the `X-Cache` entry.

   ```
   HTTP/1.1 200 OK
   Server: Apache/2.4.9 (Unix) OpenSSL/1.0.1-fips
   Last-Modified:Wed, 26 Jun 2022 18:28:37 GMT
   ETag: "1234-5a678b9012c34"
   Accept-Ranges: bytes
   Content-Length: 13162
   Content-Type: image/gif
   Cache-Control: max-age=603241
   Expires: Mon, 14 Apr 2022 16:48:38 GMT
   Date: Mon, 07 Apr 2022 17:04:37 GMT
   X-Akamai-Staging: EdgeSuite
   X-Cache: TCP_MEM_HIT from b128-48-122- 38.deploy.akamaitechnologies.com (AkamaiGHost/6.15.0.3-12528292) (-)
   X-Cache-Key: /L/12345/678910/1a/orign-example.com/images/samplepicture.gif?234567
   Connection: keep-alive
   ```

7. Use this table to interpret the results.

   

# [6. You're ready to test](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#6-youre-ready-to-test)

Test your content just as you would if you were testing it via your origin server.  

 > Warning: 
  When testing, use your actual domain for requests—_don't use its edge hostname_. Edge hostnames are applied automatically by your DNS to reroute requests to the Akamai edge network.

1. Check key functionality, such as logging in, playback, and so on.

2. Once you're satisfied that your property works, remove the hosts file entry you [added](#3-point-to-edge-servers) and then save it. 

3. On macOS 10.6 and later, flush your DNS cache again with the `dscacheutil -flushcache` command.

# [Check out Akamai Test Center](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#check-out-akamai-test-center)

If you'd rather not use the manual process we discuss above, you can access the Test Center interface in ​Control Center​​ to help with testing.

## [What is Test Center?](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop#what-is-test-center)

Test Center is a testing tool that checks the effect that configuration changes will have on your web property. It helps you ensure that your changes aren't behaving unexpectedly before you activate them in production. It helps prevent issues caused by misconfiguration and insufficient testing and increases your confidence in the safety and correctness of your changes. 

The application lets you run two types of tests:

- **Functional testing**. This lets you check if the configuration changes work as expected. 
- **Comparative testing**. This lets you compare the behavior of your hostnames between the current and new configurations.

It was designed as an addition to your existing tests and workflows, and not as their replacement. It's available as a user interface in [​Akamai Control Center​](https://techdocs.akamai.com/test-ctr/docs) and as an [API](https://techdocs.akamai.com/test-ctr/reference/api).