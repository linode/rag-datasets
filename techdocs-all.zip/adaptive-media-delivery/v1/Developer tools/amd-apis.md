# [AMD APIs](https://techdocs.akamai.com/adaptive-media-delivery/docs/amd-apis#amd-apis)
