# [AMD service-level agreement](https://techdocs.akamai.com/adaptive-media-delivery/docs/sla-amd#amd-service-level-agreement)

We maintain a service-level agreement (SLA) for Adaptive Media Delivery on ​Akamai Control Center​ .

1. Access [Control Center](https://control.akamai.com/).
1. Log in with an account that has access to create Adaptive Media Delivery properties.
1. Select ☰ > **SUPPORT** > **Download Center**.
1. In the Media Delivery category, select **Adaptive Media Delivery**.
1. Open **Service-level agreement**.
1. Click **Media content delivery service-level agreement.pdf** to download the SLA.