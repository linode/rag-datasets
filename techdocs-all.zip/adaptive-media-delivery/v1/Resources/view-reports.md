# [View reports for AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/view-reports#view-reports-for-amd)

You can monitor and identify key trends of your Adaptive Media Delivery (AMD) traffic.

 > Note: Media Delivery Reports has been decommissioned
  On 10/31/2023, Akamai decommissioned the legacy Media Delivery Reports user interface. As a result, some of the reports it offers are no longer available.
  The reports covered below replace several of these reports. Also, you can check out the [Delivery Reports Consolidation](https://techdocs.akamai.com/del-rpts-consolidation/docs/welcome) documentation for the affected reports and potential workarounds.

# [Use ​Akamai Control Center​](https://techdocs.akamai.com/adaptive-media-delivery/docs/view-reports#use-akamai-control-center)

Akamai offers easy-to-use interfaces via the Reporting tool in [​Control Center​​ ](https://control.akamai.com). 

1. Go to ☰ > **COMMON SERVICES** > **Traffic reports**.

2. Click the magnifying glass icon to expand the menu and list the available reports. 

3. Scroll down the list to the **Traffic Reports** and select any of the following:

   

 > Note: 
  Reports are available based on the services you use and your permissions in ​Control Center​​. See [How to use reports](https://techdocs.akamai.com/reporting/docs/how-use-rpts) for more details on using the **Reporting** tool.

# [Use the API](https://techdocs.akamai.com/adaptive-media-delivery/docs/view-reports#use-the-api)

Akamai offers the [Reporting API](https://techdocs.akamai.com/reporting/reference/api) that you can call to generate customized reports to meet your specific need.
