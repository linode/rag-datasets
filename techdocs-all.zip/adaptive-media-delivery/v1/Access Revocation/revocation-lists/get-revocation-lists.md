# [List revocation lists](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-revocation-lists#list-revocation-lists)
