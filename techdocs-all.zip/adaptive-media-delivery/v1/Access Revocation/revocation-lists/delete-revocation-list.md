# [Delete a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/docs/delete-revocation-list#delete-a-revocation-list)
