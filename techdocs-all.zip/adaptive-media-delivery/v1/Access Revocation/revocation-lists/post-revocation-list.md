# [Add a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/docs/post-revocation-list#add-a-revocation-list)
