# [Identifiers](https://techdocs.akamai.com/adaptive-media-delivery/docs/identifiers#identifiers)
