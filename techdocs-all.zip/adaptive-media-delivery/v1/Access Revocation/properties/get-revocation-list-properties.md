# [List revocation list ARL properties](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-revocation-list-properties#list-revocation-list-arl-properties)
