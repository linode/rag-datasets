# [Get a revocation list](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-revocation-list-meta#get-a-revocation-list)
