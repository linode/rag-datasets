# [Revoke tokens](https://techdocs.akamai.com/adaptive-media-delivery/docs/post-revocation-list-ids#revoke-tokens)
