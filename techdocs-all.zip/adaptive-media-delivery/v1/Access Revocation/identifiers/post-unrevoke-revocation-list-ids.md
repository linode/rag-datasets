# [Unrevoke tokens](https://techdocs.akamai.com/adaptive-media-delivery/docs/post-unrevoke-revocation-list-ids#unrevoke-tokens)
