# [Get an identifier](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-revocation-list-token#get-an-identifier)
