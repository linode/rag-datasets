# [List identifiers](https://techdocs.akamai.com/adaptive-media-delivery/docs/get-revocation-list-ids#list-identifiers)
