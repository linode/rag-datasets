# [Revocation lists](https://techdocs.akamai.com/adaptive-media-delivery/docs/revocation-lists#revocation-lists)
