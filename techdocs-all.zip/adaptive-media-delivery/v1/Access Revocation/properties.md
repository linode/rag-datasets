# [Properties](https://techdocs.akamai.com/adaptive-media-delivery/docs/properties#properties)
