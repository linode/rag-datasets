# [Auth Token 2.0 Verification](https://techdocs.akamai.com/adaptive-media-delivery/docs/auth-token-20-verification-amd#auth-token-20-verification)

Auth token verification (also referred to as "Token Auth") is the process of generating tokens, associating them with an authenticated user session, and then validating the request using these tokens to prevent unauthorized sharing of links to your Adaptive Media Delivery content.

 > Note: Segmented Media Protection is recommended
  Auth Token 2.0 is supported for use with AMD, but [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth) via the Segmented Media Protection behavior is the recommended method for this protection. It provides a higher level of security.
  Also, _you can't use both behaviors in the same rule_ in your AMD property. You can use them in separate rules that use different Match criteria.

We recommend that you add this behavior to your Adaptive Media Delivery property to protect your content.

# [Enable Token Auth](https://techdocs.akamai.com/adaptive-media-delivery/docs/auth-token-20-verification-amd#enable-token-auth)

Add the Auth Token 2.0 Verification behavior to the applicable rule in your property configuration, and set the options as necessary.

1. Click **Add Behavior**.

2. In the _Search available behaviors_ field, type "Auth" and select **Auth Token 2.0 Verification**.

3. Click **Insert Behavior**.

4. Set the options in the behavior:

Option | Required? | Description |  **Token Location**  |  ✓  |  Select where the token is located in an incoming HTTP request from the client. Your origin server needs to generate this key and includes it in the applicable location (as a Query String, a Cookie or in a Request Header).  |  **Token Name**  |  ✓  |  Input the value that will be used as the "token_name" in the token. You need to ensure that the value you input here is used when the token is generated.   
 ---|---|---  
 **Encryption key**  |  ✓  |  Input a hexadecimal value, comprised of an even number of characters. For example: `eee7e9157f81b2f6d471bf2c`. You can also click the cycle button () to automatically generate a proper value. This is the key value you need to use to generate the token for use with your content. Make note of this value for use later in this process.   
 **Action**  |  ✓  |  Select the desired action to take: \- **Verify and Deny**. If tokens aren't verified as "matching", a verification error occurs, and the request is denied. \- **Just Verify**. This sets the verification result in the context and specific actions can be implemented in sub-rules using the **Token Verification Result** match.   
 **Show Advanced Options**  |  X  |  You can optionally set this slider to **On** to reveal more options.   
 **Encryption Algorithm**  |  X  |  To access this option, set the Show Advanced Options slider to **On**." This is the algorithm you're using for the HMAC (Hashed Message Authentication Code) to generate the token. This setting needs to match the method chosen in the token generation code. > Warning: The algorithms from most to least secure are SHA256, SHA1, and MD5. You should not change the default of SHA256 unless you have a specific reason to do so (for example, if you have speed requirements or computational limitations on generating tokens at the origin).   
 **Escape token inputs**  |  X  |  To access this option, set the Show Advanced Options slider to **On**." Specify whether the token inputs are URL escaped before generating the token. By default, inputs are URL escaped. This setting must match the setting used in your token generation code.   
 **Ignore query string**  |  X  |  To access this option, set the Show Advanced Options slider to **On**. Specify whether the query string is included in the URL input into the token. By default, the query string is included. This setting must match the setting used in the token generation code.   
 **Transition key**  |  X  |  To access this option, set the Show Advanced Options slider to _On_." Input a second Encryption key to serve as a backup “trusted shared secret.” You either manually input a hexadecimal value, comprised of an even number of characters or auto-generate one using the cycle button (). If the token provided by the user is not valid based on the primary Encryption key, DD checks the token using this key. This ensures that users are not denied access if you're in the process of rotating the primary key. This assumes that you've transitioned to generating your tokens with the Transition Key for some period of time, _before_ updating the Encryption key value here.   
 **Salt**  |  X  |  To access this option, set the Show Advanced Options slider to "**On**." Input a value to serve as an additional "secret" that will be added to the token generation to strengthen the security of the token. You can either manually input a hexadecimal value, comprised of an even number of characters or auto-generate one using the cycle button (). 

# [Generate the access token](https://techdocs.akamai.com/adaptive-media-delivery/docs/auth-token-20-verification-amd#generate-the-access-token)

You need to generate a one-time access token and apply it to content you want to protect. The token is a delimited list of string fields, with an HMAC to prevent tampering with the strings. Each field consists of a value that is verified by Akamai when a request is made. Among other things, fields in the token include the following:

- **A token name** (`token_name`). _Required_ - This must be the same value you input for the **Token Name** setting in the [Auth Token 2.0 Verification behavior](#enable-token-auth) for your property configuration.

- **Start/end times** (`start_time`, `end_time`). _Required_ - Use these to set a time to live for the token.

- **A session identifier** (`session_id`/`sessionId`). _Optional_ - Include this as a unique identifier for a single access session. Create a session identifier using printable ascii characters and ensure that it's no larger than 36 bytes in size.

- **A Key** (`key`). `Required` - The secret used to generate the token. This is the value you set as the **Encryption key** in the [Auth Token 2.0 Verification behavior](#enable-token-auth) for your property configuration. This can also be the **Transition Key**, if applicable, or the **Encryption key + Salt/Transition key + Salt** if you've set up these optional values in the property.

 > Warning: 
  We recommend against including the IP address field in your tokens to tie the token to a specific IP address—unless all requests will only come from a specific address. This can break delivery in a property if requests come from other IP addresses or if you're using an IPv4+IPv6 dual-stacked environment.

We offer Token Auth software development kits (SDK), that you can use to generate this token. They are available for multiple programming languages, and they account for all required and optional fields.

- [C Sharp ("C#")](https://github.com/BookBeat/EdgeAuth-Token-CSharp)
- [Golang ("Go")](https://github.com/mobilerider/EdgeAuth-Token-Golang)
- [Java](https://github.com/akamai/EdgeAuth-Token-Java)
- [NodeJS](https://github.com/akamai/EdgeAuth-Token-Node)
- [Python](https://github.com/akamai/EdgeAuth-Token-Python)
- [Ruby](https://github.com/akamai/EdgeAuth-Token-Ruby)

See the README section on these pages for details on how to use that SDK.

# [Apply the token](https://techdocs.akamai.com/adaptive-media-delivery/docs/auth-token-20-verification-amd#apply-the-token)

The completed token needs to be attached as a query string parameter, cookie, or request header, to the URL for your target content. You need to apply it, based on how you've set the **Token Location** in the [Auth Token 2.0 Verification behavior](#enable-token-auth) for this property configuration.

Ideally, you should set up your origin server to dynamically generate these tokens for each client request for the content. This way, the IP address (`ip`) could be included as a parameter, and access to the content would be restricted to that single, authorized user.

# [Standard token auth requires cookie support (Apple, HLS)](https://techdocs.akamai.com/adaptive-media-delivery/docs/auth-token-20-verification-amd#standard-token-auth-requires-cookie-support-apple-hls)

Token authentication generally requires the use of browser cookies to deliver a signed token as a step in the authorization process. This can affect devices and browsers that don't support cookie use (typically Apple Safari and HLS devices).

Your end users can manually enable cookies. Safari end-users must enable cookies. In Safari, many end users will need to set **Preferences > Security > Accept Cookies: Always**. With this set, no additional interaction is required, and token authorization will work as designed.