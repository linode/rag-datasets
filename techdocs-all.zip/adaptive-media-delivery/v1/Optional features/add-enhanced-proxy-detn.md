# [Enhanced Proxy Detection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-enhanced-proxy-detn#enhanced-proxy-detection)

Enhanced Proxy Detection (EPD) lets you use the GeoGuard service provided by our data provider, GeoComply to apply proxy detection and location spoofing protection.

Add the Enhanced Proxy Detection with GeoGuard behavior to your property to identify requests for your content that have been redirected from an unwanted source via a proxy. You can then allow, deny, or redirect these requests.

# [Use Best Practices mode](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-enhanced-proxy-detn#use-best-practices-mode)

This is the Configuration Mode Akamai recommends. Select it to automatically apply the primary categories GeoGuard identifies as essential for proxy detection, then set the desired Action.

# [Customize using Advanced mode](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-enhanced-proxy-detn#customize-using-advanced-mode)

Set this as your Configuration Mode if you're looking to customize GeoGuard categories individually to meet your specific needs, and set a specific Action for each.

> Warning: Make sure you have the \. GeoGuard maintains a list of several \

# [How to set up EPD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-enhanced-proxy-detn#how-to-set-up-epd)

EPD is available for use with several Akamai products, and its configuration is the same for all of them. See the [Property Manager documentation](https://techdocs.akamai.com/property-mgr/docs/enhanced-proxy-detn-geoguard) for full usage instructions.
