# [Protect connections with mTLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#protect-connections-with-mtls)

 > Note: Limited Availability
  This feature is only available to select customers. Talk to your account team about eligibility.

The transport layer security (TLS) protocol is used to secure connections between a client and server. With a common TLS-secured web connection, only the client validates the identity of the server before allowing communications. With mutual TLS-secured (mTLS) web connections, both the client _and_ the server validate the identity of one another, before allowing communication between the two. The client and server each present a TLS identity certificate to the other, with each side verifying the authenticity, during what's called the "TLS handshake”. Once verified, the identity information is used to authorize additional communication requests between the two. 

![](https://techdocs.akamai.com/ion/img/ion-mtls-flow-v2.png)

# [1. Create a client CA set](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#1-create-a-client-ca-set)

A certificate authority (CA) set is a collection of certificates that you use to verify the authenticity of clients requesting access to your content on the Akamai​ edge network. It's specifically used to establish mTLS-authenticated connections. You'll use Akamai's mTLS Edge Truststore application for this.

## [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#before-you-begin)

You need to create the certificates you want to use for the client-to-Akamai edge network connection in the mTLS transaction. You can use any trusted certificate authority (Let's Encrypt, DigiCert) to generate these certificates. When you add a certificate to a CA set, the mTLS Edge Truststore validates it against these requirements:

- It needs to be a correctly-formed x509 (PEM-encoded) certificate.

- It has valid x509 CA bits set.

- It's within its validity period. (Make sure it's not near expiration.)

- It's a self-signed root certificate or an intermediate certificate.

- It uses the SHA-256 signature hash algorithm or better.

## [Create a new CA set](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#create-a-new-ca-set)

With your certificates ready, create a CA set to add them for use with mTLS:

1. Access [Akamai Control Center](https://control.akamai.com).

2. Select ☰ > **CDN** > **mTLS Edge Truststore**.

3. Click **New CA certificate set**.

![](https://techdocs.akamai.com/ion/img/ion-ca-set-create-v1.png)

4. Give your CA set a name and optionally, enter a description. 

 > Note: 
  Make sure you're happy with the name you choose for your CA set. Once created, you can't change it. Also, make note of the name. You'll need it later.

5. Click **Submit**. The CA set appears under **CA Certificate sets**.

6. With your new set selected, click **+ Create Version 1** to create the first version of your CA set. 

![](https://techdocs.akamai.com/ion/img/ion-ca-set-version-v1.png)

7. Click **Add certificates** and select a method to add a certificate to your set:

   - **Drag and drop**. Pick a file from your local machine and drag it to the _Paste certificate PEM(s) here_ field. You can select multiple certificate files to drag and drop.

   - **Click browse**. Navigate to and select the certificate file on your local machine. You can multi-select more than one certificate file to add.

   - **Copy/Paste**. Open the PEM-encoded certificate in a text editor and copy its entire contents. Paste into the _Paste certificate PEM(s) here_ field.

8. Click **Validate and add to version**. If you see an error message, check that your certificates meet the [validation requirements](#before-you-begin) and re-add them.

9. If necessary, repeat steps 7-8 to add more certificates.

10. Leave all other options at their default setting and click **Create version**.

## [Activate your CA set](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#activate-your-ca-set)

Get your new CA set activated on the Akamai networks. It needs to be active on the same network where the server's mTLS-enabled edge certificate is active. The staging network is used for testing and production network is used to go live.

1. in the mTLS Edge Truststore, select the CA set you just created.

2. Select the CA set version to use.

3. Click _..._ under Actions and select **Activate**.

4. Review your CA set's details to make sure everything is OK.

5. Click the **Activate version...** button for the applicable network, or click both.

 > Note: Activation time
  This varies based on the Akamai network:
  - **Staging**. Up to 2 hours.
  - **Production**. Up to 30 minutes.

# [2. Set up a server certificate](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#2-set-up-a-server-certificate)

This is the edge certificate your property shares with the client for mTLS support. You need to enable mTLS support in this certificate and then bind it to your CA set with ​Akamai's Certificate Provisioning System (CPS). 

1. Access [Akamai Control Center](https://control.akamai.com).

2. Select ☰ > **CDN** > **Certificates**.

3. Find your certificate based on its Common name and click **...** under Actions and select **View and edit deployment settings**.

 > Note: 
  If necessary, [create a new certificate](https://techdocs.akamai.com/cps/docs/create-edit-certs#create-a-new-certificate) using your domain. Make sure it's the same type (domain validated, organization validated, or extended validation) and format (standard TLS or enhanced TLS) you used for the client certificates in your CA set.

4. In 4 - Mutual Authentication, click **Edit** and set these options:

   - **Certificate Set**. Select the CA set you [created and activated](#create-a-new-ca-set).

   - **OCSP**. Enable this if the certificates you've included in your CA set use the online certificate support protocol (OCSP). OCSP can determine the X.509 certificate revocation status during the TLS handshake.

   - **Send CA list to client**. With this enabled, the edge servers will also send the names of the CA sets you've included in your edge certificate back to the requesting client.

![](https://techdocs.akamai.com/ion/img/ion-ca-set-add-in-cps-v1.png)

5. Click ** Submit** to update your edge certificate.

# [3. Enforce mTLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#3-enforce-mtls)

In the next phase of the process, update your property configuration in Property Manager to apply support for mTLS.

## [Apply basic support](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#apply-basic-support)

Here, we'll apply a simple rule to deny requests to a specific hostname, if they don't properly apply mTLS.

1. [Add a secure hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-hn#set-up-a-secure-property-hostname) to your property. Configure it to use the edge certificate where you've enabled mTLS for the server.

2. In the Property Configurations settings, click **+ Rules**.

3. The Blank Rule Template is default selected. Click _New Rule_ and give the rule an easy-to-recognize name, like **Enforce mTLS**.

4. Click **Insert Rule**.

5. In the Criteria options, click **+ Match**. The match criterion defaults to **Hostname > is one of**. 

6. In the empty field, enter the secure hostname you added.

7. In the Behaviors options, click **+ Behavior**.

8. Type `enforce` in the _Search available..._ field, select the **Enforce mTLS settings** behavior, and click **Insert Behavior**.

9. Configure the options in this behavior:

Option | Description |  **Enforce certificate authority sets**  |  _**Enable this**_. Your property will validate that the settings in this behavior apply.   
 ---|---  
 **Certificate authority sets**  |  Select the CA sets you [created](#create-a-new-ca-set) with Akamai's mTLS Edge Truststore, and [bound](#2-set-up-a-server-certificate) to your edge certificate in CPS.   
 **OCSP Status**  |  Enable this if the certificates you're using in your CA set (for client requests) and your edge certificates in CPS (for the server response) use the online certificate support protocol (OCSP). OCSP can determine the X.509 certificate revocation status during the TLS handshake.   
 **Deny request**  |  **_Enable this_**. Any request for the specified hostname that doesn't match the settings you've applied in this behavior will be denied. A request doesn't match if: \- The CA sets you've named here aren't bound to the edge certificate you've included in your secure hostname. \- The OCSP setting in your edge certificate doesn't match what you've set here. (For example, if it's disabled here, but enabled in your edge certificate, the request would be denied.) If a request matches on both, it's allowed. 

![](https://techdocs.akamai.com/property-manager/img/pm-mtls-enforce-mtls-basic-v1.png)

## [Apply custom handling](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#apply-custom-handling)

Here, we'll apply a collection of rules: a parent rule to enforce mTLS settings, and two nested child rules to apply custom handling for mismatched requests. Here's what you can expect to achieve with this:

- **Successful requests passthrough client certificate information**. A header will be sent to your origin server that contains details from the client's mTLS certificate. This lets you establish transitive trust between the client and your origin server.

- **Special handling for requests that don't match**. A request that doesn't match what you set will still be allowed. However, information will be included in the [Log Delivery Service](https://techdocs.akamai.com/log-delivery/docs) report for analysis.

### [1. Add Enforce mTLS settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#1-add-enforce-mtls-settings)

Start by adding a new parent rule to handle requests for mTLS.

1. Follow steps 1 - 8 in [Apply basic support](#apply-basic-support).

2. Configure the options in the Enforce mTLS settings behavior:

Option | Description |  **Enforce certificate authority sets**  |  _**Enable this**_. Your property will validate that the settings in this behavior apply.   
 ---|---  
 **Certificate authority sets**  |  Select the CA sets you [created](#create-a-new-ca-set) with Akamai's mTLS Edge Truststore, and [bound](#2-set-up-a-server-certificate) to your edge certificate in CPS.   
 **OCSP Status**  |  Enable this if the certificates you're using in your CA set (for client requests) and your edge certificates in CPS (for the server response) use the online certificate support protocol (OCSP). OCSP can determine the X.509 certificate revocation status during the TLS handshake.   
 **Deny request**  |  _**Disable this**_. Any request that matches the settings you've applied in this behavior will be allowed. A request that _doesn't match_ the settings will be allowed, too. But, you'll incorporate custom handling for these requests, through the other rules in the behavior. A request doesn't match settings if either of the following apply: \- The CA sets you've named here aren't bound to the edge certificate you've included in your secure hostname. \- The OCSP setting in your edge certificate doesn't match what you've set here. (For example, if it's disabled here, but enabled in your edge certificate, the request wouldn't match.) 

![](https://techdocs.akamai.com/property-manager/img/pm-mtls-enforce-mtls-custom-v1.png)

### [2. Add Client Certificate Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#2-add-client-certificate-authentication)

Next, add a child rule that forwards client certificate details to your origin server as headers. You can configure your origin server to trust the headers, to enable transitive trust.

1. In the Property Configurations settings, click **+ Rules**.

2. The Blank Rule Template is default selected. Click the _New Rule_ field and give it an easy-to-recognize name, like **Client cert auth**.

3. Click **Insert Rule**. Your new rule is added to the bottom of the tree.

4. Click the handle () for the new rule entry and drag it below your **Enforce mTLS** rule to nest it as a child rule.

![](https://techdocs.akamai.com/property-manager/img/pm-mtls-nested-rule-v1.png)

5. Click the rule to open it.

6. In the Criteria options, click **+ Match**. Set the If options to:

   - **Client certificate**

   - **Provided**. Enabled.

   - **Valid**. The associated rule will only be applied if the client's mTLS certificate is valid.

7. In the Behaviors options, click **+ Behavior**.

8. Type `client cert` in the _Search available..._ field, select the **Client Certificate Authentication** behavior, and click **Insert Behavior**.

9. Configure the options in this behavior:

   Option | Description |  **Enable**  |  **_Enable this_**. Your property builds Client-Auth HTTP headers using information from the client to server (edge network) mTLS handshake and sends them to your origin server. You can configure your origin server to acknowledge these headers to enable transitive trust between itself and the requesting client.   
 ---|---  
 **Complete client certificate**  |  When Akamai builds the `Client-to-Edge-HTTP-Auth` header, it needs to include some form of the client's x.509 certificate. \- **On**. This includes the complete client certificate, in its binary (DER) format. DER-formatted certificates leave out the "BEGIN CERTIFICATE/END CERTIFICATE" statements and typically use the ".der" extension. \- **Off**. Select the individual **Client certificate attributes** to include.   
 **Client certificate attributes**  |  With Complete client certificate set to **Off**, select from the list of certificate attributes to include them in the `Client-to-Edge-HTTP-Auth` header. \- **Client certificate subject**. The distinguished name of the client certificate's public key. \- **Client certificate common name (CN)**. The common name (CN) that's been set in the client certificate. \- **Client certificate SHA-256 fingerprint**. An SHA-256 encrypted fingerprint of the client certificate. \- **Client certificate issuer**. The distinguished name of the entity that issued the certificate.   
 **Certificate validation status**  |  **_Enable this_**. The current validation status of the client certificate in the `Client-to-Edge-HTTP-Auth` header. Configure your origin server to acknowledge the validity before it establishes trust—trust will only be established if the client certificate is currently valid. 

![](https://techdocs.akamai.com/property-manager/img/pm-mtls-client-cert-auth-custom-v2.png)

### [3. Add Logging](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#3-add-logging)

Finally, we'll add a second child rule that generates log data for mismatched mTLS certificate requests.

1. In the Property Configurations settings, click **+ Rules**.

2. The Blank Rule Template is default selected. Click the _New Rule_ field and give it an easy-to-recognize name, like **Log invalid certs**.

3. Click **Insert Rule**. Your new rule is added to the bottom of the tree.

4. Click the handle () for the rule and drag it below your **Enforce mTLS** rule to nest it as a child rule.

![](https://techdocs.akamai.com/property-manager/img/pm-mtls-nested-rule-2-v1.png)

5. Click the rule to open it.

6. In the Criteria options, click **+ Match**. Set the If options to:

   - **Client certificate**

   - **Provided**. Enabled.

   - **Invalid**

   - **Enforce mTLS settings results**. Enabled. 

   > > Note: 
   > 
   > Ensure that [Deny request](#1-add-enforce-mtls-settings) in the **Enforce mTLS settings** behavior in the parent rule is _disabled_.

7. In the Behaviors options, click **+ Behavior**.

8. Type `log custom` in the _Search available..._ field, select the **Log Custom Details** behavior, and click **Insert Behavior**.

9. Configure the options in this behavior:

   Option | Description |  **Include Custom Log Field**  |  **_Enable this_** to include what's set in the Custom Log Field in the [Log Delivery Service](https://techdocs.akamai.com/log-delivery/docs) report.   
 ---|---  
 **Custom Log Field**  |  Specify the additional data field you want appended to each log line. You can add something like "invalid_mTLS" to make it easy to recognize log entries. 

![](https://techdocs.akamai.com/property-manager/img/pm-mtls-log-custom-details-v2.png)

# [Caveats and known issues](https://techdocs.akamai.com/adaptive-media-delivery/docs/protect-connections-with-mtls#caveats-and-known-issues)

Review what's here before setting up this support:

Issue | Detail |  **Changes aren't automatically applied**  |  If you make an update to your CA set in the mTLS Edge Truststore, ensure you make the applicable changes to your property here in Property Manager, and to any certificates in the Certificate Provisioning System (CPS). For example, if you remove a CA set from the mTLS Edge Truststore, you also need to unbind the CA set from the certificate in CPS _and_ remove the CA Set from your property here in the Enforce mTLS settings behavior. If you don’t, you could see disablement of service for requests for your property.   
 ---|---  
 **TLS 1.3 doesn't support renegotiation**  |  If you need to use client certificates after the TLS handshake via renegotiation, you'll need to use a legacy version. This is because TLS 1.3 doesn't support renegotiation. For example, if you're using mTLS and you're restricting requests to certain folders, based on a URL path in the request—rather than all content on your origin server—a TLS renegotiation may be triggered. Connections using TLS 1.3 don't support renegotiation because it's a potential cyber threat. The renegotiation is just one more point in the transaction that a hacker can exploit.   
 **Certificates are subject to regular revocation**  |  Based on the type of certificate you're using, the certificate authority that validates them will revoke them after a set amount of time. (For example a domain validated certificate has a life cycle of 90 days.) Akamai edge servers check a certificate's revocation status through OCSP. As a best practice, enable OCSP in your client certificates and your edge certificate for your server. Then, enable the **OCSP Status** option when configuring the Enforce mTLS settings behavior. Many web browsers don't check the revocation status for certificates via OCSP, but this doesn't affect the mTLS use cases for certificates.   
 **Use SHA-256 encryption**  |  As a best practice, all certificates you use for mTLS should have their certificate authority signature component encrypted using _at least_ SHA-256 encryption. While the mTLS Edge Truststore application offers an option to support SHA-1 level encrypted signatures, SHA-256 offers better protection. _All mTLS certificates need to use the same level of signature encryption._   
 **SSLv3 isn't supported**  |  Any certificate you use for mTLS can't have any of its slots configured to use SSLv3. This is an antiquated protocol that is supported in some legacy environments.   
 **The shared certificate isn't supported**  |  You can't configure an edge hostname and secure it with Akamai's shared certificate. This format doesn't support mTLS. 