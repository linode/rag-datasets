# [Common Media Client Data](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#common-media-client-data)

An end user's media player understands playback behavior better than a content delivery network (CDN) can from its limited server-side data. So, we offer support for Common Media Client Data (CMCD). This is an open specification created by the Consumer Technology Association. A media player can use it to send its expanded playback information to Akamai (and other CDNs). You can use it for multiple purposes: 

- **Data can be used for segment prefetching**. Your media player can include prefetching "hints" in CMCD metadata. This is supported for content that's segmented into individual objects, as well as byte ranges for prefetching parts of much larger media objects.
- **Data is stored in logs for troubleshooting**. More data = more help fixing problems Akamai​ customer support can quickly access this log data to help reduce troubleshooting time.

There are a few things you need to do to enable support for CMCD.

# [1. Send CMCD data from the client](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#1-send-cmcd-data-from-the-client)

You'll want to set up your media player to send CMCD data from a requesting client. Data can be sent to ​Akamai using either of these methods:

- **As a custom HTTP request header**.

- **As an HTTP query argument**.

Guidelines are laid out in the [CMCD specification](https://cdn.cta.tech/cta/media/media/resources/standards/pdfs/cta-5004-final.pdf). Look to it for the latest recommendations on transmitting information in your requests.

 > Note: 
  A single request shouldn't include both CMCD headers and query arguments. If one does, ​Akamai ignores the query argument.

## [Prefetching requirements](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#prefetching-requirements)

If you'd like to support segment prefetching, the CMCD data sent by your player needs to include at least these keys:

Key | Description |  **Buffer length** (`bl`)  |  This is the buffer length for your player. AMD uses `bl` parameter feedback to ensure effective prefetching based on the momentary buffer fill grade. If the `bl` is exceeded, CMCD prefetching is disabled for client players, leaving them with a comfortable amount of buffered content.   
 ---|---  
 **Next object request** (`nor`), or **Next range request** (`nrr`)  |  Depending on how your player is requesting your segmented config, you need to include one of these keys. A single prefetch request can’t include both. \- `nor`. This is the relative path to the next object. Include this if you store your media segments as individual objects. AMD constructs the prefetch URL for a segment that's relative to the requested segment. These points apply to CMCD prefetch requests with the `nor` key: \- URL backtracking is not supported. \- The extensions in the URL sent by client player that initiates the prefetch and the `nor` prefetch URL need to be the same. \- Prefetch is applied only for HLS and DASH URLs. \- `nrr`. This applies if the next request will be a partial object request. Its string designates the byte range to be requested. You'd include this if the target media is stored in one large contiguous object and byte-range requests are used to get individual segments.  > Note: These points apply to the use of partial object caching and prefetching: \- **The minimum object size for partial object caching is 10 MB**. Anything smaller and the entire object will be prefetched, which defeats the purpose of prefetching. \- **There is a 10-fragment limit for prefetching**. If the byte range in your request exceeds this, prefetching won't be applied. 

See the CMCD specification for proper instructions on including these values in a request from your player. 

## [CORS-restricted clients and CMCD data](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#cors-restricted-clients-and-cmcd-data)

A CORS-restricted client (such as a web application running inside a browser) has to make a preflight OPTIONS request against a CDN before it can request an object that includes custom CMCD headers. So, the HTTP query argument method is recommended for browser clients, while the custom HTTP request header method is recommended for all other clients.

# [2. Set up your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#2-set-up-your-amd-property)

Make sure your property is set up to receive CMCD data, based on how the client is sending it.

## [Use custom HTTP request headers](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#use-custom-http-request-headers)

You can incorporate support for CMCD headers in multiple ways.

Method | Description |  **Create a new Akamai property**  |  If this is a new property, support for CMCD is automatically added to the [Default CORS Policy Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/default-cors-policy-rule). The `CMCD-Request`, `CMCD-Object`, `CMCD-Status`, and `CMCD-Session` request headers are included in the New Header Value field for the **Modify Outgoing Response** behavior, that's set up for **Access-Control-Allow-Headers**.  ![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-cmcd-modify-outgoing-hdrs-v1.png)  
 ---|---  
 **Create a new version of an existing Akamai property**  |  If the property contains the **Modify Outgoing Response Header** behavior, either standalone or as part of the Default CORS Policy Rule, ​Akamai​ will automatically add the `CMCD-Request`, `CMCD-Object`, `CMCD-Status`, and `CMCD-Session` request headers if the following apply: \- **Action** is set to **Modify** or **Add**. \- **Select Header Name** is set to **Access-Control-Allow-Headers**. \- **New Header Value** is _not_ set to `*`. This is a wildcard indicating all headers.   
 **Add a separate instance of the Modify Outgoing Response Header behavior**  |  If you're not employing the **Default CORS Policy** rule, you can include the **Modify Outgoing Response Header** behavior in another rule. If this is the case, this behavior's settings need to be set as follows: \- **Action**. Set this to **Modify** or **Add**. The former will _replace_ any **Access-Control-Allow-Headers** in a request with what's set in **New Header Value**. The former will _add_ what's set there to any **Access-Control-Allow-Headers** received in a request. \- **Select Header Name**. Set this to **Access-Control-Allow-Headers**. \- **New Header Value**. Enter the CMCD headers: `CMCD-Request`, `CMCD-Object`, `CMCD-Status`, and `CMCD-Session`. 

## [Use query arguments](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#use-query-arguments)

If you’d prefer to use query arguments, you need to do a couple of things.

Task | Description |  **Set the Cache Key Query Parameters behavior**  |  You need to be sure that CMCD query arguments are not cached. CMCD data changes with each request. Caching these arguments will increase the load on your origin server and affect performance. Make sure that the **Cache Key Query Parameters** behavior in your delivery property is set up using either of these methods: \- **Exclude all parameters (Recommended)**. This is the default setting for this behavior in a new ​Control Center​​ property.  ![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-cmcd-query-v1.png) \- **Include only specified parameters**. If you need to cache some of your query arguments, set **Behavior** to this setting and set **Parameters** to only the query arguments you need cached. _Ensure that all CMCD-related query arguments are left out_.   
 ---|---  
 **Avoid CMCD headers**  |  Ensure that requests from the player don't include CMCD headers, because they'll take precedence. 

## [Add CMCD segment prefetch support](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#add-cmcd-segment-prefetch-support)

If you want to include this support, add the Common Media Client Data support behavior to your AMD property and set it to "**On**."

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-cmcd-segment-prefetch-v1.png)

 > Note: 
  You need to add the behavior to the same rule tree where you configured other settings for CMCD support:
  - **The same rule**. Its match criterion needs to be met in a request to apply all of the CMCD-specific settings you defined.
  - **A child rule**. The parent-level rule contains settings to apply CMCD support via headers or query strings. The child rule can be set to have its own unique match criterion so that only those requests apply segment prefetching.

## [Add CMCD log data support](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#add-cmcd-log-data-support)

There's nothing more you need to do to support CMCD data gathering in logs for troubleshooting. Once you've [configured your player](#1-send-cmcd-data-from-the-client) and [your AMD property](#2-set-up-your-amd-property), the data is gathered automatically.

# [3. Test your setup](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#3-test-your-setup)

Ensure your player supports CMCD and thoroughly test your configuration on the staging network. Verify interactions between your player and origin server _before_ fully enabling your property on the production network.

# [Caveats and known issues](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd#caveats-and-known-issues)

Review these points before adding CMCD to your property:

Issue | Detail |  **CMCD prefetching takes precedence**  |  If you've set up [Origin-assist prefetch](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch), CMCD prefetching will override it.   
 ---|---  
 **CMCD prefetching may significantly increase log sizes**  |  Log entries can increase from 300 bytes in size, up to 512. Take this into consideration when gathering and storing log data. For example, if you're using Akamai's [Log Delivery Service](https://techdocs.akamai.com/log-delivery/docs) and externally storing logs.   
 **Requests for large `nor` URL segments can increase traffic load**  |  If your player is requesting segmented content using `nor` (the relative path to the object), and the object is greater than 1 MB in size, you may see an increase in traffic to your origin server. See [Prefetching requirements](#prefetching-requirements) for more information on `nor`.   
 **Custom prefetch solutions may create issues**  |  If you have a custom solution in place, for example, through advanced metadata, and you apply CMCD prefetching, this can lead to duplicate prefetch requests. This can create a higher load on your origin and slow delivery. Talk to your Akamai account team if you have a custom configuration.   
 **CMCD prefetches can amplify a DOS attack**  |  This can happen if prefetching inadvertently triggers a prefetch of a much larger object. For example, if a proper range isn't specified, a byte range request could request a full VOD asset that's supposed to be segmented. Make sure your player is properly requesting byte ranges to avoid this.   
 **CMCD prefetching isn't supported with Media Encryption for DASH**  |  N/A   
 **Akamai only supports a subset of CMCD keys**  |  These keys can be included in a request, but they'll be ignored: \- `sid` (session identifier) \- `cid` (content identifier) \- `d` (duration) \- `pr` (playback rate) \- `sf` (stream format) \- `st` (stream type) \- `dl` (deadline) \- `custom` (custom variables) 