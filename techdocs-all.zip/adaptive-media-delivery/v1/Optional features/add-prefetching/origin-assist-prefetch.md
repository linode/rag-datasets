# [Origin-assist prefetch](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#origin-assist-prefetch)

With this prefetching method, when Akamai fetches an object from an origin, the response includes a new header that lists the next object in the sequence. Akamai can read this information and prefetch this object.

Basically, Akamai relies on assistance from your "intelligent" origin to trigger prefetching.

# [How it works](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#how-it-works)

1. The media player makes a request for `{object-1}`.

2. AMD handles the request by forwarding it to your origin.

3. Your origin returns the requested object, `{object-1}`, back to AMD.

   - The origin response also includes headers to prefetch `{object-2}`. The value of this header is either an absolute URL path or a relative URL path that's relative to `{object-1}`.

4. AMD returns `{object-1}` to player and this completes the request/response flow for `{object-1}`.

5. Since the response from your origin also included prefetch response headers for `{object-2}`, AMD triggers prefetching.

   - AMD creates an HTTP/S request for `{object-2}` and forwards it to your origin. This is called a "prefetch request." AMD includes a preconfigured request header in it, that tells your origin that it's a prefetch request.

6. Your origin returns `{object-2}` to AMD.

   - _The origin response could include a response header to prefetch `{object-3}` to continue the prefetching process._

7. AMD caches `{object-2}`.

   - _AMD doesn't trigger prefetching for `{object-3}`_. This is because `{object-2}` was already prefetched from your origin (and you don't want a never-ending recursive prefetch cycle).

8. The player makes a request for `{object-2}`.

9. AMD fetches `{object-2}` from its cache and returns it in the response to the player.

   - If the origin response for `{object-2}` included prefetch response headers for `{object-3}`, AMD triggers prefetching of `{object-3}`, and the process can continue.

# [What's supported](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#whats-supported)

**Streaming Formats**  |  \- Apple HTTP Live Streaming (HLS) \- Dynamic Adaptive Streaming over HTTP (DASH)   
 ---|---  
 **Live or Video on Demand (VoD)**  |  Both   
 **Origin Server**  |  There may be limitations on use for certain **Origin Types** when setting up the Origin Server in your property: \- **Your Origin**. No limitations.
 \- **Media Services Live**. Only HLS streaming format is supported.
 \- **NetStorage**. Not supported. 

## [About the HLS stream](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#about-the-hls-stream)

This discusses the object types you can usually find in an HLS stream, and the order they're presented in a request.

Object | What's triggered next in a prefetch | Additional details |  **Master Playlist (.m3u8)**  |  One or more variant Playlists (.m3u8).  |  N/A   
 ---|---|---  
 **Variant Playlist (.m3u8)**  |  One or more segments belonging to the current variant playlist. The segment to prefetch depends on the play position of the player, and this can be difficult to determine for a VoD stream. For Live streams, this is _typically_ one of the last three segments in the variant playlist.  |  For the typical HLS stream, segments have the following extensions: \- `.ts` for video, video + audio
 \- `.aac`, `.ac3,` `.ec3` for audio-only \- `.vtt`, `.webvtt`, `.mp4`, etc. for subtitles For the newer HLS streams with CMAF segments, the extensions are: \- `.mp4`, `.m4v`, etc. for video \- `.mp4`, `.m4a`, etc. for audio \- `.vtt`, `.webvtt`, `.mp4` for subtitles  > Note: These are not definitive, complete lists. There are a lot of supported extensions, and some are non-standard. This is to support various one-off workflows you may have in place.   
 **Variant Playlist (.m3u8)**  |  Zero or one `init` segment (described via the `#EXT-X-MAP` tag), that belongs to the current variant playlist.  |  The `init` segments are present _almost_ exclusively for CMAF segments, and the typical extensions are: \- `.mp4` \- `.m4v` \- `.m4a`   
 **Segment**  |  The segment that follows next in the video/audio/subtitle presentation time.  |  N/A 

## [About the DASH stream](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#about-the-dash-stream)

This discusses the object types you can usually find in a DASH stream, and the order they're presented in a request.

Object | What's triggered next in a prefetch | Additional details  
 ---|---|---  
 **Manifest File (.mpd)**  `init` segments for audio and video followed by actual audio and video segments. Unlike HLS, there are no bit rate-specific playlists, and content is always demuxed, so right after fetching the MPD file, the player typically requests two segments: one for video and another for audio.  |  N/A   
 **Init segment**  |  One or more content segments.  |  N/A   
 **Segment**  |  The segment that follows next in the video/audio/subtitle presentation time.  |  N/A 

# [1. Set up your origin](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#1-set-up-your-origin)

Akamai sends specific information to your origin to initiate prefetching. Your origin needs to include a properly formatted response header after this request, to trigger prefetching. review these sections to understand the flow of prefetching.

## [i. Akamai tells your origin prefetching is enabled](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#i-akamai-tells-your-origin-prefetching-is-enabled)

Akamai handles a player request for content and sends a _prefetch request header_ to your origin, telling it that prefetching is enabled:

```
CDN-Origin-Assist-Prefetch-Enabled: 1
```

## [ii. Your origin responds to Akamai with what to prefetch](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#ii-your-origin-responds-to-akamai-with-what-to-prefetch)

Your origin needs to use the Akamai request header to trigger prefetching. Your origin must send a _prefetch response header_ that tells Akamai what should be prefetched. This response header must be comprised of the absolute or relative path to the object to be prefetched, followed by the `Content-Length` header stating the length of the complete prefetch response header.

```
CDN-Origin-Assist-Prefetch-Path: 

Content-Length: x
```

Akamai creates the full URL for the object to be prefetched by using:

- The player-requested URL of the current object, and
- The relative or absolute path listed in the prefetch response header.

### [Absolute path examples](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#absolute-path-examples)

Specify an absolute path by prefacing it with forward-slash (/"///"). This tells Akamai to use the exact path specified.

URL of player that initiated the request | Value of the response header from the origin that's used to trigger prefetch | URL of a request prefetched from Akamai |  `https://property-hostname/some/1234/video-100k/pl.m3u8`  |  `/hls/live/1234/video-100k/seg1.ts`  |  `https://property-hostname-from-player-request/hls/live/1234/video-100k/seg1.ts`   
 ---|---|---  
 `https://property-hostname/thing/1234/video-100k/seg1.ts`  |  `/hls/live/1234/video-100k/seg2.ts`  |  `https://property-hostname-from-player-request/hls/live/1234/video-100k/seg2.ts` 

 > Note: 
  In these examples, both `property-hostname` and `property-hostname-from-player` are the HTTP/1.1 "Host" header as seen by Akamai.

### [Relative path examples](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#relative-path-examples)

Specify a relative path by leaving out the forward-slash (/"/\/") from the beginning of the path. Akamai uses the forward path of the current request, minus the filename as the base path when creating the prefetch URL path.

URL of player that initiated the request | Value of the response header from the origin that's used to trigger prefetch | URL of a request prefetched from Akamai |  `https://property-hostname/some/1234/video-100k/pl.m3u8`  |  `video-100k/seg1.ts`  |  `https://property-hostname/some/1234/video-100k/seg1.ts`   
 ---|---|---  
 `https://property-hostname/thing/1234/video-100k/seg1.ts`  |  `seg2.ts`  |  `https://property-hostname/some/1234/video-100k/seg2.ts` 

 > Note: 
  In these examples, `property-hostname` is the HTTP/1.1 "Host" header as seen by Akamai.

### [Example 1: Include a single "prefetchable" path per response header](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#example-1-include-a-single-prefetchable-path-per-response-header)

The origin uses individual instances of the prefetch response header to include a single object to be prefetched.

```
CDN-Origin-Assist-Prefetch-Path: /hls/live-streaming/fifa/france-croatia/video-1000k/pl.m3u8
Content-Length: x
```

If multiple objects are to be prefetched, then one response header per prefetchable URL can be returned by origin. Ensure that all response headers use the same name. The order of these headers determines the order Akamai follows to request each object.

```
CDN-Origin-Assist-Prefetch-Path: /hls/live-streaming/fifa/france-croatia/video-1000k/pl.m3u8
CDN-Origin-Assist-Prefetch-Path: /hls/live-streaming/fifa/france-croatia/audio/pl.m3u8
Content-Length: x
```

 > Note: 
  Middle-layer proxies may not preserve this ordering of response headers, and content may not be delivered in the desired order.

### [Example 2: Include multiple "prefetchable" paths in a single response header](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#example-2-include-multiple-prefetchable-paths-in-a-single-response-header)

The origin uses a single instance of the prefetch response header to include a comma-separated list of multiple objects to be prefetched.

```
CDN-Origin-Assist-Prefetch-Path: /hls/live-streaming/fifa/france-croatia/video-1000k/pl.m3u8,/hls/live-streaming/fifa/france-croatia/audio/pl.m3u8
Content-Length: x
```

The order of the paths listed determines what is prefetched first. Since this is only a single response header, the issue with middle layer proxies doesn't apply.

## [iii. Akamai requests the prefetched object for the player](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#iii-akamai-requests-the-prefetched-object-for-the-player)

With a "prefetch object" determined by the response header from your origin, Akamai requests it, as if it was requested by the player. To allow your origin to differentiate a prefetch request from a regular request all prefetch requests from Akamai use the same request header:

```
CDN-Origin-Assist-Prefetch-Request: 1
```

Once Akamai receives the prefetch object, it caches it until the player requires it.

Along with sending the prefetch object to Akamai, you can also have your origin send a new response header to prefetch the next object in the queue, if applicable.

# [2. Add Segmented Media Streaming - Prefetch](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#2-add-segmented-media-streaming-prefetch)

Add this behavior to your AMD property by performing the following:

1. Create a new AMD property, or edit an existing one using Property Manager.

2. In the Property Configuration Settings options, click **Add Behavior**.

3. In the _Search available behaviors_ field, input **Segmented Media** to filter the listed behaviors, and select **Segmented Media Streaming - Prefetch** from the list.

4. The new behavior is added to your configuration. Set the Enable Origin-Assisted Prefetch switch to **On**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-seg-media-prefetch-v1.jpg)

# [Caveats on use](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-assist-prefetch#caveats-on-use)

If you're also using [Common Media Client Data](https://techdocs.akamai.com/adaptive-media-delivery/docs/common-media-client-data-amd) for segment prefetching, its settings will override origin-assist prefetching.