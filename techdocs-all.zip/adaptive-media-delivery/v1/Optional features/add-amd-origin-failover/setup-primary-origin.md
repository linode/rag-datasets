# [Set up your primary origin](https://techdocs.akamai.com/adaptive-media-delivery/docs/setup-primary-origin#set-up-your-primary-origin)

Just like configuring a standard property for AMD, use the Origin Server behavior in the Default Rule to serve as the *primary origin*.

A primary origin server is required for AMD and almost every other Property Manager-configured product. To set one up, start with the [Prepare your origin server](https://techdocs.akamai.com/property-mgr/docs/prepare-your-origin-server) topic in the Property Manager user documentation.

 > Note: 
 If you're using Media Services Live as your origin, caveats may apply to the functionality offered with AMD origin failover. See [Known issues with AMD origin failover](https://techdocs.akamai.com/adaptive-media-delivery/docs/known-issues-with-amd-origin-failover) for details.

# [What's next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/setup-primary-origin#whats-next)

With your primary origin fully set up, you need to define the recovery methods you want to use if it ever fails.