# [Configure the recovery methods](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-the-recovery-methods#configure-the-recovery-methods)

To implement AMD failover, you first need to add the Origin Failure Recovery Methods rule to your property and configure it.

# [Rule overview](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-the-recovery-methods#rule-overview)

The Origin Failure Recovery Methods rule offers two "sub-rules" that you use to configure the available recovery methods.

- **Failure Recovery Method1**. This rule lets you configure a backup origin for use as an origin failure recovery method.

- **Failure Recovery Method2**. This rule lets you configure a specific HTTP status code that's returned to a requesting client as an origin failure recovery method.

# [Implementation](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-the-recovery-methods#implementation)

To add this rule and configure it, perform these steps:

1. In the Property Configuration Settings panel, click **Add Rule**.

2. In the _Search available rules_ field, input "Origin Failure" to filter the listed rules. Select **Origin Failure Recovery Methods** from the list. Consider these points when adding this rule:

   - **You can't add match criteria or behaviors directly in the Origin Failure Recovery Method rule**. Configuration is applied in its **Failure Recovery Method1** and **Failure Recovery Method2** "sub-rules.")

   - **The Origin Failure Recovery Methods rule needs to be the _last_ rule in the rule tree**. This ensures that the required recovery methods are appropriately applied, and they won't be overridden by other behaviors.

3. Select the first sub-rule, **Failure Recovery Method1**.

4. In Criteria, set the drop-down to**Recovery Configuration Name** and enter a unique identifier. You can use three to 20 capitalized alphanumeric and dash characters. This is the "Recovery Method Configuration Name" that you apply to have its recovery method applied for certain failure conditions. _Make note of this value._

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-failover-recovery-method1-v2.png)

5. Apply settings for required and optional behaviors to this rule to define the backup origin.

| Behavior | Required? | Notes  
 ---|---|---  
 **Origin Failure Recovery Method**  |  ✓  |  Ensure that Recovery Method is set to **Retry using Alternate Origi** .   
 **Origin Server**  |  ✓  |  Use this behavior to set specifics for your backup origin. As with the primary origin, complete details can be found in the Property Manager [user documentation](https://techdocs.akamai.com/property-mgr/docs/origin-server).   
 **Origin Characteristics**  |  ✓  |  Apply these settings to incorporate best practices and optimize delivery and access to the origin. More details can be found in [Origin Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-charac-amd).   
 **Modify Outgoing Request Path**  |  X  |  This [behavior](https://techdocs.akamai.com/property-mgr/docs/modify-outgoing-req-path) automates common URL rewriting tasks for incoming requests before they are forwarded to the origin. 

 > Warning: 
  Only the behaviors listed in this table can be included in this rule.

6. Click the **Failure Recovery Method2** sub-rule.

7. In Criteria, ensure **Recovery Configuration Name** is selected from the "If" drop-down, and input another unique identifier. Ensure that this is different from the first one. This is the "Recovery Method Configuration Name" that you apply to have _this_ origin failure recovery method applied for certain failure conditions. _Make note of this value, too._

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-failover-recovery-method2-v2.png)

8. Set the following in the Origin Failover Recovery Method behavior:

   - **Recovery Method**. Ensure this is set to **Respond with a custom status code**.

   - **Custom Status Code**. Input the desired HTTP status code you want to be sent to a requesting client when this failure method is used.

# [What's next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/configure-the-recovery-methods#whats-next)

Next, you need to [set up a policy of the failure scenarios](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-your-recovery-policy) you want to use to trigger the failover and define the recovery methods these scenarios will use.