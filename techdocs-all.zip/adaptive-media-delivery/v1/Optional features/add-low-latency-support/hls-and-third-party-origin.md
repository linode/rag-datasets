# [HLS and a third-party origin](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#hls-and-a-third-party-origin)

If you're exclusively distributing HLS live media and want support for low latency, you need to configure a third-party origin and then apply it—and some more settings—in your AMD property.

# [How does it work?](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#how-does-it-work)

Apple has updated the [HLS specification](https://developer.apple.com/documentation/http_live_streaming/enabling_low-latency_http_live_streaming_hls) to support low latency for HLS (LL-HLS). The update allows the segments at the live edge to be described as partial segments (“parts”). A properly enabled player can access the media data faster because it doesn’t have to wait for production of the entire segment. It can request one of these parts, instead. 

# [Set up your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#set-up-your-amd-property)

 > Note: 
  The LL-HLS specification and implementation details are evolving in real-time. What’s here represents current recommendations. This could change at any time.

Set up the appropriate rule and match criteria for requests that you want to add low latency support. In that rule, you need to set up specific behaviors. What’s covered here only describes the behaviors you need to enable LL-HLS support in an AMD property rule. See [Define property configuration settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-config-settings) for full information on rule configuration.

## [Configure Origin Server](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#configure-origin-server)

Since you're using your own unique origin to deliver live content, you'd select **Your Origin** and configure the [applicable options](https://techdocs.akamai.com/property-mgr/docs/the-custom-origin-public).

 > Note: 
  You can't use NetStorage as your origin because this only applies to live media streams.

## [Configure Segmented Media Delivery Mode](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#configure-segmented-media-delivery-mode)

Apply these settings in this behavior to support low latency:

- Set Mode to **Live**. 
- Set Enable ULL Streaming to “**On**.”

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ll-hls-seg-del-mode-v1.jpg)

See [Segmented Media Delivery Mode and AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/segmented-media-deliv-mode-amd) for details on the remaining options.

## [Configure Content Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#configure-content-characteristics)

Apply these settings in this behavior to support low latency:

- **Enable HLS**. Set this to "**Yes**."
- **Enable HDS**. Set this to "**No**."
- **Enable DASH**. Set this to "**No**."
- **Enable Smooth**. Set this to "**No**."

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ll-hls-cont-char-v1.jpg)

See [Content Characteristics and AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd) for details on the remaining options.

 > Tip: 
  If you'd like to deliver other media formats with this same property and still apply low latency for HLS, don't use the Default Rule. Set up a separate rule with unique match criteria, using all of the settings covered here to distribute HLS with low latency. Then, set up another separate rule with its own match criteria and different instances of these behaviors configured for the other media formats. Make sure Enable ULL Streaming is set to "Off" in that rule. You can't use the Default Rule, because it applies to all requests.

## [Configure Cache Key Query Parameters](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#configure-cache-key-query-parameters)

An LL-HLS player asks for manifests explicitly using special `_HLS` query parameters. So, you should include those query parameters in the cache key. The easiest way to catch them all is to add **\_HLS** to the Parameters list, and then set Exact Match to “**No**.” This will catch any parameter that includes `_HLS`.

 > Note: 
  Some packagers might require additional query parameters. For example, the Apple reference stream uses query parameters in segment requests. To ensure correct operation, these parameters need to be included in the parameter list.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ll-hls-cache-key-v1.jpg)

## [Add HTTP/2](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#add-http2)

The LL-HLS specification requires HTTP/2. Add the HTTP/2 behavior to your AMD property. You’ll also need to [serve content over HTTPS](https://techdocs.akamai.com/property-mgr/docs/serve-content-over-https) to support HTTP/2.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ll-hls-http2-v1.jpg)

## [Configure Quick Retry](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#configure-quick-retry)

There are two ways that a manifest can describe the parts for LL-HLS:

- **DISCRETE mode**. Each part can be addressed discreetly via a unique URL. This is the most common mode and all players support it. This is self-serviceable.

- **BYTERANGE mode**. This lets you request HLS segment files at a byte-range offset. You’ll receive the data as it’s produced by the packager without having to request each individual byte-ranged part. This can reduce the number of requests from the client to the edge by 40%. 

 > Note: 
  The Quick Retry behavior is automatically included in the Default Rule for a new AMD property, and it’s set to “**On**.” If you’re using the Default Rule for this scenario, ensure it’s set to meet either DISCRETE or BYTERANGE modes.

## [Other recommended settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#other-recommended-settings)

Consider applying these additional settings to help with LL-HLS.

#### Tuning Read Timeout

The default read timeout with Enable ULL streaming set to “On” is 2 seconds at the edge and 1 second at the parent. The origin holds back requests for the duration of an individual part. So, this reduces the timeout window and can lead to false triggers. You can compensate for this by adding some extra margin to these values.

For example, assume you’re using 1 second parts. This could result in hold back times in the 950 - 980 millisecond range and result in occasional read timeouts. To avoid this, you can use a new millisecond resolution capability to add 500ms at the parent, like this:

```text

2s

     
1500ms

```

Work with your account representative to get this implemented with your AMD property.

#### The Allow-Timing-Origin header

For a web-based player, if you enable Timing-Allow-Origin headers, the player can access the Resource Timing API. This helps the player understand the hold back time (TTFB) and the actual download time, in order to make accurate bandwidth estimations. 

1. Click **Add Rule**.

2. Select **Blank Rule Template** from the list.

3. Click **Add Match**. 

4. Set the If parameters in the match to:

   - **Response Header**
   - **Timing-Allow-Origin**
   - **does not exist**

5. Click **Add Behavior**.

6. In Search available behaviors, type "**modify**" and select **Modify Outgoing Response Header** from the list.

7. Click **Insert Behavior**.

8. Set Action to **Modify** and Select Header Name to **Other…** 

9. In Custom Header Name, input "**Timing-Allow-Origin**".

10. Set New Header Value to “**\***” to serve as a wildcard for all values.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ll-hls-allow-timing-origin-v1.jpg)

## [Understand Property Manager rule logic](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#understand-property-manager-rule-logic)

Origin Server, Content Characteristics, and Segmented Media Delivery Mode are required behaviors that are automatically included and are required in the Default Rule. The Default Rule applies to _all_ requests. If you add another rule to your AMD property and include these behaviors in that rule to support LL-HLS, a request that meets its match criteria _will use that rule's behavior settings_. However, if you add another rule and _don't include these behaviors in it_, requests that match that rule will use what you've set in the Default Rule for these behaviors.

Remember this logic when setting up your AMD rules for low latency support.

# [Additional resources](https://techdocs.akamai.com/adaptive-media-delivery/docs/hls-and-third-party-origin#additional-resources)

- [Enabling Low-Latency HLS](https://developer.apple.com/documentation/http_live_streaming/enabling_low-latency_hls). Apple developer documentation that offers a detailed explanation of this support.

- [Using LL-HLS with Byte-range addressing](https://www.akamai.com/blog/performance/-using-ll-hls-with-byte-range-addressing-to-achieve-interoperabi). This Akamai blog discusses how to use BYTERANGE mode to achieve interoperability in low latency streaming.