# [Generate and apply a token](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content#generate-and-apply-a-token)

Along with [setting up Token Authentication in Property Manager](https://techdocs.akamai.com/adaptive-media-delivery/docs/enable-token-authentication), you need to perform a few separate steps, including integrating token generation code into your origin infrastructure.

 > Warning: 
  You need to perform this process _before_ you enable your AMD property with Token Authentication on the production network.

# [1 - Generate the access ("short") token](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content#1-generate-the-access-short-token)

You need to generate a one-time access token, also referred to as the "short token," and apply it to media content that uses it. The token is a delimited list of string fields, with an HMAC to prevent tampering with the strings. Each field consists of a value that is verified by AMD when a request is made. Among other things, fields in the token include the following:

- **A token name** (`token_name/tokenName`). This is _required_ and you need to use the value, `hdnts`.

- **Start/end times** (`start_time/startTime`, `end_time/endTime`). These are both _required_. Use them to set a time to live (TTL) for the token.

- **A session identifier** (`session_id/sessionId`). This is optional. Include it as a unique identifier for a single playback/access session. Create a session identifier using printable ascii characters and ensure that it's no larger than 64 bytes in size. This value is required if you're using [token-based access revocation](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-based-access-rev).

- **A Key** (`key`). This is _required_. This is the secret used to generate the token. This is the value you set as the **Encryption Key** for Token Authentication in the AMD property. (This can also be the **Transition Key**, if applicable, or the **Encryption key + Salt/Request Headers** or **Transition key + Salt/Request Headers** if you've set up these as Advanced Options in the AMD property.)

 > Warning: 
  We recommend against including the IP address field in your tokens to tie the token to a specific IP address—unless all requests will only come from a specific address. This can break delivery in a property if requests come from other IP addresses, or if you're using an IPv4+IPv6 dual-stacked environment.

We offer Token Auth software development kits (SDKs), that you can use to generate this token. They're available for multiple programming languages, and they account for all required and optional fields.

- [C Sharp ("C#")](https://github.com/BookBeat/EdgeAuth-Token-CSharp)
- [Java](https://github.com/akamai/EdgeAuth-Token-Java)
- [NodeJS](https://github.com/akamai/EdgeAuth-Token-Node)
- [Python](https://github.com/akamai/EdgeAuth-Token-Python)
- [Ruby](https://github.com/akamai/EdgeAuth-Token-Ruby)

See the README section on these pages for details on how to use each SDK.

# [2 - Apply the token](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content#2-apply-the-token)

The completed token should be attached as a query string parameter, cookie, or request header, to the URL for the manifest/index file for your target content, using the following format:

```

?hdnts=

```

The final token might look like the following, if it's included as a query string: (The HMAC in this example was not generated from the token input strings.)

```
http://www.mymedia.com/
/media.m3u8?hdnts=st=1370627194~exp=1370627409~acl=*~hmac=6a10b3f602ffde88c02cd1b89665bfdfdc0fc84c3cf7049752931ad7
```

Ideally, you should set up your origin server to dynamically generate these tokens for each client request for the content. This way, the IP address (`ip`) could be included as a parameter, and access to the content would be restricted to that single, authorized user.

# [3 - Ensure query string name disambiguation](https://techdocs.akamai.com/adaptive-media-delivery/docs/generate-a-token-and-apply-it-to-content#3-ensure-query-string-name-disambiguation)

Ensure that your content URLs _don't use_ the values "hdntl" and "hdnts" in any other query strings. We use these names with Token Authentication.