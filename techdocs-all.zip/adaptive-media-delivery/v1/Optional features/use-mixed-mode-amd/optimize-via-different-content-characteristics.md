# [Optimize via different Content Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-content-characteristics#optimize-via-different-content-characteristics)

With this use case, we're looking to apply different Content Characteristics for Video on Demand (VoD) requests, in order to streamline delivery of media for multiple resolutions and segment sizes.

# [Overview](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-content-characteristics#overview)

In this scenario, we're looking to optimize delivery for requests to a single Property hostname, "baseball-highlights-media.com," for Apple HTTP Live Streaming (HLS) VoD media. It assumes that these requests are originating from one of two URLs that include unique path elements:

- `https://baseball-highlights-media.com/HLS-low/{media}`. The `/HLS-low/` path is included in requests for media at a *lower* resolution.
- `https://baseball-highlights-media.com/HLS-high/{media}`. The `/HLS-high/` path is included in requests for media at a *higher*resolution.

A custom origin ("Your Origin") is used to house the VoD media for both formats.

# [Phase 1: Create the Property hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-content-characteristics#phase-1-create-the-property-hostname)

We need a new AMD property with one property hostname for the distribution of content, and we also want to employ Standard TLS security for access.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-optimize-client-char-v1.jpg)

The steps that follow outline what you need to do to create the Property hostname for this use case.

1. You need Standard TLS certificates set up for each property hostname. These can take a while to provision, so you should [create](https://techdocs.akamai.com/cps/docs/create-edit-certs) them before you create the AMD property. You need to include your Property hostnames as a CN or SAN in each respective certificate: "baseball-highlights-live-media.com" for the live content certificate, and "baseball-highlights-ondemand-media.com" for the VoD content certificate.

1. [Create](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop) a new AMD property in ​Akamai Control Center​.

1. [Set up](https://techdocs.akamai.com/property-mgr/docs/add-hn-custom-cert#general-availability) a Standard TLS Property Hostname to Edge hostname association for "baseball-highlights-media.com."

# [Phase 2: Add a new rule for lower resolution content](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-content-characteristics#phase-2-add-a-new-rule-for-lower-resolution-content)

For certain requesting players, we want to ensure that lower resolution HLS content is served. So, we're incorporating a separate rule to target requests that include the "/HLS-low/" path element, to use specific Content Characteristics behavior settings.

1. In the Property Configuration Settings click **Add Rule**.

1. Ensure **Blank Rule Template** is selected (default) and click **Insert Rule**.

1. Click the gear icon in the New Rule and select **Edit Name**. Input the desired name (for example, "VoD HLS low res") and press **Enter**.

1. Click **Add Match** and set the fields as follows:

    - **Path**
    - **matches one of**
    - **Select Items**. Click this field and input `/HLS-low/*` to indicate requests for the Property hostname (baseball-highlights-media.com) followed by the "/HLS-low" subdirectory, and then any object ("/*") in that directory.

5. Click **Add Behavior**.

1. Type "content" in the Search available behaviors field to filter results, select **Content Characteristics**, and click **Insert Behavior**. Set the options in this behavior as follows:

    - **Catalog Size**. This applies to the size of the overall catalog of content to be delivered. We're not sure of the overall size, so we set this to **Unknown**.
    - **Content Type**. **Standard Definition** (for 480i/p or 720p resolution).
    - **Popularity Distribution**. We're not sure of the popularity, so we set this to **Unknown**.
    - **Enable HLS**. Set this slider to **Yes**.
    - **Segment Duration**. Our segment size for this example is **4s** for the lower resolution content.
    - **Origin Object Size**. We're not sure of individual object sizes, so we set this to **Unknown** as well.
    - **Enable HDS, Enable DASH and Enable Smooth**. We're not using these formats in this scenario, so they need to be set to **Off**.

 > Tip: 
 Full details on these options, including recommendations on usage, can be found in the [Content Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd) topic.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-optimize-content-char-settings-v1.jpg)

# [Phase 3: Configure the Default Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-content-characteristics#phase-3-configure-the-default-rule)

Now, you configure the Default Rule to handle all other requests, as well as settings you want to be applied to *all* requests. For example, we'll set up "Your Origin" as the Origin Server to incorporate a custom origin for all requests here. Access the Default Rule and set the use case-based behaviors here as follows.

Behavior | Options  
 ---|---  
 **Origin Server**  |  For this scenario, we set this to **Your Origin**. Configure [settings](https://techdocs.akamai.com/property-mgr/docs/origin-server#origin-server-your-origin) here to align with your specific origin.   
 **Origin Characteristics**  |  Set the following options: * **Origin Location**. Set this to the geographic location that best matches the location of **Your Origin**. * **Authentication Method**. Select the auth method that matches how you've configured **Your Origin**. With this VoD scenario, if you're not using a third-party cloud origin, you would select **Akamai Origin - Auto, Other - None**.   
 **Segmented Media Delivery Mode**  |  Set Mode to **On Demand**.   
 **Content Characteristics**  |  Apply these Content Characteristics settings for all higher resolutions—requests that don't include the `/HLS-low/` path element. * **Catalog Size**. Set this to **Unknown**. * **Content Type**. Set this to **High Definition** (for 1080i or 1080p). * **Popularity Distribution**. Set this to **Unknown**. * **Enable HLS**. Set this slider to **Yes**. * **Segment Duration**. Our segment size for this example is **10s** for the higher-resolution content. * **Origin Object Size**. Set this to **Unknown**. * **Enable HDS, Enable DASH and Enable Smooth**. We're not using these formats in this scenario, so set them to **Off**.   
 **Client Characteristics**  |  Set **Client Location** to the geographic region that best represents the clients that will be accessing the VoD content. 

# [What happens next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/optimize-via-different-content-characteristics#what-happens-next)

First, you need to [complete](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop) creation of the AMD property, optionally [test](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop) it, and finally [promote](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live) it to production for use.

Once live in production, request logic for your content works as follows:

- **A request to** `baseball-highlights-media.com/HLS-low/*`. Since the `/HLS-low/` path matches this rule, *its version* of the Content Characteristics behavior is applied. However, the Default Rule applies to *all* requests. So, all of its additional behaviors are also applied—use case-based behaviors or not. For example, what you've set for the Client Characteristics behavior in the Default Rule is used because there is no instance of that use case-based behavior in the "VoD HLS low res" rule.

- **A request to** `https://baseball-highlights-media.com/HLS-high/*`. The "VoD HLS low res" rule is read first, but this request *doesn't match* its criteria. So, the request references the Default Rule, and its Content Characteristics behavior settings are used