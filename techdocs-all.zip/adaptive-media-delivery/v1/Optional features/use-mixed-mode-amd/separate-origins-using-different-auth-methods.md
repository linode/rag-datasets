# [Separate origins using different auth methods](https://techdocs.akamai.com/adaptive-media-delivery/docs/separate-origins-using-different-auth-methods#separate-origins-using-different-auth-methods)

In this scenario, we'll set up two separate Property hostname to Edge hostname associations ("property hostnames") to field requests to separate origins, and streamline delivery from each by using unique Origin Characteristics.

# [Overview](https://techdocs.akamai.com/adaptive-media-delivery/docs/separate-origins-using-different-auth-methods#overview)

In this scenario, we'll be fielding requests to two property hostnames to deliver Dynamic Adaptive Streaming over HTTP (DASH) VoD content that is hosted on two separate origin servers. It assumes that these requests are originating from one of two URLs:

- `https://baseball-highlights-4k-media.com`. This URL is targeted to request 4K quality content.
- `https://baseball-highlights-hd-media.com`. This URL is targeted to request 1080i/p (HD) content.

The 4K content is hosted on a Google Cloud Platform origin and requires that authentication, while the HD content is hosted on NetStorage.

# [Phase 1: Create the Property hostnames](https://techdocs.akamai.com/adaptive-media-delivery/docs/separate-origins-using-different-auth-methods#phase-1-create-the-property-hostnames)

We need a new AMD property with two property hostnames and we also want to employ Standard TLS security for access.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-mmc-sep-origins-diff-auth-v1.jpg)

These steps outline what you need to do to create the property hostnames for this use case.

1. You need a Standard TLS certificate set up for the Property hostname. This can take a while to provision, so you should [create](https://techdocs.akamai.com/cps/docs/create-edit-certs) it before you create the AMD property. You need to include your Property hostnames as a CN or SAN in each respective certificate—"baseball-highlights-4k-media.com" for the 4K content certificate, and "baseball-highlights-hd-media.com" for the HD content certificate.

2. [Create](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop) a new AMD property in ​Akamai Control Center​.

3. [Set up](https://techdocs.akamai.com/property-mgr/docs/add-hn-custom-cert#general-availability) two separate, Standard TLS Property Hostname to Edge hostname associations, one for "baseball-highlights-4k-media.com" and one for "baseball-highlights-hd-media.com."

# [Phase 2: Add a new rule for the HD content](https://techdocs.akamai.com/adaptive-media-delivery/docs/separate-origins-using-different-auth-methods#phase-2-add-a-new-rule-for-the-hd-content)

For player requests to `https://baseball-highlights-hd-media.com`, we want to ensure that the HD content is served from the proper origin and optimized for delivery. So, we're incorporating a separate rule to target requests for that URL, to use specific Origin Characteristics and Content Characteristics behavior settings.

1. In the Property Configuration Settings click **Add Rule**.

2. Ensure **Blank Rule Template** is selected (default) and click **Insert Rule**.

3. Click the gear icon in the New Rule and select **Edit Name**. Input a desired name (for example, "VoD HD NetStorage") and press **Enter**.

4. Click **Add Match** and set the fields as follows:

   - **Hostname**
   - **is one of**
   - **Select Items**. Click this field and input the Property hostname for the HD VoD content (for example, "baseball-highlights-hd-media.com").

5. Click **Add Behavior**.

6. Type "origin" in the Search available behaviors field to filter results, select **Origin Server**, and click **Insert Behavior**. Set the options in this behavior as follows:

   - **Origin Type**: NetStorage
   - **NetStorage Account**: Click to select the NetStorage account associated with the Storage Group that houses the HD VoD content to be delivered.

7. Repeat steps 5-6, to add the **Origin Characteristics** and **Content Characteristics** behaviors.

Behavior | Options  
 ---|---  
 **Origin Characteristics** | Set the following options to optimize the delivery of the HD content from NetStorage as an origin.
     * **Origin Location** : Set this to the geographic location that corresponds to the NetStorage Account you set in the Origin Server behavior.
     * **Authentication Method** : Akamai Origins - Auto, Others - None  
 **Content Characteristics** | We know the following for our HD content, so we set these options, accordingly:
     * **Catalog Size** : We're not sure of the overall size of the media catalog, so we set this to **Unknown**.
     * **Content Type** : **High Definition** (for 1080i/p resolution).
     * **Popularity Distribution** : We're not sure of the popularity, so we set this to **Unknown**.
     * **Enable DASH**. Set this slider to **Yes**.
     * **Segment Duration**. Our segment size for this scenario is **6s**.
     * **Origin Object Size** : We're not sure of individual object sizes, so we set this to **Unknown** as well.
     * **Enable HLS, Enable HDS and Enable Smooth**. We're not using these formats in this scenario, so they need to be set to **Off**.
 **Tip:** Full details on these options, including recommendations on usage can be found in the [Content Characteristics and AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd) topic.

# [Phase 3: Configure the Default Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/separate-origins-using-different-auth-methods#phase-3-configure-the-default-rule)

Now, you configure the Default Rule to handle all other requests, as well as settings you want to be applied to _all_ requests. For example, we need to set "Your Origin" as the Origin Server to incorporate Google Cloud Platform to configure this origin type and apply Origin Characteristics optimization for it. Access the Default Rule and set the use case-based behaviors here as follows:

Behavior | Options  
 ---|---  
 **Origin Server** | For this scenario, we set this to **Your Origin** . Configure settings here to align with your specific origin. Configure settings here to align with your specific origin. This is covered in detail in the [Property Manager help](https://techdocs.akamai.com/property-mgr/docs/configure-unique-origin)  
 **Origin Characteristics** | Set the options here as follows:
     * **Origin Location** : Set this to the geographic location that best matches the location of "Your Origin."
     * **Authentication Method** : Akamai For this use case, we'd select **Google Cloud Platform**.
 **Tip:** Full details on these options, including recommendations on usage can be found in the [Origin Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-charac-amd) topic.  
 **Segmented Media Delivery Mode** | Set the options here as follows:
     * **Mode** : On Demand  
 **Content Characteristics** | These Content Characteristics settings will be used for requests originating from `https://baseball-highlights-4k-media.com`. (This assumes that all requests for your media are originating from that URL or `https://baseball-highlights-hd-media.com`.)
     * **Catalog Size** : Set this to **Unknown**.
     * **Content Type** : Set this to **Ultra High Definition (4K)**.
     * **Popularity Distribution** : Set this to **Unknown**.
     * **Enable DASH**. For this scenario, we'd set this slider to **Yes**.
     * **Segment Duration**. Our segment size for this example is **10s** for this content.
     * **Origin Object Size** : Set this to **Unknown** as well.
     * **Enable HLS, Enable HDS, and Enable Smooth**. We're not using these formats in this scenario, so they need to be set to **Off**.  
 **Client Characteristics** | Set the options here as follows:
     * **Client Location** : Select the geographic region that best represents the clients that will be accessing all of your content.

# [What happens next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/separate-origins-using-different-auth-methods#what-happens-next)

First, you need to [complete](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop) creation of the AMD property, optionally [test](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop) it, and finally [promote](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live) it to production for use.

Once live in production, request logic for your content works as follows:

- **A request to** `https://baseball-highlights-hd-media.com`. Since this matches the `baseball-highlights-hd-media.com` property hostname that's the criteria in the "VoD HD NetStorage" rule, its Origin Server is used, and its versions of the Origin Characteristics and Content Characteristics behaviors are applied. However, the Default Rule applies to _all_ requests. So, all of its additional behaviors are also applied—use case-based behaviors or not. For example, what you've set for the Client Characteristics behavior in the Default Rule is used because there is no instance of that use case-based behavior in the "VoD HLS low res" rule.

- **A request to** `https://baseball-highlights-4k-media.com`. The "VoD HD NetStorage" rule is read first, but this request _doesn't match_ its criteria. So, the request references the Default Rule, and its Origin Server is used, as well as what's been set in the Origin Characteristics and Content Characteristics behavior settings in the Default Rule.