# [Live & on-demand: One property hostname, different URL paths](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-on-demand-one-property-hostname-different-url-paths#live-on-demand-one-property-hostname-different-url-paths)

Here, you set up a single Property hostname to Edge hostname association ("Property hostname"), and configure access to live versus video on demand (VoD) content based on matching on a specific path component in the request.

# [Overview](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-on-demand-one-property-hostname-different-url-paths#overview)

In this scenario, we'll be fielding requests to a single Property hostname, "baseball-highlights-media.com" for both live and VoD content:

- **Live Media**. `https://baseball-highlights-media.com/LIVE/{media}`
- **VoD Media**. `https://baseball-highlights-media.com/VOD/{media}`

Media Services Live is used to distribute the live content, and the VoD content is stored in NetStorage for access.

# [1 - Get your live media set up](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-on-demand-one-property-hostname-different-url-paths#1-get-your-live-media-set-up)

To start, you need to work with Media Services Live to set up your live media.

1. [Create your Media Services Live (MSL) stream](https://techdocs.akamai.com/msl/docs/create-your-media-services-live-streams) for the live media you want to distribute.

1. [Configure an origin for your live streams](https://techdocs.akamai.com/msl/docs/config-origin-stream). During this process, you'll need to make note of the **Primary Hostname** value.

# [2 - Set up the property hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-on-demand-one-property-hostname-different-url-paths#2-set-up-the-property-hostname)

We need a new AMD property with one Property hostname for distribution content, and we also want to employ Standard TLS security for access.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-mmc-same-prop-hostnames-v1.jpg)

The steps that follow outline what you need to do to create the property hostname for this use case.

1. You need a Standard TLS certificate set up for the property hostname. This can take a while to provision, so you should [create](https://techdocs.akamai.com/cps/docs/create-edit-certs) it before you create the AMD property. You need to include the domain name you set in your property hostname as a CN or SAN in the certificate&mdash;"baseball-highlights-media.com."

1. [Create](https://techdocs.akamai.com/adaptive-media-delivery/docs/create-new-prop) a new AMD property in ​Akamai Control Center​.

1. [Set up](https://techdocs.akamai.com/property-mgr/docs/add-hn-custom-cert#general-availability) a Standard TLS Property Hostname to Edge hostname association for "baseball-highlights-media.com."

# [3 - Configure the Default Rule for Live content](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-on-demand-one-property-hostname-different-url-paths#3-configure-the-default-rule-for-live-content)

Now, [set up the Default Rule in the AMD property to accommodate live media using Media Services Live (MSL). To support MSL, configure the behaviors in the Default Rule as follows:

Behavior | Options  
 ---|---  
 **Origin Server** | Set these options as follows:
 
   * **Origin Type** : **Media Services Live**
   * **MSL Origin** : This is the **Primary Hostname** you noted while [configuring an origin for your live stream in MSL](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-on-demand-one-property-hostname-different-url-paths).
 
  
 **Segmented Media Delivery Mode** | Set these options as follows:
 
   * **Mode** : **Live** , with the Show Advanced Options slider set to **Yes**
   * **Live Type** : Either **Linear** or **Event** , based on your need.
   * **Segment Access Time Mode** : If you know the Segment Access Time, and wish to set a specific value, this should be at **Configurable** with a numerical duration set, along with the applicable time increment of days, hours, minutes, and seconds from the drop-down menu. Otherwise, this should be set to **Unknown**.
 
  
 **Origin Characteristics** | Set these options as follows:
 
   * **Origin Location** : The region that best represents the location of the encoder distributing the MSL content.
   * **Authentication Method** : Akamai Origins - Auto, Others - None
 
  
 **Content Characteristics** | Set these options as follows:
 
   * **Catalog Size** : **Other**.
   * **Content Type** : The desired output quality for your live video, **Standard Definition** , **High Definition** , **Ultra High Definition (4K) Other**, or **Unknown**.
   * **Popularity Distribution** : **Other**.
   * **Enable HLS/HDS/DASH/CMAF** : **Yes** to enable compatible stream types, and to **No** to disable incompatible types.
   * **Segment/Fragment Duration** : The duration, in seconds for each segment/fragment (**2s** , **4s** , **6s** , **8s** , or **10s**). With Origin Object Size set to **Unknown** for each.
 
  
 **Client Characteristics** | Set these options as follows:
 
   * **Client Location** : The geographic region that best represents the clients that will be accessing your Live content.
   * 

# [Phase 3: Add a new rule for VoD content](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-on-demand-one-property-hostname-different-url-paths#phase-3-add-a-new-rule-for-vod-content)

To distribute VoD content, we'll configure a rule that targets requests to the Property hostname ("baseball-highlights-media.com") that include the "/VOD/" directory in the path.

1. In the Property Configuration Settings click **Add Rule**.

1. Ensure **Blank Rule Template** is selected (default) and click **Insert Rule**.

1. Click the gear icon in the New Rule and select **Edit Name**. Input the desired name (for example, "VoD Delivery Path Rule") and press **Enter**.

1. Click **Add Match** and set the fields as follows:

    - **Path**
    - **is one of**
    - **Select Items**. Click this field and input "/VOD/*" to indicate requests for the Property hostname (baseball-highlights-media.com) followed by the "/VOD" subdirectory, and then any object ("/*") in that directory.

5. Click **Add Behavior**.

1. Type "origin" in the Search available behaviors field to filter results, select **Origin Server**, and click **Insert Behavior**. Set the options in this behavior as follows:

    - **Origin Type**: NetStorage
    - **NetStorage Account**: Click to select the NetStorage account associated with the Storage Group that houses the VoD content to be delivered.

7. Repeat Step 6, to add the **Origin Characteristics**, **Segmented Media Delivery Mode**, **Content Characteristics** (optional), and **Client Characteristics** (optional) behaviors.

Behavior | Options  
 ---|---  
 **Origin Characteristics** | Set these options as follows:
 
   * **Origin Location** : Set this to the geographic location that corresponds to the NetStorage Account you set in the Origin Server behavior.
   * **Authentication Method** : Akamai Origins - Auto, Others - None  
 **Segmented Media Delivery Mode** | Set these options as follows:
     * **Mode** : On Demand  
 **Content Characteristics** | Set these options to best fit the VoD content you're delivering to your end users, to optimize its delivery. **Note:** You could leave this behavior out of this rule to use the options you've set for it in the Default Rule. However, your VoD content may have different optimization requirements than your Live content. See [Content Characteristics and AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd) for detailed information on this behavior.  
 **Client Characteristics** | Set these options as follows:
     * **Client Location** : Select the geographic region that best represents the clients that will be accessing your VoD content.
     * **Note:** Only include this behavior if you want to use a different setting than what you've applied for Client Location in the Default Rule. The Default Rule applies to all requests, so you don't have to include this behavior if you're happy with what's set there.

# [What happens next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/live-on-demand-one-property-hostname-different-url-paths#what-happens-next)

First, you need to [complete](https://techdocs.akamai.com/adaptive-media-delivery/docs/finalize-amd-prop) creation of the AMD property, optionally [test](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop) it, and finally [promote](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live) it to production for use.

Once live in production, request logic for your content works as follows:

- **A request to** `https://baseball-highlights-media.com/LIVE/*`. The Default Rule&mdash;and all of its Media Services Live-based settings&mdash;is used for these requests. The match criteria you set in the VoD Delivery Path Rule is unique to requests that include "/VOD/" in the path. So all of the settings applied in that rule are ignored.

- **A request to** `baseball-highlights-media.com/VOD/*`. The VoD Delivery Path Rule exists last in the property, so it's checked *first*. Since the "/VOD/" path matches this rule, all of its behaviors are applied. However, the Default Rule applies to *all*requests. So, the following also apply:

- **With duplicate behaviors in both the VoD Delivery Path Rule and Default Rule, what's in the VoD Delivery Path Rule is used**. For example, you set up "NetStorage" as your Origin Server for VoD, and "On Demand" for your Segmented Media Delivery Mode, so those are used for requests to the "/VOD/" path. Also, if you added the Content Characteristics behavior in this rule and configured unique settings for VoD media, *these*settings are used in place of what you've set for that behavior in the Default Rule.

- **If you've set behaviors in the Default Rule that aren't in the VoD Delivery Path Rule, they're applied**. For example, if you left out the Client Characteristics behavior from the VoD Delivery Path Rule, what you set in the Default Rule is used.

 > Note: 
 The above points apply to all behaviors in either rule, not just the use case-based behaviors.