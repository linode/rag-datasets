# [Existing properties and MMC](https://techdocs.akamai.com/adaptive-media-delivery/docs/existing-properties-and-mmc#existing-properties-and-mmc)

Mixed Mode Configuration (MMC) is only available in a new version of a property.

As is the case with any property in Property Manager, once you edit it, a new version is created. Only this new version of the property will have the MMC updates included. We highly recommend that you only promote any updates to a property to the Staging network and thoroughly test it before pushing to Production.

You can always migrate back to an earlier "working" version of your property if you run into problems.

# [Verify your origin set up](https://techdocs.akamai.com/adaptive-media-delivery/docs/existing-properties-and-mmc#verify-your-origin-set-up)

This may seem simple, but if you plan to incorporate live and video on demand (VoD) media in the same property, ensure that you have the Origin Server set up properly in the applicable rules.

- **VoD media**. In Segmented Media Delivery Mode, set Mode to **On Demand** and in Origin Server, set Origin Type to **Your Origin** or **NetStorage**. Define settings in the Origin Characteristics behavior accordingly.

- **Live media**. In Segmented Media Delivery Mode, set Mode to **Live** and in Origin Server, set Origin Type to **Media Services Live** or **Your Origin**. Define settings in the Origin Characteristics behavior accordingly.