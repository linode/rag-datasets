# [Mixed Mode](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd#mixed-mode)

Mixed Mode lets you use the same use case-based behaviors in multiple rules in the same Adaptive Media Delivery (AMD) property. This lets you simplify the configuration process and also get the best performance, by applying best practices for each use case.

# [The old way vs. the new way: Mixed Mode Configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd#the-old-way-vs-the-new-way-mixed-mode-configuration)

With a traditional AMD property&mdash;the "old way"&mdash;the various use case-based behaviors for optimization are limited to the Default Rule in the property, which uses a match criteria of "all requests." A Mixed Mode Configuration (MMC)&mdash;the "new way"&mdash;lets you set up a single property and include these behaviors in multiple rules, and set up different match criteria.

Before, you had to create an individual property to deliver on-demand media, and another to deliver live media, you can now create one. You had to create one property to optimize delivery of lower resolution of content, and a second to optimize the delivery of higher resolution content. Now you can create a single property to optimize the delivery of both, based on specific match criteria. In some cases, you can even combine multiple MMC use cases into a single property.

# [What are use case-based behaviors?](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd#what-are-use-case-based-behaviors)

There are various behaviors included in the Default Rule with your AMD property, that are used to implement "use case-based provisioning" for delivery of your content. You should familiarize yourself with these "use case-based" behaviors and how they're applied before you start using MMC.

These behaviors are required in the Default Rule of a property for AMD. MMC allows you to also include them in additional rules with their own unique match criteria. The use case-based behaviors for AMD include:

- [Client Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-charac-amd)
- [Content Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd)
- [Origin Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-charac-amd)
- [Segmented Media Delivery Mode](https://techdocs.akamai.com/adaptive-media-delivery/docs/segmented-media-deliv-mode-amd)

# [Property rule and behavior logic, and MMC](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd#property-rule-and-behavior-logic-and-mmc)

When applying rules in a property, the bottom rule in the list is reviewed first: if its match criteria is met by a request for content, the settings in its behaviors are applied for that request. The Default Rule is processed last and its behaviors' settings are applied to all requests. In the case of duplicate behaviors, if the match criteria in all other rules in the property don't match the request, the instance of the behavior in the Default Rule is used.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-mixed-mode-rule-order-v1.jpg)

So, with MMC consider the following:

- **Use case-based behaviors are required in the Default Rule**. If you added a use case-based behavior to a custom rule to support MMC, and that rule's match criteria is not met by a request, the settings applied in the Default Rule for the same use case-based behavior are applied for the request.

- **Rule logic "trickles down"**. Rules stack and the last rule listed is read first. If a request does not meet the match criteria in the last rule, the second-to-the-last rule is checked next, and so on. Consider this when applying the same use case-based behavior in multiple rules. For example, you've set up two rules with unique match criteria, along with the Default Rule that applies to all requests. They all contain the "Content Characteristics" behavior. If the match criteria in the second (last) rule isn't matched by a request, the first rule is checked. If that criteria isn't matched, what's set in the Default Rule would be used.

- **Remember that the Default Rule is still applied to all requests**. Behaviors included in the Default Rule, but not in a custom rule are applied to requests, too. So, if you set up a non-use case-based behavior in the Default Rule, its settings are also applied to a request. However, if you set up the same behavior in the custom rule, and that rule's match criteria is met, that behavior's settings are used, rather than what's in the Default Rule.

# [How to enable MMC](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd#how-to-enable-mmc)

There is no specific enablement required for use. However, MMC is only available in a new AMD property. You can't apply it to the existing version of a property.

You can edit an existing property to create a *new version* of it and apply MMC in that new version. There are caveats to this, and they're discussed in [Existing properties and MMC](https://techdocs.akamai.com/adaptive-media-delivery/docs/existing-properties-and-mmc).