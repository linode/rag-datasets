# [Origin IP access control list](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-ip-access-control-list-amd#origin-ip-access-control-list)

Origin IP access control list, or "Origin IP ACL" helps protect your origin by restricting traffic to it through a small and stable list of IP addresses. Once Origin IP ACL is in place, your origin server will only honor requests from Akamai edge servers that are issued from one of these addresses.

# [How to set up Origin IP ACL](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-ip-access-control-list-amd#how-to-set-up-origin-ip-acl)

Origin IP ACL is available for use with several ​Akamai​ products. For set up instructions, check out the [Origin IP ACL user documentation](https://techdocs.akamai.com/origin-ip-acl/docs/welcome).