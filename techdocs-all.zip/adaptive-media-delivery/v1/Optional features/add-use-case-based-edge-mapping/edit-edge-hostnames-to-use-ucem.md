# [Edit edge hostnames to use Media Delivery Type](https://techdocs.akamai.com/adaptive-media-delivery/docs/edit-edge-hostnames-to-use-ucem#edit-edge-hostnames-to-use-media-delivery-type)

Existing edge hostnames can be edited to modify Media delivery type settings, but caveats apply.

You may need to edit your edge hostname for multiple reasons:

- You want to add Media delivery type Mapping Solution to an existing property configuration that doesn't currently have it.
- You want to change the current Media delivery type setting for an edge hostname.

# [How to edit an edge hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/edit-edge-hostnames-to-use-ucem#how-to-edit-an-edge-hostname)

While you can edit various edge hostname settings via Property Manager or Edge Hostname Editor, _you can't modify anything related to edge map usage_. Changing map usage may have a significant impact on performance for existing configurations.

In special circumstances, your Media delivery type settings can be modified with assistance from Akamai. Contact your account representative for details.

 > Warning: 
  Do you have multiple property configurations set up to use the same edge hostname? If so, review each configuration to ensure that editing the edge hostname won't negatively impact it.
