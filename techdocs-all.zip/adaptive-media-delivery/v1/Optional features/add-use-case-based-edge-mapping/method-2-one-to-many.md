# [Method 2: One to many](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-2-one-to-many#method-2-one-to-many)

This method implements Media delivery type Mapping Solution to optimize delivery of both on-demand ("VOD") and live media using a single AMD property configuration.

# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-2-one-to-many#before-you-begin)

This method also uses our Mixed Mode Configuration (MMC) feature. You should [familiarize yourself with MMC and how it's applied](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd)".

# [Create the first edge hostname for VOD](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-2-one-to-many#create-the-first-edge-hostname-for-vod)

We're using Property Manager to create the new property configuration for AMD. In it, we define multiple property hostname to edge hostname associations ("property hostnames"). The first enables "VOD" as its segmented media mode.

1. [Create a new property hostname using secure delivery (HTTPS)](https://techdocs.akamai.com/property-mgr/docs/serve-content-over-https). In this example, we're using "myvideos-vod.com" as the property hostname.

2. When you reach the Mapping Solution phase of the wizard, ensure **Media delivery type** is selected and set Segmented Media Mode to **VOD**.

 > Note: 
  If you also have Edge IP Binding on your contract, it's revealed here, too. You can't use both mapping solutions in the same property hostname.

3. Look at your new property hostname and verify that "VOD" has been applied as the Mapping Solution. If it has, the edge hostname that's used by this property hostname has been set to use an optimal edge map for the delivery of on-demand content.

## [Did you create your hostname using Edge Hostname Editor?](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-2-one-to-many#did-you-create-your-hostname-using-edge-hostname-editor)

If you used the [Edge Hostname Editor](https://techdocs.akamai.com/edge-hostnames/docs/welcome-edge-hn-editor) in ​Akamai Control Center​, you also need to know the _complete name_ of your edge hostname. Follow the same process discussed above, using the Media delivery type feature to select **VOD**. In the next window, click the pencil icon () and choose **Select existing**. You're shown a list of existing edge hostnames, filtered by the specified IP Version. Locate and select the edge hostname that has "VOD" set as its Mapping Solution.

# [Create the second edge hostname for live](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-2-one-to-many#create-the-second-edge-hostname-for-live)

Repeat the same process illustrated in the section above. However, when you reach the Mapping Solution phase of the wizard, ensure **Media delivery type** is selected and set Segmented Media Mode to **Live**. In this example, we're using "myvideos-live.com" as the property hostname.

Additional points to consider here:

- If you have Edge IP Binding on your contract, it can't be used with Media delivery type.

- If you created your edge hostname using the Edge Hostname Editor, the **Note:** above applies, but you need to select the edge hostname that has **Live** set as its Segmented Media Mode.

# [Set up the Default Rule for Live](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-2-one-to-many#set-up-the-default-rule-for-live)

Now, we implement MMC to apply use case-based behaviors in separate rules. For this example, we'll start with the Default Rule for requests to the "Live" Use Case edge hostname.

 > Note: 
  This is not required. You can configure the Default Rule for VOD content if desired. You just need to configure the subsequent rule (below) to handle requests for VOD, instead of using what's discussed here.

The Segmented Media Delivery Mode behavior is automatically included in this rule, as a "use case-based behavior." To sync with the Media delivery type settings for the applicable edge hostname, set this to "Live."

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-ucem-seg-media-del-v1.jpg)

There are additional required and optional settings to apply in the Default Rule:

- **Advanced Options**. With **Live** set as the Segmented Media Delivery Mode, additional options are available via the Show Advanced Options slider. Live media delivery is accomplished using Media Services Live (MSL), and these are used when configuring it for use with AMD. They are discussed in the [Media Services Live user documentation](https://techdocs.akamai.com/msl/docs/setup-media-services-live-origin).

 > Warning: 
  These options only apply to the use of Akamai's Media Services Live product with AMD. They can't be used with your own custom live media configuration.

- **The Origin Server behavior**. Here, you need to select **Media Services Live** as the Origin Type. You also need to set up a new live stream using MSL, outside of Property Manager. Both of these are also covered in the _Media Services Live 4.x User Guide_.

- **Configure other behaviors in the Default Rule**. Apply settings for each, as desired. Remember: _Any behavior applied in the Default Rule applies to all requests_. So, if you haven't set the same behavior in another rule, what's set for it here is applied. Review all of your behavior settings in the Default Rule and all subsequent rules.

# [Set up a new rule for VOD](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-2-one-to-many#set-up-a-new-rule-for-vod)

Here, we'll add a subsequent rule, the "On demand media delivery rule." We'll configure it to specifically field requests for the "VOD" mode edge hostname. Rule precedence in Property Manager dictates that a lower rule in the list is applied _first_, and its settings override matching settings in a rule higher in the list. So, requests to the VOD mode edge hostname:

- Read this rule and apply its settings first for on-demand delivery.

- Read the Default Rule and apply any additional settings you've set here that weren't set in the On demand UCEM delivery rule. (This occurs because the Default Rule applies to all requests.)

Follow these steps to set up this rule:

1. In the Property Configuration Settings click **Add Rule**.

2. Ensure **Blank Rule Template** is selected (default) and click **Insert Rule**.

3. Click the gear icon in the New Rule and select **Edit Name**. Input a desired name ("On demand Media Delivery Rule") and press **Enter**.

4. Click **Add Match** and set the fields as follows:

   - **Hostname**
   - **is one of**
   - **Select Items**. Click this field and input the Property Hostname you associated with the "VOD" mode edge hostname (using the examples from this use case, this would be, "myvideos-vod.com").

5. Click **Add Behavior**.

6. Type "segment" in _Search available behaviors_ to filter results, select **Segmented Media Delivery Mode**, and click **Insert Behavior**. Set Mode to **On demand**.

7. You also need to provide a proper Origin Server to serve your on-demand content. (The Default Rule has "Media Services Live" set as its origin, and that won't work.) Click **Add Behavior**.

8. Type "origin" in _Search available behaviors_ to filter results, select **Origin Server**, and click **Insert Behavior**. Set the options in this behavior as follows:

   - **Origin Type**: For this use case, we're using **NetStorage**.
   - **NetStorage Account**: Click to select the NetStorage account associated with the Storage Group that houses the on-demand content to be delivered.

9. You can add more behaviors, including use case-based ones supported for use with MMC. This includes [Origin Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/origin-charac-amd), [Content Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd), and [Client Characteristics](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-charac-amd), as well as other [recommended](https://techdocs.akamai.com/adaptive-media-delivery/docs/rcmd-behs-default-rule) and [optional](https://techdocs.akamai.com/adaptive-media-delivery/docs/optal-behs-default-rule) behaviors. What you set here for any behavior will override what's set in the Default Rule for these same behaviors, when a request for on-demand content is received.

10. **Save** the property configuration.

# [What's next?](https://techdocs.akamai.com/adaptive-media-delivery/docs/method-2-one-to-many#whats-next)

Once you've completed and saved the property configuration, you need to:

- **Activate it on the Staging network and [test](https://techdocs.akamai.com/adaptive-media-delivery/docs/test-amd-prop)  it**.

- **Activate it on the Production network and [go live](https://techdocs.akamai.com/adaptive-media-delivery/docs/go-live)**. At this phase, you update your DNS record to CNAME your property hostnames for live and on-demand requests to the applicable edge hostname you created:

  - **Requests to the property hostname for live content will be optimized to the "Live" mode edge map.**They'll also ignore the "On demand Media Delivery Rule" and apply settings defined in the Default Rule.

  - **Requests to the property hostname for on-demand content will be optimized to the "VOD" mode edge map**. They also trigger the "On demand Media Delivery Rule" and use behaviors applied in it. Any additional, applicable behaviors set in the Default Rule are also applied.