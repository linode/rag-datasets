# [Mismatch issues and Media delivery type](https://techdocs.akamai.com/adaptive-media-delivery/docs/mismatch-issues-and-ucem#mismatch-issues-and-media-delivery-type)

You may encounter a "mismatch" between what you've set in a property hostname's Mapping Solution for an edge hostname, and what's applied in the "use case-based" behavior in the rules in your property configuration.

Here, we describe some of these mismatch conditions, and how to resolve them.

# [Incorrect mapping from your property hostname to edge hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/mismatch-issues-and-ucem#incorrect-mapping-from-your-property-hostname-to-edge-hostname)

The first step to resolve any mismatch is to make sure that the mapping from the property hostname to the edge hostname in Property Manager is accurate. This mapping must match the DNS CNAME record that translates your property hostname to the edge hostname that was generated.

# [Does your Media delivery type setting match the mode-based behavior?](https://techdocs.akamai.com/adaptive-media-delivery/docs/mismatch-issues-and-ucem#does-your-media-delivery-type-setting-match-the-mode-based-behavior)

With Adaptive Media Delivery, what you've set for the Media delivery type: Segmented Media Mode and the Segmented Media Delivery Mode behavior setting must match. For example, your Adaptive Media Delivery configuration has set "**VOD**" as the Media Delivery Mode for the edge hostname. So, the Segmented Media Delivery Mode behavior  must be set to **On demand**.