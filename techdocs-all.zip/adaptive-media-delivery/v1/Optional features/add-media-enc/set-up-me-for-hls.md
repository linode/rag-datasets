# [Set up ME for HLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-hls#set-up-me-for-hls)

Review these sections to add media encryption to your AMD property to encrypt HLS-format segments.

# [HLS player requirements](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-hls#hls-player-requirements)

The player you use needs to meet some prerequisites.

Requirement | Description |  **Use HTTPS**  |  This reduces the possibility of a man-in-the-middle attack that could compromise an encrypted media stream. Make sure your player is connecting to the Akamai edge network using HTTPS. This helps protect all applicable media keys, manifests, and playlists during delivery. _HTTP connections are not supported._ Individual media segments can be delivered through a standard HTTP connection from your origin to edge servers, but we recommend that you set up your AMD property to use HTTPS, exclusively. \- See [Prepare your edge certificate](https://techdocs.akamai.com/property-mgr/docs/prepare-your-edge-certificates) for information on setting up your property to secure the connection between your player and the Akamai edge network. \- See [Prepare your origin server](https://techdocs.akamai.com/property-mgr/docs/prepare-your-origin-server) for information on securing the connection between the edge network and your origin server.   
 ---|---  
 **Manifest specification**  |  Manifest files associated with your target HLS-format content must comply with the formatting described in the [HTTP Live Streaming Protocol Specification](https://tools.ietf.org/html/draft-pantos-http-live-streaming-20). If a manifest deviates from this specification, media encryption _will not work_.   
 **AES-128 encryption is used**  |  Media encryption only supports AES-128 because it's the most commonly used. Any player you're using must support AES-128.   
 **Akamai needs to be your key server**  |  You can't use a third-party key server. By adding Media Encryption to your AMD property, you automatically set Akamai as your key server. There's nothing more you need to do. 

# [Add it to your property](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-hls#add-it-to-your-property)

To enable media encryption, you need to apply specific settings:

 > Warning: About the initialization vector
  With previous versions of media encryption for HLS, you could manually define an **Initialization Vector**. It served as added protection when AES-128 encrypting the key files. If you used the previous version of media encryption, you'll be asked to update to the new version. If you upgrade and go live with your AMD property, any inflight streams that use the initialization vector will result in disablement of service (DOS) in a the player. 
  The new version of media encryption dynamically creates this value for each session. A manual instance of an initialization vector is no longer needed.

1. In the Segmented Media Protection behavior, set the HLS Encryption to "**On**".

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-me-hls-v1.png)

2. You should enable [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth), too. It's also available in the Segmented Media Protection behavior. It protects client access to the key file by using secure, long tokens.

3. With settings defined as desired, click **Save** to apply.

## [Specific path matches in a custom rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-hls#specific-path-matches-in-a-custom-rule)

If you incorporate a custom rule with specific path matches and apply media encryption for content in those paths, you also need to include the proper path to the media encryption "key file" as a path match: `/serve.key`.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-me-hls-path-matches-v1.png)

You need to do this because the manifest associated with your target content always looks to `/serve.key` to find this key. If you don't add this path match, when this AMD property is run for a request, edge servers won't be able to find the Media Encryption behavior. So, the key isn't generated and the stream fails.

# [Caveats and known issues](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-hls#caveats-and-known-issues)

There are some things that can limit the use of media encryption in some scenarios. Before you go live with it, review these key points and take the appropriate measures.

Issue | Description |  **Byte-range playlists aren't supported**  |  When media encryption is enabled for a stream with byte-range segments, incorrect byte ranges can be reported in the playlist file. So, when a player transitions from one bit rate to another, it can fail to append the new segment to the previous one in its playback buffer. Symptoms of this include playback failure and audio and video sync issues. We're looking to add support for byte-range requests with a future release.   
 ---|---  
 **Existing stream-level encryption is passed through**  |  If content served by your AMD property is already encrypted using stream-level encryption (such as data encrypted via a DRM system implemented on your origin server), it won't be encrypted further. The encrypted content will just be passed through. 