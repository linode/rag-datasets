# [Set up ME for both](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-both#set-up-me-for-both)

If you want to use media encryption for both DASH and HLS-format segments, you'll need to set up your environment and your AMD property a little differently.

 > Note: DASH support is Limited Availability
  Media Encryption for DASH is currently only available to selected customers. Talk to your Akamai account team to see if you're eligible.

# [Ready your content](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-both#ready-your-content)

We recommend that you separate your DASH and HLS media content in different subdirectories on your origin server. For example, something like this:

```

/hls/*

/dash/*
```

Of course, the path can be more elaborate than this, but we'll be using these paths as examples in this exercise.

# [Ready your player](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-both#ready-your-player)

The player requirements discussed in the [DASH](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-dash#dash-player-requirements) and [HLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-hls#hls-player-requirements) instructions apply here, too.

# [Ready your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-both#ready-your-amd-property)

By default, the Segmented Media Protection behavior is added to the Default Rule, which applies to all requests. To support both media formats with media encryption, you need to set up a custom rule for each, add an instance of the Segmented Media Protection behavior, and configure specific match criteria:

1. Access the **Segmented Media Protection** behavior in the Default Rule. 

2. Make sure that _both_ HLS Encryption and DASH Encryption are set to **Off**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-me-both-default-rule-v1.png)

3. Click **+ Rules**.

4. Select the **Blank Rule Template** and click **Insert Rule**.

5. In the New Rule, select **...** > **Edit Name**. Enter something easily recognizable like "DASH ME rule."

6. Click **+ Match** and set the **If** options:  

   - Select **Path**
   - Select **matches one of**
   - Enter the following values in the field:
     - `/AquireLicense`. This is the DASH license request path. This is a fixed value because a request for the license key components always looks to this path.
     - `/dash/*`. This is the path to the [separate directory](#your-content) of DASH-format media on your origin server.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-me-both-dash-criteria-v1.png)

7. Select **+ Behavior** > **Standard property behavior**.

8. Type `Segment` in the _Search available..._ field, select **Segmented Media Protection** and click **Insert Behavior**.

9. Enable **DASH Encryption** and ensure that all other options are _disabled_.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-me-dash-both-enable-v1.png)

10. Click **+ Rules**.

11. Select the **Blank Rule Template** and click **Insert Rule**.

12. Rename this rule to something like "HLS ME Rule."

13. Click **+ Match** and set the **If** options:

    - Select **Path**
    - Select **matches one of**
    - Enter the following values in the field:
      - `/serve.key`. This is the HLS license request path. This is a fixed value because a request for the license key components always looks to this path.
      - `/hls/*`. This is the path to the [separate directory](#your-content) of HLS-format media on your origin server.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-me-both-hls-criteria-v1.png)

14. Select **+ Behavior** > **Standard property behavior**.

15. Type `Segment` in the _Search available..._ field, select **Segmented Media Protection** and click **Insert Behavior**.

16. Enable **HLS Encryption** and ensure that all other options are _disabled_.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-me-hls-both-enable-v1.png)

# [Address caveats and known issues (Required)](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-both#address-caveats-and-known-issues-required)

Both media formats have various known issues that apply to the use of media encryption. Review them for both [DASH](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-dash#caveats-and-known-issues) and [HLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-hls#address-hls-known-issues) and make sure you don't have any conflicts.

# [Add Token Auth (Recommended)](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-both#add-token-auth-recommended)

You should enable [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth), too. It protects client access to the key file by using secure, long tokens. Enable it in the Segmented Media Protection behavior instance in the Default Rule so that it applies to all requests.