# [Set up ME for DASH](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-dash#set-up-me-for-dash)

Review these sections to add media encryption to your AMD property to encrypt DASH-format segments.

 > Note: DASH support is Limited Availability
  Media Encryption for DASH is currently only available to selected customers. Talk to your Akamai account team to see if you're eligible.

# [Supported DASH players](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-dash#supported-dash-players)

Currently, media encryption is supported for use with these players:

- [DASH Javascript Player](https://reference.dashif.org/dash.js/nightly/samples/dash-if-reference-player/index.html) (DASH IF Reference Client)

## [DASH player requirements](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-dash#dash-player-requirements)

There are various prerequisites your DASH player needs to meet.

Requirement | Description |  **Use HTTPS**  |  This reduces the possibility of a man-in-the-middle attack that could compromise an encrypted media stream. Make sure your player is connecting to the Akamai edge network using HTTPS. This helps protect all applicable media keys, manifests, and playlists during delivery. _HTTP connections are not supported._ Individual media segments can be delivered through a standard HTTP connection from your origin to edge servers, but we recommend that you set up your AMD property to use HTTPS, exclusively. \- See [Prepare your edge certificate](https://techdocs.akamai.com/property-mgr/docs/prepare-your-edge-certificates) for information on setting up your property to secure the connection between your player and the Akamai edge network. \- See [Prepare your origin server](https://techdocs.akamai.com/property-mgr/docs/prepare-your-origin-server) for information on securing the connection between the edge network and your origin server.   
 ---|---  
 **Support the Clear Key DRM system**  |  Your player needs to support Clear Key, as required by [W3C Encrypted Media Extensions (EME)](https://www.w3.org/TR/encrypted-media/#common-key-systems).   
 **Support AES-128 encryption mode**  |  Encrypted DASH content needs to use either the `cenc` or the `cbcs` [protection schemes](https://dashif.org/guidelines/iop-v5/#part-6-content-protection-and-security). To change the default `cbcs` scheme, set up your player to include this query string value in requests: `aka_dme_enc=cenc`. You can also consistently override the default `cbcs` scheme in all requests with the [Advanced](https://techdocs.akamai.com/property-mgr/docs/adv-beh) behavior. Reach out to Akamai Professional Services to have this configured for you.   
 **SegmentTemplate, only**  |  Your manifest files need to use `SegmentTemplate` format. Currently, `SegmentBase` and `SegmentList` format manifests aren't supported. (`SegmentList` format is also not recommended by the DASH-IF.)   
 **Akamai needs to be your key server**  |  You can't use a third-party key server. By adding Media Encryption to your AMD property, you automatically set Akamai as your key server. There's nothing more you need to do. 

# [Add it to your property](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-dash#add-it-to-your-property)

To enable media encryption, you need to apply specific settings:

1. In the Segmented Media Protection behavior, set DASH Encryption to "**On**".

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-me-dash-v1.png)

2. You should enable [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth), too. It's also available in the Segmented Media Protection behavior. It protects client access to the key file by using secure, long tokens.

3. With settings defined as desired, click **Save** to apply.

## [Specific path matches in a custom rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-dash#specific-path-matches-in-a-custom-rule)

If you incorporate a custom rule with specific path matches and apply media encryption for content in those paths, you also need to include the proper path to the media encryption "key file" as a path match: `/AcquireLicense`.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-me-dash-path-matches-v1.png)

You need to do this because the manifest associated with your target content always looks to `/serve.key` to find this key. If you don't add this path match, when this AMD property is run for a request, edge servers won't be able to find the Media Encryption behavior. So, the key isn't generated and the stream fails.

# [Caveats and known issues](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-me-for-dash#caveats-and-known-issues)

There are some things that can limit the use of media encryption in some scenarios. Before you go live with it, review these key points and take the appropriate measures.

Issue | Description |  **Byte-range playlists aren't supported**  |  When media encryption is enabled for a stream with byte-range segments, incorrect byte ranges can be reported in the playlist file. So, when a player transitions from one bit rate to another, it can fail to append the new segment to the previous one in its playback buffer. Symptoms of this include playback failure and audio and video sync issues. We're looking to add support for byte-range requests with a future release.   
 ---|---  
 **SegmentTemplate identifiers are not supported within a segment path**  |  A DASH SegmentTemplate manifest offers support for various identifiers, such as `$Number$`, `$Time$`, or `$RepresentationId$`. They can serve as variables that are populated with a specific value when a request is made for your media content. For example, `$Time$` would be replaced with the actual time of the request. Since these values are variable, you can’t include them _in the path_ for a segment because media encryption signature validation would fail. However, you can include them in the segment filename: \- **Supported**: `//$Number$-manifest.mpd` \- **Not supported**: `/-$Time$/$Number$-manifest.mpd`   
 **Existing stream-level encryption is passed through**  |  If content served by your AMD property is already encrypted using stream-level encryption (such as data encrypted via a DRM system implemented on your origin server), it won't be encrypted further. Pre-encrypted content will just be passed through to the client.   
 **HTTP/2 is not supported**  |  An `HTTP2 FRAME SIZE ERROR` has been seen when clients try to fetch DASH segments when media encryption is enabled.   
 **Partial Object Caching is not supported**  |  Partial object caching makes a series of range requests to fetch a segment. The content is received in ranges and the encryption logic is not supported when the content received is in ranges.   
 **Bit Rate Limiting is not supported**  |  Currently, [Bit Rate Limiting](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting) is not supported due to buffer issues.   
 **Live playback issues with Firefox**  |  We've seen video distortions while playing encrypted DASH content on Firefox. Sometimes the distortions are observed in the beginning and improve as the stream progresses. Other times we've seen them a few minutes into the stream.   
 **Issue with manifest files that use the BaseURL tag**  |  Media encryption doesn't work if the `BaseURL` tag is present in a DASH manifest. With BaseURL, the signature generation mechanism needs a canonical base path. The Akamai network doesn't currently consider the value of BaseURL tag.   
 **AquireLicense server request fails with CORS error**  |  A request to the AcquireLicense server that's used with ClearKey DRM can fail on the player when accompanied by a CORS request. This is because it expects the `Content-Type` header to be added to the Access-Control-Allow-Headers. To fix this issue, you can add `Content-Type`: 1\. Access the **Default CORS Policy** rule in your Akamai property. 2\. Find the Modify Outgoing Response Header behavior with **Access-Control-Allow-Headers** set as the Select Header Name. 3\. Add **Content-Type** to the new Header to the New Header Value field.  ![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-me-cors-issue-v1.png)  
 **Instances of the "DRM: unable to create session!" error**  |  The [DASH JavaScript Player](https://reference.dashif.org/dash.js/v4.4.0/samples/dash-if-reference-player/index.html) has intermittently shown this error when ClearKey encryption is used in a stream. Try refreshing the player and retry playback to remove the error. See this [GitHub page](https://github.com/Dash-Industry-Forum/dash.js/issues/3949) for more details.   
 **Hostname Override isn't supported**  |  Media encryption doesn't work with DASH streams if you have a hostname override set in your AMD property using \\``AKA_PM_TO_BE_ENCRYPTED_HOSTNAMES`.   
 **HEVC / H.265 / MPEG-H Part 2 isn't supported**  |  Currently, the supported video compression standard is Advanced Video Coding / H.264 / MPEG-4 Part 10.   
 **Standard format isn't supported**  |  Media encryption currently does not work with DASH streams on standard formats such as Azure. 