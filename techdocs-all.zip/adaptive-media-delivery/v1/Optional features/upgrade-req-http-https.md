# [HTTP to HTTPS Upgrade](https://techdocs.akamai.com/adaptive-media-delivery/docs/upgrade-req-http-https#http-to-https-upgrade)

HTTP to HTTPS Upgrade converts HTTP (non-secure) requests from your clients to HTTPS between the Akamai edge network and your origin server, to secure the transfer of data between the two.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/http-https-upgrade-behavior-v1.jpg)

# [Get access to HTTP to HTTPS Upgrade](https://techdocs.akamai.com/adaptive-media-delivery/docs/upgrade-req-http-https#get-access-to-http-to-https-upgrade)

You need to have this added to your contract to access the appropriate behavior in Property Manager. Contact your account representative to add this functionality.

# [Set it up](https://techdocs.akamai.com/adaptive-media-delivery/docs/upgrade-req-http-https#set-it-up)

HTTP to HTTPS Upgrade is available for use with several ​Akamai products, and its configuration is the same for all of them. See the [Property Manager documentation](https://techdocs.akamai.com/property-mgr/docs/http-https-upgrade) for full usage instructions.