# [Breadcrumbs](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-breadcrumbs#breadcrumbs)

The "Breadcrumbs" feature looks to improve real-time visibility of performance-impacting and error conditions for media streaming with AMD.

# [What it does](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-breadcrumbs#what-it-does)

Breadcrumbs lets Akamai quickly do two things:

1. **Help you troubleshoot problems**. Troubleshooting a streaming delivery issue typically requires that you contact us and provide client-side and Akamai edge IP information. We consult log information, along with some amount of back and forth communication to diagnose the issue. Breadcrumbs provides more real-time visibility into the Akamai network, to better help us in troubleshooting your issues. While Akamai customer support can simply look at a specific line in a specific log file to identify a problem, they have to locate this "specific" content in the logs. With Breadcrumbs, a potential problem is specifically written as a "breadcrumbs" line in the logs, making it easier to locate.

2. **Leverage Breadcrumbs data via your player**. If your media player can support it, you can configure your player to get real-time insight regarding the Akamai network. Breadcrumbs includes data such as network health and the location in the Akamai network ("geo") used to serve content. You can aggregate this data from your player to a central location for review.

 > Note: 
  The actual root cause of an issue may not always be identifiable via breadcrumbs.

## [The bottom line](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-breadcrumbs#the-bottom-line)

The Breadcrumbs service provides per HTTP transaction visibility into the Akamai platform, regardless of how deep within that platform, and simplifies log review for troubleshooting.

# [How to set up Breadcrumbs](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-breadcrumbs#how-to-set-up-breadcrumbs)

Breadcrumbs is available for use with several Akamai​ products, and its configuration is the same for all of them. See the [Property Manager documentation](https://techdocs.akamai.com/property-mgr/docs/breadcrumbs-amd#add-breadcrumbs) for full usage instructions.