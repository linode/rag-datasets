# [Media Encryption](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-media-enc#media-encryption)

Add this feature to encrypt individual media segments, before delivering them to a requesting client. Here's an overview of how it works:

1. Information about the key used to decrypt content is included in the media manifest file.

2. Your media player (the client) requests your media, processes the manifest, and requests this key. 

3. Akamai, acting as the key server, provides the decryption key if the user is authenticated and authorized to play the content. 

4. The client uses the decryption key to decrypt and play the media segments.

Media encryption (ME) uses session-level encryption. The stream is encrypted for each user playback session, based on the stream, user, and time or date. Every new request for a stream is considered an individual session, which typically involves a request for the stream manifest. The decryption key is created per session and it's sent out dynamically when a new session is initiated. Each new session is independently encrypted with unique keys, and each separate user needs to access a separate key to decrypt the content.

# [The content protection hierarchy](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-media-enc#the-content-protection-hierarchy)

Akamai offers multiple levels of access and protection to secure your content. Here's where media encryption fits into our content protection hierarchy:

- **No protection: Open Access**. Anyone can access your content

- **Level 1: Token Auth**. An encrypted token in the request is compared against a token you've associated with your content. For added protection, we recommend that you combine [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth) along with media encryption, via the Segmented Media Protection behavior.

- **Level 2: Geo Protection**. This _allows_ access to requesting clients in geographic regions or IP addresses/CIDR blocks you mark as _good_, or _blocks_ access to clients in regions or IP addresses/CIDR blocks you mark as _bad_. You can add it to your property via the [Content - Targeting Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot) behavior.

- **Level 3: HTTPS Protection**. [Configure](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-hn) your AMD property to access and send content via secure delivery.

- **_Level 4: Media Encryption_**.

- **Additional protection: DRM Encryption**. This prevents access to only those clients that have been authorized to have a DRM license for the playback environment or content, including additional rights management rules.

Akamai attempts to improve the default media encryption use case, which is typically one key for each piece of content, by making the content decryption keys session-specific. For example, "User 1" and "User 2" accessing the same content have different decryption keys.

# [Supported media formats](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-media-enc#supported-media-formats)

Media encryption is supported for use with the [Segmented Media Delivery Modes](https://techdocs.akamai.com/adaptive-media-delivery/docs/segmented-media-deliv-mode-amd) of **On Demand**, or **Live** (using Akamai Media Services Live), for the following media formats:

- Apple HTTPS Live Streaming (HLS)
- Dynamic Adaptive Streaming over HTTP (DASH)