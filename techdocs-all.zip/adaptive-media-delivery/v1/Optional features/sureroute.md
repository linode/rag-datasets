# [SureRoute](https://techdocs.akamai.com/adaptive-media-delivery/docs/sureroute#sureroute)

SureRoute tests multiple routes between the Akamai edge server and your origin server to identify an optimal path for performance. It also establishes alternative routes to deal with potential request failures. 

It's supported for use with several delivery products, and its setup isn't unique to Adaptive Media Delivery. Have a look at the Property Manager's [SureRoute documentation](https://techdocs.akamai.com/property-mgr/docs/sureroute-beh) for complete details.

### [Is all of your content cacheable?](https://techdocs.akamai.com/adaptive-media-delivery/docs/sureroute#is-all-of-your-content-cacheable)

SureRoute is best-suited for non-cacheable content such as no-store or bypass-cache objects. It's automatically disabled when Akamai edge servers recognize that your content is cacheable. This is because cacheable content is best-served from an edge server cache and not from a route to your origin. If you're sure that all of your content is cacheable, we recommend that you disable this feature.

 > Warning: SureRoute can't be used with Cloud Wrapper.
  If you've added the [Cloud  Wrapper](https://techdocs.akamai.com/adaptive-media-delivery/docs/cloud-wrapper) service to your Adaptive Media Delivery property, you need to disable SureRoute.