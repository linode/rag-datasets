# [Protocol Downgrade for Enhanced TLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-legacy-protocol-downgrade-behavior#protocol-downgrade-for-enhanced-tls)

Property Manager offers a behavior named, "Protocol Downgrade." It's used to downgrade from Enhanced TLS certificate (HTTPS L3) security to HTTP for the connection between the <
> edge and your origin server.

# [How it works](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-legacy-protocol-downgrade-behavior#how-it-works)

You'd add this behavior if you're using an Enhanced TLS certificate (HTTPS L3) in your property hostname and you want to serve static objects to the end-user client over HTTPS, but fetch them from the origin via HTTP. This eliminates the need for a secure certificate on your origin server, for requests that originate with an Enhanced TLS certificate.

# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-legacy-protocol-downgrade-behavior#before-you-begin)

Before you set up this behavior, review the points here to familiarize yourself with its various features and limitations.

- **No PII**. You can't deliver personally identifiable information (PII) if using these behaviors. See [No personally identifiable information (PII)](https://techdocs.akamai.com/adaptive-media-delivery/docs/no-personally-identifiable-information-pii) for more information.

- **A downgrade is restricted to GET, HEAD, and OPTIONS methods**.

- **This behavior doesn't allow whole site downgrades**. For example, you can't use these behaviors to downgrade delivery of the full site, `www.mymediasite.com` from your origin.

- **Limits based on file extension**. You can only apply Protocol Downgrade to media assets with the following file extensions: `m3u8, ts, aac, mp3, vtt, f4m, f4f, bootstrap, ism, csm, ismc, isml, ismv, isma, 3g2, 3gp, aac, asf, avi, dv, f4v, flv, f4a, m4a, m4v, m4p, matroska, mj2, mkv, mov, mp3, mp4, mpeg, mpegts, mpg, mxf, ogg, ts, webm, wmv, jpg, gif, png, ico, bmp`. You can't use Protocol Downgrade on any request for HTML, JavaScript, or executable file types.

- **Forward request content restrictions**. The forward HTTP request to the origin will be stripped of all cookies, query strings, and referer information.

- **You can include all headers in a downgraded request, except these**:

  - `Origin`
  - `Referer`
  - `Cookie`
  - `Cookie2`
  - `sec-*`
  - `proxy-*`

- **Custom certificate restrictions**. Any HTTPS connection terminated on the PCI-compliant secure network (that is, HTTPS requests using a custom certificate) are first forwarded using the Akamai shared certificate before going forward to the origin using HTTP. This may result in additional midgress costs. No protocol downgrade is applied directly on the PCI-compliant network.

## [Understand appropriate behavior scoping](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-legacy-protocol-downgrade-behavior#understand-appropriate-behavior-scoping)

 > Error: 
  If you include Protocol Downgrade, you're assuming all liability for all information that's transferred using it.

When you implement Protocol Downgrade in Property Manager, you should enclose the behavior in a rule to restrict it to content that is appropriate to transfer over HTTP. This rule can use [URL path](https://techdocs.akamai.com/property-mgr/docs/path-match), [query string](https://techdocs.akamai.com/property-mgr/docs/query-string-param), [filename](https://techdocs.akamai.com/property-mgr/docs/filename-match), [file extension](https://techdocs.akamai.com/property-mgr/docs/file-ext) or any other property of the request that would identify it as safe to transfer over HTTP.

# [Add Protocol Downgrade](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-legacy-protocol-downgrade-behavior#add-protocol-downgrade)

This behavior requires permission for use, and you need to work with your Akamai account representative to add advanced configuration settings to implement it. If you've never used this behavior, it won't be available for use in your AMD property.