# [Migrate from Enhanced TLS to Standard TLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/migrate-from-enhanced-tls-to-standard-tls#migrate-from-enhanced-tls-to-standard-tls)

If you're using the Protocol Downgrade behavior with an Enhanced TLS (L3) certificate securing your AMD property, and you need to migrate to a less secure Standard TLS/shared certificate connection (L1), you have multiple options:

- **Migrate to Standard TLS and then add Protocol Downgrade (HTTPS Downgrade to Origin)**. If you don't need the stringent protection that an L3 certificate provides, you can migrate to L1. When migrating, you need to account for the cache migration duration—L3 security will be applied until its associated certificate expires, and then reverts to your L1 certificate. After the revert, you can apply the Protocol Downgrade (HTTPS Downgrade to Origin) behavior.

- **Create a new AMD property and implement Standard TLS or the shared certificate**. You can generate a new configuration to deliver your content and apply Standard TLS or shared certificate protection. You can then apply the Protocol Downgrade (HTTPS Downgrade to Origin) behavior. You'd then need to redirect requests for your content to the property hostname you set in this property.

- **Keep the Protocol Downgrade behavior**. If you need L3 security, you need to keep Protocol Downgrade set in your property. If your certificate needs to be PCI compliant, you need to use this method. All other certificate levels offered by Akamai (Standard TLS and Shared Certificate) are *not* PCI-compliant.