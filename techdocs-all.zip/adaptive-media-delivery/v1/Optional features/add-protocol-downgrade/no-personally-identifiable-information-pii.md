# [No personally identifiable information (PII)](https://techdocs.akamai.com/adaptive-media-delivery/docs/no-personally-identifiable-information-pii#no-personally-identifiable-information-pii)

Personally Identifiable Information (PII) can't be delivered via a property that uses any form of Protocol Downgrade—Enhanced TLS or Standard TLS. PII is any information about an individual maintained by an agency. This includes the following:

- **Information that can be used to distinguish or trace an individual's identity**. This includes an individual's name, social security number, date and place of birth, mother's maiden name, or biometric records.

- **Other information that is linked or linkable to an individual**. This includes medical, educational, financial, and employment information.

# [Don't incorporate the Personally Identifiable Information (PII) rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/no-personally-identifiable-information-pii#dont-incorporate-the-personally-identifiable-information-pii-rule)

If you include it in your property, and then add either the Protocol Downgrade (Enhanced TLS) or Protocol Downgrade (HTTPS Downgrade to Origin - Standard TLS) behaviors anywhere in the configuration, an error is raised. You won't be able to save the configuration until that rule, or either behavior is removed.

# [More information](https://techdocs.akamai.com/adaptive-media-delivery/docs/no-personally-identifiable-information-pii#more-information)

Check out this reference for more information on [personally identifiable information (PII)](https://csrc.nist.gov/glossary/term/PII).