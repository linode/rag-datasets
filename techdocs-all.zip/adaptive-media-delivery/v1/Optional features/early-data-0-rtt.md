# [Early Data (0-RTT)](https://techdocs.akamai.com/adaptive-media-delivery/docs/early-data-0-rtt#early-data-0-rtt)

TLS 1.3 introduces Early Data, also known as zero round-trip time (0-RTT) data. It allows clients resuming a session to send application data during the TLS handshake, eliminating the need for an additional round trip.

 > Warning: 
  To use Early Data, your certificate needs to have transport layer security (TLS) 1.3 enabled in its deployment settings.

# [How it works](https://techdocs.akamai.com/adaptive-media-delivery/docs/early-data-0-rtt#how-it-works)

Establishing a secure connection between a client and server consists of a series of messages to exchange cryptographic information and communication parameters before sending actual data. Before TLS version 1.3, establishing a secure channel after the TCP handshake typically required two round trips (2-RTT). With the introduction of TLS 1.3, the TLS handshake has been reduced to one round trip (1-RTT) in most cases.

To further reduce Time To First Byte in TLS 1.3 connections, you can enable the Early Data behavior to allow clients that had previously connected to an edge server to send application data alongside the Client Hello, before performing a full TLS handshake. For more details, see [RFC 8470](https://datatracker.ietf.org/doc/html/rfc8470) and [RFC 8446](https://datatracker.ietf.org/doc/html/rfc8446). For security reasons, the default [Early Data (0-RTT)](https://techdocs.akamai.com/property-mgr/docs/early-data-0rtt) behavior only allows GET requests without query parameters. However, you can use the separate [Early Data (0-RTT) Advanced](https://techdocs.akamai.com/property-mgr/docs/early-data-0rtt-advanced) behavior to also allow query parameters with any of the GET, PUT, POST, DELETE, HEAD, and OPTIONS methods.

**Key technical details**

- The session tickets are valid for approximately 23 hours.
- We hand out two separate Session Tickets on each connection.
- The upper limit of the Early Data allowance is 128 KB per stream and 192 KB per connection.
- We use QUIC address validation tokens to remove amplification factor limits.
- Session resumption without Early Data remains allowed as well.
- We don’t support session ticket sharing (multi-CDN setup).

# [How to set up Early Data](https://techdocs.akamai.com/adaptive-media-delivery/docs/early-data-0-rtt#how-to-set-up-early-data)

Early Data is available for use with several Akamai​ products, and its configuration is the same for all of them. See the [Property Manager documentation](https://techdocs.akamai.com/property-mgr/docs/early-data-0rtt) for full usage instructions.