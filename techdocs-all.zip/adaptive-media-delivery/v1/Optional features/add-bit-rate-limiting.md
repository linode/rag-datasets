# [Bit Rate Limiting](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting#bit-rate-limiting)

Bit Rate Limiting lets you control the rate that Akamai serves AMD content to end users. You can optionally vary the speed based on file size or elapsed download time.

For example, apply it to prevent media downloads from progressing faster than they're consumed. You could also apply multiple instances of it to set up different end-user experience tiers of delivery performance&mdash;a higher bit rate maximum for requests from one URL, and a lower rate for another.

# [Don't include this in the Default Rule](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting#dont-include-this-in-the-default-rule)

The Default Rule in a property configuration applies to all requests. But, the Bit Rate Limiting behavior only supports these Match criteria in a rule:

- **File Extension**. Requests for a specific file type will have Bit Rate Limiting applied.

- **Filename**. Requests for a specific file will have Bit Rate Limiting applied.

- **Path**. Requests for content that exist in a specific path in your origin will have Bit Rate Limiting applied.

- **Time Interval**. Requests that are received during a specified time interval will have Bit Rate Limiting applied.

- **User Location Data**. Requests that initiate from a specified geographic region will have Bit Rate Limiting applied.

You need to create a separate rule in your property configuration, set the match criteria you want to use, and add the Bit Rate Limiting behavior to that rule. You can combine Match criteria in the rule. See [Use case examples](#use-case-examples) for details.

# [Add the behavior](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting#add-the-behavior)

Follow these steps to add Bit Rate Limiting to your AMD property configuration:

1. In Property Configuration Settings, click **Add Rule**.

1. Select **Blank Rule Template** and click **Insert Rule**.

1. Click **Add Match**. Set the first drop-down to one of the matches listed in the previous section. Configure the remaining options in the match to suit your need.

1. Repeat **Step 3** to add another of the supported matches, if desired.

1. Click **Add Behavior**.

1. Select the **Bit Rate Limiting** behavior from the list and click **Insert Behavior**.

1. Set its options as follows:

    - **Bit Rate Limiting**. Set this to **On** to enable this behavior.

    - **Bit Rate**. Set the maximum bit rate to serve your content once the **Threshold** is met. The allowed units of measure are Kbps, Mbps, and Gbps.

    - **Threshold**. Once this Threshold is met, content delivery is limited to the **Bit Rate** you set.

        - **If set to "Bytes"**: The Bit Rate is enforced after this many bytes have been transferred.

        - **If set to "Seconds"**: The Bit Rate is enforced after delivery has continued for this length of time.

## [There are default settings](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting#there-are-default-settings)

If you simply enable Bit Rate Limiting and don't set a Bit Rate or a Threshold, your configuration will deliver content at a maximum bit rate of 15 Mbps as soon as a request is received. (The **Bit Rate** is default set to 15 Mbps with a **Threshold** of 0 seconds.)

# [Use case examples](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting#use-case-examples)

These sections show how you would configure a new rule in your property configuration to use Bit Rate Limiting in some example scenarios.

## [Example 1: Enforce Bit Rate Limiting for segment files](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting#example-1-enforce-bit-rate-limiting-for-segment-files)

We want the limit to be applied to requests for segment files, including *.ts, *.mp4, and *.m4s formats. We've set the behavior to apply a 10 Mbps limit after 60 seconds of transfer time.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/bit-rate-limiting-example-1-v1.jpg)

## [Example 2: Enforce Bit Rate Limiting for segment files to a specific location](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting#example-2-enforce-bit-rate-limiting-for-segment-files-to-a-specific-location)

We want the limit to be applied to requests for specific software patch files, that originate from several Western states in the United States. We've set the behavior to apply a 5 Mbps limit after 20 MB of transfer (20000000 Bytes).

![](https://techdocs.akamai.com/adaptive-media-delivery/img/bit-rate-limiting-example-2-v1.jpg)

## [Example 3: Enforce Bit Rate Limiting for local time](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-bit-rate-limiting#example-3-enforce-bit-rate-limiting-for-local-time)

We want the limit to be applied to requests originating from Germany, between 6:00 and 8:00 PM, local time. We've set the behavior to apply a 6 Mbps limit after 1 MB of transfer (1000000 Bytes).

![](https://techdocs.akamai.com/adaptive-media-delivery/img/bit-rate-limiting-example-3-v1.jpg)

