# [Mapping Solution – Media Delivery Type](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-use-case-based-edge-mapping#mapping-solution-media-delivery-type)

Media delivery type lets you apply a specific mode to an edge hostname to aid in delivering your content. With AMD, you can select a segmented media mode to best deliver either live or on demand format media.

# [How does it work?](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-use-case-based-edge-mapping#how-does-it-work)

When an edge hostname is generated, specific "edge maps" are used, based on multiple factors. You define some of these:

- **Delivery network**. The geographic location of your content and requesting clients.

- **Product**. AMD in this case.

- **IP version**. IPv4 only, or IPv4 and IPv6 ("dual stack").

Akamai selects an edge map that is best suited to deliver your content based on how you define these settings.

Media delivery type offers additional criteria. It lets you select from two separate modes for your edge hostname to further define the optimal edge map. These modes can be incorporated in one of two ways:

- **Method 1: Use a single edge hostname and configure either a "Live" or "On Demand" media mode for it ("one to one")**. The optimal edge map is selected to deliver your content, based on the selected mode. Live and on demand content have very different access patterns.

- **Method 2: Set up two separate edge hostnames to deliver live and on demand content from a single property configuration ("many to one")**. This applies separate, optimal edge maps for each delivery mode. You also incorporate Mixed Mode Configuration to apply key use case-based behaviors in separate rules in the property configuration, and apply match criteria for each property hostname—one to apply settings for requests to the live media property hostname, and a second for the on demand media property hostname.

# [Media Delivery Type vs. Mixed Mode Configuration](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-use-case-based-edge-mapping#media-delivery-type-vs-mixed-mode-configuration)

Akamai also offers Mixed Mode Configuration (MMC) that allows you to apply various mode-based behaviors to additional rules in a property configuration, and set delivery conditions to apply these specific behaviors to each request. For example, you can use MMC to set up separate edge hostnames—one for live content and another for on demand—and configure separate rules to manage requests for each format, _all in the same property configuration_. In the past, these behaviors were only available in the Default Rule, that applied to all requests for the property configuration. So, you had to set up separate property configurations for each media format.

Segmented media mode also allows you to select from live or on demand content for an AMD property configuration, but it's used to optimize delivery for each mode by selecting the optimal edge map to deliver this content.

You can combine these features in a single property configuration to optimize delivery through the best edge map, and control both live and on demand delivery with a single property configuration. However, there are what we call "mismatch issues" that may apply when combining them. These are covered later in this documentation.

See [Use Mixed Mode with AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/use-mixed-mode-amd) for full details.

# [How do I get Media Delivery Type?](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-use-case-based-edge-mapping#how-do-i-get-media-delivery-type)

This is automatically available if you've purchased the AMD product. However, if you wish to use Mixed Mode Configuration, to apply Method 2 above, you need to have it added to your contract. Contact your account representative for details.

# [How to enable Media Delivery Type Mapping Solution](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-use-case-based-edge-mapping#how-to-enable-media-delivery-type-mapping-solution)

You select a use case when you're setting up a property hostname to edge hostname association ("Property Hostname") in Property Manager.