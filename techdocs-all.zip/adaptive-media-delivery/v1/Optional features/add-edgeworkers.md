# [EdgeWorkers](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-edgeworkers#edgeworkers)

Use EdgeWorkers to help optimize content delivery, by deploying JavaScript functions at the edge.

# [What is EdgeWorkers?](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-edgeworkers#what-is-edgeworkers)

EdgeWorkers is a server-less solution that uses scripts that are invoked at the different [phases of an HTTP request](https://techdocs.akamai.com/edgeworkers/docs/event-handler-functions). This provides an opportunity to improve performance, by moving compute operations closer to your users.

Once you add EdgeWorkers to your property, developers can activate code outside of Akamai Control Center. Just activate custom scripts and efficiently implement enhancements. You can write functions that access HTTP headers, cookies, and URLs in order to construct complex logic.

So, if you want to implement AMD enhancements, but don't have significant experience with Control Center or Property Manager, you can use EdgeWorkers.

Here are some more examples of how you can use EdgeWorkers:

- Redirect requests based on geography, device, and user-agent
- Apply conditional logic to filter traffic and construct responses
- Add or remove debug information from an HTTP message
- Respond with custom error responses, even when the origin is down

# [How to configure EdgeWorkers](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-edgeworkers#how-to-configure-edgeworkers)

There are some administrative tasks required to configure your AMD property to execute EdgeWorkers functions:

1. [Add EdgeWorkers to your contract](https://techdocs.akamai.com/edgeworkers/docs/add-edgeworkers-to-contract)

1. [Add the EdgeWorkers behavior](https://techdocs.akamai.com/edgeworkers/docs/add-edgeworkers-to-contract)

1. [Create an EdgeWorker ID](https://techdocs.akamai.com/edgeworkers/docs/create-an-edgeworker-id)

# [Check out the "Hello World" tutorials to get started](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-edgeworkers#check-out-the-hello-world-tutorials-to-get-started)

We've put together some [tutorials](https://techdocs.akamai.com/edgeworkers/docs/hello-world) that show you how to get an EdgeWorkers function up and running on your site. You'll learn how to set up the EdgeWorkers service and then create and deploy the Hello World code bundle using the EdgeWorkers Management application, API, and CLI.

# [Known issues](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-edgeworkers#known-issues)

Before you add EdgeWorkers support to your AMD configuration, there are some known issues you should consider. We are working on fixes to these issues.

- **EdgeWorkers is not supported for use with Token Authentication**. An EdgeWorkers request for an AMD property that also has [Token Authentication](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth) enabled is *denied*.

- **EdgeWorkers is not supported for use with Partial Object Caching (POC)**. You can't include various behaviors or options in your AMD property rules if you want to use EdgeWorkers. This includes the following:

    - **Media File Retrieval Optimization**. This is a [caching-related behavior](https://techdocs.akamai.com/property-mgr/docs/media-file-retrieval-optimization) that helps speed the delivery of larger media files when NetStorage is your origin.

    - **Origin Object Size settings in Content Characteristics**. POC is automatically applied for the larger origin objects you can select as your Origin Object Size in the Content Characteristics behavior. You can't select any of these Origin Object Sizes if you also want to use EdgeWorkers with your AMD configuration. See [Content Characteristics and AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/content-charac-amd) for specifics.

- **EdgeWorkers is not supported for use with the Cache HTTP Redirects behavior**. After the [Cache HTTP Redirects](https://techdocs.akamai.com/property-mgr/docs/cache-http-redirects) behavior applies a redirect, follow-up EdgeWorkers requests fail due to an error with origin-side event handlers.

- **The EdgeWorkers "failaction" is incompatible with the Site Failover behavior if it's Action is set to "Serve alternate content from NetStorage."** You'll see a 400 response when an EdgeWorkers execution fails and the [Site Failover behavior](https://techdocs.akamai.com/property-mgr/docs/site-failover) tries to fetch content from NetStorage as your alternate origin. If you need to incorporate Site Failover, you'll need to set the failover Action to something other than NetStorage.