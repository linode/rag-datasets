# [Manifest Personalization for DASH](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-manifest-personalization-dash#manifest-personalization-for-dash)

With the increasing demand for online content, you may be challenged to deliver even more when network and bandwidth capacity are limited. To help with this, you can include Manifest Personalization ("MPer") with AMD to limit or restrict the maximum bit rate for DASH content served to your customers.

# [How it works](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-manifest-personalization-dash#how-it-works)

MPer for DASH lets you incorporate "bit rate targeting." You determine an upper bit rate limit and MPer trims bit rates above this limit from the DASH manifest. Any request above the maximum bit rate value is downgraded to the bit rate maximum you've defined.

Your account representative will help you add MPer for DASH to your AMD property configuration. When a request is sent to a property hostname in your configuration, and it matches the MPer rule criteria, your manifest is updated on the fly to incorporate your bit rate targeting settings.

 > Note: Manifest and Playlist Manipulation in EdgeWorkers
  Alternatively, you can use an [EdgeWorkers function](https://techdocs.akamai.com/edgeworkers/docs/manifest-and-playlist-personalization) to dynamically create personalized Video on Demand (VOD) or live manifest and playlist files.

# [What video formats are supported?](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-manifest-personalization-dash#what-video-formats-are-supported)

Manifest Personalization is supported for use with on-demand DASH media. We're looking to add support for Live media with a future release.

# [MPer with DASH vs. HLS](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-manifest-personalization-dash#mper-with-dash-vs-hls)

Currently, MPer functionality for DASH is limited to what's discussed here. We're working diligently to reach feature parity with the HLS version of MPer and expect to have it in a future release.

# [Configure MPer for DASH](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-manifest-personalization-dash#configure-mper-for-dash)

You need to have MPer set up in your AMD property and also set up your player to include a query string value in requests.

## [Add MPer for DASH to your property](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-manifest-personalization-dash#add-mper-for-dash-to-your-property)

You need to work with your account representative ("rep") to add MPer to your AMD property. Your account rep will add an "Advanced Override." This adds customized metadata and inserts it in the XML that makes up your AMD property's configuration file. Consider these points when setting up MPer:

- **You need to determine the maximum bit rate (bandwidth) value for your content**. When a request meets the match criteria for MPer, the "Representation" elements are rewritten in the manifest. One is set to support your maximum bit rate (via its "bandwidth" parameter) and others are included for lower bit rate "buckets." (More on buckets in the next section.) Representation elements that included bit rates above the maximum are dropped from the manifest. _MPer supports a maximum bit rate of 10,000 Kbps._

- **The rule is set with a match criteria for requests that include DASH manifest files**. Work with your account rep to ensure that the proper file names and extensions for your DASH manifests are included in your Advanced Override.

## [Apply a bit rate upper limit in your player](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-manifest-personalization-dash#apply-a-bit-rate-upper-limit-in-your-player)

This is accomplished by appending the `
b-upper-limit={#}`
 query string to requests for your content. You need to update your player to ensure that this query string is included in all requests if you want to use MPer to apply bit rate targeting.

```
https://big-time-movies.akamaized.net/dash/MR/MultiResPer.mpd?b-upper-limit=2000
```

- **Values set in the "b-upper-limit" are in Kbps**. DASH manifests use bps to specify the "bandwidth" attribute used for bit rate. Akamai metadata recognizes this in the query string and makes the conversion.

- **There are threshold bit rate "buckets."** Akamai has set up a range of threshold points, or "buckets," for ranges of "b-upper-limit" values. Your manifest is updated by MPer to include your maximum bit rate and all buckets below it. Values set in the query string that fall into a certain range are round down to the applicable bucket for bit rate targeting.

If a request includes a "b-upper-limit" in this range... | ...the manifest applies this bucket bit rate (in Kbps)  
 ---|---  
 1000 - 1999 | 1000  
 2000 - 2999 | 2000  
 3000 - 3999 | 3000  
 4000 - 4999 | 4000  
 5000 - 5999 | 5000  
 6000 - 7999 | 6000  
 8000 - 9999 | 8000  
 10000 + | 10000

- **You can set the value for "b-upper-limit" in a request to any value below your established maximum bit rate value**. For example, if you've defined a maximum bit rate of 4,000 Kbps, you could still set the query string to "b-upper-limit=2000" for a single request. Content delivered for that request would be served at a maximum of 2,000 Kbps.

- **A "b-upper-limit" won't exceed your maximum bit rate**. The maximum bit rate you communicated to your account rep when initially adding MPer is the absolute maximum. If the value in "b-upper-limit=\<#>" exceeds that, MPer still serves the content but at your maximum bit rate.

# [Caveats and known issues with MPer for DASH](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-manifest-personalization-dash#caveats-and-known-issues-with-mper-for-dash)

There are some caveats and known issues that apply to the use of MPer for DASH. Review them before adding this functionality to your property.

Issue | Description  
 ---|---  
 **UTF-16 encoded DASH manifests are only supported with additional configuration** | By default, the background service that powers MPer for DASH doesn't support UTF-16 encoded manifests. Additional metadata can be implemented to get the service to accommodate them. The service first tries a regex replacement of text using UTF-8. When that's not possible, it tries again for UTF-16 encoded text. Talk to your account rep to see if this workaround can be applied in your environment.  
 **Range headers are removed** | The background service that powers MPer for DASH is not compatible with range requests. When MPer is enabled and a request includes a Range header, a 502 error is returned. To handle this issue, range headers are removed from requests that include MPer.\\.  
 **Manifest files can be no larger than 1MB in size** | Requests that include a manifest greater than 1MB in size are met with a 5xx error.  
 **FireTV devices may not be supported with MPer** | The Representation elements that include bit rates above your specified maximum are dropped from the manifest. Representation elements are contained within "Adaptation Sets" in the manifest. If all of the Representation elements within an Adaptation Set are eliminated, the Adaptation Set is "empty," and it should also be removed by MPer. In rare circumstances, an empty Adaption Set may be left in a DASH manifest after MPer modifies it. Testing has shown that playback via FireTV devices can stop if empty Adaptation Sets exist in the manifest.