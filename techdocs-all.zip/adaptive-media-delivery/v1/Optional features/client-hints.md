# [Client Hints](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-hints#client-hints)

The User-Agent HTTP header carries information from a requesting client, like its browser application branding and media player resolution. Media players can use this data to customize the experience for the individual end user. Unfortunately, it's not an ideal mechanism because it can carry too much information that can be used for targeted fingerprinting. To move away from the User-Agent HTTP header, Google Chrome has introduced the Client Hints method. It offers a means to only request specific client information.

# [How it works](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-hints#how-it-works)

We offer a combination of behaviors you can add to your Adaptive Media Delivery property for this support:

- **Request Client Hints**. Chromium-based browsers support a set of client-related data, or "client hints data objects." You select the ones you want a browser to include in requests from a client for your content. If the browser agrees, it sends the data in future requests from the client. Browser agreement depends on how the end user has configured their browser.
- **Permissions-Policy**. By default, a browser limits access to the client hints data objects to the specific host that requested it. Using your Adaptive Media Delivery property as an example, this could be the domain for a media stream, that you've included in an edge hostname. However, any host that receives hints can delegate access to them to other documents that the host has embedded inside of an `
` element. This is done by including the desired client hints and the domains to these documents, in the `Permissions-Policy` header.

# [Implementation](https://techdocs.akamai.com/adaptive-media-delivery/docs/client-hints#implementation)

Client Hints isn't unique to Adaptive Media Delivery. See the [Property Manager documentation](https://techdocs.akamai.com/property-mgr/docs/request-client-hints) for more information on setting it up.