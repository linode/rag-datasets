# [Low Latency Streaming support](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-low-latency-support#low-latency-streaming-support)

Low latency streaming looks to reduce latency and decrease the overall transfer time of your live streams. 

# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-low-latency-support#before-you-begin)

You need to understand how low latency is supported, based on the import format of your live content:

- **DASH**. Akamai recommends that you use Media Services Live as your origin to deliver your live content.
- **HLS**. This requires a third-party origin to distribute your live content.

> Info: HDS and Smooth aren’t supported.