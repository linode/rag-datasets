# [Content Targeting Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#content-targeting-protection)

Add this service to permit or deny access to your content based on region-specific values associated with the requesting client. For example, you can add the Content Targeting - Protection behavior and configure it to deny access to clients in a specific geographic region ("geo protection"), or only allow requests coming from a specific set of IP addresses.

 > Note: 
  The client's geographic location is retrieved from the client's IP address. By default, this feature uses the information from the X-Forwarded-For header. To only use the geographic location of the connecting IP address, see [Apply Advanced Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#apply-advanced-protection).

# [The content protection hierarchy](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#the-content-protection-hierarchy)

​Akamai​ offers multiple levels of access and protection to secure your content. Here's where Content Targeting Protection fits into our protection hierarchy:

- **No protection - Open Access**. Anyone can access your content

- **Level 1: Content Targeting - Protection**.

- **Level 2: Token Auth**. An encrypted token in the request is compared against a token you've associated with your content. You can add it to your property using the [Token Authentication & AMD](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-token-auth) options in the Segmented Media Protection behavior.

- **Level 3: HTTPS Protection**. [Configure](https://techdocs.akamai.com/adaptive-media-delivery/docs/define-prop-hn) your AMD property to access and send content via secure delivery.

- **Level 4: Media Encryption**. Your content is encrypted. Only requests that include the proper decryption key can decode it for access. You can add it to your property using the [Media Encryption](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-media-enc) options in the Segmented Media Protection behavior.

- **Most protection: DRM Encryption**. This prevents access to only those clients that have been authorized to have a DRM license for the playback environment or content, including additional rights management rules.

# [Get Content Targeting - Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#get-content-targeting-protection)

You need to have this added to your contract to access the appropriate behavior in Property Manager. Talk to your account team about adding this functionality.

# [Add Content Targeting - Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#add-content-targeting-protection)

Once you have it added to your contract, you can add Content Targeting - Protection to your AMD property by performing the following:

1. Create a new AMD property, or edit an existing one using Property Manager.

2. In the Property Configuration Settings options, click **Add Behavior**.

3. In the _Search available behaviors_ field, input **Content Targeting** to filter the listed behaviors, and select **Content Targeting - Protection** from the list.

4. The new behavior is added to your property. Set the Enable Content Targeting switch to **On**.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-content-target-prot-enable-v1.jpg)

Once enabled, you can apply Content Targeting - Protection in multiple ways.

## [Apply Geo Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#apply-geo-protection)

Worldwide, IP addresses are unique to a specific geographic location. This functionality uses this concept, and leverages the geographic location of the end-user system attempting to access your content, and either allows or deny access to it, based on the IP address.

To implement this protection, set the Enable Geo Protection slider to **On** and define the following settings:

- **Mode**. Select the desired operator:

  - **Allow...**. This _grants access_ to clients that fall within the settings you apply.
  - **Deny...**. This _blocks_ clients that fall within the settings you apply.

- **Countries**. Click this field and select an entire country that you want to be allowed or denied access. Each is followed by its two-letter country designation. For example, "US" represents the United States, \\ and "BR" represents Brazil. Repeat this to add additional countries.

- **Regions**. Click this field and select a specific country and corresponding region that should be allowed or denied access. For example, you can select individual states within the United States, provinces in Canada and China, etc. Objects are listed alphabetically, by country first, and then region. Each is followed by its two-letter country designation and abbreviated region. For example, "United States - California"  is represented as "US-CA." Repeat this to add more regions.

- **DMAs (United States, only)**. Click this field to select a "Designated Market Area." Repeat to add additional DMAs. A DMA is a specific region in which the population can receive the same (or similar) internet media offerings. Current entries are based on the proprietary Nielsen Media Research DMA regions. You can request specific DMA data from Nielsen, at 
.

- **Override GEO Controls for these IPs/CIDR blocks**. With your operator set to 'Deny...", input an IP address/CIDR block that exists within your specified Countries or Regions. This overrides the "Deny..." setting, allowing access to that specific IP address/CIDR Block. Repeat as necessary to add additional IP address/CIDR blocks. _You can have a maximum of 160 entries in this field_.

 > Note: 
  The **"Override GEO Controls..."** functionality only works to override a "Deny..." **Mode** setting for individual IP addresses within a specified country or region. It can't be used to override a mode of "Allow..." For example, you can't use it to allow a region, and specifically block an individual IP address. Use the IP Access functionality to configure this.

- **Redirect request instead of Deny**. Set this slider to **On** and input a complete page address in the **Redirect URL** field to serve as a deny destination. _This URL cannot be longer than 2000 total characters_. If an access attempt is denied, it is redirected to this address:

  - **"Allow..." Mode**. Any request outside what you have specifically configured here is denied and sent to this redirect URL.

  - **"Deny..." Mode**. A request that matches any value you have defined here is denied and sent to this redirect URL.

 > Note: 
  The requesting client needs to handle HTTP 302 on manifest requests to support this functionality. You also need to have a page set up and accessible via the noted URL to serve as the deny destination.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-geo-protection-v1.jpg)

## [Apply IP Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#apply-ip-protection)

This functionality lets you provide individual IP addresses or classless inter-domain routing (CIDR) blocks that should be allowed or denied access to your content.

To implement this protection, set the Enable IP Protection slider to **On** and define the following settings:

- **Mode**. Select the desired operator:

  - **Allow...**. This _grants access_ to clients that fall within the settings you apply.
  - **Deny...**. This _blocks_ clients that fall within the settings you apply.

- **IP Addresses/CIDR Blocks**. Click this field, input a valid IP address or CIDR block to be allowed or denied access, and click the (new item) entry to add it. Repeat to add more entries.

- **Redirect request instead of Deny**. Set this slider to **On** and input a complete page address in the **Redirect URL** field to serve as a deny destination. _This URL cannot be longer than 2,000 total characters_. If an access attempt is denied, it is redirected to this address:

  - **"Allow..." Mode**. Any request outside what you have specifically configured here is denied and sent to this redirect URL.
  - **"Deny..." Mode**. A request that matches any value you have defined here is denied and sent to this redirect URL.

 > Note: 
  The requesting client must be able to handle 302 on manifest requests to support the above functionality. It also requires that you have a page setup and accessible via the noted URL to serve as the deny destination.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-ip-protection-v1.jpg)

## [Apply Referrer Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#apply-referrer-protection)

You may have granted various outside websites access to your players or content. For example, you may have used a link on a page on a page outside your site. Unauthorized sites may attempt to hijack these links and publish them to their own site. Use this to specifically name qualified referrer website URLs to block these referrers from accessing your content.

To add this protection, set the Enable Referrer Protection slider to **On** and define the following settings:

- **Mode**. Select the desired operator:

  - **Allow...**. This _grants access_ to clients that fall within the settings you apply.
  - **Deny...**. This _blocks_ clients that fall within the settings you apply.

- **Referrer Domains**: Click this field, input a referrer domain and click the (new item) entry to add it. Repeat to add additional domains. _A Referrer Domain cannot exceed 256 total characters_. Domains can be input using the following formats:

- **Full Domain**. Input as `www.address.com`. Don't include `http(s)://`.

- **Domain Prefaced with a Period (" . ")**.  For example, this could be `.address.com`. The period serves as a form of wildcard, indicating that all domains that end in `.address.com` are allowed.

  - **Redirect request instead of Deny**. Set this slider to **On** and input a complete page address in the **Redirect URL** field to serve as a deny destination. _This URL cannot be longer than 2000 total characters_. If an access attempt is denied, it is redirected to this address:

  - **"Allow..." Mode**. Any request outside what you have specifically configured here is denied and sent to this redirect URL.

  - **"Deny..." Mode**. A request that matches any value you have defined here is denied and sent to this redirect URL.

 > Note: 
  The requesting client must be able to handle 302 on manifest requests to support the above functionality. It also requires that you have a page set up and accessible via the noted URL to serve as the deny destination.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/amd-enable-referrer-protection-v1.jpg)

## [Apply Advanced Protection](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#apply-advanced-protection)

This functionality lets you ignore or check any IP addresses passed in the `X-Forwarded-For` header for Geo Protection and IP Protection. 

 > Note: 
  It is available only when you enable Geo Protection or IP Protection.

To implement this protection, specify how and whether Akamai processes the `X-Forwarded-For` header:

- ** X-Forwarded-For within Geo Protection**. Enable to ignore the information from the `X-Forwarded-For` header.
- **X-Forwarded-For within IP Protection**. Select the desired option:

  - **Ignore XFF**. Ignores any IP addresses passed in the `X-Forwarded-For` header and only checks the connecting IP address.

  - **Check both XFF & Connecting IP**. Checks any IP addresses passed in the `X-Forwarded-For` header as well as the connecting IP address.

  - **Ignore connecting IP if XFF is present**. Ignores the connecting IP address if the `X-Forwarded-For` header is passed.

# [Protection precedence](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#protection-precedence)

You can combine the protections offered with Content Targeting - Protection. If you do, be aware that various operations and settings take precedence over another, in the event of a conflict. This is in place to ensure that lighter protections are executed first, versus heavier ones. So that internal servers spend fewer cycles to serve a request.

## [Individual protection precedence](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#individual-protection-precedence)

Each individual protection is applied in the following order, lighter to heavier, with the first taking the highest precedence:

1. IP Protection
2. Referrer Protection
3. Geo Protection

## ["Deny" takes precedence over an "Allow"](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#deny-takes-precedence-over-an-allow)

Using the protection order defined above, if a Mode of **Deny...** set for one protection conflicts with a Mode of **Apply...** set for lower protection, _the Deny takes precedence_. For example, assume you set IP Address Protection to **Deny...** a specific IP address, and then set Geo Protection to **Allow...** the Country that includes that IP address. _That individual address will still be denied access_.

## [The last "Redirect" takes precedence](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-content-tgting-prot#the-last-redirect-takes-precedence)

If you have enabled and configured the **Redirect request instead of Deny** for any of the protections, and a conflict occurs, the last redirect is applied. "Last" is based on the order defined in [Individual protection precedence](#individual-protection-precedence).

- If IP Protection applies a redirect, and Referrer Protection is set to "Deny..." a conflicting address, _the request is denied_.

- If IP Protection applies a redirect, and Referrer Protection also applies a redirect, _the redirect set for Referrer Protection is applied in the event of a conflict_.

- If IP Protection applies a redirect, Referrer Protection applies redirect, and GEO Protection is set to "Deny..." a conflicting address, _the request is denied_.

- If IP Protection applies a redirect, Referrer Protection applies a redirect, _and_ Geo Protection applies a redirect, _the redirect set for Geo Protection is applied in the event of a conflict_.