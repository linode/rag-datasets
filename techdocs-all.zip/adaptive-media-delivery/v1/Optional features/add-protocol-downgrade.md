# [Protocol Downgrade](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade#protocol-downgrade)

If you're incorporating Enhanced TLS (L3), Standard TLS, or Akamai's shared certificate delivery security (HTTPS L1), you may want to apply HTTPS to the request from the client to Akamai edge servers, but "downgrade" the connection to HTTP-only between Akamai and your origin. This is called protocol downgrade.

> Info: Are you using NetStorage?. If you're using NetStorage as your origin server in your AMD property, Protocol Downgrade does not apply.

# [Overview](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade#overview)

With protocol downgrade, the secure HTTPS connection starts with the client that accesses AMD edge servers, where your AMD property is read and processed. However, you serve an HTTP connection when content is sent from your origin back to the edge servers.

You might need protocol downgrade if either of the following applies:

- You haven't upgraded your origin to support secure connections. (Or, you don't want to.)

- You want to avoid the overhead associated with secure sockets layer (SSL) when serving non-personally identifiable information (PII) assets.

To implement this, we offer multiple behaviors that can be applied, based on the level of security in the certificate in your property hostname.

## [You need a secure (HTTPS) property hostname](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade#you-need-a-secure-https-property-hostname)

There are two separate behaviors used to add this support. They require secure certificate delivery (HTTPS), in the request from the end user to the Akamai edge. These behaviors are supported as follows:

- **Protocol Downgrade**. This requires an Enhanced TLS (L3) certificate in a property hostname in your property.
 
- **Protocol Downgrade (HTTPS Downgrade to Origin)**. This is used with either a Standard TLS (L1) certificate, or the Akamaishared certificate hostname in your property hostname.**

# [How to get protocol downgrade](https://techdocs.akamai.com/adaptive-media-delivery/docs/add-protocol-downgrade#how-to-get-protocol-downgrade)

You need to have the applicable protocol downgrade support added to your contract to access the appropriate behavior in Property Manager. Contact your Account Representative to add this functionality.