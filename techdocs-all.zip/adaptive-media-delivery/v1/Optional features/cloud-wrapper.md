# [Cloud Wrapper](https://techdocs.akamai.com/adaptive-media-delivery/docs/cloud-wrapper#cloud-wrapper)

Add this behavior to your Adaptive Media Delivery property to enhance origin offload by optimizing data caches in regions nearest to your origin server.

# [How it works](https://techdocs.akamai.com/adaptive-media-delivery/docs/cloud-wrapper#how-it-works)

Cloud Wrapper maximizes origin offload for large libraries of content. It gives you access to supplementary, regional resources for your hosts, called a "footprint." Content from your origin is cached in your footprint, which reduces the need for direct contact with your origin. This helps your origins operate at peak performance.

You need to add Cloud Wrapper to your contract to get access to it. Talk to your account team for all the details. Once it's added, you'll set up a specific configuration for your footprint and add its behavior to your Adaptive Media Delivery property in Property Manager.

You can find full requirements and usage details in the [Cloud Wrapper documentation](https://techdocs.akamai.com/cloud-wrapper/docs).

# [Caveats and known issues](https://techdocs.akamai.com/adaptive-media-delivery/docs/cloud-wrapper#caveats-and-known-issues)

Before you add this support to your Adaptive Media Delivery property, consider these points:

- **Adaptive Media Delivery and our website delivery products can't use the same footprint**. You'll work with your Akamai account team to set up your specific footprint for use with Cloud Wrapper. You can't configure Adaptive Media Delivery properties with Ion or Dynamic Site Accelerator properties in the same footprint.

- **SureRoute and SiteShield aren't supported**. Cloud Wrapper can't be used with Adaptive Media Delivery properties that also have [SureRoute](https://techdocs.akamai.com/adaptive-media-delivery/docs/sureroute) and [SiteShield](https://techdocs.akamai.com/property-mgr/docs/siteshield-beh) enabled in the same rule group.

- **With Adaptive Media Delivery, Tiered Distribution is automatically enabled**. The [Tiered Distribution](https://techdocs.akamai.com/property-mgr/docs/tiered-dist) behavior is optimized in the background of the [Origin Characteristics](https://techdocs.akamai.com/property-mgr/docs/origin-charac) behavior in the Default Rule. You don't need to add the standalone version of the Tiered Distribution behavior to your property. Rely on the settings that are automatically applied via Origin Characteristics.