# [Set up your player for watermarking](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-your-player-for-watermarking#set-up-your-player-for-watermarking)

You need to configure the client application ("player") that will be accessing content to perform various tasks to support watermarking.

- **Your player needs to get the watermarking token (WMT)**. When an end user requests content, your player needs to first request the WMT from the watermarking vendor.

- **Your player needs to supply the token to Akamai **. As the request progresses to the edge, the WMT needs to be included.

# [How a player requests a WMT](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-your-player-for-watermarking#how-a-player-requests-a-wmt)

The requirements for this can vary, based on your chosen third-party watermarking vendor. Contact your vendor for details on how to configure your player to request the WMT.

# [How the player communicates the WMT to Akamai](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-your-player-for-watermarking#how-the-player-communicates-the-wmt-to-akamai)

This can be done in multiple ways:

- **Include the token as a virtual path component (VPC)—*Recommended***. You can have your content management system retrieve the token from the watermarking vendor, and insert it into the URL. Your player transparently supplies Akamai with the WMT, without additional software or configuration changes. After acknowledging the WMT, the Akamai edge strips it from the request path before sending it to your origin.

    `HLS: http://ss-wmt.akamaized.net/wmt:
/Stub/HLS/VoD/ToS/ToS.m3u8`
    `DASH: http://ss-wmt.akamaized.net/wmt:
/Stub/Dash/VoD/ToS/ToS.mpd`

- **Include the token in the Authorization Header**. You can have the client include this header, in its request. The format of the header is fairly straightforward:

    `Authorization: 
`

- **Include the token as a query parameter**. You can use the query section of the URL to submit the WMT, using the "`wmt`" parameter:

    `https://customer-1.akamaized.net/hls/vod/segment1.ts?wmt=
`

> Info: Both the \