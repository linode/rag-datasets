# [The watermarking token (WMT)](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-watermarking-token-wmt#the-watermarking-token-wmt)

Here, we cover the composition of the WMT and include requirements you can share with your watermarking vendor to properly format them.

A WMT is created by your selected watermarking vendor. Your client application ("player") needs to request it from the vendor, and send it to the edge with every segment or fragment request for content. Akamai ensures the token is present and verifies the signature of the token to prevent tampering.

# [The WMT format](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-watermarking-token-wmt#the-wmt-format)

The WMT is formatted using the JSON Web Token (JWT) format. It consists of a header, payload, and signature separated by period characters:

    Watermarking Token (WMT) = JWT = 
.
.

- `
`. This is a JSON object that needs to be base64url encoded. It confirms the format of the object and the algorithm used to compute the 
. It also specifies the "kid" (Key ID) associated with the 
 that's used for verification. This must match the Verification Key ID #<#> set in your AMD property for the applicable Verification Public Key #<#>. If you've defined both a Verification Public Key #1 and Verification Public Key #2 for added security, the Verification Key ID #1 needs to be included as the "kid" to use Verification Public Key #1; and Verification Key ID #2 needs to be included to use Verification Public Key #2. With watermarking enabled for your AMD property, any request that's missing a "kid" is denied.

- `
`. This is a JSON object that needs to be base64url encoded. Also referred to as the "claim set," this includes the watermarking pattern (WMID) that Akamai should use to deliver content. You can optionally set up support for Pattern Encryption which must also be enabled and configured in your AMD property.

- `
`. This is a JSON Web Signature (JWS) for security to protect the WMT from tampering via signing. This must match what you've set as the Verification Public Key #1 (or Verification Public Key #2) in the Token Signing options in your AMD property. It is hash encrypted using the algorithm ("alg") set in the JWT Header.

## [Example watermarking token](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-watermarking-token-wmt#example-watermarking-token)

The table that follows shows pre-base64url encoded examples of the JWT Header and JWT Payload in a WMT that use the watermarking pattern “`ABABAABBAABBAAABBBABAB`.” Pattern Encryption has also been incorporated using a pattern encryption password of “password1.” The Signature is generated based on values set in both the JWT Header and Payload.

> Info: Random values have been included here, and what's displayed is for example purposes, only.

[block:html]
{
  "html": "
\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nComponent\n\n| Example\n\n| Notes\n\n  
 ---|---|---  
 \n\n\n\n\n\n\n\n**JWT Header** \n\n| 
     
     
     \n{\n    \"typ\": \"JWT\",\n    \"alg\": \"RS256\",\n    \"kid\": \"cn=allsports.basbeballshorts.com; nva=2021-09-23 18:59:59 EST\"\n}\n
 
 \n\n| \"RS256\" (RSA Signature with SHA-256) is the algorithm that's used to hash encrypt the JWT Signature.\n\n  
 \n\n\n\n**JWT Payload** \n\n| 
     
     
     \n{\n    \"iss\": \"urn:baseballshorts\",\n    \"iat\": 0132547698,\n    \"wmver\": 1,\n    \"wmid\": \"\n    \"wmidalg\": \"aes-128-cbc\",\n    \"wmidivlen\": 16,\n    \"wmidivhex\": \"a12345678bcdefg9012gh345ij678k\",   \n    \"wmidivb64\": \"aBcDEf1GhijklM+2NOpqrs==\",\n    \"wmidctb64\": \"1aBcD23EfGHIJklmnoPqR4sTU5vwxy678ZaBcdeFGh=\",\n    \"wmidpid\": \"decryptpw_2020-01-01\",\n    \"wmidpalg\": \"sha256\"\n}\n
 
 \n\n| Since we've also included Pattern Encryption in this example, all of the `wmid*` claims are included in the payload. The watermarking identifier (`wmid`), Initialization Vector (`wmidiv*`), encryption password (`wmidp*` ), and of course the actual cipher-text of the WMID itself (`wmidctb64` ) are all specified so that Akamai can properly decrypt it. Knowing the shared-secret password identified by \"`decryptpw_2020-01-01`\" whose value in this example is \"`password1` ,\" Akamai can generate the SHA-256 hash, as specified by \"`wmidpalg`,\" and decrypt the pattern.\n\n  
 \n\n\n\n**JWT Signature** \n\n| 
     
     
     \n{sha256 hash of the Verification Public Key #<#>.}\n
 
 \n\n| The `alg` parameter from the JWT Header is used to determine the algorithm for hash encryption of the JWT Signature, and it's verified using the key identified by the `kid` parameter in the JWT Header.\n\n  
 \n\n\n\n
\n
"
}
[/block]
## [The JWT Payload Claim Set](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-watermarking-token-wmt#the-jwt-payload-claim-set)

Here's the set of claims that can be used in the JWT Payload for a WMT.
[block:html]
{
  "html": "
\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nParameter\n\n| Claim Name\n\n| Allowable Values\n\n| Usage\n\n| Description\n\n  
 ---|---|---|---|---  
 \n\n\n\n\n\n\n\n`iat` \n\n| Issued At\n\n| A number representing the numeric date of issue. For example, the UNIX timestamp.\n\n| ** _Required_** \n\n| The `iat` (issued at) claim identifies the time at which the JWT was issued. This claim can be used to determine the age of the JWT.\n\n  
 \n\n\n\n`iss` \n\n| Issuer\n\n| A case sensitive string or URI\n\n| ** _Required_** \n\n| The `iss` (issuer) claim identifies the principal that issued the JWT.\n\n  
 \n\n\n\n`wmver` \n\n| WMT Schema Version\n\n| 1\n\n| ** _Required_** \n\n| The \"`wmver`\" claim identifies the schema version of the WMT. This gives a hint to the parser as to the fields found in the token.\n\n  
 \n\n\n\n`wmid`\n\n| Watermarking ID (WMID)\n\n| 1\n\n| *\n\n| The \"`wmid`\" is the Watermarking ID that's used to tell the Akamai edge (or another CDN) which variant should be delivered for the specific end-user session.\n\n* If you've enabled [Pattern Encryption](\\"#guid-0ba201ae-8cb5-4a0c-ab11-39155f7cd96f\\") in your AMD property, then `wmidctb64` carries the encrypted version of the `wmid` and this claim is *not required*. This parameter is required if you're not using Pattern Encryption.\n\n  
 \n\n\n\n`wmidalg` \n\n| WMID Decryption Algorithm\n\n| aes-128-cbc, aes-256-cbc\n\n| Optional\n\n| The \"`wmidalg`\" claim identifies the cipher algorithm that's used to decrypt content. This only applies if you've enabled **Pattern Encryption** in your AMD property.\n\n  
 \n\n\n\n`wmidfmt` \n\n| WMID Format\n\n| ab, hex\n\n| Optional\n\n| The \"`wmidfmt`\" claim identifies the encoding format of the WMID pattern.\n\n
 
 \n
   * **ab** (Default): specifies the pattern is a sequence of \"A\" and \"B\" characters. For example, `wmid\": \"ABBABAAABBBABABBBAAABBABBAAA`
 \n
   * **hex**. specifies the pattern is a hex string when decoded into binary implies 0=A and 1=B. For example, `wmid\": \"68EB8D8`, which translates to \"`ABBABAAABBBABABBBAAABBABBAAA`.\"
 \n
\n\n\n\n  
 \n\n\n\n`wmidivlen` \n\n| WMID IV Length\n\n| 1..N\n\n| Optional\n\n| The \"`wmidivlen` \" claim identifies the length of the Initialization Vector (IV) suitable for the specified decryption algorithm (`wmidalg`).\n\n  
 \n\n\n\n`wmidivhex` \n\n| WMID IV Hex String\n\n| Hexadecimal String\n\n| *\n\n| The \"`wmidivhex`\" claim identifies the IV to use with the specified decryption algorithm.\n\n* This claim is required if the `wmidalg` cipher requires an IV, and the target system must receive a Hex String encoded value. This is typically the case with Akamai. Contact your account representative if you require a different configuration.\n\n  
 \n\n\n\n`wmidivb64` \n\n| WMID IV Base64\n\n| Base64 String\n\n| *\n\n| The \"`wmidivb64` \" claim identifies the IV to use with the specified decryption algorithm.\n\n* This claim is required if the `wmidalg` cipher requires an IV, and the target system must receive a Base64-encoded value. By default, Akamai uses the `wmidivhex` claim. So, when Akamai is the only recipient of this token, only the `hex` version of the IV needs to be sent.\n\n  
 \n\n\n\n`wmidctb64` \n\n| WMID Ciphertext Base64\n\n| Base64 String\n\n| *\n\n| The `wmidctb64` claim contains the encrypted cipher text of the \"`wmid`.\"\n\n* This claim is required if the `wmidalg` cipher indicates the `wmid` is encrypted.\n\n  
 \n\n\n\n`wmidoff` \n\n| WMID Pattern Offset\n\n| 128, 256\n\n| Optional\n\n| The \"`wmidoff` \" claim identifies an offset that should be applied to the function that calculates the location in the pattern to use for the current media sequence number (MSN). The offset allows for a prohibitively large pattern to be defined, but only a portion of it sent in the WMT at any given point in time.\n\nThe legal values are intentionally large to allow for WMT caching to be effective.\n\n  
 \n\n\n\n`wmidpid`\n\n| WMID Password ID\n\n| String\n\n| *\n\n| The \"`wmidpid`\" claim identifies the password to use when generating the decryption key for use with Pattern Encryption.\n\n* This claim is only required if the you've enabled **Pattern Encryption** in your AMD property. (In this case, the `wmidalg` cipher would require a decryption key.)\n\n  
 \n\n\n\n`wmidpalg` \n\n| WMID Password Algorithm\n\n| sha256\n\n| *\n\n| The \"`wmidpalg`\" claim identifies the hashing function to use when generating a decryption key from a password.\n\n* This claim is only required if the `wmidalg` cipher requires a decryption key.\n\n  
 \n\n\n\n
\n
"
}
[/block]