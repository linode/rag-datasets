# [Set up watermarking in your AMD property](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-watermarking-in-your-amd-property#set-up-watermarking-in-your-amd-property)

You need to add the Watermarking behavior to your AMD property, and you can optionally set other features it offers.

# [Before you begin](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-watermarking-in-your-amd-property#before-you-begin)

You need to have it added to your Akamai contract. Work with your account representative ("rep") to get it added: `AdaptiveMediaDelivery::Watermarking`.

# [Add the Watermarking behavior](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-watermarking-in-your-amd-property#add-the-watermarking-behavior)

Follow these steps to get it added to your AMD property.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/watermarking-behavior-v1.jpg)

1. In the Property Configuration Settings options, click **Add Behavior**.

1. In the *Search available behaviors* field, input "watermarking" to filter the listed behaviors. Ensure that you select **Watermarking** from the list.

1. The new behavior is added to your configuration. Set the Enable Watermarking slider to "**On**."

1. Enable and configure at least one of these features. We recommend both. You may need to work with your watermarking vendor to obtain some of the values discussed here:

    - **Perform Signature Verification**. Ensure that this slider is set to "**On**" (default). Settings you apply here are used to verify the signature in a watermarking token (WMT). What you define here must match what's included in the `
` in the actual WMT that's defined by your watermarking vendor. You can disable this, but watermarking is susceptible to an outside attack if a signature is not included in the [WMT](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-watermarking-token-wmt) for verification.

        - **Verification Key ID #1**. Enter a unique identifier to associate with Verification Public Key #1. This value is included in the "kid" parameter in the WMT to specify that Verification Public Key #1 is used as the 
.

        - **Verification Public Key #1**. Include the full public key to be used to verify the signature in the WMT. The value needs to be hashed using the applicable encryption format set in the WMT. (The `alg` parameter set in the [JWT Header](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-watermarking-token-wmt).)

        - **Verification Key ID #2 / Verification Public Key #2**. These function the same as the "#1" options. You can include a second ID/Key combination for added security. The "kid" in the WMT must contain the Verification Key ID #2 to use Verification Public Key #2.

    - **Pattern Encryption**. If each WMT will also be encrypted by the watermarking vendor, set this slider to "**On**," (This is defined via the `wmidalg` and `wmifpid` parameters in the WMT.)

        - **Decryption Password ID #1**. Include the unique ID established for Decryption Password #1. This is included as the `wmidpid` in the WMT by your watermarking vendor.

        - **Decryption Password #1**. Input the unique password that Akamai edge servers will use to decrypt the WMT.

        - **Decryption Password ID #2 / Decryption Password #2**. You can optionally generate a second ID/Password combination to rotate passwords. The `wmidpid` included in the WMT needs to match the appropriate Decryption Password.

5. Apply Miscellaneous Settings based on the [preprocessing method](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing) your watermarking vendor used.

    - "**filename-prefix AB naming**". Set A/B Variant Location to **Filename prefix**.
    - "**directory-prefix AB naming**". Set A/B Variant Location to **Parent directory prefix**.
    - "**unlabeled A variant**". Set Use Original as A to "**On**." Then, set A/B variant location, based on the associated preprocessing method you're using with this support:

        - **filename-prefix AB naming**. Set this to **Filename prefix**.
        - **directory-prefix AB naming**. Set this to **Parent directory prefix**.