# [Watermarking-supported media formats](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-supported-media-formats#watermarking-supported-media-formats)

Watermarking is supported for use with various media formats and distribution methods.

# [Both live and on-demand media formats are supported](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-supported-media-formats#both-live-and-on-demand-media-formats-are-supported)

To work with watermarking, a media format must offer a basic mechanism for converting a request into a logical segment number. Put simply, AMD needs to map a watermarking pattern to the series of segments being requested.

- **On demand content is supported**. On demand content is packaged as a sequence of segments or fragments, and the sequence number is explicitly provided.

- **Live content is supported in a limited manner**. This is more complex with live media. So, watermarking is supported in a limited way with a specific watermarking vendor.

> Info: Media Services Live is not supported for use with watermarking.

# [Supported formats](https://techdocs.akamai.com/adaptive-media-delivery/docs/watermarking-supported-media-formats#supported-formats)

The following media formats are supported for use with watermarking:

- **Apple HTTP Live Streaming (HLS)**. Both segmented and fragmented forms of HLS are supported. With HLS, Akamai needs to deliver HLS manifest files, too. See [Key considerations with watermarking](https://techdocs.akamai.com/adaptive-media-delivery/docs/key-considerations-with-watermarking) for details.

- **Dynamic Adaptive Streaming over HTTP (DASH)**. Segmented format DASH is supported.
All formats have various requirements of the encoder or the third-party watermarking vendor or both.