# [Source content \](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#source-content)

You need to work with your watermarking vendor to produce watermarked content from your unmarked, source material.

This process is referred to as "preprocessing," and it requires that your watermarking vendor perform the following:

- Convert source material content into "A" and "B" segments/fragments. We refer to these as "variants."  
  Store the "A" and "B" variants on your origin server using different "A" and "B" file naming or pathing.

- Generate a manifest file without any indication of the "A" and "B" variants.

- There are multiple preprocessing methods you can apply.

# [The "filename-prefix AB naming" method](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#the-filename-prefix-ab-naming-method)

This is the easiest to implement, and it's the recommended method for preprocessing. The watermarking vendor needs to generate A and B variants of your source content, by including "A" and "B" in the filename of each variant segment or fragment and then store it in the applicable directory in your origin.

Here's an example that uses a presentation called "baseball," with a master playlist, a media playlist, and several TS segments:

```

/baseball/master.m3u8 ← This contains relative paths to variants: 1080-media.m3u8, 720-media.m3u8

/baseball/1080-media.m3u8 ← This references relative paths to segments: /1080/segment_1.ts

/baseball/1080/A.segment_1.ts

/baseball/1080/A.segment_2.ts

/baseball/1080/B.segment_1.ts

/baseball/1080/B.segment_2.ts

/baseball/720-media.m3u8 ← This references relative paths to segments: /720/segment_1.ts

/baseball/720/A.segment_1.ts

/baseball/720/A.segment_2.ts

/baseball/720/B.segment_1.ts

/baseball/720/B.segment_2.ts
```

# [The "directory-prefix AB naming" method](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#the-directory-prefix-ab-naming-method)

Instead of prefixing the filename, the path just before the segments/fragments is prefixed with "`/A/`" and "`/B/`" subdirectories. Variants are stored using the same file naming in each of these directories, accordingly.

Here's an example that uses a presentation called "baseball," with a master playlist, a media playlist, and several TS segments. Notice how the segment content is stored in "A" and "B" named subdirectories, but keeps its original file naming.

```

/baseball/master.m3u8 ← This contains relative paths to variants: 1080-media.m3u8, 720-media.m3u8

/baseball/1080-media.m3u8 ← This references relative paths to segments: /1080/segment_1.ts

/baseball/1080/A/segment_1.ts

/baseball/1080/A/segment_2.ts

/baseball/1080/B/segment_1.ts

/baseball/1080/B/segment_2.ts

/baseball/720-media.m3u8 ← This references relative paths to segments: /720/segment_1.ts

/baseball/720/A/segment_1.ts

/baseball/720/A/segment_2.ts

/baseball/720/B/segment_1.ts

/baseball/720/B/segment_2.ts
```

# [The "unlabeled A variant" method](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#the-unlabeled-a-variant-method)

This is additional support that can be applied to either of the preprocessing methods. It lets you easily disable watermarking once the requirement has passed. The watermarking vendor needs to leave out the specific "A" label from your content, based on your selected method—either no "A" leading the filename, or no "`/A/`" subdirectory in the path. Essentially, the "A" variant content just needs to maintain its standard naming and exist in the default location called out in the manifest file.

# [Disable watermarking with this method](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#disable-watermarking-with-this-method)

1. Disable Watermarking in your AMD property.
2. Update your client application (player) to request segment content from the default location called out in the manifest file.

Here are some examples that show how segments might be stored on your origin, after conversion by your watermarking vendor, if you're also using this method.

## [If you're using the "filename-prefix AB naming" method](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#if-youre-using-the-filename-prefix-ab-naming-method)

```

/baseball/master.m3u8 ← This contains relative paths to variants: 1080-media.m3u8, 720-media.m3u8

/baseball/1080-media.m3u8 ← This references relative paths to segments: /1080/segment_1.ts

/baseball/1080/segment_1.ts ← Unlabeled, this facilitates easy disabling of watermarking.

/baseball/1080/segment_2.ts ← Unlabeled, this facilitates easy disabling of watermarking.

/baseball/1080/B.segment_1.ts

/baseball/1080/B.segment_2.ts

/baseball/720-media.m3u8 ← This references relative paths to segments: /720/segment_1.ts

/baseball/720/segment_1.ts ← Unlabeled, this facilitates easy disabling of watermarking.

/baseball/720/segment_2.ts ← Unlabeled, this facilitates easy disabling of watermarking.

/baseball/720/B.segment_1.ts

/baseball/720/B.segment_2.ts
```

## [If you're using the "directory-prefix AB naming" method](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#if-youre-using-the-directory-prefix-ab-naming-method)

```

/baseball/master.m3u8 ← This contains relative paths to variants: 1080-media.m3u8, 720-media.m3u8

/baseball/1080-media.m3u8 ← This references relative paths to segments: /1080/segment_1.ts

/baseball/1080/segment_1.ts ← Unlabeled, this facilitates easy disabling of watermarking.

/baseball/1080/segment_2.ts ← Unlabeled, this facilitates easy disabling of watermarking.

/baseball/1080/B/segment_1.ts

/baseball/1080/B/segment_2.ts

/baseball/720-media.m3u8 ← This references relative paths to segments: /720/segment_1.ts

/baseball/720/segment_1.ts ← Unlabeled, this facilitates easy disabling of watermarking.

/baseball/720/segment_2.ts

/baseball/720/B/segment_1.ts

/baseball/720/B/segment_2.ts
```

# [Are you using separate audio and video segments?](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#are-you-using-separate-audio-and-video-segments)

If you prepared your content with separate audio and video segments using the _same file extensions_, Akamai will attempt the A to B variant switch with audio as well as video. So, your watermarking vendor must prepare A and B variants for the audio segments as well, even though the A to B switch for the audio has no watermarking benefit.

If the audio segments use a _different file extension_, they must reside in the default location specified in the manifest because the A to B switch is bypassed for them. This is one of the primary benefits of the “filename-prefix AB naming” approach when preprocessing content.

This applies to all preprocessing methods.

# [DASH-specific preprocessing requirements](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#dash-specific-preprocessing-requirements)

The only variant of DASH that's supported is `SegmentTemplate` using the `$Number$` expansion in a DASH media presentation description (MPD). The `$Number$` macro must be at the end of the file name, and prefixed with an underscore ("\_") character. Additionally, any “init” URLs must be prefixed with an additional naming of the form, “`
_init.mp4`.” This helps Akamai detect the file as an “`init`” request and tells the Akamai edge server to skip the AB switching.

 > Warning: Use proper file naming
  If your DASH `_init` segments don't follow these naming requirements, requests for them will result in a 403 error. The `{filename}` value for an `_init` file can be a maximum of 247 characters in length.

This DASH MPD snippet shows an example of the tags and attributes:

```

    

        

            <SegmentTemplate duration="120" timescale="30" startNumber="1"
                           media="$RepresentationID$/$RepresentationID$_$Number$.m4v"
                           initialization="$RepresentationID$/$RepresentationID$_init.m4v"/>
            ...
        

        

            <SegmentTemplate duration="192512" timescale="48000" startNumber="1"
                           media="$RepresentationID$/$RepresentationID$_$Number$.m4a"
                           initialization="$RepresentationID$/$RepresentationID$_init.m4a"/>
            ...
        

    

```

# [How to generate the manifest file](https://techdocs.akamai.com/adaptive-media-delivery/docs/source-content-preprocessing#how-to-generate-the-manifest-file)

The original manifest file—before any preprocessing—is what is used by your client application (player) to request content. You don't need to modify the manifest file to obtain variant content. The Akamai edge uses the [the watermarking token (WMT)](https://techdocs.akamai.com/adaptive-media-delivery/docs/the-watermarking-token-wmt) that your vendor creates to do this throughout the process, and ensures proper delivery of the appropriate "A" or "B" segment.