# [Set up for non-watermarked content](https://techdocs.akamai.com/adaptive-media-delivery/docs/set-up-for-non-watermarked-content#set-up-for-non-watermarked-content)

It's safe to assume that not all of the content you want to deliver to end users needs to be watermarked. Here, we cover what you need to do to support this content.

Once you add the Watermarking behavior to a rule in your AMD property and enable it, it applies to all requests for content that meet that rule's match criteria. So, all requests for content that match that rule—regardless if they require watermarking—must include a watermarking token (WMT). To account for non-watermarked content, use multiple rules and set specific match criteria. For example:

1. Set up a rule in your AMD property to specifically match requests for content you want watermarked.

1. Set up a separate "Blank Rule Template" in the property, and set its match criteria to accommodate requests for non-watermarked content.

There are a couple of additional points you should remember:

- **Rule priority in a property**. The lower a rule is listed in Property Manager, the higher its priority. With this use case, a rule to filter out requests for non-watermarked content should be lower in the list.

![](https://techdocs.akamai.com/adaptive-media-delivery/img/non-watermarking-content-v1.jpg)

- **The "Default Rule" in a policy applies to *all requests***. Don't set up the Watermarking behavior in this rule unless you're looking to have all content watermarked.