# [Reset a property report](https://techdocs.akamai.com/adaptive-acceleration/docs/post-property-reset#reset-a-property-report)
