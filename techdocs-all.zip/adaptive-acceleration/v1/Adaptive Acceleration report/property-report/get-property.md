# [Get a property report](https://techdocs.akamai.com/adaptive-acceleration/docs/get-property#get-a-property-report)
