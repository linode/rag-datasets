# [Property report](https://techdocs.akamai.com/adaptive-acceleration/docs/property-report#property-report)
