# [Adaptive Acceleration API](https://techdocs.akamai.com/adaptive-acceleration/docs/adaptive-acceleration-api#adaptive-acceleration-api)
