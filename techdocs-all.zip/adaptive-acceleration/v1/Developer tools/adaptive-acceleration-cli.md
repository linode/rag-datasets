# [Adaptive Acceleration CLI](https://techdocs.akamai.com/adaptive-acceleration/docs/adaptive-acceleration-cli#adaptive-acceleration-cli)
