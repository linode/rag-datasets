# [Welcome to Adaptive Acceleration](https://techdocs.akamai.com/adaptive-acceleration/docs/welcome-adaptive-acceleration#welcome-to-adaptive-acceleration)

You can add Adaptive Acceleration to your Ion property to improve HTML page load performance.  Adaptive Acceleration syncs with Akamai real-user monitoring to gather navigation and resource timing data, and stores that data in a policy that's associated with your hostname. As requests for your hostname continue, policy data is gathered and reviewed to identify key resources. This allows Adaptive Acceleration to provide these resources to an end user's browser ahead of time, reducing the load and rendering time for your web pages.

# [1. Set up Adaptive Acceleration](https://techdocs.akamai.com/adaptive-acceleration/docs/welcome-adaptive-acceleration#1-set-up-adaptive-acceleration)

First, you need to set up Adaptive Acceleration in your Ion property. We've created some workflows to help with this:

- [Use Property Manager in ​Akamai Control Center​](https://techdocs.akamai.com/ion/docs/set-up-adaptive-acceleration)
- [Use the Property Manager API](https://techdocs.akamai.com/ion/reference/add-manage-adaptive-acceleration)

# [2. Manage your Adaptive Acceleration reports](https://techdocs.akamai.com/adaptive-acceleration/docs/welcome-adaptive-acceleration#2-manage-your-adaptive-acceleration-reports)

This is what's covered in this documentation. Specifically, the use of the Adaptive Acceleration interface in ​Akamai Control Center​ as well as its companion API and CLI components. These tools let you review the reports of real-user monitoring data gathered to apply Adaptive Acceleration, and reset the data-gathering mechanism.

- [View and troubleshoot a policy](https://techdocs.akamai.com/adaptive-acceleration/docs/view-and-troubleshoot-a-policy) 
- [Reset the Policy](https://techdocs.akamai.com/adaptive-acceleration/docs/reset-the-policy) 

# [What's new](https://techdocs.akamai.com/adaptive-acceleration/docs/welcome-adaptive-acceleration#whats-new)

- [Release notes](https://techdocs.akamai.com/adaptive-acceleration/changelog)