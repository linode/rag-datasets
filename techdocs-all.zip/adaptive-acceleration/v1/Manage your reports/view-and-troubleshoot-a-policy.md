# [View and troubleshoot a report](https://techdocs.akamai.com/adaptive-acceleration/docs/view-and-troubleshoot-a-policy#view-and-troubleshoot-a-report)

Adaptive Acceleration creates reports based on beacon data gathered from mPulse. If requested content or visitor patterns change, RUM beacon data will be used to periodically update the Adaptive Acceleration report. 

# [The Adaptive Acceleration API](https://techdocs.akamai.com/adaptive-acceleration/docs/view-and-troubleshoot-a-policy#the-adaptive-acceleration-api)

***

You can programmatically view your report and review pushed and pre-connected resources as well as any preloaded fonts being sent to end-user browsers.

# [The Adaptive Acceleration interface](https://techdocs.akamai.com/adaptive-acceleration/docs/view-and-troubleshoot-a-policy#the-adaptive-acceleration-interface)

***

You can use this interface to view Adaptive Acceleration report details for troubleshooting. 

1. From ​Akamai Control Center​, select ☰ > **CDN** > **Properties**.

2. Find the Ion property with Adaptive Acceleration enabled, and click its **Property Name** link to open it.

3. From the **Related apps** menu, select **Automatic Push and Preconnect**. The Adaptive Acceleration interface is revealed, where you can use these resources:

   - **Review the Policy Last Updated timestamp**. This tells you when the report was last refreshed.

   - **Click View warnings**. This shows warnings that may help you troubleshoot a specific issue. 

   - **Click View Event Logs**. This shows a list of events that have occurred with the Adaptive Acceleration service for the selected domain.

   - **Expand Global Policy**. This shows you the resources that were pushed and the hostnames that were pre-connected for the selected domain.

 > Tip: 
  You can also [review separate report data](https://techdocs.akamai.com/adaptive-acceleration/docs/troubleshoot) for mPulse beacon data that was used to apply Adaptive Acceleration.