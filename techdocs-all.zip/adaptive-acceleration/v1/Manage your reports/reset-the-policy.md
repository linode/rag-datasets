# [Reset the report](https://techdocs.akamai.com/adaptive-acceleration/docs/reset-the-policy#reset-the-report)

In some cases, you might want to force a new report, rather than wait for earlier data to drop out of the analysis. Akamai's mPulse real-user monitor cycles data from its analysis every four hours.

# [Reset after you change your site](https://techdocs.akamai.com/adaptive-acceleration/docs/reset-the-policy#reset-after-you-change-your-site)

***

You might want to reset the report if your site's content changed substantially in a short period of time. Without a reset, requests for pages that have new images, scripts, fonts, and styles could keep getting older resources. Also, a user's browser can revert to issuing separate requests for the new resources and hostname connections, which may delay delivery. Resetting the report schedules a fresh analysis of your site's usage almost immediately.

 > Note: Before you reset...
  When font files are updated at the origin, you need to perform a report reset. The auto-update functionality refreshes the current report based on the latest beacons. It doesn't account for origin changes such as font version upgrades.
  When you reset a report, Adaptive Acceleration won't apply again until the beacon data source collects sufficient data. All past data is immediately cleared.

# [The Adaptive Acceleration API](https://techdocs.akamai.com/adaptive-acceleration/docs/reset-the-policy#the-adaptive-acceleration-api)

***

You can use an application programming interface (API) to purge the report programmatically. For example, if your site uses automatic deployments, you might add a purge to the end of the deployment workflow.

# [The Adaptive Acceleration interface](https://techdocs.akamai.com/adaptive-acceleration/docs/reset-the-policy#the-adaptive-acceleration-interface)

***

1. From ​Akamai Control Center​, select ☰ > **CDN** > **Properties**.

2. Find the Ion property with Adaptive Acceleration enabled and click its **Property Name** link to open it.

3. From the Related apps menu, select **Automatic Push and Preconnect**.

4. Click **Reset policy**.

# [The Adaptive Acceleration CLI](https://techdocs.akamai.com/adaptive-acceleration/docs/reset-the-policy#the-adaptive-acceleration-cli)

***

Akamai offers a [CLI for Adaptive Acceleration](https://github.com/akamai/cli-adaptive-acceleration) that you can use to manually reset your report. This may be the approach you want to take if your site resources change frequently. For example, this may apply if you're working in a continuous deployment environment.