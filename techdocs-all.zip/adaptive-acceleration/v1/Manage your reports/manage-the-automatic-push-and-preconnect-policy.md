# [About reports](https://techdocs.akamai.com/adaptive-acceleration/docs/manage-the-automatic-push-and-preconnect-policy#about-reports)

An Adaptive Acceleration report creates rules based on beacon data that's gathered from Akamai's mPulse application. Changes in requested content and visitor patterns prompt the beacon data source to periodically update your report. The Policy Last Updated timestamp indicates the last time the report was refreshed.

Reports apply to three of the Adaptive Acceleration features:

- **Automatic Push**
- **Automatic Preconnect**
- **Automatic Font Preload** (This requires mPulse as your beacon data source.)

![](https://techdocs.akamai.com/ion/img/ion-a2-options-v2.png)

# [What's in a report](https://techdocs.akamai.com/adaptive-acceleration/docs/manage-the-automatic-push-and-preconnect-policy#whats-in-a-report)

The Adaptive Acceleration page in ​Control Center​​ displays information about the rules that determine:

- which resources to send 
- which connections to establish
- which fonts to preload to URLs on your property
- warnings and event logs for the report for troubleshooting

# [More information](https://techdocs.akamai.com/adaptive-acceleration/docs/manage-the-automatic-push-and-preconnect-policy#more-information)

If you'd like more information on Adaptive Acceleration including how it's set up and details on what's gathered in the report, take a look at its tutorial in the [Ion user docs](https://techdocs.akamai.com/ion/docs/set-up-adaptive-acceleration#4-enable-automatic-push-preconnect-and-font-preload).