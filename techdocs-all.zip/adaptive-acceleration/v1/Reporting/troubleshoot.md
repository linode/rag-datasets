# [Real user monitoring reports](https://techdocs.akamai.com/adaptive-acceleration/docs/troubleshoot#real-user-monitoring-reports)

The mPulse real-user monitoring tool that Adaptive Acceleration leverages offers data reporting. You can use it to [monitor](https://techdocs.akamai.com/mpulse/docs/about-mpulse-reports) your beacon data.