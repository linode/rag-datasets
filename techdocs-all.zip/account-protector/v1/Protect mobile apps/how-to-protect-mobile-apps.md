# [How to protect mobile and other native apps](https://techdocs.akamai.com/account-protector/docs/how-to-protect-mobile-apps#how-to-protect-mobile-and-other-native-apps)

How to integrate Account Protector into your mobile or other native application.

If you have a mobile ***web*** app, set up account protection for login pages, protecting them like any other API resource endpoints.

For mobile and other ***native*** apps, you can use the [Native App Traffic Protection SDK](https://techdocs.akamai.com/native-app-traffic-protect-sdk/) , which is an add-on to Account Protector. It lets you take account protection technology and apply it to traffic from your native applications. If you don't have the SDK, contact your account team.