# [List protected API operations](https://techdocs.akamai.com/account-protector/docs/get-account-protection#list-protected-api-operations)
