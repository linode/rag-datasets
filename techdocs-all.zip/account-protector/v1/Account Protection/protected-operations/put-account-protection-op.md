# [Update a protected API operation](https://techdocs.akamai.com/account-protector/docs/put-account-protection-op#update-a-protected-api-operation)
