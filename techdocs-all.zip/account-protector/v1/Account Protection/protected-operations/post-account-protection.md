# [Create protected API operations](https://techdocs.akamai.com/account-protector/docs/post-account-protection#create-protected-api-operations)
