# [Delete a protected API operation](https://techdocs.akamai.com/account-protector/docs/delete-account-protection-op#delete-a-protected-api-operation)
