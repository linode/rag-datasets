# [Get protected API operations](https://techdocs.akamai.com/account-protector/docs/get-account-protection-op#get-protected-api-operations)
