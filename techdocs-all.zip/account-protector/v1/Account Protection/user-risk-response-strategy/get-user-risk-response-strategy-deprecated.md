# [Get user risk response strategy (deprecated)](https://techdocs.akamai.com/account-protector/docs/get-user-risk-response-strategy-deprecated#get-user-risk-response-strategy-deprecated)
