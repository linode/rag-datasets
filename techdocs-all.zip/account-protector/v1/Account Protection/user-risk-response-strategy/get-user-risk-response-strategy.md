# [Get user risk response strategy](https://techdocs.akamai.com/account-protector/docs/get-user-risk-response-strategy#get-user-risk-response-strategy)
