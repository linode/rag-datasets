# [Update the user risk response strategy](https://techdocs.akamai.com/account-protector/docs/put-user-risk-response-strategy#update-the-user-risk-response-strategy)
