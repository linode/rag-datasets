# [Get Account Protector general settings](https://techdocs.akamai.com/account-protector/docs/get-account-protection-settings#get-account-protector-general-settings)
