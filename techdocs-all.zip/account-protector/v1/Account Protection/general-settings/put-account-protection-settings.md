# [Update Account Protector general settings](https://techdocs.akamai.com/account-protector/docs/put-account-protection-settings#update-account-protector-general-settings)
