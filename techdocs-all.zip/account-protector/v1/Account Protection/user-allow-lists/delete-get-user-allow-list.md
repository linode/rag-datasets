# [Delete the user allow list ID for Account Protector](https://techdocs.akamai.com/account-protector/docs/delete-get-user-allow-list#delete-the-user-allow-list-id-for-account-protector)
