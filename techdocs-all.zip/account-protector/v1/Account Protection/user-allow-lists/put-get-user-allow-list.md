# [Update the user allow list ID for Account Protector](https://techdocs.akamai.com/account-protector/docs/put-get-user-allow-list#update-the-user-allow-list-id-for-account-protector)
