# [Get the user allow list ID for Account Protector](https://techdocs.akamai.com/account-protector/docs/get-user-allow-list#get-the-user-allow-list-id-for-account-protector)
