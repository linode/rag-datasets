# [User risk response strategy](https://techdocs.akamai.com/account-protector/docs/user-risk-response-strategy#user-risk-response-strategy)
