# [General settings](https://techdocs.akamai.com/account-protector/docs/general-settings#general-settings)
