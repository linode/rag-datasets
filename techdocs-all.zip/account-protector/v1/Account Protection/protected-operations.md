# [Protected operations](https://techdocs.akamai.com/account-protector/docs/protected-operations#protected-operations)
