# [Bot product comparison](https://techdocs.akamai.com/account-protector/docs/bot-product-comparison#bot-product-comparison)

Availability of features and entitlements by bot product.

How you handle bots, depends upon your needs:

- To see what bots are hitting your site and then mitigate or allow them, you can use the bot protections that come included with App & API Protector. This offering is called **Bot Visibility and Mitigation**.

- Say you're dealing with adversarial bots or you have specific transactional endpoints, like a checkout page, you need to protect.  To  combat the most sophisticated bots, turn to **Bot Manager Premier**, which you can add on to any WAF solution or purchase alone.

- If you have a problem with credential stuffing bots  attacking your login page or trying to take over accounts of your end users, look into **Account Protector**.

- If you see lots of scraper bots lifting your data and slowing your site's performance, you'll want to implement our definitive solution to this problem: **Content Protector**

 > Note: 
  Some customers may have Bot Manager Standard, which is no longer sold, but still in use.

The following list shows what major bot management features come with each bot product.

| Feature | Bot Visibility and Mitigation | Bot Manager Standard | Bot Manager Premier | Account Protector | Content Protector (LA) |
|---|---|---|---|---|---|
|  | _The bot protections which are included with <strong>App & API Protector</strong> and <strong>App & API Protector with Advanced Security Management</strong>. [Read online help](https://techdocs.akamai.com/app-api-protector/docs/view-mitigate-bots) _ | _No longer sold, but still in use. _ | _Handle adversarial bots with highly sophisticated bot protections. Standalone product, which you can also add on to any web application firewall product. [Read online help](https://techdocs.akamai.com/bot-manager/docs/welcome)_ | _Mitigate user account takeover and abuse. Includes Bot Manager Premier. [Read online help](https://techdocs.akamai.com/account-protector/docs/welcome-to-account-protector)_  | _Protect your content from web scraper bots with our most effective solution yet. [Read online help](https://techdocs.akamai.com/content-protector/docs/welcome)_ |
| **General bot detection** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Akamai-categorized bots** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Custom-defined bots** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Transparent detection** (also called **Browser impersonator detection**) | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Request anomaly detection** (no longer supported, this is replaced by [Browser impersonator detection](https://techdocs.akamai.com/bot-manager/docs/transparent-det#browser-impersonator)) | ✓ | ✓ | ✓ | ✓ |  |
| **Active detections** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Protection against basic web scrapers** |  | ✓ | ✓ | ✓ | ✓ |
| **Protection against sophisticated web scrapers** |  |  |  |  | ✓ |
| **Standard transactional endpoint protection** (also called **behavioral detection**) |  |  | ✓ | ✓ |  |
| **GraphQL, AJAX, and search endpoints** |  |  |  |  | ✓ |
| **Race conditions** |  |  |  |  | ✓ |
| **[Forward bot results to origin](https://techdocs.akamai.com/bot-manager/docs/signal-origin)** |  |  | ✓ | ✓ | ✓ |
| **Scoring** |  |  | ✓ Bot Score |  ✓ Bot Score ✓ User Risk Score | ✓ Scraper Score |
| **Actions** | <li>Monitor <li>Skip <li>Deny <li>Allow <li>Ignore <li>Conditional Actions <li>Interstitial Challenge <li>Crypto Challenge  | <li>Monitor <li>Skip <li>Deny <li>Custom Deny <li>Slow, Delay <li>Tarpit <li>Serve Alternate <li>Allow <li>Ignore <li>Conditional Actions  | <li>Monitor <li>Skip <li>Captcha <li>Crypto challenge <li>Deny <li>Custom Deny <li>Slow, Delay <li>Tarpit <li>Serve Alternate <li>Allow <li>Ignore <li>Conditional Actions  | <li>Monitor <li>Skip <li>Captcha <li>Crypto challenge <li>Deny <li>Custom Deny <li>Slow, Delay <li>Tarpit <li>Serve Alternate <li>Allow <li>Ignore <li>Conditional Actions  | <li> Monitor <li> Skip <li> Deny <li> Custom Deny <li> Slow <li> Delay <li> Tarpit <li> Serve Alternate <li> Allow <li> Ignore <li> Conditional Actions  |
| **Bot Trends Report** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Web Security Analytics shows bots** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Bot Endpoint Protection report** |  |  | ✓ | ✓ |  |
| **Bot rate policies** |  | ✓ | ✓ | ✓ | ✓ |
| **Account Takeover Protection** |  |  |  | ✓ |  |
| **Account Opening Abuse Protection** |  |  |  | ✓ |  |
| **Mutilistep workflow protection** |  |  |  | ✓ |  |
| **Forward user risk results to origin** |  |  |  | ✓ |  |