# [Welcome to Account Protector](https://techdocs.akamai.com/account-protector/docs/welcome-to-account-protector#welcome-to-account-protector)

How can you trust that a login request is coming from the account owner and not an imposter?

Use Account Protector to help detect and mitigate inauthentic user behavior that can lead to account takeover and other abuse. The solution recognizes authentic users, allowing seamless customer journeys for trusted users and blocking imposters who want to steal assets like: bank account funds, gift card balances, and rare game items. This solution works in real time, accelerating your ability to spot and stop account takeover without increasing friction for your legitimate users. 

Account Protector evaluates requests and calculates a _user risk score_ gauging the likelihood that a request is not authentic.  Based on that score, you can apply different response actions at the edge. Base decisions on both real-time and historical behavioral activity. You can also pull data via our SIEM API to analyze with separate fraud tools.

In addition to understanding individual user profiles, it also evaluates population profiles -- understanding how your overall group of users interact with your site in order to detect abusive behaviors even from the first login of a new user.

Because it incorporates machine learning, the service understands more as it acquires credential data and self-tunes. So it gets better at ferreting out misuse and confirming authentic logins. This adaptive intelligence means your legitimate users can login with greater ease and safety. 

When you purchase Account Protector you also get the cutting-edge bot mitigation capabilities of Bot Manager Premier, which can help you fend off credential stuffing and other automated abusive behaviors.

# [Get started](https://techdocs.akamai.com/account-protector/docs/welcome-to-account-protector#get-started)

- [How it works](https://techdocs.akamai.com/account-protector/docs/how-it-works)
- [Where account protection settings live](https://techdocs.akamai.com/account-protector/docs/where-to-set-account-protection-controls)
- [Prerequisites](https://techdocs.akamai.com/account-protector/docs/prerequisites)
- [Define login endpoints](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints)

# [Developer tools](https://techdocs.akamai.com/account-protector/docs/welcome-to-account-protector#developer-tools)

- [Account Protector API](https://techdocs.akamai.com/account-protector/reference/api) 
- [Native App Traffic Protection SDK](https://techdocs.akamai.com/native-app-traffic-protect-sdk/docs)
- [Bot Manager API](https://techdocs.akamai.com/bot-manager/reference/api)
- [Cloud security APIs](https://techdocs.akamai.com/application-security/reference)

# [What's new](https://techdocs.akamai.com/account-protector/docs/welcome-to-account-protector#whats-new)

- [Release notes](https://techdocs.akamai.com/account-protector/changelog)