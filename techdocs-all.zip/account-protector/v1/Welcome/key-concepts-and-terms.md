# [Key concepts and terms](https://techdocs.akamai.com/account-protector/docs/key-concepts-and-terms#key-concepts-and-terms)

Some terms you'll want to understand.

- **Action**. Response to a triggered rule. An action may be to log an alert or to deny a  request. Account Protector lets you specify additional actions, like serving up alternate content or delaying incoming connections.

- **Allowlist**. A list of entities that are trusted. You can put an entity, like an IP address or geographic region on a list of allowed visitors. Account Protector offers a [user list](https://techdocs.akamai.com/account-protector/docs/user-lists) feature, which is a specific allowlist that lets you specify users who should bypass account protections. 

- **Blocklist**. A list of entities that are suspect or undesirable. You can put an entity like an IP address or geographic region on a list of unwanted visitors. You could choose to deny requests from blocklisted addresses or locations. Account Protector doesn't specifically use blocklists. To deny requests, you [set your user risk response strategy](https://techdocs.akamai.com/account-protector/docs/set-user-risk-response-strategy).

- **Bot**. Short for "robot," this is a program that performs automated tasks for a user or another program. Good bots are services like search engine crawlers. Bad bots include programs that scrape data, like prices, or repeatedly try login credentials.

- **Credential stuffing**. Occurs when criminals acquire a user's access credentials for one website, then use automated tools to try them on other sites. Often they use a simple brute force approach, testing login forms repeatedly.

- **Device fingerprint**. Factored into user risk score calculations, this value reflects the browser and device a user regularly uses to log into your site. This is not a unique identifier for a user.

- **Device ID**. Factored into user risk score calculations, this value is a unique identifier for a browser on a specific device. If cookies change, this ID changes.

- **False negative**. A request from a bad actor generates a user risk score that is too low. To deal with this you may need to adjust your response strategy thresholds.

- **Indicators**. Elements, like device and location, that factor into user risk score. An indicator may signify risk or trust. General indicators are neutral details about a request. [See indicator list](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators).

- **False positive**. A legitimate user's request generates a user risk score that is too high. To deal with this you may need to adjust your response strategy thresholds. Or, it may help to implement a conditional action which excludes the condition causing account protection to snag desired user requests. 

- **Security configuration**. A collection of protection settings that live on the Akamai edge server with your delivery configuration. This is the basic building block for all protections you set. 

- **Security policy**. Lets you set protection controls and specify resulting response actions. A security configuration can contain many security policies.

- **Shared resources**. Elements you can use across multiple security policies or security configurations. These handy items let you update an item in one place, and have it update automatically in controls  where you use it. Network lists, rate policies, custom rules, and client reputation profiles are all shared resources.

- **SIEM (Security Information and Event Management) integration**. Lets you capture security events generated in your cloud security solution and analyze them in your favorite SIEM reporting application, like Splunk.

- **User ID**.   A Universally Unique Identifier (UUID) that account protection generates automatically and uses to track a user's behavior.  

- **User list**. A collection of user IDs or usernames you create for use as an allowlist in Account Protector.  

- **Username**.  The identifier or moniker a user has with your site or service. Usually visitors enter a username and password to gain access.  If you want to export this value in SIEM events, include it [when you turn on SIEM integration](https://techdocs.akamai.com/siem-integration/docs/akamai-siem-integration-for-splunk-and-cef-syslog#step-1-turn-on-siem-integration).

- **User profile**. Set of data attached to a UUID, including a history of logins, locations, behavior, devices, and more.  

- **User risk level**. In reports you see these color-coded segments that break risk scores into severity tiers:

  - 
**Critical**
 - score range from 76 to 100.

  - 
**High**
 - score range from 51 to 75.

  - 
**Medium**
 - score range from 26 to 50.

  - 
**Low**
 - score range from 0 to 25.

- **User risk score**. Measure between 0-100 of the likelihood that a request is suspect and not from an authentic user . Higher score means higher risk. [More](https://techdocs.akamai.com/account-protector/docs/user-risk-score)

- **User risk score status**. Lets you know what data a user risk score is based on and whether account protection is using a complete user profile or other factors. [More](https://techdocs.akamai.com/account-protector/docs/account-protector-signal-to-origin#score-status)

- **UUID**.  A randomly-generated value—a Universally Unique Identifier—that account protection uses to identify a user. Appears as reporting as **User ID**.