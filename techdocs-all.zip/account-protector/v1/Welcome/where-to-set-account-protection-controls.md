# [Where to set account protection controls](https://techdocs.akamai.com/account-protector/docs/where-to-set-account-protection-controls#where-to-set-account-protection-controls)

Account protection is like any other cloud security protection. It lives within a security configuration. A security configuration is the basic building block for all security protections. It contains all controls you set to evaluate an incoming request, lets you define the scope of protections, and control some general settings. Even if Account Protector is the only product you use, it lives inside a security configuration. You'll find details on managing a security configuration&mdash;even if you don't use the suite of web protections it usually contains&mdash;in any of the following online help:

- [App & API Protector online help](https://techdocs.akamai.com/app-api-protector/docs)
- [Kona Site Defender online help](https://techdocs.akamai.com/kona-site-defender/docs)
- [Web Application Protector online help](https://techdocs.akamai.com/web-app-protector/docs)

Account Protector includes Bot Manager Premier, which provides cutting-edge detections and the ability to counter the most sophisticated adversarial bots. For full details on using Bot Manager Premier, consult [Bot Manager online help](https://techdocs.akamai.com/bot-manager/docs).

 > Note: 
  Account Protector and Bot Manager are not currently compatible with Property Manager's HTTP/3 behavior. To ensure bot and user account detections run as expected, don't turn on this behavior in Property Manager.