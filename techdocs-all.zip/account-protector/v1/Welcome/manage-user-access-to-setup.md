# [Manage user access to setup](https://techdocs.akamai.com/account-protector/docs/manage-user-access-to-setup#manage-user-access-to-setup)

Your basic access to any application depends upon what apps and services you purchased and are part of your account and contract.

Beyond that, an administrator can add users then create and assign roles to grant individual users access to applications. You can find detailed instructions for managing users, roles, and permissions in the [Identity and Access Management online help](https://techdocs.akamai.com/iam).

When you edit a role you created or cloned, you see a long list of permissions. As a control center user, if Account Protector is on your account, and you have access to edit Security Configuration and Bot Manager, you can edit Account Protector Settings. The one exception to this is the **User Console Search** permission, which lets one of your staff members search for a [user profile](https://techdocs.akamai.com/account-protector/docs/view-user-profile) by username. To find permissions that let users view, edit, and create security configurations and account protection settings, scroll down to the **Web Security** section (formerly called **Web Application Firewall** ). Here, you can select the permissions you want to grant:

| Permission | Grants the following abilities |
|---|---|
| Security Configuration - Edit | <ul><li>View/edit security configurations <li>View/edit network lists <li>View/manage security reporting</li></ul>  |
| Security Configuration - View Only | <ul><li>View security configurations <li>View network lists <li>View security reporting</li></ul>  |
| Network List - Edit | View/edit network lists |
| Network List - View Only | View network lists |
| SecurityViewOnly (Legacy) | Legacy. Do not use. |
| Bot Manager Config | View/edit Bot Management protections |
| User Console Search | Search User Intelligence Console report by username, not just account protector-generated user ID. |
|  Username in Clear - View | See the actual username in the User Intelligence Console, Web Security Analytics, and User Lists. |

