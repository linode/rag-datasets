# [Account Protector indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#account-protector-indicators)

An overview of indicators collected and analyzed in order to create users behavioral profile and identify irregularities.

Review the indicators to see in detail what contributed to the final user risk score. A general indicator provides statistics related to the observed behavior. A risk indicator signals a behavior that increased the user risk score of the request, while a trust indicator points to a behavior that decreased the user risk score. An example of a risk indicator may be a new AS number that the account owner has never used in the past. A trust indicator may be a device that the account owner uses regularly.

# [User Profile indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#user-profile-indicators)

| Name                              | Type       | Header and SIEM key | Description                                                                                                           |
| :-------------------------------- | :--------- | :------------------ | :-------------------------------------------------------------------------------------------------------------------- |
| User Network Profiling            | Risk/Trust | unp                 | Evaluates the user's network based on the user's behavioral profile and data for the entire user population.          |
| User Country/Area Profiling       | Risk/Trust | ugp                 | Evaluates the user's country or area based on the user's behavioral profile and data for the entire user population.  |
| User Time of Day Profiling        | Risk/Trust | utp                 | Evaluates the time-of-day based on the user's behavioral profile and data for the entire user population.             |
| User Device Fingerprint Profiling | Risk/Trust | udfp                | Evaluates the device fingerprint based on the user's behavioral profile and data for the entire user population.      |
| User Device OS Profiling          | Risk/Trust | udop                | Evaluates the device operating system based on the user's behavioral profile and data for the entire user population. |
| User Device Browser Profiling     | Risk/Trust | udbp                | Evaluates the device browser type based on the user's behavioral profile and data for the entire user population.     |
| New User Device                   | General    | nd                  | Indicates whether the device is new (unknown) for the user. Possible values are `true` and `false`.                   |
| User Device ID Profiling          | Trust      | udip                | Evaluates the device based on the user's behavioral profile.                                                          |
| User IP Address Profiling         | General    | uip                 | Evaluates the IP address based on the user's behavioral profile.                                                      |
| No User Identifier                | Risk       | nui                 | No User Identifier was available for the request.                                                                     |

# [Device indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#device-indicators)

| Name                                                  | Type    | Header and SIEM key | Description                                                                                                  |
| :---------------------------------------------------- | :------ | :------------------ | :----------------------------------------------------------------------------------------------------------- |
| Device ID                                             | General | di                  | Identifier for this specific device.                                                                         |
| Device OS                                             | General | do                  | Operating system family and major version number.                                                            |
| Device browser type                                   | General | db                  | Browser or application family and major version number.                                                      |
| Number of users for device in last hour               | General | duc_1h              | Number of users recorded on specific device within last hour.                                                |
| Number of users for device in last 24 hours           | General | duc_1d              | Number of users recorded on specific device within last 24-hours.                                            |
| Excessive number of users for a device                | Risk    | due                 | Number of different users on a specific device in the last hour or 24 hours reached suspiciously high level. |
| Excessive failed percentage for a device              | Risk    | dfe                 | Percentage of requests that were failures on the device reached a suspiciously high level.                   |
| IPs for device in last hour                           | General | dic_1h              | Number of different originating IP addresses used by a device in the last hour.                              |
| IPs for device in last day                            | General | dic_1d              | Number of different originating IP addresses used by a device in last 24 hours.                              |
| Excessive IPs for a device                            | Risk    | die                 | Number of different IP addresses recorded for a device reached suspiciously high level.                      |
| Number of AS numbers for device in last hour          | General | dac_1h              | Number of different AS numbers recorded for a device in the last hour.                                       |
| Number of AS numbers for device in last 24 hours      | General | dac_1d              | Number of different AS numbers recorded for a device in the last 24 hours.                                   |
| Excessive number of AS numbers for a device           | Risk    | dae                 | Number of different AS Numbers recorded for a device reached suspiciously high level.                        |
| Number of countries/areas for device in last hour     | General | dgc_1h              | Number of different countries/areas recorded for a device in the last hour.                                  |
| Number of countries/areas for device in last 24 hours | General | dgc_1d              | Number of different countries/areas recorded for a device in the last 24 hours.                              |
| Excessive number of countries/areas for a device      | Risk    | dge                 | Number of different countries/areas recorded for a device reached suspiciously high level.                   |
| Number of cities for device in last hour              | General | dcc_1h              | Number of different cities recorded for a device in the last hour.                                           |
| Number of cities for device in last 24 hours          | General | dcc_1d              | Number of different cities recorded for a device in the last 24 hours.                                       |
| Excessive number of cities for a device               | Risk    | dce                 | Number of different cities recorded for a device reached suspiciously high level.                            |
| Excessive percentage of bad IPs for a device          | Risk    | dre                 | Percentage of IP addresses for a device with a bad client reputation reached suspiciously high level.        |
| Numbers of user-agents for device in last hour        | General | dbc_1h              | Number of different user agents recorded for a device in the last hour.                                      |
| Numbers of user-agents for device in last 24 hours    | General | dbc_1d              | Number of different user agents recorded for a device in the last 24 hours.                                  |
| Excessive number of user-agents for a device          | Risk    | dbe                 | Number of different user agents recorded for a device reached suspiciously high level.                       |
| Excessive number of requests for device               | Risk    | dnre                | Number of requests recorded for a device reached suspiciously high level.                                    |
| Excessive number of names for a device                | Risk    | dnae                | Number of different names recorded for a device reached suspiciously high level.                             |
| Excessive number of phone numbers for a device        | Risk    | dpe                 | Number of different phone numbers recorded for a device reached suspiciously high level.                     |
| Excessive number of email addresses for a device      | Risk    | dee                 | Number of different email addresses recorded for a device reached suspiciously high level.                   |
| Excessive number of other identifiers for a device    | RIsk    | doe                 | Number of different other identifiers recorded for a device reached suspiciously high level.                 |
| Excessive copy-paste behavior for device              | Risk    | dcpe                | Number of copy-paste events recorded for a device reached a suspiciously high level.                         |

# [Network indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#network-indicators)

| Name                                      | Type            | Header and SIEM key | Description                                                                                |
| :---------------------------------------- | :-------------- | :------------------ | :----------------------------------------------------------------------------------------- |
| Is cloud network                          | General or Risk | aci                 | AS number for request matches a cloud provider like AWS or Azure.                          |
| Excessive failed percentage for AS number | Risk            | afe                 | Percentage of requests that were failures for AS number reached a suspiciously high level. |

# [User indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#user-indicators)

| Name                                                | Type         | Header and SIEM key | Description                                                                                                          |
| :-------------------------------------------------- | :----------- | :------------------ | :------------------------------------------------------------------------------------------------------------------- |
| Number of devices for user in last hour             | General      | udc_1h              | Number of different devices recorded for a user in the last hour.                                                    |
| Number of devices for user in last 24 hours         | General      | udc_1d              | Number of different devices recorded for a user in the last 24 hours.                                                |
| Excessive number of devices for a user              | Risk         | ude                 | Number of different devices recorded for a user reached suspiciously high level.                                     |
| Excessive failed percentage for user                | Risk         | ufe                 | Percentage of requests that were failures for user reached a suspiciously high level.                                |
| Number of IPs for user in last hour                 | General      | uic_1h              | Number of different IP addresses recorded for a user in the last hour.                                               |
| Number of IPs for user in last 24 hour              | General      | uic_1d              | Number of different IP addresses recorded for a user in the last 24 hours.                                           |
| Excessive number of IPs for user                    | Risk         | uie                 | Number of different IP addresses recorded for a user reached suspiciously high level.                                |
| Number of AS numbers for user in last hour          | General      | uac_1h              | Number of different AS numbers recorded for a user in the last hour.                                                 |
| Number of AS numbers for user in last 24 hours      | General      | uac_1d              | Number of different AS numbers recorded for a user in the last 24 hours.                                             |
| Excessive number of AS numbers for user             | Risk         | uae                 | Number of different AS numbers recorded for a user reached suspiciously high level.                                  |
| Number of countries/areas for user in last hour     | General      | ugc_1h              | Number of different countries/areas recorded for a user in the last hour.                                            |
| Number of countries/areas for user in last 24 hours | General      | ugc_1d              | Number of different countries/areas recorded for a user in the last 24 hours.                                        |
| Excessive Number of countries/areas for user        | Risk         | uge                 | Number of different countries/areas recorded for a user reached suspiciously high level.                             |
| Number of cities for user in last hour              | General      | ucc_1h              | Number of different cities recorded for a user in the last hour.                                                     |
| Number of cities for user in last 24 hours          | General      | ucc_1d              | Number of different cities recorded for a user in the last 24 hours.                                                 |
| Excessive number of cities for user                 | Risk         | uce                 | Number of different cities recorded for a user reached suspiciously high level.                                      |
| Excessive percentage of bad reputation IPs for user | Risk         | ure                 | Percentage of IP addresses for a user with a bad client reputation reached suspiciously high level.                  |
| Excessive number of requests for user               | Risk         | unre                | Number of requests recorded for a user reached suspiciously high level.                                              |
| Suspicious Session Age                              | Risk         | ssa                 | Session age is too short.                                                                                            |
| Account suspected of being created for fraud        | Risk         | sac                 | When the account was opened, it was suspected of being created for fraudulent purposes.                              |
| Recently compromised user account                   | Risk         | sap                 | This user's account was recently attacked and the origin returned a successful login status to the attacking client. |
| Impossible User Travel                              | Risk/General | iut                 | The user connects from multiple locations that are far apart in a period too short to move between them.             |
| Suspicious Copy/Paste                               | Risk/General | scp                 | Detected unusual copy-paste activity, possibly indicating suspicious behavior.                                       |
| Abnormal typing speed                               | Risk         | ats                 | Detected unusual typing speed, possibly indicating suspicious behavior.                                              |
| Abnormal typing behavior                            | Risk         | atb                 | Detected unusual typing activity, possibly indicating suspicious behavior.                                           |
| Excessive number of phone numbers for user          | Risk         | upe                 | Number of different phone numbers recorded for a user reached suspiciously high level.                               |
| Excessive number of email addresses for user        | Risk         | uee                 | Number of different email addresses recorded for a user reached suspiciously high level.                             |
| Excessive copy-paste behavior for user              | Risk         | ucpe                | Number of copy-paste events recorded for a user reached a suspiciously high level.                                   |

# [PII indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#pii-indicators)

| Name                                                        | Type | Header and SIEM key | Description                                                                                           |
| :---------------------------------------------------------- | :--- | :------------------ | :---------------------------------------------------------------------------------------------------- |
| Excessive number of names for an other identifier           | Risk | onae                | Number of different names recorded for other identifier reached suspiciously high level.              |
| Excessive number of email addresses for an other identifier | Risk | oee                 | Number of different email addresses recorded for an other identifier reached suspiciously high level. |
| Excessive number of phone numbers for an other identifier   | Risk | ope                 | Number of different phone numbers recorded for an other identifier reached suspiciously high level.   |
| Excessive number of IPs for an other identifier             | Risk | oie                 | Number of different IPs recorded for an other identifier reached suspiciously high level.             |
| Excessive number of devices for an other identifier         | Risk | ode                 | Number of different devices recorded for an other identifier reached suspiciously high level.         |
| Excessive number of AS numbers for an other identifier      | Risk | oae                 | Number of AS numbers devices recorded for an other identifier reached suspiciously high level.        |
| Excessive number of countries for an other identifier       | Risk | oge                 | Number of countries devices recorded for an other identifier reached suspiciously high level.         |

# [IP address indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#ip-address-indicators)

| Indicator name                               | Indicator type | Header and SIEM key | Description                                                                                       |
| :------------------------------------------- | :------------- | :------------------ | :------------------------------------------------------------------------------------------------ |
| Is Proxy                                     | Risk           | prx                 | Originates from a proxy server                                                                    |
| Is VPN                                       | Risk           | vpn                 | Originates from a virtual private network (VPN)                                                   |
| Number of users for IP in last hour          | General        | iuc_1h              | Number of different users recorded for an IP address in the last hour.                            |
| Number of users for IP in last 24 hours      | General        | iuc_1d              | Number of different users recorded for an IP address in the last 24 hours.                        |
| Excessive number of users for IP             | Risk           | iue                 | Number of different users recorded for an IP address reached suspiciously high level.             |
| Number of devices for IP in last hour        | General        | idc_1h              | Number of different devices recorded for an IP address in the last hour.                          |
| Number of devices for IP in last 24 hours    | General        | idc_1d              | Number of different devices recorded for an IP address in the last 24 hours.                      |
| Excessive number of devices for IP           | Risk           | ide                 | Number of different devices recorded for an IP address reached suspiciously high level.           |
| Excessive failed percentage for IP           | Risk           | ife                 | Percentage of requests that were failures for IP address reached a suspiciously high level.       |
| Excessive number of requests for IP          | Risk           | inre                | Number of requests recorded for an IP reached a suspiciously high level.                          |
| Excessive number of phone numbers for IP     | RIsk           | ipe                 | Number of different phone numbers recorded for an IP address reached suspiciously high level.     |
| Excessive number of other identifiers for IP | Risk           | ioe                 | Number of different other identifiers recorded for an IP address reached suspiciously high level. |
| Excessive number of names for IP             | Risk           | inae                | Number of different names recorded for an IP address reached suspiciously high level.             |
| Excessive number of email addresses for IP   | Risk           | iee                 | Number of different email addresses recorded for an IP address reached suspiciously high level.   |
| Excessive copy-paste behavior for IP         | Risk           | icpe                | Number of copy-paste events recorded for an IP address reached a suspiciously high level.         |

# [Bot indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#bot-indicators)

| Name | Type | Header and SIEM key | Description            |
| :--- | :--- | :------------------ | :--------------------- |
| Bot  | Risk | bot                 | Originates from a bot. |

# [Reputation indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#reputation-indicators)

| Name          | Type | Header or SIEM key | Description                                                          |
| :------------ | :--- | :----------------- | :------------------------------------------------------------------- |
| IP reputation | Risk | ip_rep             | Reputation of the IP address based on past activity across platform. |

# [Email address indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#email-address-indicators)

| Name                                                       | Type | Header and SIEM key | Description                                                                                          |
| :--------------------------------------------------------- | :--- | :------------------ | :--------------------------------------------------------------------------------------------------- |
| Malformed Email Address                                    | Risk | mea                 | Email address traits are atypical and suspicious.                                                    |
| Suspicious Use of Special Characters in Email Local-Part   | Risk | sce                 | Suspicious use of special characters in name portion (local-part) of the email address.              |
| Unusual Email Local-Part Syntax                            | Risk | uhs                 | Unusual text pattern in the name portion (local-part) of the email address.                          |
| Unusual Domain Syntax                                      | Risk | uds                 | Unusual text pattern in email address domain.                                                        |
| Disposable Email                                           | Risk | de                  | Email address format typical of temporary or disposable addresses.                                   |
| IP and Email Domain Country/Area Mismatch                  | Risk | iet                 | IP address country/area differs from email domain country/area.                                      |
| Excessive number of requests for an email domain           | Risk | edue                | Number of requests recorded for an email domain reached suspiciously high level.                     |
| Excessive number of names for an email address             | Risk | enae                | Number of different names recorded for an email address reached suspiciously high level.             |
| Excessive number of phone numbers for an email address     | Risk | epe                 | Number of different phone numbers recorded for an email address reached suspiciously high level.     |
| Excessive number of other identifiers for an email address | Risk | eoe                 | Number of different other identifiers recorded for an email address reached suspiciously high level. |
| Excessive number of IPs for an email address               | Risk | eie                 | Number of different IPs recorded for an email address reached suspiciously high level.               |
| Excessive number of AS numbers for an email address        | Risk | eae                 | Number of different AS numbers recorded for an email address reached suspiciously high level.        |
| Excessive number of devices for an email address           | Risk | ede                 | Number of different devices recorded for an email address reached suspiciously high level.           |
| Excessive number of users for an email address             | Risk | eue                 | Number of different users recorded for an email address reached suspiciously high level.             |
| Excessive number of countries for an email address         | Risk | ege                 | Number of different countries recorded for an email address reached suspiciously high level.         |
| Excessive number of email addresses for a phone number     | Risk | pee                 | Number of different email addresses recorded for a phone number reached suspiciously high level.     |

# [Phone number indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#phone-number-indicators)

| Name                                                     | Type | Header and SIEM key | Description                                                                                        |
| :------------------------------------------------------- | :--- | :------------------ | :------------------------------------------------------------------------------------------------- |
| Excessive number of names for a phone number             | Risk | pnae                | Number of different names recorded for a phone number reached suspiciously high level.             |
| Excessive number of other indetifiers for a phone number | Risk | poe                 | Number of different other identifiers recorded for a phone number reached suspiciously high level. |
| Excessive number of IPs for a phone number               | Risk | pie                 | Number of different IPs recorded for a phone number reached suspiciously high level.               |
| Excessive number of devices for a phone number           | Risk | pde                 | Number of different devices recorded for a phone number reached suspiciously high level.           |
| Excessive number of users for a phone number             | Risk | pue                 | Number of different users recorded for a phone number reached suspiciously high level.             |
| Excessive number of AS numbers for a phone number        | Risk | pae                 | Number of different AS numbers recorded for a phone number reached suspiciously high level.        |
| Excessive number of countries for a phone number         | Risk | pge                 | Number of different countries recorded for a phone number reached suspiciously high level.         |

# [Other indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#other-indicators)

| Name                                 | Type | Header and SIEM key | Description                                          |
| :----------------------------------- | :--- | :------------------ | :--------------------------------------------------- |
| Response action overridden by a user | Risk | rao                 | A user changed the response action for this request. |