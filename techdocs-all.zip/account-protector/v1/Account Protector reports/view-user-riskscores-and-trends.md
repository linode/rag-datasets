# [View user risk scores, patterns, and trends](https://techdocs.akamai.com/account-protector/docs/view-user-riskscores-and-trends#view-user-risk-scores-patterns-and-trends)

Web Security Analytics is a great place to view details on requests you evaluate for user risk. Come here to :

- identify patterns in attacks and find requests mistakenly flagged as risky (false positives).
- filter on specific data to get statistics across security services.
- review raw HTTP data in Sample View.

A good place to start is to view indicators:

1. Go to ☰ > **WEB & DATA CENTER SECURITY** > **Security Center**.

2. On the left side of the screen, select **Analysis** > ** Web Security Analytics**.  

3. Set a time period within the last 30 days. Click the date field at the top of the screen and select the duration or dates you want to see.

4. Click in the gray Filter box. Select **API Resource Purpose Type** matches **Login**. Then click **Apply**.

   If you only want to see users with a high score, add a filter for **User risk score** is **greater than** the minimum score you want, like 90. For a similar effect, filter for **User risk level** matches **Critical** to see scores from 76 to 100.

   To further hone your view, you can also filter out bot requests. Add a filter for **Attack Type** does not match **Bot**. 

5. In the left menu, click **Account Protection** and select **Indicator**. 

6. View distribution. If there are notable patterns that repeat for several indicators, select them to drill down for details. 

 > Note: 
  Web Security Analytics shows only detections and rules that trigger. So, for example, if a web application firewall control denies a request, account protection never runs. If it had run, you may have seen high user risk score for that request. In other words, reports may not show user risk score for ALL requests that may be suspect, because they were mitigated by prior protection. [More on evaluation order](https://techdocs.akamai.com/account-protector/docs/how-it-works#request-evaluation).

# [Other account protection dimensions](https://techdocs.akamai.com/account-protector/docs/view-user-riskscores-and-trends#other-account-protection-dimensions)

View requests by other user-risk-related dimensions. Under Account Protection, you can also select:

- **User ID**. The User ID dimension provides request data by individual web users represented by their UUID (universally unique identifier).

- **User Risk Level**. View the number and distribution of requests grouped by color-coded user risk level:

  - 
**Critical**
 - requests with a score range from 76 to 100.

  - 
**High**
 - requests with a score range from 51 to 75.

  - 
**Medium**
 - requests with a score range from 26 to 50.

  - 
**Low**
 - requests with a score range from 0 to 25.

- **Device ID**. Requests grouped by the unique device identifier (based on browser, device, and cookies).

- **Device OS**.  OS of the device used to send the request.

- **Device Browser Type**. Requesting browser type .

- ** Indicator.** Anomalies and trust signals that contribute a user risk score. [See full indicator list](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators).

 > Note: View _
username_
 
_
Beta_

  If you have Administrator rights, or have been [granted the specific view permissions](https://techdocs.akamai.com/account-protector/docs/manage-user-access-to-setup), you can also see the reader-friendly username value in some Web Security Analytics reporting sections (in that report's new user interface experience. This report has both an old and new interface. If you see a yellow banner at the top of Web Security Analytics, click the **new experience** link. If on the upper right of the Web Security Analytics screen you see a **... **settings button, you're in the new experience.) 
    When you list requests by User ID, an option to **Show Username** appears on the upper right of the report section. 