# [View user activity in multistep flows](https://techdocs.akamai.com/account-protector/docs/view-user-activity-in-multistep-flows#view-user-activity-in-multistep-flows)

# [View reports in User Intelligence Console](https://techdocs.akamai.com/account-protector/docs/view-user-activity-in-multistep-flows#view-reports-in-user-intelligence-console)

1. Log in to ​Akamai Control Center​ with your username and password.
2. Go to** ☰ > Web & Data Center Security  > Security Center**.
3. Go to **Tools > User Intelligence Console**.
4. Use filters to match with multistep group names and success conditions.
5. View the users matching the filters.

# [View reports in Web Security Analytics](https://techdocs.akamai.com/account-protector/docs/view-user-activity-in-multistep-flows#view-reports-in-web-security-analytics)

1. Log in to ​Akamai Control Center​ with your username and password.
2. Go to **☰ > Web & Data Center Security  > Security Center > Web Security Analytics**.
3. Add the **Origin Response dimension** to see the **Success** and **Step Success** response type.  **Success** shows the number of flows that ended successfully, and **Step Success** shows the number of successful steps in the flow.
4. Use the **Origin Response** filter to match with **Success** and **Step Success**.