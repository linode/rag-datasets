# [View a user profile](https://techdocs.akamai.com/account-protector/docs/view-user-profile#view-a-user-profile)

If you're curious about a user, view their full profile. For example, if you see a high user risk score, the profile can tell you why. You can look back up to 90 days to get the long view and identify trends.

1. Go to ☰ > **WEB & DATA CENTER SECURITY** > **Security Center**.

2. On the left side on the screen, select **Tools** > **User Intelligence Console**

3. Open a user profile in one of the following ways:

   - Click a user that appears in the report to drill down for details.

   

# [API Resource Purpose Type Summary](https://techdocs.akamai.com/account-protector/docs/view-user-profile#api-resource-purpose-type-summary)

The pie charts display the number and risk level of requests the user sent to a type of your protected endpoints, for example to login or add to cart.

Click  and  in the section header to switch between the pie chart and bar chart views.

# [Request Timeline](https://techdocs.akamai.com/account-protector/docs/view-user-profile#request-timeline)

Identify trends on the timeline that shows a daily number of requests and their risk level.

# [Tables](https://techdocs.akamai.com/account-protector/docs/view-user-profile#tables)

Click the dropdown next to table name and select one of the options to see the data by Risk Level or by number of Requests in descending order.

The tables below display:

- **Top Countries/Areas** where the user requests to the protected endpoints originated and their risk level.

- **Top AS Numbers** where the user requests to the protected endpoints originated and their risk level.

- **Top Devices** from which the user requests to the protected endpoints originated and their risk level.

The **Requests** table displays the details of up to 250 user requests in the selected date range. The requests are sorted by the timestamp column in descending order.  
Click the Columns tab on the right, to add or remove selected types of data to display in the table, for example connecting IP, device OS, client type, network and policy name.  
You can resize the column width and click the header to sort by a particular column.