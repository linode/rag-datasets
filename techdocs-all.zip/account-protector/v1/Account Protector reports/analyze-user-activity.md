# [Analyze user activity](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#analyze-user-activity)

The User Intelligence Console lets you get an overview of the activity of your users on protected endpoints. See the countries, devices, IP addresses, and email domains the requests are coming from. This is the place to investigate high-risk users.

Use the data to tune your Account Protector settings or to respond to threats and mitigate attack attempts with your other tools.

# [Set report scope](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#set-report-scope)

1. Go to ☰ > **WEB & DATA CENTER SECURITY** > **Security Center**.

2. On the left side on the screen, select **Tools** > **User Intelligence Console**

3. In the Security Center menu bar, modify the general settings for the view.

   - Switch to view another security configuration. Click the name of the current security configuration, and select a different configuration from the menu.

   - Set a time period within the last 3 months. Click the date field and select the duration or dates you want to see.

   - Apply filters to all charts to get only the data you need. On the upper right of the screen, click the filter button. Then click **Add** and select a dimension to filter on from the list.

   - Use the condition builder to make the filter more granular. Select a **dimension** and an **operator**, for example **Match** or **Starts with**. Then enter a value in the text field or select one from a list. Click **Add** to include another line in the condition. Click **Apply**. To clear a filter click **X** next to its name.

# [Interact with the charts](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#interact-with-the-charts)

- In a pie chart, to enable and disable sections of the chart, click a section name in the legend.

- To view the details for a specific item, hover the mouse over it.

- For some charts, to switch between the pie chart and bar chart views, click  and  in its header.

- To download the data for further analysis in the CSV format, click the download button that is next to any chart header.

# [Basic activity by the numbers](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#basic-activity-by-the-numbers)

- **Users** shows the total number of users who sent requests to the protected endpoints.

- **Devices** shows the number of unique devices the requests came from.

- **Countries/Areas** displays the countries and areas where the requests to the protected endpoints originated.

- **AS Numbers** shows request data by AS (autonomous system) number, which identifies the originating network. AS numbers are calculated by a reverse look up on the connecting IP addresses at the time the requests were received by Akamai's edge servers.

- **Requests** shows the total number of requests to the protected endpoints.

# [Users by Risk Level](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#users-by-risk-level)

This chart breaks down users by their risk level. The higher the level, the more probability that a user session includes suspicious activity. Because users can make several requests, and each may score differently, a single user may appear in multiple risk levels. For this reason percentages may not add up to 100%.

# [API Resource Purpose Type Summary](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#api-resource-purpose-type-summary)

The pie chart displays the number of requests to each type of your protected endpoints. The endpoints are categorized by resource type, for example login or add to cart.  
Switch to table to see the number and the risk level of requests which came to each type of endpoint.

# [Request Timeline](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#request-timeline)

Identify trends on the timeline that shows a daily number of requests and their risk level.

# [Top Users](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#top-users)

Click the dropdown next to Top Users and select one of the options to see the data by Risk Level or by number of Requests in descending order. To investigate a specific user, click the User ID link and choose one of the following options:

- see the User Profile
- see what data is available in Web Security Analytics.

To add a user to an allowlist list or remove them one:

1. Click the User ID link and click **Add User to Allowlist**.
   - To add the user to a list, turn its checkbox on.
   - To remove the user from a list, turn its checkbox off.
2. Click Save

# [Requests](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#requests)

The table displays the details of up to 250 requests in the selected date range. The requests are sorted by the timestamp column in descending order.  
Click the Columns tab on the right, to add or remove selected types of data to display in the table, for example origin response, device OS, end-user IP, hostname, and score status.  
You can resize the column width and click the header to sort by a particular column.

Add a user to an allowlist list or remove them from such a list

1. Click the User ID link and click **Add User to Allowlist**.
   - Select the checkboxes next to list names to add the user.
   - Deselect the checkboxes to remove the user.
2. Click Save

 > Note: 
  You can create allowlists to decrease false positives.

  

# [Save and share views](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity#save-and-share-views)

Open the view you want to share by selecting desired filters and other settings.

On the top right of the screen, click the **\< **share button. The URL for the view saves to your clipboard for you to paste in a message and share with colleagues.

 > Note: 
  Always use the menu option to share views, and don't copy out of your browser address bar. Addresses in a browser belong to a specific user, on the current account, and may not work for other users.