# [Tune user risk response strategy](https://techdocs.akamai.com/account-protector/docs/tune-user-risk-response-strategy#tune-user-risk-response-strategy)

Account protection tuning best practices are the same as for any other security protection: You start by monitoring traffic and only after you're confident that settings work the way you want them to, do you move to mitigate or deny requests.

# [Let account protection collect data](https://techdocs.akamai.com/account-protector/docs/tune-user-risk-response-strategy#let-account-protection-collect-data)

After you first implement account protection, give it some time to generate user profiles. A good gauge of progress on this front is **user score status**. Track overall progress building user profiles in Web Security Analytics:

1. Go to ☰ > **WEB & DATA CENTER SECURITY** > **Security Center**.

1. On the left side of the screen, select **Analysis** > ** Web Security Analytics**. Then select **Account Protection > User Score Status**. If you see:

    - a lot of scores that are ranked **No user profile yet: scored on other factors** then give Account Protector more time to gather data and keep monitoring
    - that most scores are **User profile sufficient to score** with some **Partial user profile built: scored on other factors** thrown in, then you know that collected data and user profiles are in a more complete state and you can move on to monitor and tweak your response strategy.

 [List of possible user score statuses](https://techdocs.akamai.com/account-protector/docs/account-protector-signal-to-origin#score-status).

# [Monitor account protection settings](https://techdocs.akamai.com/account-protector/docs/tune-user-risk-response-strategy#monitor-account-protection-settings)

Monitor user traffic to see how your response strategy is playing out. Start in [Web Security Analytics](https://techdocs.akamai.com/account-protector/docs/view-user-riskscores-and-trends) and take advantage of the [User Intelligence Console](https://techdocs.akamai.com/account-protector/docs/analyze-user-activity) too. 

# [A legitimate user gets high scores](https://techdocs.akamai.com/account-protector/docs/tune-user-risk-response-strategy#a-legitimate-user-gets-high-scores)

If you know a legitimate user is continually getting high scores, start by investigating in the User Profile report to see why. Say a user travels often for work, you may see that logins from many different locations contribute to their high score. As Account Protector machine learning absorbs this information, it learns that this trait is typical of the user and adjusts their user risk score accordingly.

If lots of legitimate users are getting caught in your aggressive response segment, consider raising thresholds for that segments. You may have set them too low.

# [Mitigate risky users](https://techdocs.akamai.com/account-protector/docs/tune-user-risk-response-strategy#mitigate-risky-users)

After you grow comfortable with your account protection setup and believe that lots of user profiles are in place and generating user risk scores well for login requests, you're ready to start blocking suspicious user traffic.

First, you must give thought to precisely what kind of requests from high-risk users you want to deny or mitigate. For example, say you only do business in one country. That would be a good factor to include in any mitigating action you set up. Next, consider what user risk score you are comfortable blocking out. How high a level? Do you want to err on the side of never blocking one of your legitimate users? Let's say you sell only to customers in Japan and you're confident that any requestor with a user risk score of 88 or above, should never access your site.

You would set your response strategy, using a conditional action. First, set the bottom threshold of your Aggressive Response segment to 88. The response action you choose for that segment would be a conditional action, that specifies:

IF
Network list  does not match the geo list you created for country/area Japan
THEN
Deny 100% of requests   (*Note that because you apply this conditional action only to requests with user scores of 88 and above, you're not denying all requests from outside Japan.*)
ELSE
Monitor