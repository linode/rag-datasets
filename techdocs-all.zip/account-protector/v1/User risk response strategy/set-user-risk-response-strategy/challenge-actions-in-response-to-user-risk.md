# [Challenge actions in response to user risk (Beta)](https://techdocs.akamai.com/account-protector/docs/challenge-actions-in-response-to-user-risk#challenge-actions-in-response-to-user-risk-beta)

If you're a part of the Account Protector Challenge Actions in Response to User Risk beta program, you can set up a CAPTCHA or proof-of-work cryptographic challenge to let only humans through. The user risk engine is focused on detecting bot and human-driven account abuse, and it may also help detect account abuse activity driven by bots that may otherwise go unnoticed. This way, account protection mitigates slow and low account abuse bot activity with minimal potential risk to the experience of legitimate account holders. Challenge responses don’t impact the user risk score.

With this feature, you can apply the following actions for web client traffic:

- Google reCAPTCHA challenge. It requires the client machine to run JavaScript and the human user to solve an image puzzle.
- Akamai web crypto challenge (CCA). It requires the client to run JavaScript and resolve a complex cryptographic puzzle. It needs no user interaction. A spinner shows while the challenge is resolved. Choose this action if you don't want to impact your user experience.
- Conditional actions using reCAPTCHA and CCA.

 > Note: 
  During the beta, Akamai web behavioral challenge, adaptive web challenge, and mobile crypto challenge aren’t available. They will be supported later on.

You can configure the same or different bot management and account protection challenges on one endpoint. In such a case:

- If triggered, the bot management challenge is served first.
- An account protection challenge is served if the bot score is not high enough to trigger a bot management challenge and the interval of the previously solved challenge has passed.

 > Note: 
  Don’t set the challenge interval below 30 seconds. It also can’t be lower than the CCA duration.

For best results, use Monitor for Cautious Response when a user request has some risk indicators, a Challenge action for Strict Response when a user request has multiple strong risk indicators that are insufficient to generate a critical risk score, and Deny for Aggressive Response when a user request reaches critical risk score.

The challenge page opens only when a user risk score reaches the score range configured to trigger a challenge. Only users who can solve the challenge may proceed. Even if a person were mistakenly flagged as a bot, all they'd have to do is complete the challenge successfully to continue.

You can customize the look of challenge pages to match your website as a part of a challenge configuration. For detailed instructions for the challenge’s setup steps, see [Bot Manager online help](https://techdocs.akamai.com/bot-manager/docs/challenge-actions).