# [Let users omit the configured policy action](https://techdocs.akamai.com/account-protector/docs/user-lists#let-users-omit-the-configured-policy-action)

If you have trusted users that repeatedly get high-risk scores, you can [create a client list](https://techdocs.akamai.com/client-lists/docs/create) or a network list of the type User and always allow them through. Account protection supports both types, but we recommend using client lists, as network lists will soon be deprecated.

Some examples of user classes that may frequently generate high risk scores for low risk activities include:

- service accounts running from the cloud

- accounts used by penetration testing teams

- frequent travelers who also use loaner devices, shared PCs, country-specific mobile phones, and the like, especially when those users differ significantly from the rest of the user population

- users who purposefully clear cookies, block JavaScript, and use anonymous proxies that may be shared with real account takeover perpetrators.

Because user lists are a shared resource, you can use them across several security configurations.

1. [Create a client list](https://techdocs.akamai.com/client-lists/docs/create) of the type **User**.

2. Open a security configuration where you want to use the list.

3. Click the **Cross-policy Bot & User Settings** tab.

4. Scroll to User Lists and select a list from the menu.

5. Click **Save**.

6. Activate the security configuration.

 > Note: 
  User list is currently limited to 1000 entries.

# [Add users to the client user list](https://techdocs.akamai.com/account-protector/docs/user-lists#add-users-to-the-client-user-list)

1. [Open and edit the user list](https://techdocs.akamai.com/client-lists/docs/edit-list-entries) you want to add the user to.
2. In the **Add items** field, enter **User ID** format changes to Account Protector-generated User ID.

   > > Note: Can't enter username?
   > 
   > For data protection, not everyone can search or enter readable usernames. If you don't have this ability, but feel that you should, ask your account administrator to grant you a role that has the **User Console Search** permission granted in it. [More on user permissions](https://techdocs.akamai.com/account-protector/docs/manage-user-access-to-setup)
3. Click **Save changes**.
4. Activate the client list.

   > > Note: Add a user from the user profile
   > 
   > If you're [viewing a user's profile](https://techdocs.akamai.com/account-protector/docs/view-user-profile) and realize they should always skip account protection, you can add them to a user allowlist immediately. On the upper right of the profile screen, click **Add to User Allowlist**. Select the lists you want to add them to and click **Save**.