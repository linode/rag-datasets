# [User risk score](https://techdocs.akamai.com/account-protector/docs/user-risk-score#user-risk-score)

User risk score is the key to setting up your response. This score indicates the likelihood that a request to a protected endpoint doesn't come from the real account owner. The suspicious requester may be engaging in malicious activity, like account takeover attempt.

User risk score is calculated based on:
- User behavioral profiling, which captures account owners' previous activity. Deviations from a profile may indicate suspicious behavior and impersonation attempts. This profiling complies fully with data privacy laws like GDPR.

- User population profiling, which takes into account the behavior of a specific population, like the set of users that buy from an individual company. Requests from locations, networks and devices not commonly used by the population raise the risk score. 

- Reputation data that considers past history of account abuse. Also observed behavior anomalies like excessive logins, a single user connecting from multiple locations within a short time span, or a single source using several different credential sets, and more.  Akamai can deliver such a sophisticated analysis, because we serve about 30% of the world's web traffic. This means our data pool is massive—big enough for our experts and machine learning algorithms to formulate extremely accurate scoring that dynamically adjusts to changing behavior patterns and detects emerging threats

User risk score is a gauge you use to customize your response strategy. To do so, you set response thresholds by score based on your preferred approach and appetite for risk.