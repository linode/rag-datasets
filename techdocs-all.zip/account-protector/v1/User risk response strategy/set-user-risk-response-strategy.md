# [Set user risk response strategy](https://techdocs.akamai.com/account-protector/docs/set-user-risk-response-strategy#set-user-risk-response-strategy)

Create response segments and assign an action appropriate to the level of risk.

Set your user risk response strategy using two variables:

- **Threshold.** These are user risk scores you set to define response segments. Base thresholds on your traffic and priorities. You can set the segments to apply to all the policies within a security configuration or set them for a specific policy only.
- **Action.** For each API resource and telemetry type, select an action for a response segment. Account Protector applies that action to all requests with user risk scores that fall in the segment's range.

# [Set cross-policy user risk response segments](https://techdocs.akamai.com/account-protector/docs/set-user-risk-response-strategy#set-cross-policy-user-risk-response-segments)

1. Open a security configuration.

2. Click the **Cross-policy Bot & User Settings** tab.

3. Scroll to User Risk Response Strategy.  
   For each telemetry type you want to adjust, click the threshold number and drag it to change the segment range. You can create these response segments:

   - **Cautious Response**. Most appropriate for lower risk scores.
   - **Strict Response**. Middle ground where you can see requests with some suspicious traits, but not definitely malicious.
   - **Aggressive Response**. Contains higher scores, which most likely mean that the requester is not the legitimate account owner.

   > > Tip: 
   > 
   > For User Risk Score of zero and other low scores you can create a segment with no action, below the level of Cautious Response. Use it only for trusted requests, not likely to come from an impersonator, because you don't apply protections or monitor these requests.

4. Click **Save**.

Now, within a relevant policy, set an action for each response segment.

# [Set user risk response strategy](https://techdocs.akamai.com/account-protector/docs/set-user-risk-response-strategy#set-user-risk-response-strategy)

1. Open a security configuration.

2. In the left menu, click a security policy you want to modify.

3. In the left menu, under Match Target and Protections, click **Account Protection**.

4. In the Protected Resources section and click an API name.

5. Scroll to User Risk Response Strategy.

6. **Optional:** Click **Override cross-policy thresholds** and set your custom thresholds.

   For each telemetry type you want to adjust, click the threshold number and drag it to change the segment range. You can create these response segments:

   - **Cautious Response**. Most appropriate for lower risk scores.
   - **Strict Response**. Middle ground where you can see requests with some suspicious traits, but not definitely malicious.
   - **Aggressive Response**. Contains higher scores, which most likely mean that the requester is not the legitimate account owner.

   > > Tip: 
   > 
   > For User Risk Score of zero and other low scores you can create a segment with no action, below the level of Cautious Response. Use it only for trusted requests, not likely to come from an impersonator, because you don't apply protections or monitor these requests.

7. Select an action for each response segment:

   - **Monitor**. Report the request in Web Security Analytics and via the SIEM API. If you're just beginning setup, select this action. As with any security setup, you start by monitoring requests while you learn about your traffic.  Later, you can apply a mitigating action like deny or tarpit. For further guidance, see [Tune user risk response strategy](https://techdocs.akamai.com/account-protector/docs/tune-user-risk-response-strategy).        
   - **Delay**. Wait 1-3 seconds before responding. Traffic still gets to your origin.
   - **Slow**. Wait 8-10 seconds before responding. Some requestors, especially bots, may close the connection on their own rather than wait too long. Note that traffic is delayed, but still gets to your origin.
   - **Deny**. Block request and serve a 403 response. 
   - **Tarpit**. Keep the connection open, but do not respond. This option keeps a requestor in the dark about what is happening, so it's hard for them to take evasive action.
   - **Serve Alternate**. Send request to an alternate page or site. [See Bot Manager online help for details](https://techdocs.akamai.com/bot-manager/docs/set-alternate-content).
   - **Conditional actions**.   Customize actions based on criteria like schedule, request characteristics, and more. Consider carefully what requests you want to mitigate and how. Then craft your conditional action accordingly. When you're ready, [see Bot Manager online help for conditional action creation](https://techdocs.akamai.com/bot-manager/docs/set-conditional-actions).

   If you’re a part of the Account Protector Challenge Actions in Response to User Risk beta program, you can select the following additional actions:

- **Google reCAPTCHA challenge**. This challenge requires the client machine to run JavaScript and the user to solve an image puzzle. It is available for web client traffic.
- **Akamai crypto challenge**. This challenge requires the client machine to run JavaScript and solve a complex cryptographic puzzle. It needs no user interaction. A spinner is displayed while the challenge is resolved.

For more information, see [Challenge actions in response to user risk](https://techdocs.akamai.com/account-protector/docs/challenge-actions-in-response-to-user-risk).

 > Note: I don't see an action I use to handle bots.
  Some actions, [available for bot response](https://techdocs.akamai.com/bot-manager/docs/predefined-actions-bot), aren't currently available for user risk response.

8. Click **Save**.

9. Activate the security configuration.

If you have trusted users, whose requests should bypass Account Protection, create and activate a [User list](https://techdocs.akamai.com/account-protector/docs/user-lists).