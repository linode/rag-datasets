# [Forward user risk results to origin](https://techdocs.akamai.com/account-protector/docs/account-protector-signal-to-origin#forward-user-risk-results-to-origin)

Send user risk detection results with each request forwarded to the origin.

If you have your own in-house fraud detection system, you may want to control the response to suspected account fraud from your origin server. You can opt to include user risk detection results when Account Protector sends the request forward to the origin, and use that signal to have your own system respond or to save data for later analysis. 

 > Note: 
  To take action at origin, don't mitigate at the edge. If, in account protection or bot management you set a mitigating action, like deny, tarpit, serve alternate, or challenge, the request stops at the edge and won't be forwarded to your origin. For detection methods you want to handle at origin, set actions to any that let requests through, like: monitor, slow, or delay. [More on setting response actions](set-user-risk-response-strategy).

In Account Protection **General Settings**, beside **Add user information to each request forwarded to origin as an HTTP header**. click **Yes**. Turning this on adds a header named `Akamai-User-Risk`to forwarded requests. 

# [Score status](https://techdocs.akamai.com/account-protector/docs/account-protector-signal-to-origin#score-status)

_Score status_ lets you know what data a _user risk score_ is based on. Depending on how many times Account Protector has encountered requests from a user,  a score derives from a full or partial user profile, or other factors based in our expansive knowledge of web traffic and request behavior across the globe. 

 > Note: 
  In reporting, you see the description for quick and easy status identification. When user score status appears in the header, you see the number only to ensure brevity.

| Score | Description                                                                                                                                                                                                               |
| :---- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **0** | User profile sufficient to score                                                                                                                                                                                          |
| **1** | No score: Unknown error                                                                                                                                                                                                   |
| **2** | No user profile yet. Scored on other factors.                                                                                                                                                                             |
| **3** | Partial user profile built: scored on other factors. _Previously successful logins have been seen but not enough to have a full view of a user's activity. Score based on the partial user profile and other indicators._ |
| **4** | Request scored without telemetry                                                                                                                                                                                          |
| **5** | No score: timed out                                                                                                                                                                                                       |
| **6** | Username blank: scored on non-profile factors                                                                                                                                                                             |
| **7** | Can’t identify user: scored on non-profile factors                                                                                                                                                                        |