# [Include user risk events in SIEM export](https://techdocs.akamai.com/account-protector/docs/include-user-risk-events-in-siem-export#include-user-risk-events-in-siem-export)

You can use your favorite Security Information and Event Management (SIEM) solution to analyze security events generated from the ​Akamai​ platform, including those detected by Account Protector.

[When you turn on SIEM integration](https://techdocs.akamai.com/siem-integration/docs/akamai-siem-integration-for-splunk-and-cef-syslog#step-1-turn-on-siem-integration), you can choose the security policies for which you want to export data. To include the unencrypted Username, turn on the **Include username** checkbox.

A sample JSON object for a user risk event in the SIEM output looks like this:

```
{  
    "format": "json",  
    "type": "akamai_siem",  
    "version": "1.0",  
    "attackData": {  
        "clientIP": "192.0.2.0",  
...data removed for brevity },  
    "geo": {  
        "asn": "14618",  
        "city": "ASHBURN",  
        "continent": "288",  
        "country": "US",  
        "regionCode": "VA"  
    },  
    "httpMessage": {  
        "bytes": "266",  
...data removed for brevity },  
    "userRiskData":{  
        "uuid":"964d54b7-5555-413a-a4d6-877777770ec8d5",  
        "username": "[user@example.com](mailto:user@example.com)",  
        "status":"0",  
        "score":"75",  
        "risk":"udfp:1325gdg4g4343g/M|unp:74256/H",  
        "trust":"ugp:US",  
        "general":"duc_1h:10|duc_1d:30",  
        "allow":"0"  
} }
```

[Read the full instructions for SIEM setup](https://techdocs.akamai.com/siem-integration/docs/welcome-siem-integration).