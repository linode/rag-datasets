# [Export a configuration version](https://techdocs.akamai.com/account-protector/docs/get-export-config-version#export-a-configuration-version)
