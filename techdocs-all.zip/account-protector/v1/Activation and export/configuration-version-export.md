# [Configuration version export](https://techdocs.akamai.com/account-protector/docs/configuration-version-export#configuration-version-export)
