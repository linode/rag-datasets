# [Prerequisites](https://techdocs.akamai.com/account-protector/docs/prerequisites#prerequisites)

Before you start with Account Protector, and if you use the complementary solutions listed here, you should have the following basic application security protections set up and well-tuned, which means that you have: 

- Identified and resolved false positives and false negatives. 
- Confidently moved to deny bad requests and block bots (required).

# [Web application firewall protections (recommended)](https://techdocs.akamai.com/account-protector/docs/prerequisites#web-application-firewall-protections-recommended)

A security configuration is the basic building block that most protections rely on. Depending on which web application firewall solution you have, follow all the setup and tuning steps that get you to an effective protection posture. Find all the details in the online help for your product:

- [App & API Protector](https://techdocs.akamai.com/app-api-protector/docs)
- [Kona Site Defender](https://techdocs.akamai.com/kona-site-defender/docs)
- [Web Application Protector](https://techdocs.akamai.com/web-app-protector/docs)

# [Identify endpoints to protect](https://techdocs.akamai.com/account-protector/docs/prerequisites#identify-endpoints-to-protect)

Account protection can cover the following API operation purposes:

- **Login**: Allows the user to log in to their account.
- **Account creation**: Allows the user to open a new account.
- **Account verification**: Verifies if an account exists.
- **Password reset**: Allows users to get a new password when they don’t know the previous one.
- **Account update**: Allows updating details on the user’s account.
- **Password change**: Allows changing the password after login.
- **Payment**: Allows conducting checkout transactions or money transfers.
- **Loyalty points**: Allows the user to view the amount of loyalty points they have for the retailer.

Learn more about the [operation purposes](https://techdocs.akamai.com/api-definitions/docs/operation-purposes-1) in API Definitions online help.

# [Bot Manager Premier (required)](https://techdocs.akamai.com/account-protector/docs/prerequisites#bot-manager-premier-required)

Account Protector takes the adversarial bot protection offered in Bot Manager Premier and extends it to let you identify and counter user-account-takeover fraud. Follow all the setup and tuning steps bot coverage entails. Before you start with Account Protector, you should:

- Have all your protected endpoints defined and covered by Bot Manager Premier.
- Have configured a bot score response strategy, which helps inform user risk response that you set up in Account Protector.
- Already apply mitigating actions, like deny and tarpit to bot traffic.

If you haven't already, read all about how to accomplish these tasks in [Bot Manager online help](https://techdocs.akamai.com/bot-manager/docs/welcome).