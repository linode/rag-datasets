# [CIAM Integration](https://techdocs.akamai.com/account-protector/docs/ciam-integration#ciam-integration)

# [CIAM overview](https://techdocs.akamai.com/account-protector/docs/ciam-integration#ciam-overview)

Customer Identity and Access Management (CIAM) is a specialized branch of identity management that focuses on securely managing the identities and access of external users, including customers and partners. CIAM platforms implement a range of identity and access management functionality to both secure user access and maintain a smooth experience. These policies cover features such as user registration, authentication, Single Sign-On (SSO) across applications, Multi-Factor Authentication (MFA), and more.  
They aim to balance security, user experience, and regulatory compliance, while supporting scalability for millions of users.

# [Account Protector and CIAM platforms](https://techdocs.akamai.com/account-protector/docs/ciam-integration#account-protector-and-ciam-platforms)

**Providing robust protection against account abuse**  
Simplify and strengthen customer interactions with CIAM platforms and Account Protector. Mitigate expensive and dangerous account abuse, including sophisticated bot attacks, account takeover, and more. By integrating authentication, profile management, and risk intelligence, you can implement consistent security controls across user registrations, logins, and profile updates. Use identity-based policies, risk-based approaches, and advanced threat intelligence to deliver seamless, secure digital experiences.

**Seamless integration to proactively mitigate risk**  
Easily integrate the user risk score into existing CIAM workflows. You can automatically detect and respond to high-risk events, such as suspicious logins or registrations, by triggering response actions directly within the CIAM platform.

**How it works**  
The integration forwards risk signals from Account Protector directly to the CIAM platform during registration, login, or other user interactions. Based on configurable thresholds, CIAM can initiate mitigation actions, such as requiring additional verification steps or outright blocking the interaction.

# [Integrate a CIAM platform with Account Protector](https://techdocs.akamai.com/account-protector/docs/ciam-integration#integrate-a-ciam-platform-with-account-protector)

1. Identify endpoints you want to protect.

Learn more about the operation purposes in [API Definitions](https://techdocs.akamai.com/api-definitions/docs/operation-purposes-1) online help.

2. [Create API resources](https://techdocs.akamai.com/api-definitions/docs/add-api-resources).
3. [Create API operations ](https://techdocs.akamai.com/api-definitions/docs/set-up-resource-purposes).
4. [Configure Bot Manager](https://techdocs.akamai.com/bot-manager/docs/define-operation).
5. Update cross-policy user settings.
6. Configure the global user allow list.
7. Configure the global user risk response strategy.

During this step, ensure that you [forward user risk results to the origin](https://techdocs.akamai.com/account-protector/docs/account-protector-signal-to-origin). The following image shows the required settings:

8. Enable Account Protector using Update Account Protector settings and configure Origin Signal Header behavior.
9. Add protected API operations under Account Protection.
10. Follow the CIAM provider instructions to include Account Protector user risk in the authentication policy.
11. **Optional: **In case a CIAM provider requires a key for this integration, contact the Akamai support team for assistance.