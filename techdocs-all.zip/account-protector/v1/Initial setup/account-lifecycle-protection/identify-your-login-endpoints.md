# [Account Takeover Protection](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints#account-takeover-protection)

Malicious actors trying to take over a user account must pass through your login pages.  Account protector works by evaluating requests to these pages. To start setup, you must define these login endpoints as the resources you want to protect. If you've already done so as part of Bot Manager Premier setup, and your API operation (formerly called _resource purpose_) settings not only include origin-reported failures and successes, but also capture the **username** in the POST body data, move on to [specifying expected traffic](https://techdocs.akamai.com/account-protector/docs/specify-expected-traffic).

 > Note: Which pages should you protect?
  Protecting login pages is the best place to start. Later you may also want to protect additional transactional pages behind login, like account creation or password reset pages.  When you do so, you can make sure that trusted users are searching your site, for example. On the other hand, you won't get much out of protecting pre-login pages.

# [Set up an Account Protector protected operation](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints#set-up-an-account-protector-protected-operation)

You define a protected endpoint as an _API Operation_ (formerly called **API resource purpose**) when you define your API.

1. Open the security configuration you use to protect accounts.

2. Open the security policy.

3. On the left side of the screen, click **Account Protection**.

4. If it's not on already, enable account protection by clicking the On/Off slider to **On**.

5. Click the **Protected Resources** section.

6. If you haven't already, in API Definitions, [define the API operation](https://techdocs.akamai.com/api-definitions/docs/register-api) you want to protect.

   > > Warning: 
   > 
   > It's critical to [include _origin-reported failures_ and _origin-reported successes_](https://techdocs.akamai.com/api-definitions/docs/set-origin-success-and-failure-conditions), and capture username (read on to learn how) when you [create your API operation](https://techdocs.akamai.com/api-definitions/docs/set-up-resource-purposes). Also, when you define your API (in the API Definitions app), make sure **Case-sensitive URLs and parameters** is OFF to avoid potential evasions.

7. If you already have the API defined, click **+** and then under **Add API Resource**, select it.  
   Don't see the API operation you want to protect? To add an API operation here, it must already be covered by bot management. [Add it there first](https://techdocs.akamai.com/bot-manager/docs/define-operation).

# [Capture username](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints#capture-username)

Capturing **_username_** from requests is critical to building user profiles. When you define your API, you must specify the location of the username in the POST body. The body looks something like this:

```text
log=jsmith&pwd=19f225d1!3EB0&wp-submit=Log+In&redirect_to=https%3A%2F%2test.example.tips%2F
```

In this example, the unique identifier when a user authenticates is the username `jsmith`.  The key that identifies that in the POST data is `log`.  You configure your API Definition to look for URL-Encoded value and search for `log`. 

 

## [JSON/XML](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints#jsonxml)

JSON/XML bodies are a little more complicated in that the API definition can't parse through the POST body to find the right key to capture the username.  You must define where the key exists in the JSON/XML payload. How you define it depends on whether your format is simple, nested, or arrayed:

- **Simple** format has only one open curly bracket and one close curly bracket.  Define your API definition to find the unique login name (in this case "customerEmail") with the correct JSON Type. 

```text
{
    "customerFirstName": "Sample",
    "customerLastName": "User",
    "customerEmail": "sample@example.com",
    "password": "s1QeQQcArZ2eWSXQQt!tAa"
}
```

 - **Nested** format is slightly harder. You must define how the API Definition finds the username, by saying where it lives in the JSON data.  In this example, the unique login name `customerEmail` is inside another set of curly brackets owned by `contactData`.

```text
{
    "contactData":
    {
        "customerFirstName": "Sample",
        "customerLastName": "User",
        "customerEmail": "sample@example.com",
        "password": "s1QeQQcArZ2eWSXQQt!tAa"
    },
    "fake_field": "testing"
}
```

 - **Arrays** require a special setup. If your username lives in a specific index in a JSON array, repeated XML element, or repeated POST parameter, follow these steps to tell our API Definitions app where it’s located.

  > > Warning: Warning
  > 
  > This feature requires your code to enforce a set array order, in which values are always found in the same location or index. If your code doesn’t, this setup won’t work.

  1. Go to your API definition

  2. Create or edit  a  Resource.

  3. Under the method you select, like POST, expand Request Parameters and, beside Type,  turn on the Array checkbox and enter the path to the array location.  
     ![](https://techdocs.akamai.com/account-protector/img/array_checkbox_final.png)

  4. Go to or create the operation you use for login or account creation.  
     _**Note:** Account creation operations let you use array indexes in additional required parameters only (See step f)._

  5. Under Username parameter, select the parameter containing the array.  
     Enter the array index numbers to share where username data lives. This is a number that specifies a value’s position in the array and starts at zero. For example, in this JSON snippet:

     ```text
     {
         "gateway_customer": {
             "identities": {
                 "identity": [
                     {
                         "data": "test@example.com",
                         "type": "USERNAME"
                     },
                     {
                         "data": "qwerty123",
                         "type": "PASSWORD"
                     }
                 ]
             }
         }
     }

     ```

     the username parameter is: `/gateway_customer/identities/identity`  
     and the username index is at the first level, so you’d enter an index value of: `0`

     ![](https://techdocs.akamai.com/account-protector/img/req_array_params_final1.jpg)

     if the path has multiple array elements, you must specify an index for each one.  
     _**Reminder: **Your code must enforce the defined array order, so values are always found in the same index._

  6. Optional: You can  limit requests that fall under this operation. If the path you want to limit on contains an array, you must specify those parameter array indexes.  
     _**Important:** Don't add a parameter here unless you want to protect ONLY requests that include that parameter._

     1. Under **additional required parameters**, click **Add parameter** and select one that you created under this API’s resource.
     2. Select **exists** or **matches**, depending upon what type of condition you’re setting.
     3. Under **Array indexes**, enter each array index location.  

        ![](https://techdocs.akamai.com/account-protector/img/req_array_cond_final.jpg)

  7. Click **Save**.

  8. Activate the new version of your API definition.