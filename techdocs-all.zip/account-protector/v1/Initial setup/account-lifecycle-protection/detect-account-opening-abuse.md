# [Account Opening Abuse protection](https://techdocs.akamai.com/account-protector/docs/detect-account-opening-abuse#account-opening-abuse-protection)

In addition to protecting login pages, you can also protect your account creation workflows. Fraudsters may use stolen or fictitious identities to create accounts on your system. They use these accounts to do things like:

- abuse sales promotions and offers
- hoard inventory to make it unavailable to legitimate customers
- scrape prices
- launder money
- use stolen credit cards

# [Setup](https://techdocs.akamai.com/account-protector/docs/detect-account-opening-abuse#setup)

To protect against account opening abuse, you add the endpoint where your visitors create accounts, and protect it using Account Protector. This [definition and protection of endpoints](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints) is the same process for any transactional page you protect, but account creation pages require some special settings.

 > Note: What about multistep workflows?
  If your account creation flow consists of several steps, try the [multistep groups](https://techdocs.akamai.com/account-protector/docs/multistep-groups) 
_BETA_
 feature.

In the API definitions app, when you register the transactional page and [create an operation](https://techdocs.akamai.com/api-definitions/docs/set-up-resource-purposes), under **Operation Purpose**, select **Account Creation**. Then, under **User Data Parameters**, select the parameters where your user ID values live (You defined  these parameters in the preceding API definitions step [adding a resource](https://techdocs.akamai.com/api-definitions/docs/add-api-resources)). Here, you're telling account protector what values your users enter as login credentials and where to find them.  For each parameter that's used as a login credential, turn on its **Used for login** checkbox.

![](https://techdocs.akamai.com/account-protector/img/aoa_params_apidef.jpg)

For account opening abuse to function properly, [set origin success and failure conditions](https://techdocs.akamai.com/api-definitions/docs/set-origin-success-and-failure-conditions).

For best results, set up all user identifiers available during the signup process (even if they're not used for login), including the location of first name and last name. This wide set of information aids detection going forward.

After you set up this operation, [protect it](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints) in Account Protector as you would any transactional endpoint.

# [View user account creation data](https://techdocs.akamai.com/account-protector/docs/detect-account-opening-abuse#view-user-account-creation-data)

The contents of the user parameter you specify here is the value you see in reports as **username** for this account creator (if you have [permission to see username)](https://techdocs.akamai.com/account-protector/docs/manage-user-access-to-setup). If you enter more than one user parameter, Account Protector uses the first one that appears in the order of the **User Data Parameters ** entry fields, which is: 

1. email
2. phone number
3. other identifier

In other words, if several are listed including **email**, it uses **email**. If there's  only a **phone number** parameter, it uses that. If there's a **phone number** and **other identifier**, it uses **phone number,** except in the case were the **other identifier** contains an email address value. Then it uses that email address value, even if phone number exists. That's because email data is an important factor used in detections and can be an informative identifier for you and your staff too.

Suspicious account creation is detected by a set of [account opening abuse indicators](https://techdocs.akamai.com/account-protector/docs/account-protector-indicators#account-opening-abuse-indicators-beta), which assess the risk that a new account registration is not a genuine user. When an account creation request is suspicious, reporting shows one or more of these indicators as the reason.

_**Privacy note: **Data transmitted through assessment and reporting on these detections is encrypted and protected as sensitive personally identifiable information. [Read more about  Account Protector's high data privacy standards](https://techdocs.akamai.com/account-protector/docs/how-it-works#data-privacy)._