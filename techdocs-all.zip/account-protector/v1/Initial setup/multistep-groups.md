# [Multistep groups](https://techdocs.akamai.com/account-protector/docs/multistep-groups#multistep-groups)

# [Overview](https://techdocs.akamai.com/account-protector/docs/multistep-groups#overview)

Account protection allows you to secure your complex multistep flows, such as login, account creation, account verification, password reset, and payment. Using the Multistep Groups feature, you can track user information across different application steps by linking multiple API operations. 

A multistep flow consists of different steps performed in a particular order to complete the flow. Each of these requests belongs to one multistep group. Account protection links these multiple requests together and reuses fields from previous requests later in the workflow so that they can be correctly assigned to the same user, providing a fuller view of the flow and better protection for the user.

The following are different examples of multistep workflows supported by account protection:

- Login, in which a user first must provide their username, and then their password on another screen. Then, the user has to provide a code sent to their email. In this flow, the username is only available on the first request, and the login is completed after multi-factor authentication (MFA).
- Account creation consists of multiple steps allowing the user to provide a username or email, and then give additional information, such as billing and account preferences. After providing the additional information, the account is fully created.
- Password reset, where the user provides an email address, and then receives an email with a link to reset their password.
- Payment for conducting checkout transactions or money transfers. It can be used for checkout as a guest or logged-in user. For guest checkout, enhanced protection is provided when the user enters their information in the first steps and pays at the end of the flow.

For more information about this feature, see the [API Definitions online help](https://techdocs.akamai.com/api-definitions/docs/multistep-groups).