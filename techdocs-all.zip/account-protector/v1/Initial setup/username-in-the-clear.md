# [Username in the clear](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#username-in-the-clear)

When you investigate a suspicion of fraud in the Akamai Control Center or your internal system, it’s important to correlate the user activity with an actual user – you can do that with the username in the clear feature. It enables easier and more accurate correlation of user activity by providing visibility to unobfuscated usernames throughout the account lifecycle.

This feature allows you to:  

- Easily analyze and correlate user behavior: you gain immediate visibility into unobfuscated usernames, eliminating reliance on complex UUID mappings.  
- Streamline fraud investigations: quickly and accurately trace fraudulent activity in the Akamai Control Center or internal systems back to specific users.  
- Simplify operations: you no longer need to rely exclusively on timestamps, IP addresses, and request IDs to map users, significantly reducing operational complexity and error.

# [Configuration](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#configuration)

## [Permissions](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#permissions)

To use the feature, you need to have the **Username in Clear - View** permission in the Akamai Control Center.  
The user with the admin role receives them by default. To extend access to other users, add permissions to custom roles in **Akamai Control Center >> Account Admin >> Identity & Access**.

## [Header injection](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#header-injection)

Include the username in the user risk information in the forwarded request sent to the origin.

1. In the **Akamai Control Center**, open your security configuration.
2. Open the security policy.
3. From the **Match Targets and Protections** section, select **Account Protection**.
4. Expand the **General Settings** section.
5. Select the **Include username** option.
6. Save the policy settings.

See a sample header:

Akamai-User-Risk: uuid=86b37525-8047-4a3c-8d7a-23e99901da05;username=[sample@user.com](mailto:sample@user.com);ouid=m534264;requestid=19e22e;status=4;score=0;general=aci:0|db:Chrome 85|di:0fc91b5ec42f5a471c16a85e3e388ca57697c1a9|do:Mac OS X 10;risk=;trust=udbp:Chrome 85|udfp:25ba44ec3b391ba4ce5fbbd2979635e254775e7d|udop:Mac OS X 10|ugp:FR|unp:12322|utp:weekday_3;allow=0;action=monitor_

## [SIEM integration](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#siem-integration)

Include the username in the JSON object of the SIEM message.

1. In the **Akamai Control Center**, open your security configuration.
2. Open the security policy.
3. Go to the **Advanced Settings** tab.
4. Go to the **Logging\*** section and expand the **Data collection for SIEM integration** section.
5. Select the **Username** checkbox.
6. Save the policy settings. 

See a sample JSON object in the SIEM message:

_{  
    "format": "json",  
    "type": "akamai_siem",  
    "version": "1.0",  
    "attackData": {  
        "clientIP": "52.91.36.10",  
        ...data removed for brevity  
    },  
    "geo": {  
        "asn": "14618",  
        "city": "ASHBURN",  
        "continent": "288",  
        "country": "US",  
        "regionCode": "VA"  
    },  
    "httpMessage": {  
        "bytes": "266",  
        ...data removed for brevity  
    },  
    "userRiskData":{  
        "uuid":"964d54b7-0821-413a-a4d6-8131770ec8d5",  
        "username": "[user@akamai.com](mailto:user@akamai.com)",  
        "status":"0",  
        "score":"75",  
        "risk":"udfp:1325gdg4g4343g/M|unp:74256/H",  
        "trust":"ugp:US",  
        "general":"duc_1h:10|duc_1d:30",  
        "allow":"0"  
    }  
}_

# [Reporting](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#reporting)

Authorized users can analyze and correlate user activity to the unobfuscated username when provided in Web Security Analytics and the User Intelligence Console.

## [Web Security Analytics](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#web-security-analytics)

To show requests by the user ID, add a requests table. Click the Show username toggle to additionally view the username. Note that the toggle is displayed for authorized users only.

## [Samples View](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#samples-view)

In the **Samples** view, select **Username** to add a column in the samples request table. Note that this option is available for authorized users only.

In each request details, the username is also shown under **Client Info**.

## [User Intelligence Console](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#user-intelligence-console)

Perform the following actions on the landing page:

- Select User ID & Username to view the top user IDs & usernames.
- Select the Username option from the Columns in the Requests table to view the username in the result list.

## [User Profile Page - User ID](https://techdocs.akamai.com/account-protector/docs/username-in-the-clear#user-profile-page-user-id)

Authorized users can view the actual username associated with a specific User ID by clicking the **Show username** toggle.