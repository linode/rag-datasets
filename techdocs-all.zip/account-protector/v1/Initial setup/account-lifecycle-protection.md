# [Account Lifecycle Protection](https://techdocs.akamai.com/account-protector/docs/account-lifecycle-protection#account-lifecycle-protection)

# [Overview](https://techdocs.akamai.com/account-protector/docs/account-lifecycle-protection#overview)

Account Lifecycle Protection allows you to protect user accounts through the entire user journey: from account creation through login, password reset, and post-login activities.

Identifying and mitigating risk is a constant and evolving challenge. Fraudsters adapt their techniques and tactics to evade existing detections. Traditional static risk assessment methods at login or account creation are no longer sufficient to detect these sophisticated threats effectively. Continuous risk assessment throughout the user journey is critical to detect the slightest behavioral changes that may indicate impersonation or fraudulent activity.  
By monitoring user behavior in real time and adapting to changing risk profiles, you can safeguard users' accounts and respond promptly to emerging risks while delivering a great experience for trusted users.

Decisions on when and where to add friction to suspicious users or reduce friction for trusted users may vary. Account Lifecycle Protection allows you to assess user risk at multiple points throughout the user journey so that you can enforce decisions based on your company’s risk tolerance and business objectives.

Account lifecycle protection includes support for[ Account Takeover Protection](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints), [Account Opening Abuse](https://techdocs.akamai.com/account-protector/docs/detect-account-opening-abuse), and the following additional operations:  
**Pre-login operations**:

- Account verification: Verifies if an account exists.
- Password reset: Allows the user to get a new password when they don’t know the previous one.

**Post-login operations:**

- Account update: Allows updating details on the user’s account, such as email address, phone number, credit card number, etc.
- Password change: Allows changing the password, for example, if the user’s previous password was compromised or if they want to change it regularly for safety reasons.
- Payment: Allows conducting checkout transactions or money transfers.

# [Integration](https://techdocs.akamai.com/account-protector/docs/account-lifecycle-protection#integration)

## [Pre-login operations](https://techdocs.akamai.com/account-protector/docs/account-lifecycle-protection#pre-login-operations)

The Account verification and Password reset operations have been updated to include a username parameter.

To protect these operations, perform the following actions:

1. In API Definitions, [define your endpoints](https://techdocs.akamai.com/api-definitions/docs/set-up-resource-purposes) for Account verification and/or Password reset.
2. Define the username parameters.
3. Optional: Define response success and origin response failure conditions (ORF/ORS).
4. Enable bot management and account protection for the configured operations. 

 > Note: Important:
  - You **must** configure the username parameter. 
 - ORS/ORF configuration is **required** and used as a feedback mechanism from the origin to determine whether the operation is completely successful.

  

## [Post-login operations](https://techdocs.akamai.com/account-protector/docs/account-lifecycle-protection#post-login-operations)

The following operations are now available: Account update, Password change, and Payment.

To protect these operations, perform the following actions:

1. In API Definitions, [define your endpoints](https://techdocs.akamai.com/api-definitions/docs/set-up-resource-purposes) for these operations.
2. Where available, configure the username parameters.
3. Optional: Define ORS/ORF.
4. Enable the bot management and account protection for the configured operations.  

 > Note: 
  - Configure the username only if it’s validated by the origin against an active user session.  If a username is not provided, Account Protector generates a risk score based on the most recently seen username that logged in successfully from a client with the same long-term Bot Manager cookie.
 - ORF/ORS configuration is highly recommended and used as a feedback mechanism from the origin to determine whether the operation is completely successful.
