# [Configuration basics](https://techdocs.akamai.com/account-protector/docs/configuration-basics#configuration-basics)

# [Configuration guidelines](https://techdocs.akamai.com/account-protector/docs/configuration-basics#configuration-guidelines)

- You must define the username parameter (or user identifier for account creation) for at least one operation in the flow. Note that the username must be provided in the first request that is received in a multistep group, to link the flow with a user and begin tracking the multistep session.
- The following operation purposes are available for multistep workflows:
  - Account Creation
  - Account Verification
  - Login
  - Password Reset
  - Payment
- You can add an existing operation to a multistep group only if the operation type is available in multistep workflows.
- All API endpoints in a multistep group should be added to both bot management and account protection configurations.
- You can add just a part of the operations from a multistep workflow to the account protection, but if the whole multistep group is not covered, the flow may not be fully protected.
- Every authentication flow requires a separate multistep group. For example, one for login and another for account creation.
- Don’t mix different types of authentication flows in a single multistep group (except the account verification use case).
- If available, take usernames from the request body or header, not from previous operations.
- Add origin response step success and origin response failure conditions for each operation, and a success condition for every operation that ends the flow (like successful login or successful account creation).
- Select the MFA check box for multi-factor authentication such as a one-time password from SMS, an authenticator app, or an email.
- For API operations, the POST method is preferred. If possible, avoid the GET method.

# [Configure bot management](https://techdocs.akamai.com/account-protector/docs/configuration-basics#configure-bot-management)

You need to add API endpoints to both bot management and account protector to ensure that the multistep workflow is fully protected. To configure bot management, [set up transactional endpoint protection](https://techdocs.akamai.com/bot-manager/docs/set-trans-endpoints). 

# [Configure account protection](https://techdocs.akamai.com/account-protector/docs/configuration-basics#configure-account-protection)

[Define multiple endpoints](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints); one for each step of the multistep flow.

 > Note: 
  For complete protection, add all multistep operations from a group to account protection. In case an operation is missing, a warning appears under all operations from that multistep group.