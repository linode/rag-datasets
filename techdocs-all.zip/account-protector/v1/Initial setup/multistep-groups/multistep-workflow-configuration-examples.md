# [Configuration examples](https://techdocs.akamai.com/account-protector/docs/multistep-workflow-configuration-examples#configuration-examples)

See the examples of login, account creation, account verification, and password reset flows.

Before adding any flow, perform the following actions:

1. Log in to the ​Akamai Control Center​ with your username and password.
2. Navigate to ☰ > CDN > API definitions.
3. On the **API Definitions** page, in the **Registered APIs** section, select the name and version of the API you want to edit.
4. From the menu, select **API Operations**.

# [Add a login flow](https://techdocs.akamai.com/account-protector/docs/multistep-workflow-configuration-examples#add-a-login-flow)

In the following example, login is based on two operations:

- The first validates the email address and password.
- The second performs an optional authentication with MFA for high-risk users.

1. In  the**API Operations** section, in the right corner of the table, click the **+** icon and select **Multistep operation**.
2. Enter the multistep group name and click **Add.**
3. Define the first operation of the flow.

 > Note: 
  In this operation, the username and password are validated. The origin provides a 200 response code for users who don't need to complete an MFA. Alternatively, if the origin decides that MFA is required, it provides a 302 response code and redirects to an MFA operation. In such cases, multi-factor authentication is not selected as this is not an MFA operation, however, the multistep group success condition is defined.

8. Click **Save and add another operation**.
9. Define the second operation of the flow:
   1. Select the **“username (from previous step)”** option.
   2. Select multifactor authentication to require MFA from the users.
   3. Set the success condition.
   4. Set the failure condition.
10. Click **Save**.

# [Add an account creation flow](https://techdocs.akamai.com/account-protector/docs/multistep-workflow-configuration-examples#add-an-account-creation-flow)

In the following example, account creation consists of three operations:

- The user provides an email address with first and last name.
- The user provides their phone number.
- The user selects email communication preferences and the account is created.

  

1. In  the**API Operations** section, in the right corner of the table, click the **+** icon and select **Multistep operation**.
2. Enter the multistep group name and click **Add**.
3. Define the first operation of the flow:
   1. Capture the email address, first, and last name from the response body.
   2. Set step success and failure conditions.
4. Click **Save and add another operation**.
5. Define the second operation:
   1. Use the “**from **” option for parameters passed in the first operation: **email**, **first name**, and **last name**.
   2. Capture the phone number from the response body.
   3. Set step success and failure conditions.
6. Click Save and add another operation.
7. Define the third operation:

   1. Use the “**from **” option for **email**, **first name**, and **last name**.
   2. Use the “**from**” option for the** phone number**.
   3. Set the multistep group success condition, as this is the last step of the flow.

   
8. Click **Save**.

# [Add an account verification flow](https://techdocs.akamai.com/account-protector/docs/multistep-workflow-configuration-examples#add-an-account-verification-flow)

For this scenario, the initial step of the process involves verifying the user's email address. If an account is already associated with an email address, the user can proceed with logging in by providing their password. In case an account does not exist, the user has to create a new account by setting up a password.

In the following example, account verification consists of three operations:

- Account verification that captures the email address to track the user in the next operation.
- Login to enable logging in if the user’s account already exists.
- Account creation for a new user.

  

1. In  the**API Operations** section, in the right corner of the table, click the **+** icon and select **Multistep operation**.
2. Enter the multistep group name and click **Add**.
3. Define the account verification operation and capture the username from the request body.
4. Click **Save and add another operation**.
5. Define the login operation:
   1. Use the “**username from a previous step**” option.
   2. Define the multistep group success condition to inform about successful login.
   3. Define the failure condition to inform about failed login attempts.
6. Click **Save and add another operation**.
7. Define the account creation operation:
   1. Use the “**email from a previous step**” option.
   2. Define the multistep group success condition to inform about successful account creation.
   3. Define the operation failure condition to inform about failed account creation attempts.
8. Click **Save**.

# [Add a password reset flow](https://techdocs.akamai.com/account-protector/docs/multistep-workflow-configuration-examples#add-a-password-reset-flow)

In the following example, password reset consists of two operations:

- The user provides the email address where they receive a one-time password.
- The user enters the one-time password along with a new password.

  

1. In  the**API Operations** section, in the right corner of the table, click the **+** icon and select **Multistep operation**.
2. Enter the multistep group name and click **Add**.
3. Define the account verification operation and capture the username from the request body.
4. Click **Save and add another operation**.
5. Define the second password reset operation: 
   1. Use the “**email from a previous step**” option.
   2. Set the multistep group success condition to inform about successful password reset.
   3. Set the operation failure condition to inform about failed password reset attempts.
6. Click **Save**.

# [Add a Login Merged MFA flow](https://techdocs.akamai.com/account-protector/docs/multistep-workflow-configuration-examples#add-a-login-merged-mfa-flow)

In the following example, the login flow consists of three operations:

- The user submits the username and password via a Web interface.
- The user submits the username and password via a Mobile interface.
- The user enters the MFA one-time passcode (this is a shared operation for Web and Mobile).

1. In  the**API Operations** section, in the right corner of the table, click the **+** icon and select **Multistep operation**.
2. Enter the multistep group name and click **Add**.
3. Define the Web login operation and capture the username from the request body.
4. Click **Save and add another operation**.
5. Define the Mobile login operation and capture the username from the request body.
6. Define the third MFA operation:  
   a. Use the “username from a previous step” option.  
   b. Set the multistep group success condition to inform about successful password reset.  
   c. Set the operation failure condition to inform about failed password reset attempts.
7. Click **Save**.