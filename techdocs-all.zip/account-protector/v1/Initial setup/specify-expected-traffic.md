# [Specify expected traffic and telemetry types](https://techdocs.akamai.com/account-protector/docs/specify-expected-traffic#specify-expected-traffic-and-telemetry-types)

After you [define a resource to protect](https://techdocs.akamai.com/account-protector/docs/identify-your-login-endpoints), you specify what client types you expect to make requests, and what telemetry type they'll pass. For example, say you have a web resource, whose sole purpose is to accept entries from your native mobile app and web clients should never make a request. 

You set expected traffic by security policy.

1. Open the security policy where you want to set expected traffic.

2. Click **Account Protection**.

3. Click **Protected Resources**.

4. Expand the endpoint, and go to the **Expected Traffic** section.

5. Set handling for telemetry types you expect  
   Turn on each client type you expect to make requests.

   - **Web client - standard telemetry** requests comes through a web browser and use standard telemetry, which is best if your protected resource and regular HTML pages live on the same domain. (cross-domain coverage is not yet available)
   - **Web client - inline telemetry** requests come through a web browser and use inline telemetry, which you need when your protected resource gets requests from web pages on a different domain. [Read more about telemetry types in Bot Manager Help](https://techdocs.akamai.com/bot-manager/docs/set-up-inline-telemetry).
   - **Native Mobile App** requests come from a native mobile app, that you defined in Shared Resources. [Read how to define a native mobile app in Bot Manager online help](https://techdocs.akamai.com/bot-manager/docs/define-custom-clients-like-mobile-apps).

   For telemetry types you turned on, you can now [set a nuanced user risk response strategy](https://techdocs.akamai.com/account-protector/docs/set-user-risk-response-strategy).

 > Warning: 
  To turn on telemetry settings here they must already be on with bot management settings for the same API operation. Edit in bot management first, then return here.

1. Set handling for requests from telemetry types you don't expect.

   For any client/telemetry type that won't be making requests to this protected resource, leave its **Expected Traffic** checkbox turned off. Then scroll down to the **User Risk Response Strategy** section and set the action you want to take on requests from that client type.