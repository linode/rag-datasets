Error parsing table data: name 'null' is not defined

\*512 GB Dedicated CPU and Premium plans are in limited availability.

See [Choosing a Compute Instance Type and Plan](/docs/products/compute/compute-instances/plans/choosing-a-plan/) to compare plans.