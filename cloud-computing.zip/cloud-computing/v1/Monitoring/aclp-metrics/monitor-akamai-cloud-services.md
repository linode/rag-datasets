# [Use the centralized dashboards (Beta)](https://techdocs.akamai.com/cloud-computing/docs/monitor-akamai-cloud-services#use-the-centralized-dashboards-beta)

To visualize metrics data by service for multiple entities at once:

1. Log in to [Cloud Manager](https://cloud.linode.com).
2. Expand **Monitor** in the side navigation menu and select **Metrics**. 
3. Select a dashboard from the **Dashboard** dropdown menu. 
4. Set the **Time Range**.  Select from preset time ranges or define a custom time range. You can query up to 31 days of data at one time.
5. Use the filters to narrow down the list of entities for which metrics data should be visualized. See [Metrics reference](https://techdocs.akamai.com/cloud-computing/docs/metrics-dimensions-parameters#dimensions) for more information about some of these filters.
6. Optionally, set the [aggregation interval](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#aggregation-interval-dropdown-list) and [aggregation function](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#aggregation-function-dropdown-list) at the widget level.

The dashboard can display metrics data for up to 10 entities at a time. If you select multiple entities, each entity will appear as its own line in graphs and tables.