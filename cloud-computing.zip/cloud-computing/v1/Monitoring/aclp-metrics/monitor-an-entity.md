# [Analyze metrics for a single entity (Beta)](https://techdocs.akamai.com/cloud-computing/docs/monitor-an-entity#analyze-metrics-for-a-single-entity-beta)

To view and analyze metrics data for a single entity:

1. Log in to [Cloud Manager](https://cloud.linode.com).
2. Select the appropriate service from the side navigation menu.
3. Find and select the entity for which you want to see metrics data. 
4. On the details page that appears, select the **Metrics** tab. 
5. Select a dashboard from the **Dashboard** dropdown list. 
6. Set the **Time Range**.  
7. Use the filters to narrow down the list of entities for which metrics data should be visualized. See the [Metrics reference](https://techdocs.akamai.com/cloud-computing/docs/metrics-dimensions-parameters#dimensions) for more information about some of these filters.
8. Optionally, set the [aggregation interval](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#aggregation-interval-dropdown-list) and [aggregation function](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#aggregation-function-dropdown-list) at the widget level.