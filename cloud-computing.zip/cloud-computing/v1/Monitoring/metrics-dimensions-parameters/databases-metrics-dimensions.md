# [Databases metrics and dimensions](https://techdocs.akamai.com/cloud-computing/docs/databases-metrics-dimensions#databases-metrics-and-dimensions)

This topic covers the metrics, dimensions, and system alert parameter values for Databases.

### [Metrics](https://techdocs.akamai.com/cloud-computing/docs/databases-metrics-dimensions#metrics)

| Metric               | API equivalent     | Definition                                                                                                                                                  | Unit |
| :------------------- | :----------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------- | :--- |
| Available Disk Space | `available_disk`   | Amount of storage space on a disk drive that isn’t currently in use                                                                                         | GB   |
| Available Memory     | `available_memory` | Amount of memory available to be allocated to new or existing processes                                                                                     | GB   |
| CPU Usage            | `cpu_usage`        | Amount of load handled by individual processor cores to run various programs on a virtual machine (VM) expressed as a percentage of the total available CPU | %    |
| Disk I/O Read        | `read_iops`        | Number of read operations a storage disk can perform per second                                                                                             | IOPS |
| Disk I/O Write       | `write_iops`       | Number of write operations a storage disk can perform per second                                                                                            | IOPS |
| Disk Space Usage     | `disk_usage`       | Measurement of a VM's disk usage for tasks and programs expressed as a percentage of the total available disk space                                         | %    |
| Memory Usage         | `memory_usage`     | Amount of memory a VM uses at any given time expressed as a percentage of the total available memory                                                        | %    |

### [Dimensions](https://techdocs.akamai.com/cloud-computing/docs/databases-metrics-dimensions#dimensions)

| Dimension        | API equivalent     | Definition                                                                                                              |
| :--------------- | :----------------- | :---------------------------------------------------------------------------------------------------------------------- |
| Database Cluster | `database_cluster` | The specific group of databases or servers connected to a system to improve performance, availability, and scalability. |
| Database Engine  | `database_engine`  | The underlying system that the database is using to operate: MySQL or PostgreSQL                                        |
| Node Type        | `node_type`        | The type of node in a cluster: primary or secondary                                                                     |
| Region           | `region`           | Localized geographic area where the entity is located                                                                   |

### [System alerts configuration](https://techdocs.akamai.com/cloud-computing/docs/databases-metrics-dimensions#system-alerts-configuration)

The following parameters have been preconfigured for **Memory Usage**, **CPU Usage**, and **Disk Space Usage** system alerts: 

| Parameter | Value |
|---|---|
| Aggregation function | Average |
| Threshold | Dedicated: 95% used Shared: 90% used |
| Polling interval | 5 minutes |
| Evaluation period | 5 minutes |
| Blip interval | 3 |