# [Edit an alert definition (Beta)](https://techdocs.akamai.com/cloud-computing/docs/edit-alert#edit-an-alert-definition-beta)

To edit an alert definition:

1. Log in to [Cloud Manager](https://cloud.linode.com). 
2. Expand **Monitor** in the side navigation menu and select **Alerts**. 
3. Use the search and filter tools to find the alert you wish to change.
4. Select **Edit ** from the options menu.
5. Make the required changes. The following changes are permitted: 
   - **System alerts**: Entities can be [assigned or unassigned](https://techdocs.akamai.com/cloud-computing/docs/assign-unassign-entities).
   - **User alerts**: All definition details can be edited except for the selected service.