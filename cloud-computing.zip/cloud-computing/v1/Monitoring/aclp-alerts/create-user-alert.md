# [Create a user alert (Beta)](https://techdocs.akamai.com/cloud-computing/docs/create-user-alert#create-a-user-alert-beta)

If you need more flexibility than the preconfigured system alerts allow, you can create a user alert. A user alert allows you to customize the evaluation criteria that triggers it, the entities assigned to it, and the notification channel used.

Before creating a user alert, check the [system limits](https://techdocs.akamai.com/cloud-computing/docs/akamai-cloud-pulse#system-limits). keep the following in mind:

If multiple metrics are being evaluated, the minimum supported polling interval is the upper limit of the minimum aggregation interval for the selected metrics.

To create a user alert in Cloud Manager:

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Expand **Monitor** in the side navigation menu and select **Alerts**. 

3. Click **Create Alert**.

4. Complete the "General Information" section. For guidance, see [Alert parameters](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#alert-parameters).

5. Assign entities to the alert:
   - Use the search and filter tools to find the desired entities.
   - Select an entity to assign or unassign it to the alert. Repeat until tall of the desired entities are assigned.

6. Specify the evaluation criteria that must be met to trigger the alert.  For example, if you want an alert to fire when CPU usage exceeds 90% for 5 polling intervals:  

   - **Data field**: CPU Usage  
   - **Aggregation type**: Average 
   - **Operator**: >  
   - **Threshold**: 90
   - **Evaluation period\***: 10 min  
   - **Polling interval\***: 1 min  
   - **Blip interval**: 5  

   Currently, the only available evaluation period is five minutes and the only available polling interval is five minutes. For more information about these values, see [Alert parameters](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#alert-parameters).

7. Add a notification channel. During Beta, you will: 
   1. Click **Add Notification Channel**.  
   2. Select **Email** as the type.  
   3. Select the preconfigured **Read-Write Channel**.  This channel sends an email notification to all users with read/write access to the impacted entity.
   4. Click **Add Channel**.

8. Click **Submit** to create your new alert.

It may take up to five minutes for your new alert to be created. You can check the status of your alert on the Definitions tab of the Alerts page in Cloud Manager. A status of “In Progress” means the alert is still being created. This status will change to “Enabled” once the alert is active.