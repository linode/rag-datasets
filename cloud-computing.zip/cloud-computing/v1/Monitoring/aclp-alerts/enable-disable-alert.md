# [Enable or disable an alert (Beta)](https://techdocs.akamai.com/cloud-computing/docs/enable-disable-alert#enable-or-disable-an-alert-beta)

User alerts can be enabled or disabled at any time.

To do so in Cloud Manager:

1. Log in to [Cloud Manager](https://cloud.linode.com). 
2. Expand **Monitor** in the side navigation menu and select **Alerts**, then select the **Definitions** tab.
3. Use the search tools to find the alert you wish to change.
4. Select **Enable** (or **Disable**) from the options menu.

It may take up to five minutes for your change to be applied. You can check the status of your alert on the Definitions tab of the Alerts page in Cloud Manager. A status of “In Progress” means your change is still being processed.

 > Note: 
  System alerts can't be disabled, but you can [unassign entities](https://techdocs.akamai.com/cloud-computing/docs/assign-unassign-entities).