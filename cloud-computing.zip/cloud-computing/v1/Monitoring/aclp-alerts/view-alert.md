# [View an alert definition (Beta)](https://techdocs.akamai.com/cloud-computing/docs/view-alert#view-an-alert-definition-beta)

An alerts definition is accessed using Cloud Manager or the [Linode API](https://techdocs.akamai.com/linode-api/reference/post-alert-definition-for-service-type).

To view an alert definition in Cloud Manager:

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Expand **Monitor** in the side navigation menu and select **Alerts**. 

3. Select the **Definitions** tab to see the list of configured alert definitions including both system and user alerts.

   You'll see a summary of details such as:

   - The name of the alert
   - The status: enabled, disabled, in progress, or failed
   - The Akamai Cloud service the alert applies to
   - The creator the alert: system or username
   - The time the alert definition was last modified

   A status of “In Progress” means the alert has been created but the system is still working on its implementation. A status of “Failed” means something has gone wrong, and you should contact [Support](https://www.linode.com/support/) for assistance.

4. Use the search, filters, and sorting to quickly find the alert definition you want.

5. Click the alert's name or chose **Show Details** from the options menu to view the full configuration—criteria, assigned entities, and notification channels. The entities list shows only the entities you have access to.