# [Assign or unassign entities to an alert (Beta)](https://techdocs.akamai.com/cloud-computing/docs/assign-unassign-entities#assign-or-unassign-entities-to-an-alert-beta)

Entities can be assigned or unassigned to alerts at any time. 

To do so in Cloud Manager:

1. Log in to [Cloud Manager](https://cloud.linode.com).
2. Expand **Monitor** in the side navigation menu and select **Alerts**. 
3. Use the search and filter tools to find the alert you wish to change.
4. Select **Edit** from the options menu. The Edit page appears.
5. Use the search and filter tools to find the entity you wish to assign or unassign.
6. Select an entity to assign it to the alert, or unselect it to unassign it.
7. Repeat steps 5 and 6 until entity assignment is complete.
8. Click **Save**.

It may take up to five minutes for your changes to be applied. You can check the status of your alert on the Definitions tab of the Alerts page in Cloud Manager. A status of “In Progress” means your changes are still being processed. The alert will return to its previous status (enabled or disabled) once the process is complete.

 > Note: 
  If you want to disable an alert for all entities, consider [disabling the alert](https://techdocs.akamai.com/cloud-computing/docs/enable-disable-alert) instead.