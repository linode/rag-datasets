# [Delete an alert (Beta)](https://techdocs.akamai.com/cloud-computing/docs/delete-alert#delete-an-alert-beta)

System and user alerts can be enabled or disabled at any time.

To do so in Cloud Manager:

1. Log in to [Cloud Manager](https://cloud.linode.com). 
2. Expand **Monitor** in the side navigation menu and select **Alerts**. 
3. Select the **Definitions** tab.
4. Use the search tools to find the alert you wish to change.
5. Select **Delete** from the options menu. A confirmation modal appears.
6. Type the name of your Alert to confirm deletion and click **Delete**.

It may take up to five minutes for your change to be applied. You can check the status of your alert on the Definitions tab of the Alerts page in Cloud Manager. A status of “In Progress” means your change is still being processed.

 > Note: 
  System alerts can't be deleted, but you can [unassign entities](https://techdocs.akamai.com/cloud-computing/docs/assign-unassign-entities).