# [Overview (Beta)](https://techdocs.akamai.com/cloud-computing/docs/akamai-cloud-pulse#overview-beta)

 > Note: 
  Akamai Cloud Pulse is currently in beta, with new capabilities being phased in gradually. Databases was the first service to be integrated. Additional services will be added over time.

Akamai Cloud Pulse is an observability solution that delivers real-time insights into the performance, availability, and reliability of your cloud entities and infrastructure.  These insights can help you to monitor your services, respond quickly to any issues that arise, and plan for future needs. This beta release includes the following Metrics and Alerts capabilities:

**Metrics:**

- Collects and stores metrics for Akamai Cloud services.   
- Enables visualization and analysis of key metrics through [dashboards](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#use-metrics-dashboards)
- Provides programmatic access to metrics through the [Linode API](https://techdocs.akamai.com/linode-api/reference/get-dashboards-all)

**Alerts:**

- Notifies users of critical system events via [system alerts](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#system-alerts)
- Supports the creation and management of custom [user alerts](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#user-alerts) based on user-defined evaluation criteria
- Supports email as the notification channel
- Provides programmatic access to alerts through the [Linode API](https://techdocs.akamai.com/linode-api/reference/post-alert-definition-for-service-type)

# [Key concepts and terms](https://techdocs.akamai.com/cloud-computing/docs/akamai-cloud-pulse#key-concepts-and-terms)

The following term are defined based on their usage within the context of Cloud Manager:

- **Alert**. A configurable rule that monitors metrics or events and triggers an action when specified conditions are met.
- **Dashboard**. A collection of graphs that visualize metrics and trends over time.
- **Dimension**. A descriptive attribute or category that adds context to the data and enables filtering or grouping. 
- **Entity**. The primary object or resource from which metrics are collected, such as a a database cluster or virtual machine.
- **Metric**. A quantifiable indicator of health, behavior, or performance. 
- **Service**. An Akamai Cloud service, such as Databases or Linodes.
- **System alert**. A preconfigured alert that notifies users of critical events affecting one or more entities.                                                                                             
- **User alert**. An user-defined alert that evaluates a metric against custom thresholds.
- **Widget**. A dashboard component that visualizes metric data over time in graphical and tabular form.

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/akamai-cloud-pulse#pricing)

Metrics and Alerts are offered at no cost during the Beta period.

# [System Limits](https://techdocs.akamai.com/cloud-computing/docs/akamai-cloud-pulse#system-limits)

Keep the following limits in mind when using Metrics and Alerts:

Dashboards:

- **Entities**: Up to 10 entities can be selected for visualization at one time.  
- **Time range**: Up to 31 days of data can be queried at one time. 

Alert definitions:

- **Metrics per alert**: An alert can monitor up to 5 metrics. 
- **Dimension Filters per alert**: An alert definition can include up to 5 optional dimension filters.
- **Entities per alert**: An alert can target up to 100 entities.
- **User alerts per account**: Up to 100 user alerts can be created per account.
- **Notification channels per Alert**: An alert can be associated with up to 5 notification channels.