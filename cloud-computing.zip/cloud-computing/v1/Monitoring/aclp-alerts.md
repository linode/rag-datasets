# [Alerts (Beta)](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#alerts-beta)

 > Note: 
  Alerts is currently in beta, with new capabilities being phased in gradually. Databases was the first service to be integrated. Additional services will be added over time.

Configure alerts to monitors key metrics and events in real time and automatically trigger notifications or actions when predefined thresholds or conditions are met. 

The Alerts capability:

- Automatically notifies users of critical system events through [system alerts](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#system-alerts) 
- Supports the creation of custom [user alerts](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#user-alerts) based on user-defined metrics thresholds and configuration parameters
- Enables proactive issue detection and faster incident response.

# [Access alerts](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#access-alerts)

You can access and manage alerts in Cloud Manager, or programmatically using the API:

**Centralized alerts**: Navigate to [Monitor > Alerts](https://cloud.linode.com/alerts) to view a centralized list of alert definitions. You can filter, sort, and search both system and user alerts. 

**Linode API:**Use the Linode API to create, view, modify, or delete alerts programmatically. See the [API reference](https://techdocs.akamai.com/linode-api/reference/post-alert-definition-for-service-type) for details.

# [Alert types](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#alert-types)

## [System alerts](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#system-alerts)

Preconfigured by the system, these alerts fire when specific metric thresholds are met. Currently, notifications are sent via email to all users with read/write access to the impacted entity. By default, all entities associated with a service are automatically assigned to that service's system alerts. 

You can [assign and unassign entities](https://techdocs.akamai.com/cloud-computing/docs/assign-unassign-entities) to a system alert using the **Edit** functionality.

If you need a custom thresholds, create a [user alert](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#user-alerts), then reassign affected entities from the system alert to your new custom alert.  

## [User alerts](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#user-alerts)

Create custom alerts called user alerts based on user-defined metrics thresholds, dimension filters, and notification channels. Only one notification channel type is currently supported: email, using the preconfigured Read-Write Channel.

You can only create alerts for the entities within your access scope. Also, all entities assigned to an alert must belong to the same account.

## [Alert parameters](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#alert-parameters)

The following alert parameters are preconfigured for system alerts, and configurable for user alerts:

| Parameter                     | Description                                                                |
| :---------------------------- | :------------------------------------------------------------------------- |
| **General Information**       |                                                                            |
| Name                          | Name of the alert                                                          |
| Description.                  | Brief description of the alert                                             |
| Service                       | Akamai Cloud service the alert applies to (e.g., Databases)                |
| Severity                      | Alert severity: info, low, medium, or severe                               |
| **Entities**                  |                                                                            |
| Region (optional)             | Region the entities are in                                                 |
| Entities                      | Entities assigned to the alert                                             |
| **Alert evaluation criteria** |                                                                            |
| Data field (metric)           | Metric being monitored (e.g., CPU Usage, Memory Usage)                     |
| Aggregation type              | Statistic used to aggregate values: sum, min, max, or average              |
| Operator                      | Operator for threshold evaluation:  >,  \< , ≥, ≤, =                       |
| Threshold                     | Threshold value (%)                                                        |
| Dimension filter (optional)   | Optional dimensional attribute that contextualizes the data                |
| Polling interval              | Frequency at which the metric is checked                                   |
| Evaluation period             | Time window evaluated before triggering the alert.                         |
| Blip interval                 | Number of consecutive evaluations meeting criteria before firing an alert. |

# [Next steps](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts#next-steps)

- Learn to [view](https://techdocs.akamai.com/cloud-computing/docs/view-alert), [create](https://techdocs.akamai.com/cloud-computing/docs/create-user-alert), and [edit](https://techdocs.akamai.com/cloud-computing/docs/edit-alert), alert definitions. 
- Explore supported [metrics and dimensions](https://techdocs.akamai.com/cloud-computing/docs/metrics-dimensions-parameters).
- Review the [API reference](https://techdocs.akamai.com/linode-api/reference/post-alert-definition-for-service-type) for programmatic access.