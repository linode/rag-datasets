# [Metrics reference (Beta)](https://techdocs.akamai.com/cloud-computing/docs/metrics-dimensions-parameters#metrics-reference-beta)

 > Note: 
  Metrics and Alerts are currently in Beta, with new capabilities being phased in gradually. Databases was the first service to be integrated. Additional services will be integrated over time.

A set of metrics, dimensions, and preconfigured system alert parameters is supported for each Akamai Cloud service. Select a service from the following list for more information about its associated metrics and dimensions. Services will be added to this list as they are integrated with these capabilities.

- [Databases](https://techdocs.akamai.com/cloud-computing/docs/databases-metrics-dimensions)