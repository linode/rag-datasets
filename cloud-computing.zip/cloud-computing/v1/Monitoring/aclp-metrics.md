# [Metrics (Beta)](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#metrics-beta)

 > Note: 
  Metrics are currently in beta, with new capabilities being phased in gradually. Databases was the first service to be integrated. Additional services will be added over time.

Akamai Cloud Pulse automatically collects and stores performance metrics your cloud services. These metrics can be visualized through dashboards, inspected at the entity level, and retrieved using the API. Metrics data provides essential insights into the health, behavior, and performance of your cloud resources and infrastructure. 

# [Access metrics](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#access-metrics)

You can access metrics in two ways within Cloud Manager, or programmatically using the API:

**Centralized dashboards**: Navigate to [Monitor > Metrics](https://cloud.linode.com/metrics) and select a dashboard from the dropdown list. Dashboards consolidates metrics from multiple entities. Use the filters to adjust the time range and narrow the list of included entities. 

**Entity details page: **Open the details page for a specific entity (for example, a database cluster) and select the Metrics tab. This page provides metrics information for the specific entity only. 

**Linode API:** use the Linode API to retrieve metrics programmatically. See the [API reference](https://techdocs.akamai.com/linode-api/reference/get-dashboards-all) for details.

# [Use metrics dashboards](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#use-metrics-dashboards)

Dashboards provide a consolidated view of metrics for your services. The Metrics page containing dashboards has the following components.

## [Dashboard selection](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#dashboard-selection)

Select the dashboard you wish to view from the dropdown list, for example, "Resource Usage". 

## [Time range](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#time-range)

Select from preset ranges, such as "Last 12 Hours", or define a custom time range. You can query up to 31 days of data at one time. The dashboard aggregates metric data at the appropriate granularity based on the time range you select.

## [Filters](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#filters)

Use the filters to narrow down the list of entities available for selection. Up to 10 entities can be selected for visualization at one time. 

## [Widgets](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#widgets)

Each widget corresponds to a single metric. The number of widgets and the type of metrics visualized depend on the service and dashboard selected. See the[Metrics reference](https://techdocs.akamai.com/cloud-computing/docs/metrics-dimensions-parameters) for more information about each metric. 

You can change the width of the widget from 50% and 100%, or from 100% to 50% by clicking the resize icon.

Widgets contain the following components:

### [Graph](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#graph)

The widget graph visualizes a single metric over time.

### [Table](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#table)

 The widget table contains the maximum, average, and last values for the selected time period.

### [Aggregation interval dropdown list](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#aggregation-interval-dropdown-list)

![A screenshot of the aggregation interval dropdown menu in a metrics dashboard widget.](https://techdocs.akamai.com/linode/tools/img/aclp-aggregation-interval-v1.png)
 

Data can be aggregated at intervals of 1 minute, 5 minutes, 1 hour, or 1 day. If the aggregation interval is set to "Auto", data is aggregated based on the chosen time range. Time ranges correspond to the following granularities:

| Time range         | Granularity |
| :----------------- | :---------- |
| Less than 24 hours | 1 minute    |
| 24 hours to 7 days | 5 minutes   |
| more than 7 days   | 1 hour      |

### [Aggregation function dropdown list](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#aggregation-function-dropdown-list)

![A screenshot of the aggregation interval dropdown menu in a metrics dashboard widget.](https://techdocs.akamai.com/linode/tools/img/aclp-aggregation-function-v1.png)

Chose the function used to aggregate metric values: sum, maximum, minimum, or average.

# [Next steps](https://techdocs.akamai.com/cloud-computing/docs/aclp-metrics#next-steps)

- Learn to create and manage [alerts](https://techdocs.akamai.com/cloud-computing/docs/aclp-alerts) that monitor key metrics and trigger notifications or actions when thresholds or conditions are met.
- Explore supported [metrics and dimensions](https://techdocs.akamai.com/cloud-computing/docs/metrics-dimensions-parameters).
- Review the [API reference](https://techdocs.akamai.com/linode-api/reference/get-dashboards-all) for programmatic access.