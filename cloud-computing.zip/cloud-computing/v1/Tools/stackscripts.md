# [StackScripts](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#stackscripts)

[StackScripts](http://linode.com/stackscripts/) provide users with the ability to automate the deployment of custom systems. They work by running a custom script when deploying a new Linode. These custom scripts store tasks that you may need to repeat often on new Linodes, such as:

- Automating common system administration tasks, such as installing and configuring software, configuring system settings, adding limited user accounts, and more.
- Running externally hosted deployment scripts.
- Quickly creating Linodes for yourself or clients with the exact starter configuration you need.

All StackScripts are stored in the Cloud Manager and can be accessed whenever you deploy a Linode. A StackScript authored by you is an _Account StackScript_. A _Community StackScript_ is a StackScript created by a community member that has made their StackScript publicly available.

# [Features](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#features)

## [Quick and easy customization](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#quick-and-easy-customization)

Select a StackScript, fill out any required fields, and click to deploy. StackScripts run the first time a Linode boots, allowing you to automatically customize the default Linux distribution.

## [A library of stackscripts](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#a-library-of-stackscripts)

Customize your Linode with one of the many StackScripts in our library or discover a community-sourced script. They include everything from installing a Linode-optimized LAMP stack to configuring an IPsec VPN server.

## [Create your own](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#create-your-own)

Writing new StackScripts is simple. If you can’t find the right StackScript for your needs, author your own.

# [Pricing and availability](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#pricing-and-availability)

StackScripts are available at no charge across [all core compute regions](https://www.linode.com/global-infrastructure/), but are not available in distributed compute regions.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#technical-specifications)

- Deployable on new Linodes
- Use any supported Linux distribution (see [Choose a Linux Distribution](https://techdocs.akamai.com/cloud-computing/docs/choose-a-distribution))
- Supports the bash scripting language and any other scripting language supported by your chosen Linux distribution(s) (such as Python)
- Supports custom user-defined fields (UDFs)
- StackScripts can be made public to share with the community
- Manage StackScripts through an intuitive web-based control panel ([Cloud Manager](https://cloud.linode.com/)), the [Linode CLI](https://www.linode.com/products/cli/), or programmatically through the [Linode API](https://www.linode.com/products/linode-api/)

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of Akamai cloud computing products and services.
  - [StackScripts Endpoint Collection](https://linode.com/docs/api/stackscripts)
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line.