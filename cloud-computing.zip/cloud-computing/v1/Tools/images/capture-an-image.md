# [Capture an image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#capture-an-image)

Here we cover how to capture the disk from an existing Linode and save it as an image. This stores it for you so you can quickly create new Linodes using the image.

# [Requirements and considerations](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#requirements-and-considerations)

When capturing an image file from an existing Linode, consider these points:

- **Maximum disk size for an image**. This is currently **6 GB\***. To check the internal disk usage:

  1. Log in to the [Cloud Manager](https://login.linode.com/).

  2. Select **Linodes**.

  3. Find the target Linode and click **Launch LISH Console**.

  4. Run `df -h`.

  5. Locate the disk in the output and review the value in the `Used` column.

- **The disk's internal storage needs to be 10% less than your account's image size limit**. With the default image size limit of 6 GB, your disk's storage usage should be _under_ 5.4 GB. Have a look at [Check and Clean a Linux System's Disk Space](https://www.linode.com/docs/guides/check-and-clean-linux-disk-space/) for some tips on managing space.

- **The disk needs to be formatted using ext3 or ext4 file systems**. An images can't be captured if you're using a [raw disk](https://en.wikipedia.org/wiki/Rawdisk) or a disk you've formatted using a custom file system. CoreOS disk images are in RAW format. You can't use an image made from a CoreOS disk to deploy a new Linode.

- **Power off a Linode to avoid database corruption**. If your Linode is running an active database, you should power off the Linode before you create an image. If you leave a database active in a running Linode, you may see corruption or data loss in the imaged copy of the database.

- **Only the selected disk is saved to the image**. When capturing an image, other aspects of the Linode aren't stored. This includes Configuration Profiles, Block Storage Volumes, IP addresses, and all other Linode-based settings.

- **Account limits**. Your account can store up to **25\*** custom images, offering **150 GB\*** of combined storage for all images.

- **Pricing**. Custom images are billed monthly at $0.10 per GB, based on the _uncompressed_ image size."

\* _If you need to store larger images or more images, contact [Support](https://www.linode.com/support/) with details on your applications or intended workloads._

# [Capture an image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#capture-an-image)

There are multiple methods you can use to capture an image.

 > Note: New images are encrypted
  When you capture a new image, we automatically encrypt it for its protection. Images remain encrypted at rest, in storage, in caching, and in transit. When you deploy an image, we automatically decrypt the contents for you.

## [Use Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#use-cloud-manager)

When you're sure your target Linode disk is [compatible](#requirements-and-considerations), you can create an image of it in Cloud Manager.

1. Log in to [Cloud Manager](https://login.linode.com/).

2. Open **COMPUTE** from the left-hand menu.

3. Select **Images** and click **Create Image**.

4. Select the **Capture Image** tab.

5. Set the Select Linode & Disk options:

   - **Linode**. Select the Linode that houses the disk you want to use for your image.

   - **Disk**. Select the specific disk you want to use for your image.

![A screenshot of the Capture Image tab showing a selected Linode and disk.](https://techdocs.akamai.com/linode/tools/img/images-capture-v2.png)

5. Set the Image Details options:

   - **Label**. This defaults to the names of the Linode and Disk you've selected. You can optionally change this to another easy-to-recognize name for the image.

   - **This image is cloud-init compatible**. Enable this if you want the image to support cloud-init. Many Linode-supported distributions are compatible with it by default, or you may have installed cloud-init. Our [Metadata service](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service) is designed to be consumed by cloud-init.

   - **Add Tags**. For organizational purposes, you can enter a tag to group similar objects under a specific value. Once you set one, you can select it again with other images.

   - **Description**. Optionally add some text to describe your image.

6. Click **Create Image**.

You're redirected to the main Images page. Your new image is displayed in the Custom Images table, with a Status of **Creating {X}%**. Once it's ready, Cloud Manager changes its status to **Available**. The Size of the image is based on the disk's usage, not the size of the disk itself.

![A table within the Custom Images section showing the status of the image.](https://techdocs.akamai.com/linode/tools/img/images-capture-status-v2.png)

## [Use the API](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#use-the-api)

Here we combine API operations to locate the target Linode and target a [compatible](#requirements-and-considerations) disk to generate an image.

### [List regions](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#list-regions)

Run this API curl request, making sure to properly paste in or reference your [API token](https://techdocs.akamai.com/linode-api/reference/get-started#authentication). Store the `id` and `label` values for the region where your target Linode lives.

```command
curl -H "Authorization: Bearer $TOKEN" \
    https://api.linode.com/v4/regions
```

### [List Linodes](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#list-linodes)

Run this request using the stored region `id` to filter the response. Identify the specific Linode you want, and store the `disk` value from the `specs` object for the disk you want to use for the image.

```command
curl -H "Authorization: Bearer $TOKEN"
    -H 'X-Filter: { "region": "us-east" }'
    https://api.linode.com/v4/linode/instances
```

### [Create the image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#create-the-image)

Run this request to create the image. Store the `id` value that's generated for it.

- `disk_id`. Set this to the `disk` you stored from the Linode.
- `label`. Optionally give your image an easily recognizable name. If this is left out, the name of the image will default to `
-
`.
- `tags`. For organizational purposes, you can optionally enter one or more tags to group similar objects under these specific values. Once you set one, you can set it again with other images.
- `description`. Optionally add some text to describe your image.
- `cloud_init`. Set to `true` if you want the image to support cloud-init. Many Linode-supported distributions are compatible with it by default, or you may have installed cloud-init on the disk, yourself. Our [Metadata service](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service) is designed to be consumed by cloud-init.

```command
curl -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -X POST -d '{
      "disk_id": 12345
      "label": "Golden Image 2",
      "tags": [
        "gold", "secondary"
      ]
      "description": "Secondary golden image for Ubuntu Linux",
      "cloud_init": "true"
    }' \
    https://api.linode.com/v4/images
```

### [Check the status](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#check-the-status)

The process takes some time to complete. You can check on it by running this request, using the `id` you stored after creating the image. When the `status` is `available`, the image is ready for use.

```command
curl -H "Authorization: Bearer $TOKEN" \
    https://api.linode.com/v4/images/{image_id}
```