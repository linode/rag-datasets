# [Replicate an image](https://techdocs.akamai.com/cloud-computing/docs/replicate-an-image#replicate-an-image)

You can target an existing image and replicate an exact copy of it to another compute region. This helps speed up deployment of the image directly to that region. 

 > Note: 
  - You can replicate an image you've [captured](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image) or one that you've [uploaded](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image). Recovery images can't be replicated.
  - As part of our limited promotional period, image replicas are free of charge until November 1, 2025. After this date, replicas will be subject to our standard monthly rate of $0.10/GB. When replicas become billable, your monthly charge will be calculated using the value returned in that image's **All Replicas** column, divided by 100. [Learn more](https://www.linode.com/blog/compute/image-service-improvements-akamai-cdn/).

## [Use Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/replicate-an-image#use-cloud-manager)

1. Log in to [Cloud Manager](https://login.linode.com/).

2. Select **Images**.

3. Locate the desired image in the table, click more options (**...**), and select **Manage Replicas**. The Manage Replicas for \
 drawer opens.

4. Use the **Add Regions** drop-down to select one or more compute regions to replicate your image. The regions appear along with the current region where the image is located.

   > > Note: 
   > 
   > Object Storage is used to store images. Only core compute regions that support our [Object Storage](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center#product-availability) service are available.

![](https://techdocs.akamai.com/linode/tools/img/images-replicate-select-v1.png)

The Status of the selected image is updated to **Pending Replication**. Once it reaches **Available**, your image has been successfully replicated.

![](https://techdocs.akamai.com/linode/tools/img/images-replicate-added-v2.png)

## [Use the API](https://techdocs.akamai.com/cloud-computing/docs/replicate-an-image#use-the-api)

You can use the [Replicate an image](https://techdocs.akamai.com/linode-api/reference/post-replicate-image) operation to create a replica.