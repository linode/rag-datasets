# [Deploy an image to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-an-existing-compute-instance#deploy-an-image-to-an-existing-linode)

While it's typically more common to [deploy an Image to a _new_ Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-a-new-compute-instance), you can deploy an image to an _existing_ Linode. Do this to maintain consistent billing or if to add the image alongside existing data.

 > Note: 
  A Linode can have up to 50 disks.

# [Method 1: Rebuild a Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-an-existing-compute-instance#method-1-rebuild-a-linode)

This is considered the "start over" method. You'll rebuild an existing Linode by applying your image to it. This deletes all data and disks on the Linode and creates new disks from the selected image.

 > Note: 
  You should only use this method if you no longer need the data that's on the target Linode.

1. Access [Cloud Manager](https://cloud.linode.com/) and select **Images** from the left menu.

2. Find the Image you want to use, click its option menu (**...**), and select **Rebuild an Existing Linode**.

   

   ![A screenshot showing the Rebuild an Existing Linode option within the more options ellipsis menu.](https://techdocs.akamai.com/linode/tools/img/images-rebuild-a-linode-v2.png)

   

3. The **Rebuild an Existing Linode from an Image** panel opens. Select the **Linode ** you want to use and click **Rebuild Linode**.

4. You're redirected to the **Rebuild Linode \
 ** dashboard. Set the options here as necessary: 
   - **From Image**. Leave this set as is. ("From Image" indicates you're rebuilding from your image.)
   - **Images**. Your image is pre-selected here.
   - **Root Password _(Required)_**.  Set a password that you'll use to log in to the system as the root user. The root user is the main account and has access to the entire system, including files and commands. Make the password extremely strong to prevent attackers from gaining access to your system. By default, the root user can log in over Lish and SSH using this password. As a best practice you _should not_ solely rely on this password as a means of access. See [Set up and secure a Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance) for more information.
   - **SSH Keys _(Optional, but best practice)_**. Secure login to your Linode through SSH. These keys are created as a pair: a private key stored on your local computer, and a public key that you can upload to remote systems and services. Since your private key is kept safe and secure, and you only upload the public key, this is a much more secure method for authentication than the Root Password. See [Manage SSH keys](https://techdocs.akamai.com/cloud-computing/docs/manage-ssh-keys) for more information.
   - **Confirm**. This process will overwrite existing data on the target Linode. To confirm that this is OK, enter the name of thatLinode.

5. Click  **Rebuild Linode**. 

# [Method 2: Add a disk to a Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-an-existing-compute-instance#method-2-add-a-disk-to-a-linode)

If you want to keep an existing Linode, you can restore your image to a _separate_ disk on it. For example, use this method if you want multiple bootable configurations on your Linode, and only need to access one at a time.

1. Access the [Cloud Manager](https://cloud.linode.com/), click the **[Linodes](https://cloud.linode.com/linodes)** link in the sidebar, and select a Linode from the list.

2. **Create a disk with the Image**. Follow the instructions to [create a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#create-a-disk) using [Cloud Manager](https://cloud.linode.com/). Keep the following considerations in mind:

   - Confirm there is enough unallocated storage space to accommodate the new disk for the desired Image. If you aren't sure of the size of the Image, open the **[Images](https://cloud.linode.com/images)** page, find the Image within the list, and view the _Size_ column.
   - When creating the disk, select the **Create from Image** option and select the Image you wish to deploy.

3. **Optionally create a swap disk**. Your image _may_ require a swap disk in order to boot. If you already have a swap disk on your Linode from a previous image deployment (visible under the **Disks** panel), you can reuse that same disk with your new image. Otherwise, you can create a new swap disk:

   1. Navigate back to the Linode's **Storage** tab and click the **Add a Disk** button.

   2. In the **Add Disk** form, select **Create Empty Disk** and choose the _swap_ option from the **Filesystem** dropdown menu. Then enter a _Label_ and _Size_ (usually 128MB, 256MB, or 512MB). Click the **Add** button to create the disk.

4. **Create or edit a configuration profile**. To boot using the new disk, the disk needs to be properly assigned within a new or existing [configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance) and selected as the _Root Device_.

   1. Navigate to the Linode's **Configuration** tab and click the **Add Configuration** button. It's also possible to adjust an existing configuration profile by clicking the _Edit_ link next to that configuration.

   2. Within the **Add (or Edit) Configuration** form that appears, assign the disk under **Block Device Assignment** and select that device as the **Root Device**. Here are the important fields within this form:

      | Field           | Value                                                                                                                                  |
      | --------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
      | Label           | A name for the configuration profile.                                                                                                  |
      | Comments        | Enter any comments that may help you remember the purpose for your new configuration profile, or any other notes you'd like to record. |
      | Select a Kernel | In most cases, select _GRUB 2_.                                                                                                        |
      | /dev/sda        | Choose the disk for the new Image that was just deployed.                                                                              |
      | /dev/sdb        | Choose the swap disk, if one is available.                                                                                             |

      For all of Linode's standard distribution images, the other fields can retain their default values. For Custom Images, you may need to update other parts of the configuration profile. Review the [Managing Configuration Profiles on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#edit-a-configuration-profile) and [Install a Custom Linux Distribution on a Linode](https://linode.com/docs/guides/install-a-custom-distribution/) guides for further guidance.

5. Reboot the Linode using the new Image. Navigate to the **Configuration** tab, find the new configuration profile in the list, and click the corresponding **Boot** link. This link may be displayed with the **More Options** ellipsis dropdown menu.

   

   ![A screenshot of the Boot link within the table.](https://techdocs.akamai.com/linode/tools/img/images-config-profile-boot-v3.png)

   
