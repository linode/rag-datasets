# [Deploy an image to a new Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-a-new-compute-instance#deploy-an-image-to-a-new-linode)

Follow these steps to deploy your stored image as a disk in a new Linode.

 > Note: 
  A Linode can have up to 50 disks.

1. Log in to Cloud Manager and navigate to the **Images** page.

2. Locate the Image you want to use, click its **ellipsis** options menu, and select **Deploy to a New Linode**.

   

   ![A screenshot showing the Deploy to New Linode option within the more options ellipsis menu.](https://techdocs.akamai.com/linode/tools/img/images-deploy-to-new-linode-v2.png)

   

3. The **Create Linode** form is revealed. Specifically set these options:
   - **Region**. You can deploy a saved image to any compatible region:
     - **Custom image**. This is an image you created, either a [captured image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image)  or an [uploaded image](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image) . These can be deployed to any region. (These are what we call second generation images.)
     - **Recovery image**. This image is automatically generated after you [delete a Linode](https://techdocs.akamai.com/cloud-computing/docs/images#recover-a-deleted). These are generated using our legacy, first generation image service. These can only be deployed to core compute regions. (The list available in the **Regions** drop-down is limited to core compute regions.)
       > > Note: 
       > 
       > See [Regions and images](https://techdocs.akamai.com/cloud-computing/docs/images#regions-and-images)  for complete details on region support.
   - **Choose an Image**. Your image is default selected here. Leave this as is.
   - **Linode Plan**. Select an appropriate plan for your image. The plan size needs to accommodate the size of the disk in your image.

4. Set the remaining options as necessary. See [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance) for details on thee options.

5. Click the **Create Linode** button to create the Linode based on the selected Image.

# [Troubleshooting](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-a-new-compute-instance#troubleshooting)

If you can't access your new Linode through SSH or it doesn't respond to pings, check to see if [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#individual-linode-setting)  is enabled. If it's disabled, the internal network configuration on your new Linode is not automatically configured. In this case, you can do either of the following:

- Enable Network Helper and reboot.
- [Manually edit](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) your network configuration files and reboot.