# [Upload an image](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#upload-an-image)

Here we cover how to create a custom image by uploading a properly-formatted `.img` file for use as a custom image.

 > Tip: 
  This is intended for advanced system administrators. In most cases, you might be better suited [capturing an image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image) directly from an existing Linode, or through our [Packer Builder](https://www.linode.com/docs/guides/how-to-use-linode-packer-builder/) tool. Both of these methods ensure maximum compatibility with our services and are easier to follow.

# [Requirements and considerations](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#requirements-and-considerations)

Before you create a custom image for upload, consider these points:

- **Use a raw disk image**. Your image file needs to be in [raw disk image format](https://en.wikipedia.org/wiki/IMG_(file_format)) (`.img`). Other file formats aren't supported.

- **Format the disk using the ext3 or ext4 file system**. If you have a [raw disk](https://en.wikipedia.org/wiki/Rawdisk), or you've formatted your disk using another file system, it's not compatible.

 > Note: 
  As a best practice, ensure that your disk is _not_ partitioned. You can use partitioned disks, but some manual configuration may be required. You can also use our [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) tool which is most compatible with non-partitioned image files.

- **Account limits**. Your account can store up to **25\*** custom images, offering **150 GB\*** of combined storage for all images.

- **Pricing**. Custom images are billed monthly at $0.10 per GB, based on the _uncompressed_ image size."

# [Set up an image file](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#set-up-an-image-file)

Here are a few methods to get you started. Depending on how you obtain or generate it, the image or image file may need further configuration so it can be used with our Image Upload feature.

- **Existing Image**. Use a compatible image from your own on-premise environment, existing cloud provider, or through an online repository , such as a distribution's official image repository.

- **Packer**. Use Packer's [QEMU Builder](https://www.packer.io/docs/builders/qemu) to automate the creation of a custom image. In the `.json` configuration file for your image, set `"accelerator": "kvm"` and `"format": "raw"`. If running Packer inside of a virtual machine, the hypervisor needs to support nested virtualization.

- **The `dd` utility**. Install and configure an operating system on a local, remote, or virtualized system and create a disk image using the `dd` command-line tool.

- **The QEMU disk image utility**. Use the [QEMU disk image utility](https://qemu-project.gitlab.io/qemu/tools/qemu-img.html) to create the image.

## [Compress the image file](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#compress-the-image-file)

Once you have your image file, you need to compress it using gzip. Other compression algorithms aren't compatible. Maximum file sizes apply:

- The maximum compressed file size is **5 GB**.
- The maximum uncompressed image file size is **6 GB\***.

Based on your operating system, here are some compression methods you can use:

- **Linux and macOS**. Run this command, replacing _[file.img.gz]_ with the file name of your image. See [Archiving and Compressing files with GNU Tar and GNU Zip](https://www.linode.com/docs/guides/archiving-and-compressing-files-with-gnu-tar-and-gnu-zip/) for additional information on gzip.

  ```
  gzip [file.img]
  ```
- **Windows**. Use a third-party tool that supports gzip compression, such as [7-Zip](https://www.7-zip.org/).

\* _If you need to store larger images or more images, contact [Support](https://www.linode.com/support/) with details on your applications or intended workloads._

## [Determine uncompressed file size](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#determine-uncompressed-file-size)

When you're planning the storage requirements for a Linode, it's helpful to know the _uncompressed_ size of an image file. This also helps you stay within the [limits of the images service](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#requirements-and-considerations). The best way to determine the uncompressed size of a gzip archive is to uncompress that archive and then examine its file size. Alternatively, use the zcat utility by running the following command, replacing _[file.img.gz]_ with the file name of your image:

```
zcat [file.img.gz] | wc -c
```

# [Upload an image file](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#upload-an-image-file)

You have multiple options when uploading an image file.

 > Note: Images are automatically encrypted
  When you upload a new image, we automatically encrypt it for its protection, even if you've already encrypted it. Your images remain encrypted when in storage, in caching, and in transit. When you deploy an image, we'll automatically decrypt the encryption we've applied. If you've also encrypted the image, you'll need to manually decrypt it.

## [Use Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#use-cloud-manager)

Once you have a compatible image file that meets all the requirements, upload it through the **Upload Image** Cloud Manager form. After it's uploaded, you can deploy Linodes using the image.

1. Log in to [Cloud Manager](https://login.linode.com/).

2. Open **COMPUTE** from the left-hand menu.

3. Select **Images** and click **Create Image**.

4. Select the **Upload Image** tab. Set these options:

   - **Label**. Enter an easy-to-recognize name for the image. If you leave this blank, Cloud Manager uses the label set for the disk.

   - **This image is cloud-init compatible**. Enable this only if your image is compatible with cloud-init, or has cloud-init installed, and the config has been changed to use our [Metadata service](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server).

   - **Region**. Select the core compute region where you want the image to be stored. As a best practice, select the region that's closest to you for the fastest upload. For more information on regions, see [Regions and images](https://techdocs.akamai.com/cloud-computing/docs/images#regions-and-images).

   - **Add Tags**. Optionally enter a tag to group similar objects under a specific value. Once you set one, you can select it again with other images.

   - **Description**. Optionally add some text to describe your image.

5. Select a [compatible](#requirements-and-considerations) image file you want to use. Either drag and drop it into the designated area or click **Browse Files** to navigate your local system. The filename appears along with a progress bar for the file upload.

### [Finish a Cloud Manager upload](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#finish-a-cloud-manager-upload)

After upload, Cloud Manager creates a custom image and redirects you to the main Images page. You should see it listed along with a status of **Pending Upload**. Once it's ready, Cloud Manager changes its status to **Available**.

![A screenshot of the Available status within the Custom Images table.](https://techdocs.akamai.com/linode/tools/img/images-upload-status-v2.png)

 > Note: 
  If an error occurs, Cloud Manager may delete the image and write a message to your [events](https://cloud.linode.com/events) log. See [Events and activity feeds](https://techdocs.akamai.com/cloud-computing/docs/what-are-cloud-manager-events-and-activity-feeds) for more details on viewing Cloud Manager events.

## [Use the Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#use-the-linode-cli)

You can also upload an image file using the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli).

1. Run this command to install or update the Linode CLI:

   ```
   pip3 install linode-cli --upgrade
   ```

2. If this is your first time using the CLI or if you encounter any authorization issues, reconfigure and authorize your installation:

   ```
   linode-cli configure
   ```

3. Create a custom image and upload a [compatible](#requirements-and-considerations) image file using the following command:

   ```
   linode-cli image-upload --label "[Label]" [File] --region "[region-id]" --description "[Description]"
   ```

   - `[Label]`. Replace this with a unique name for the image.

   - `[File]`. Replace this with the filename and path of the image file you want to use.

   - `[region-id]` (Optional). Replace this with the id of the compute region where you want to store the image. If you leave this is out, the CLI uses the default region you specified when you configured it.

   - `[Description]` (Optional). Replace this with some text to describe your image.

### [Example upload command](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#example-upload-command)

Here's an example of the command for a custom image created in the Newark data center with the label "Example Image," a description of "Some details about the image," and the image file "~/Downloads/image-file.img.gz" will be uploaded.

```
linode-cli image-upload --label "Example Image" --description "Some details about the image" --region "us-east" ~/Downloads/image-file.img.gz
```

### [Finish a CLI upload](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#finish-a-cli-upload)

After you issue the command, the CLI displays a progress bar for the file upload. On completion, the CLI displays a single data row table with details on the new custom image with a status of `pending_upload`.

The image upload may take a few minutes to fully process. To verify it's available for use, run this command and look for a status of `available` for the custom image:

```
linode-cli images list --is_public false
```