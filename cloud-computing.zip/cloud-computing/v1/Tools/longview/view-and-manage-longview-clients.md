# [View and manage Longview clients](https://techdocs.akamai.com/cloud-computing/docs/view-and-manage-longview-clients#view-and-manage-longview-clients)

# [View Longview clients](https://techdocs.akamai.com/cloud-computing/docs/view-and-manage-longview-clients#view-longview-clients)

Log in to the [Cloud Manager](https://cloud.linode.com/) and click the **Longview** link in the sidebar.

All existing Longview clients are displayed along with some basic system information and metrics, including:

- Hostname
- System uptime
- Available package updates
- Number of CPUs and CPU utilization
- Amount of system memory and memory utilization
- Amount of swap memory and swap utilization
- Average CPU load
- Network traffic
- Amount of disk space and disk utilization

# [Create a new Longview client](https://techdocs.akamai.com/cloud-computing/docs/view-and-manage-longview-clients#create-a-new-longview-client)

To start capturing metrics for one of your Linodes (or other Linux systems), you can create a new Longview Client instance and install the Longview Agent. See [Create a Longview Client and Install the Longview Agent](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview) for instructions.

# [Delete a Longview client](https://techdocs.akamai.com/cloud-computing/docs/view-and-manage-longview-clients#delete-a-longview-client)

1. Log in to the [Cloud Manager](https://cloud.linode.com/dashboard) and click on the **Longview** link in the sidebar.

2. Click the **ellipsis** button corresponding to the Longview Client instance you'd like to remove and select **delete**.

   

3. Next, SSH into the Linode or Linux system that the Longview Client was monitoring.

   ```
   ssh user@192.0.2.17
   ```

4. Uninstall the Longview Agent by removing the `linode-longview` package.

   - **Debian and Ubuntu:**

     ```
     sudo apt-get remove linode-longview
     ```

   - **CentOS:**

     ```
     sudo yum remove linode-longview
     ```

   - **Other Distributions:**

     ```
     sudo rm -rf /opt/linode/longview
     ```