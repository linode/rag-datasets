# [Troubleshooting Longview](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-linode-longview#troubleshooting-longview)

This guide discusses basic troubleshooting steps to help you diagnose and resolve any issues you may encounter while using Longview. If you're experiencing problems with the Longview client, follow the steps outlined in this guide to help determine the cause.

# [Basic diagnostics](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-linode-longview#basic-diagnostics)

1. Ensure that your system is [fully updated](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#perform-system-updates).

   > > Note: 
   > 
   > Longview requires Perl 5.8 or later.

2. Verify that the Longview client is running. Use the command that is appropriate for your distribution's initialization system:

   - **Distributions with systemd**

     ```
     sudo systemctl status longview
     ```

   - **Distributions without systemd**

     ```
     sudo service longview status
     ```

   If the Longview client is not running, start it with the command appropriate for your distribution's initialization system:

   - **Distributions with systemd**

     ```
     sudo systemctl start longview
     ```

   - **Distributions without systemd**

     ```
     sudo service longview start
     ```

   If the service fails to start, check Longview's log for errors. The log file is located in `/var/log/linode/longview.log`.

# [Debug mode](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-linode-longview#debug-mode)

Restart the Longview client in debug mode for increased logging verbosity.

1. First stop the Longview client:

   - **Distributions with systemd**

     ```
     sudo systemctl stop longview
     ```

   - **Distributions without systemd**

     ```
     sudo service longview stop
     ```

2. Then restart Longview with the `debug` flag:

   ```
   sudo /etc/init.d/longview debug
   ```

3. When you're finished collecting information, repeat the first two steps to stop Longview and restart it again without the debug flag.

   If Longview does not close properly, find the process ID and kill the process:

   ```comand
   ps aux | grep longview
   sudo kill $PID
   ```

# [APT upgrade issue](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-linode-longview#apt-upgrade-issue)

The Longview APT servers have switched from HTTP to HTTPS for the linode-longview package, which may cause the following error when running apt update for the existing customers.

```
Hit:1 http://mirrors.linode.com/ubuntu jammy InRelease
Hit:2 http://mirrors.linode.com/ubuntu jammy-updates InRelease
Hit:3 http://mirrors.linode.com/ubuntu jammy-backports InRelease
Hit:4 http://repo.netdata.cloud/repos/edge/ubuntu jammy/ InRelease
Hit:5 http://repo.netdata.cloud/repos/repoconfig/ubuntu jammy/ InRelease
Ign:6 http://apt-longview.linode.com jammy InRelease
Err:7 http://apt-longview.linode.com jammy Release
404  Not Found [IP: 2600:3c03::f03c:91ff:feba:159b 80]
Ign:8 https://apt.vector.dev stable InRelease
Hit:9 https://apt.vector.dev stable Release
Get:10 http://security.ubuntu.com/ubuntu jammy-security InRelease [129 kB]
Get:12 http://security.ubuntu.com/ubuntu jammy-security/restricted amd64 c-n-f Metadata [584 B]
Get:13 http://security.ubuntu.com/ubuntu jammy-security/multiverse amd64 c-n-f Metadata [228 B]
Reading package lists... Done
E: The repository 'http://apt-longview.linode.com jammy Release' no longer has a Release file.
N: Updating from such a repository can't be done securely, and is therefore disabled by default.
N: See apt-secure(8) manpage for repository creation and user configuration details.
```

To resolve it use this command:

```
sudo sed -i 's|http://apt-longview.linode.com|https://apt-longview.linode.com|g' /etc/apt/sources.list.d/longview.list
```

# [Firewall rules](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-linode-longview#firewall-rules)

If your Linode has a firewall, it must allow communication with Longview's aggregation host at `longview.linode.com` (IPv4: `96.126.119.66`). You can view your firewall rules with one of the commands below, depending on the firewall controller used by your Linux distribution:

- **firewalld**

  ```
  sudo firewall-cmd --list-all
  ```

  > > Note: 
  > 
  > Review our [Introduction to FirewallD on CentOS](https://linode.com/docs/guides/introduction-to-firewalld-on-centos/) guide for more help with FirewallD.

- **iptables**

  ```
  sudo iptables -S
  ```

  > > Note: 
  > 
  > Review our [Control Network Traffic with iptables](https://linode.com/docs/guides/control-network-traffic-with-iptables/) guide for more help with iptables.

- **ufw**

  ```
  sudo ufw show added
  ```

  > > Note: 
  > 
  > Review our [How to Configure a Firewall with UFW](https://linode.com/docs/guides/configure-firewall-with-ufw/) guide for more help with UFW.

If the output of those commands show no rules for the Longview domain (or for `96.126.119.66`, which is the IP for the Longview domain), you must add them. A sample iptables rule that allows outbound HTTPS traffic to Longview would be the following:

```
iptables -A OUTPUT -p tcp --dport 443 -d longview.linode.com -j ACCEPT
```

 > Note: 
  If you use iptables, you should also make sure to persist any of your firewall rule changes. Otherwise, your changes will not be enforced if your Linode is rebooted. Review the [iptables-persistent](https://linode.com/docs/guides/control-network-traffic-with-iptables/#introduction-to-iptables-persistent) section of our iptables guide for help with this.

# [Verify API key](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-linode-longview#verify-api-key)

The API key given in the Cloud Manager should match that on your system in `/etc/linode/longview.key`.

1. In Cloud Manager, the API key is located in the **Installation** tab of your Longview Client instance's [detailed view](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview).

2. SSH into your Linode. The Longview key is located at `/etc/linode/longview.key`. Use `cat` to view the contents of that file and compare it to what's shown in Cloud Manager:

   ```
   cat /etc/linode/longview.key
   ```

   The two should be the same. If they are not, paste the key from the Cloud Manager into `longview.key`, overwriting anything already there.

# [Cloned keys](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-linode-longview#cloned-keys)

If you clone a Linode which has Longview installed, you may encounter the following error:

```text Output
Multiple clients appear to be posting data with this API key. Please check your clients' configuration.
```

This is caused by both Linodes posting data using the same Longview key. To resolve it:

1. Uninstall the Longview agent on the cloned system.

   - **CentOS**:

     ```
     sudo yum remove linode-longview
     ```

   - **Debian or Ubuntu**:

     ```
     sudo apt-get remove linode-longview
     ```

   - **Other Distributions**:

     ```
     sudo rm -rf /opt/linode/longview
     ```

2. Add a new [Longview Client instance](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview#create-a-longview-client). This will create a new Longview API key independent from the system which it was cloned from.

   > > Note: 
   > 
   > The GUID provided in the Longview Client's installation URL is not the same as the Longview API key.

3. [Install the Longview Agent](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview#install-the-longview-agent) on the cloned Linode.

# [Contact support](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-linode-longview#contact-support)

If you still need assistance after performing these checks, please open a [support ticket](https://techdocs.akamai.com/cloud-computing/docs/help-and-support#contact-customer-support).