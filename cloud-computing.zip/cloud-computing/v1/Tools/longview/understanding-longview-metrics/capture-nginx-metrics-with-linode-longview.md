# [Capture NGINX metrics with Longview](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#capture-nginx-metrics-with-longview)

In addition to capturing general system metrics, Longview can also be used to capture metrics for NGINX. The NGINX tab appears in Cloud Manager when Longview detects that you have NGINX installed on your system. It can help you keep track of NGINX workers, requests, system resource consumption, and other information.

 > Note: 
  In order to use Longview to capture data for NGIXN, you must have the Longview Agent successfully installed on the system you wish to monitor. See [Create a Longview Client and Install the Longview Agent](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview).

# [In this guide](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#in-this-guide)

This guide covers using Longview with NGINX and includes the following topics:

- [Configuring Longview for NGINX](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#configure-longview-for-nginx).
- [Interacting with the NGINX data provided by Longview in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#view-nginx-metrics).
- [Troubleshooting Longview for NGINX](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#troubleshooting).

# [Configure Longview for NGINX](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#configure-longview-for-nginx)

## [Automatic configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#automatic-configuration)

_These instructions are compatible only with Debian and Ubuntu and do not work on CentOS._

If NGINX is installed and running when you install the Longview agent, Longview should automatically configure itself for NGINX. If you install NGINX _after_ setting up the Longview agent, you can perform the steps below to configure Longview with any available software integrations (Apache, NGINX, and MySQL). Any existing Longview data is not affected and will remain accessible.

1. [SSH into the Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode) you are monitoring with Longview.

2. Ensure that NGINX is running.

   ```
   sudo systemctl status NGINX
   ```

3. Run the automatic Longview configuration command.

   ```
   dpkg-reconfigure -phigh linode-longview
   ```

   For many systems, Longview should be able to configure itself automatically. If this is the case, your output should be similar to the following:

   ```text Output
   Checking Nginx configuration...
   Found nginx status page at http://127.0.0.2/nginx_status specified in /etc/linode/longview.d/Nginx.conf
   ```

   If this output appears, Longview is configured and you can skip to the last step.

4. If Longview can't locate the NGINX status page, a prompt may appear. This could indicate that the status page is in an unusual and unspecified location, or that the status module isn't enabled, or that NGINX itself is misconfigured.

   

   Select one of the options:

   - **No**: The configuration tool exits and you can perform a [manual configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#manual-configuration). This may be safer if you have a delicate NGINX setup.

   - **Yes**: The configuration tool attempts to enable the status module, set the status page location in a new vhost configuration file, and restart NGINX. This option is easier, but has the potential to disrupt your current NGINX configuration. If you choose yes, and the configuration is successful, you should see output similar to the following:

     ```text Output
     [ ok ] Stopping Longview Agent: longview.
     Checking Nginx configuration...
     Restarting nginx: nginx.
     Finished configuring nginx, writing new configuration to /etc/linode/longview.d/Nginx.conf
     [ ok ] Starting Longview Agent: longview.
     update-rc.d: using dependency based boot sequencing
     ```

     > > Note: 
     > 
     > The automatic configuration sets the status page location to `http://127.0.0.2/nginx_status`.

5. Refresh Longview in Cloud Manager to verify that the NGINX tab is now present and collecting data for your Longview client instance.

   If instead you received a failure message similar to the output example, double-check your NGINX installation and then perform a [manual configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#manual-configuration). You can also visit the [Troubleshooting](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#troubleshooting) section at the end of this guide.

   ```text Output
   [FAIL] Reloading web server config: nginx failed!
   ```

## [Manual configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#manual-configuration)

_These instructions work for all supported distributions, including Debian, Ubuntu, and CentOS._

To enable the NGINX Longview integration manually, follow these steps on your system via SSH:

1. [SSH into the Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode) you are monitoring with Longview.

2. Add the following lines to your NGINX configuration to enable the status module and set the location of the status page. The lines should be placed within your main configuration file's `http` block (`/etc/nginx/nginx.conf`) or in a separate [site configuration file](https://linode.com/docs/guides/getting-started-with-nginx-part-2-advanced-configuration/#host-multiple-websites).

   ```text /etc/nginx/nginx.conf
   server {
       listen 127.0.0.1:80;
       server_name 127.0.0.1;
       location /nginx_status {
           stub_status on;
           allow 127.0.0.1;
           deny all;
       }
   }
   ```

3. Restart NGINX:

   ```
   sudo systemctl restart nginx
   ```

4. Edit the Longview configuration file for NGINX (`/etc/linode/longview.d/Nginx.conf`) so that it includes the following line. If this line is commented out, you can uncomment it.

   ```text /etc/linode/longview.d/Nginx.conf
   location http://127.0.0.1/nginx_status
   ```

5. Restart Longview:

   ```
   sudo systemctl restart longview
   ```

6. Refresh Longview in Cloud Manager to verify that the NGINX tab is now present and collecting data for your Longview client instance.

You should now be able to see Longview data for NGINX. If that's not the case, proceed to the [Troubleshooting](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#troubleshooting) section at the end of this article.

# [View NGINX metrics](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#view-nginx-metrics)

1. Log in to [Cloud Manager](https://cloud.linode.com/) and select the **Longview** link in the sidebar.

2. Locate the Longview Client you have configured for NGINX and click the corresponding **View details** link.

3. Select the **NGINX** tab.

   

   You'll see the current version of NGINX listed on the upper left-hand side of the page.

   Mouse over a data point to see the exact numbers for that time. With [Longview Pro](https://techdocs.akamai.com/cloud-computing/docs/longview), you can view older time periods for your data. The next sections cover the Longview Nginx App in detail.

## [Requests](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#requests)

The **Requests** graph shows the total number of requests NGINX handled at the selected time. This is every HTTP and HTTPS request to your system.

## [Connections](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#connections)

The **Connections** graph shows the amount of data that NGINX accepted and handled via web requests at the time selected.

## [Workers](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#workers)

The **Workers** graph shows all of the NGINX workers at the selected time. The workers are broken down by state:

- Waiting
- Reading
- Writing

## [Cpu](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#cpu)

The **CPU** graph shows the percentage of your system's CPU being used by NGINX at the selected time. If you want to see the total CPU use instead, check the [Overview tab](https://techdocs.akamai.com/cloud-computing/docs/understanding-longview-metrics#overview).

## [Ram](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#ram)

The **RAM** graph shows the amount of RAM or memory being used by NGINX at the selected time. If you want to see your system's total memory use instead, check the [Overview tab](https://techdocs.akamai.com/cloud-computing/docs/understanding-longview-metrics#overview).

## [Disk io](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#disk-io)

The **Disk IO** graph shows the amount of input to and output from the disk caused by NGINX at the selected time. To see the total IO instead, visit the [Disks tab](https://techdocs.akamai.com/cloud-computing/docs/understanding-longview-metrics#disks).

## [Process count](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#process-count)

The **Process Count** graph shows the total number of processes on your system spawned by NGINX at the selected time. If you want to see more details, and how this stacks up against the total number of processes on your system, see the [Processes tab](https://techdocs.akamai.com/cloud-computing/docs/understanding-longview-metrics#processes).

# [Troubleshooting](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#troubleshooting)

If you don't see Longview data for Nginx, you'll instead get an error on the page and instructions on how to fix it. As a general tip, you can check the `/var/log/linode/longview.log` file for errors as well.

## [Unable to access server status page for NGINX](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#unable-to-access-server-status-page-for-nginx)

The error will state `Unable to access server status page (http://example.com/example) for Nginx: 
`. This error occurs when NGINX's status setting is disabled or has been changed from the default location.

 > Note: 
  This error occurs when Longview attempts to check the status page `location` listed in `/etc/linode/longview.d/Nginx.conf`, or the default page at `http://127.0.0.1/nginx_status`, but receives a non-200 HTTP response code. Basically, it means that the status page Longview is checking doesn't exist.

To fix this, follow these steps:

1. Make sure NGINX is running:

   ```
   sudo systemctl restart nginx
   ```

2. Check the status page location, and make sure it's available over Port 80. The default location Longview checks is `http://127.0.0.1/nginx_status` on localhost, but NGINX doesn't typically have a status page location set up by default. In the NGINX configuration file (typically `/etc/nginx/nginx.conf`) or in a [separate site configuration file](https://linode.com/docs/guides/getting-started-with-nginx-part-2-advanced-configuration/#host-multiple-websites), this is designated with the lines in the example file below. If your configuration file does not contain these lines, add them to the file within the `http` block. For more details, see the [Manual Configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#manual-configuration) section of this guide.

   ```text /etc/nginx/nginx.conf
   server {
       listen 127.0.0.1:80;
       server_name 127.0.0.1;
       location /nginx_status {
           stub_status on;
           allow 127.0.0.1;
           deny all;
       }
   }
   ```

3. Longview is designed to check the default location automatically. If you use the default location shown above, you should be done. Refresh Longview in Cloud Manager to verify that the NGINX tab is now present and collecting data for your Longview client instance.

4. If you're not using the default location, you need to create a new file, `/etc/linode/longview.d/Nginx.conf`, and set the `location` variable to match what you set in the NGINX configuration file:

   ```text /etc/linode/longview.d/Nginx.conf
   location http://127.0.0.1/url-goes-here
   ```

5. Restart Longview:

   ```
   sudo systemctl restart longview
   ```

6. Refresh Longview in Cloud Manager to verify that the NGINX tab is now present and collecting data for your Longview client instance.

 > Note: 
  If you originally compiled NGINX without the status module, you will need to recompile it with `--with-http_stub_status_module` and all your other settings. Then go back and try to enable the Longview Nginx App.

## [The NGINX status page doesn't look right](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#the-nginx-status-page-doesnt-look-right)

The error will state `The Nginx status page doesn't look right. Check 
 and investigate any redirects for misconfiguration.` This error occurs when Longview is able to reach the status page, but doesn't receive the expected content.

 > Note: 
  This error occurs when Longview attempts to check the status page, and receives a 200 HTTP response code, but can't scrape the expected status content from the page. That is, the page exists on your system, but it doesn't have the right content. If, for example, Longview was to check your website's home page, you would get this error.

To resolve this issue, follow these steps:

1. Visit the URL shown in the error. See if it directs or redirects you to a page that isn't the NGINX status page.

2. Update your NGINX and Longview settings so that they specify the same status page location:

   - The **server_name** and **location** lines in your NGINX configuration file. See the [Manual Configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#manual-configuration) section for more details.
   - The **location** line in `/etc/linode/longview.d/Nginx.conf`

   If the location line isn't set in `/etc/linode/longview.d/Nginx.conf`, Longview will check the default location of `http://127.0.0.1/nginx_status` on localhost.

3. Make sure there aren't any NGINX redirects or other settings that are affecting this page.

4. Restart Longview:

   ```
   sudo systemctl restart longview
   ```

5. Refresh Longview in Cloud Manager to verify that the NGINX tab is now present and collecting data for your Longview client instance.

## [NGINX tab is missing](https://techdocs.akamai.com/cloud-computing/docs/capture-nginx-metrics-with-linode-longview#nginx-tab-is-missing)

If the Longview Nginx tab is missing entirely, this indicates that NGINX is either not installed, or has stopped. If you restart NGINX, you will be able to see the tab again and view all of your old data.