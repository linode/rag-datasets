# [Capture Apache metrics with Longview](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#capture-apache-metrics-with-longview)

In addition to capturing general system metrics, Longview can also be used to capture metrics for Apache. The Apache tab appears in Cloud Manager when Longview detects that you have Apache installed on your system. It can help you keep track of Apache's settings, workers and requests, system resource consumption, and other information.

 > Note: 
  In order to use Longview to capture data for Apache, you must have the Longview Agent successfully installed on the system you wish to monitor. See [Create a Longview Client and Install the Longview Agent](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview).

# [In this guide:](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#in-this-guide)

This guide covers using Longview with Apache and includes the following topics:

- [Configuring Longview for Apache](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#configure-longview-for-apache).
- [Interacting with the Apache data provided by Longview in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#view-apache-metrics).
- [Troubleshooting Longview for Apache](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#troubleshooting).

# [Configure Longview for Apache](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#configure-longview-for-apache)

## [Automatic configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#automatic-configuration)

_These instructions are compatible only with Debian and Ubuntu and do not work on CentOS._

If Apache is installed and running when you install the Longview agent, Longview should automatically configure itself for Apache. If you install Apache _after_ setting up the Longview agent, you can perform the steps below to configure Longview with any available software integrations (Apache, NGINX, and MySQL). Any existing Longview data is not affected and will remain accessible.

1. [SSH into the Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-instance) you are monitoring with Longview.

2. Ensure that Apache is running.

   ```
   sudo systemctl status apache2
   ```

3. Run the automatic Longview configuration command.

   ```
   dpkg-reconfigure -phigh linode-longview
   ```

   For most systems, Longview should be able to configure itself automatically. If this is the case, your output should be similar to the following:

   ```text Output
   Checking Apache configuration...
   Found Apache status page at http://127.0.0.1/server-status?auto specified in /etc/linode/longview.d/Apache.conf
   ```

   Once you see this successful message, the Longview should automatically start collecting Apache data. Refresh Longview in Cloud Manager to start viewing your Apache stats for your Longview Client instance.

   If you receive a failure message or the popup shown below, you should visit the [Troubleshooting](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#troubleshooting) section at the end of this article.

   

## [Manual configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#manual-configuration)

_These instructions work for all supported distributions, including Debian, Ubuntu, and CentOS._

To enable the Apache Longview integration manually, follow these steps on your system via SSH:

1. [SSH into the Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-instance) you are monitoring with Longview.

2. Verify that **mod\_status** is enabled for Apache (it should be by default). For more information, see the [Apache Module mod\_status](https://httpd.apache.org/docs/2.4/mod/mod_status.html) documentation.

   - **Debian and Ubuntu:**

     ```
     sudo a2enmod status
     ```

   - **CentOS:**

     ```
     sudo yum install links
     httpd -M | grep status
     ```

     The output should be similar to:

     ```text Output
     status_module (shared)
     ```

3. Update your Apache configuration file to include the block in the example file below. Depending on your Linux distribution and version, your Apache configuration file may be stored in one of the following locations:

   - `/etc/apache2/httpd.conf`
   - `/etc/apache2/apache2.conf`
   - `/etc/httpd/httpd.conf`
   - `/etc/httpd/conf/httpd.conf`

   ```apache httpd.conf or apache2.conf
   

       ExtendedStatus On
       

           SetHandler server-status
           Require local
       

   

   ```

4. Edit the Longview configuration file for Apache (`/etc/linode/longview.d/Apache.conf`) so that it includes the following line. If this line is commented out, you can uncomment it.

   ```apache /etc/linode/longview.d/Apache.conf
   location http://127.0.0.1/server-status?auto

   ```

5. Restart Apache:

   - **Debian and Ubuntu:**

     ```
     sudo systemctl restart apache2
     ```

   - **CentOS:**

     ```
     sudo systemctl restart httpd
     ```

6. Restart Longview:

   ```
   sudo systemctl restart longview
   ```

7. Refresh the Longview in your Cloud Manager.

You should now be able to see Longview data for Apache. If that's not the case, proceed to the [Troubleshooting](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#troubleshooting) section at the end of this article.

# [View Apache metrics](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#view-apache-metrics)

1. Log in to [Cloud Manager](https://cloud.linode.com/) and select the **Longview** link in the sidebar.

2. Locate the Longview Client you have configured for Apache and click the corresponding **View details** link.

3. Select the **Apache** tab.

   

   You'll see the current version of Apache listed on the upper left hand side of the page.

   Hover over a data point to see the exact numbers for that time. With [Longview Pro](https://techdocs.akamai.com/cloud-computing/docs/longview), you can view older time periods for your data. The next sections cover the Longview Apache App in detail.

## [Requests](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#requests)

The **Requests** graph shows the total number of requests Apache handled at the selected time. This is every HTTP and HTTPS request to your system.

## [Throughput](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#throughput)

The **Throughput** graph shows the amount of data that Apache sent and received via web requests at the time selected.

## [Workers](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#workers)

The **Workers** graph shows all of the Apache workers at the selected time. The workers are broken down by state:

- Waiting
- Starting
- Reading
- Sending
- Keepalive
- DNS Lookup
- Closing
- Logging
- Finishing
- Cleanup

## [Cpu](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#cpu)

The **CPU** graph shows the percentage of your system's CPU being used by Apache at the selected time. If you want to see the total CPU used instead, check the [Overview tab](https://techdocs.akamai.com/cloud-computing/docs/understanding-longview-metrics#overview).

## [Memory](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#memory)

The **Memory** graph shows the amount of RAM being used by Apache at the selected time. If you want to see your system's total memory use instead, check the [Overview tab](https://techdocs.akamai.com/cloud-computing/docs/understanding-longview-metrics#overview).

## [Disk io](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#disk-io)

The **Disk IO** graph shows the amount of input to and output from the disk caused by Apache at the selected time. To see the total IO instead, visit the [Disks tab](https://techdocs.akamai.com/cloud-computing/docs/understanding-longview-metrics#disks).

## [Process count](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#process-count)

The **Process Count** graph shows the total number of processes on your system spawned by Apache at the selected time. If you want to see more details, and how this stacks up against the total number of processes on your system, see the [Processes tab](https://techdocs.akamai.com/cloud-computing/docs/understanding-longview-metrics#processes).

# [Troubleshooting](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#troubleshooting)

If you don't see Longview data for Apache, you'll instead get an error on the page and instructions on how to fix it. As a general tip, you can check the `/var/log/linode/longview.log` file for errors as well. You should also compare your mod\_status configuration file to the example shown in Step 2 of the [Manual Configuration (All Distributions)](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#manual-configuration) section of this article.

By default Longview uses port 80 for its automatic configuration. In the event you are experiencing problems you may need to edit the `/etc/apache2/ports.conf` file to use port 8080 or another non-standard port.

## [Autoconfigure mod\_status popup](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#autoconfigure-modstatus-popup)

If you run the [automatic Longview configuration tool](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#configure-longview-for-apache), and get the popup message shown below:

This indicates that Longview can't locate the Apache status page. In turn, this could indicate that either:

- The status page is in an unusual and unspecified location.
- **mod\_status** isn't enabled.
- An Apache virtual host setting is interfering with requests to the status page.
- Apache itself is misconfigured.

If you choose:

- **\
**: the Longview tool will quit, and you can do a [manual configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#manual-configuration). This is the safer option.
- **\
**: the Longview tool will attempt to enable mod\_status, set the status page location, and restart Apache. This option is easier, but has the potential to disrupt your current Apache configuration. If you choose yes, and the configuration is successful, you should see output like the following:

  ```text Output
  [ ok ] Stopping Longview Agent: longview.
  Checking Apache configuration...
  Enabling module status.
  To activate the new configuration, you need to run:
    service apache2 restart
  [....] Reloading web server config: . ok
  Apache mod_status enabled
  [ ok ] Starting Longview Agent: longview.
  update-rc.d: using dependency based boot sequencing
  ```

  Refresh the Longview Apache tab in Cloud Manager to verify that it's working now.

  If instead you receive a failure message, such as:

  ```text Output
  [FAIL] Reloading web server config: apache2 failed!
  ```

  You will need to double-check your Apache installation, and then do a [manual configuration](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#manual-configuration).

## [Unable to access local server status for apache](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#unable-to-access-local-server-status-for-apache)

This error will state `Unable to access local server status for Apache at 
: 
:`. This error occurs when either:

- Apache's mod\_status setting is disabled or has been changed from the default location.

- An Apache virtual host configuration is interfering with web requests to the mod\_status location.

  > > Note: 
  > 
  > This error occurs when Longview attempts to check the status page `location` listed in `/etc/linode/longview.d/Apache.conf`, or the default page at `127.0.0.1/server-status?auto`, but receives a non-200 HTTP response code. Basically, it means that the status page Longview is expecting is not being returned by the server.

To fix this, follow these steps:

1. Make sure Apache is running:

   ```
   sudo systemctl restart apache2
   ```

2. Make sure mod\_status is enabled. See the [Apache website](https://httpd.apache.org/docs/2.4/mod/mod_status.html#page-header) for details. You can also check the output of the following command:

   ```
   apachectl -M
   ```

3. Check the location for mod\_status. The default location on Debian and Ubuntu systems is `http://127.0.0.1/server-status?auto` on localhost. In the Apache configuration file, this is designated with the lines:

   ```apache httpd.conf or apache2.conf
   

       SetHandler server-status
   ```

   The `SetHandler server-status` line indicates that this is the location block for mod\_status. The location line itself sets the location.

   **On cPanel/WHM:**

   To direct Longview to the cPanel customized status page, edit the `location` line in `/etc/linode/longview.d/Apache.conf` to match the following:

   ```apache /etc/linode/longview.d/Apache.conf
   location http://localhost/whm-server-status?auto
   ```

4. Longview is designed to check the default location automatically. If you use the default location shown above, you should be done. Refresh the Longview in Cloud Manager to verify that it's working now.

5. If you're not using the default location, you need to create a new file, `/etc/linode/longview.d/Apache.conf`, and set the `location` variable to match what you set in the Apache configuration file:

   ```apache /etc/linode/longview.d/Apache.conf
   location http://127.0.0.1/custom/location/path
   ``

   ```

6. Determine if an Apache virtual host configuration is interfering with requests to the mod\_status location. Use a tool like `curl` or `wget` to request the server status location:

   ```
   curl http://127.0.0.1/server-status?auto
   ```

   Observe the output. If the output looks like something other than a simple status page, then you'll have to fix your [Apache virtual host](https://linode.com/docs/web-servers/apache-tips-and-tricks/) configuration.

7. Restart Longview:

   ```
   sudo service longview restart
   ```

8. Refresh the Longview in Cloud Manager to verify that it's working now.

## [The Apache status page doesn't look right](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#the-apache-status-page-doesnt-look-right)

This error states `The Apache status page doesn't look right. Check 
 and investigate any redirects for misconfiguration.` This error occurs when Longview is able to reach the mod\_status page, but doesn't receive the expected content.

 > Note: 
  This error occurs when Longview attempts to check the status page, and receives a 200 HTTP response code, but can't scrape the expected status content from the page. That is, the page exists on your system, but it doesn't have the right content. If, for example, Longview was to check your website's home page, you would get this error.

To resolve this issue, follow these steps:

1. Visit the URL shown in the error. See if it directs or redirects you to a page that isn't the Apache status page.

2. Update your Apache and Longview settings so that they specify the same location:

   - The **\
** line in your Apache configuration file
   - The **location** line in `/etc/linode/longview.d/Apache.conf`

   If neither of these is set, the default location of `http://127.0.0.1/server-status?auto` on localhost will be used.

3. Make sure there aren't any Apache redirects or other settings that are affecting this page.

4. Restart Longview:

   ```
   sudo systemctl restart longview
   ```

5. Refresh the Longview in Cloud Manager to verify that it's working now.

## [Missing graphs: enable extendedstatus](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#missing-graphs-enable-extendedstatus)

If some of your Apache graphs are missing, you may see the error `Enable ExtendedStatus in your Apache configuration for throughput and request graphs.`

This indicates that you need to add the following line to your Apache configuration file in the `
` section:

```apache httpd.conf
ExtendedStatus On
```

When you've finished modifying the configuration file, restart Apache:

- **Debian and Ubuntu:**

  ```
  sudo systemctl restart apache2
  ```

- **CentOS:**

  ```
  sudo systemctl restart httpd
  ```

## [Apache tab is missing](https://techdocs.akamai.com/cloud-computing/docs/capture-apache-metrics-with-linode-longview#apache-tab-is-missing)

If the Longview Apache tab is missing entirely, this indicates that Apache is either not installed, or has stopped. If you restart Apache, you will be able to see the tab again and view all of your old data.