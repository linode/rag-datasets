# [Create a StackScript](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#create-a-stackscript)

This guide walks you through creating a StackScript through Cloud Manager.

1. [Open the Create StackScript Form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#open-the-create-stackscript-form-in-cloud-manager)
2. [Set the Label](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#set-the-label)
3. [Add a Description](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#add-a-description)
4. [Select Compatible Distribution Images](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#select-compatible-distribution-images)
5. [Create the Custom Script](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#create-the-custom-script)
6. [Enter a Revision Note](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#enter-a-revision-note)
7. [Save the StackScript](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#save-the-stackscript)

# [Open the create StackScript form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#open-the-create-stackscript-form-in-cloud-manager)

Log in to [Cloud Manager](https://cloud.linode.com/) and select **StackScripts** from the left navigation menu. Click the **Create StackScript** button. This opens the _[StackScript Create](https://cloud.linode.com/stackscripts/create)_ form.

# [Set the label](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#set-the-label)

Within the **Label** field, enter the label you wish to use identify this StackScript. A good label should provide some indication as to what the StackScript will be used to deploy. The label must be alphanumeric, between 3 and 128 characters, and unique from other StackScript labels on your account.

# [Add a description](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#add-a-description)

Enter a brief overview of your StackScript in the **Description** field, outlining what it does and any software it might be installing or configuring. If you intend on sharing this StackScript with other users on your account or making this StackScript public, this description should be sufficient to help others understand the purpose of the StackScript.

# [Select compatible distribution images](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#select-compatible-distribution-images)

Within the **Target Images** field, select each distribution image that is compatible with your StackScript. When deploying a Compute Image based on this StackScript, the available images are limited to whichever images are selected here. At least one image must be selected, though you can add multiple images if you wish to provide an option during deployment. See [Choose a Linux Distribution](https://techdocs.akamai.com/cloud-computing/docs/choose-a-distribution) to learn more about the supported distributions.

# [Create the custom script](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#create-the-custom-script)

Paste (or type) your custom script in the **Script** field. This is the script that the StackScript calls when deploying a Linode. The interpreter needed to execute your script must exist in the distribution images that were previously selected. The first line of the script must include a shebang followed by the path to the interpreter you wish to use.

- **Bash:** `#!/bin/bash`
- **Python:** `#!/usr/bin/env python`
- **Python 3:** `#!/usr/bin/python3`

For more details on the components of a StackScript, see [Write a Custom Script for Use with StackScripts](https://techdocs.akamai.com/cloud-computing/docs/write-a-custom-script-for-use-with-stackscripts) guide.

# [Enter a revision note](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#enter-a-revision-note)

Each time you make a change to a StackScript (including creating it), you can set a **Revision Note** to indicate what changes were made.

# [Save the StackScript](https://techdocs.akamai.com/cloud-computing/docs/create-a-stackscript#save-the-stackscript)

Once you are finished filling out all required fields, click the **Create StackScript** button to create the StackScript. After it has been created, you can edit all of the fields as needed. See [Edit a StackScript](https://techdocs.akamai.com/cloud-computing/docs/manage-stackscripts#edit-a-stackscript).

 > Note: 
  To deploy a new Linode with your StackScript, follow the steps in the [Deploying a New Linode Using a StackScript](https://techdocs.akamai.com/cloud-computing/docs/deploy-a-compute-instance-using-a-stackscript) guide.