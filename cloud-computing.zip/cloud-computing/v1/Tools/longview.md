# [Longview](https://techdocs.akamai.com/cloud-computing/docs/longview#longview)

Longview is a system data graphing service. It tracks metrics for CPU, memory, and network bandwidth on both an aggregate and per-process basis. It also provides real-time graphs that can help expose performance problems.

# [Platform-agnostic](https://techdocs.akamai.com/cloud-computing/docs/longview#platform-agnostic)

The Longview client is [open source](https://github.com/linode/longview) and provides an agent that can be installed on any Linux distribution – including systems not hosted on Akamai Cloud.

# [Pro plan](https://techdocs.akamai.com/cloud-computing/docs/longview#pro-plan)

Longview is free for all customers for up to ten clients. You also have the option to purchase **Longview Pro** which includes additional analytics for an added cost. Longview's free version updates every 5 minutes and provides 12 hours of data history. Longview Pro gives you data resolution at 60 second intervals, and you can view a complete history of your Linode's data instead of only the previous 12 hours.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/longview#availability)

Longview can be installed on Linodes across [all core compute regions](https://www.linode.com/global-infrastructure/), but is not supported in distributed compute regions.

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/longview#pricing)

There are four different Longview Pro plan tiers you can choose from. Each plan varies in the amount of clients that can be monitored by Longview.

| Plan                  | Number of Clients | Price              |
| --------------------- | ----------------- | ------------------ |
| Longview Free         | 10                | Free               |
| Longview Pro 3 Pack   | 3                 | $20/mo ($0.03/hr)  |
| Longview Pro 10 Pack  | 10                | $40/mo ($0.06/hr)  |
| Longview Pro 40 Pack  | 40                | $100/mo ($0.15/hr) |
| Longview Pro 100 Pack | 100               | $200/mo ($0.30/hr) |

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/longview#technical-specifications)

- Compatible with most Linux systems, even those not offered on Akamai Cloud. Official support for **CentOS**, **Debian**, and **Ubuntu**.
- **Data retention:** Unlimited for Longview Pro, 12 hours for Longview Free.
- **Data resolution:** 1 minute for Longview Pro, 5 minutes for Longview Free.

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/longview#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of services on Akamai Cloud.
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line.