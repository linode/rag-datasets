# [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#cloud-manager)

Cloud Manager is an intuitive web-based interface for managing your account and services. Through Cloud Manager, you can deploy and manage virtual machines, configure networking, control user accounts, and access the full range of Akamai's cloud computing services.

# [Features](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#features)

## [Self-service data center migration](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#self-service-data-center-migration)

Cloud Manager supports you with self-serve migrations so you can conveniently move your infrastructure between data centers.

## [Simple account management](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#simple-account-management)

Effortlessly create and configure your infrastructure with Cloud Manager. Assign SSH keys, deploy resources across the network, and add cloud storage volumes or buckets all from a single UI.

Advanced search helps you quickly find your Akamai Cloud resources. Search using simple strings, Boolean operators, parenthesis, or custom groups with tags you create in Cloud Manager.

Manage your account, update payment information, review credits remaining, and print invoices.

## [Deploy marketplace apps](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#deploy-marketplace-apps)

Whether you want to set up a game server, your own VPN, or self-host your software with GitLab, Marketplace Apps make it quick and easy to get up and running on your Linodes.

## [Performance monitoring](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#performance-monitoring)

Real-time analytics tracking, per-process and in aggregate, monitors the performance of your CPU, memory, and network bandwidth.

## [User control and security](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#user-control-and-security)

Share access to your Linodes with your team by adding multiple users. Controls are configurable for each individual user. Manage your API Keys and add personal access tokens for more control over your services.

# [Release notes](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#release-notes)

Release notes for Cloud Manager are located on Cloud Manager's public GitHub repository. See the [Releases](https://github.com/linode/manager/releases) page on the [linode/manager](https://github.com/linode/manager/) repository.