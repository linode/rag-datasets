# [Overview of Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#overview-of-cloud-manager)

[Cloud Manager](https://cloud.linode.com/) provides a user-friendly interface to manage your infrastructure, user accounts, billing and payments, and to open and track support tickets. You can easily create Linodes, manage Kubernetes clusters, add backups to your Linode, deploy Marketplace Apps, track event notifications, create Object Storage buckets, and more. Cloud Manager is implemented solely atop our public [API](https://techdocs.akamai.com/linode-api/reference/api), which gives you access to all our latest products and services.

# [In this guide](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#in-this-guide)

This guide provides an overview of the features and services available in Cloud Manager. Some of the topics that will be discussed are:

- An introduction to each section of Cloud Manager, including links to related guides throughout our documentation library.
- The location of commonly used Cloud Manager features.
- Settings that might make your overall Cloud Manager experience better

# [Linodes](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#linodes)

The Linodes section of Cloud Manager lets you create and manage your Linodes. Each Linode in Cloud Manager includes:

- [Summary information](https://techdocs.akamai.com/cloud-computing/docs/monitor-and-maintain-a-compute-instance#cloud-manager) about your Linode, like CPU usage, IPv4 and [IPv6 traffic](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode), and Disk IO
- Access to any of your Linode's attached Volumes and the ability to [create a Volume](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes)
- Networking information and features, including the ability to add IPv4 and IPv6 addresses, [IP transfer](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#transferring-ip-addresses) and [IP sharing](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuring-ip-sharing)
- The ability to [resize your Linode](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance), boot your Linode into [Rescue Mode](https://techdocs.akamai.com/cloud-computing/docs/rescue-and-rebuild#rescue-mode-overview), and [rebuild your Linode](https://techdocs.akamai.com/cloud-computing/docs/rescue-and-rebuild#rebuilding)
- Access to the [Backups service](https://techdocs.akamai.com/cloud-computing/docs/backup-service)
- An [Activity Feed](https://techdocs.akamai.com/cloud-computing/docs/what-are-cloud-manager-events-and-activity-feeds#viewing-a-linodes-activity-feed) that displays any relevant events related to this Linode
- Settings that allow you to update your Linode's label, [reset your Linode's root password](https://techdocs.akamai.com/cloud-computing/docs/reset-the-root-password-on-a-compute-instance), [manage system usage email notifications](https://techdocs.akamai.com/cloud-computing/docs/monitor-and-maintain-a-compute-instance#configure-cloud-manager-email-alerts), [manage Watchdog](https://techdocs.akamai.com/cloud-computing/docs/recover-from-unexpected-shutdowns-with-lassie) (Akamai Cloud's automatic reboot feature), and delete your Linode.
- Areas to [manage disks](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance) and [manage configuration profiles](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance)
- [Cross data center migrations](https://techdocs.akamai.com/cloud-computing/docs/migrate-to-a-new-data-center)

# [Volumes](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#volumes)

The **Volumes** section of Cloud Manager gives you access to the [Block Storage](https://www.linode.com/products/block-storage/) service. To learn how to create and manage Block Storage volumes using Cloud Manager, see our [Block Storage Overview](https://techdocs.akamai.com/cloud-computing/docs/block-storage) guide.

# [Object storage](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#object-storage)

The **Object Storage** section of Cloud Manager gives you access to the [Object Storage service](https://www.linode.com/products/object-storage/) which is a globally-available, Amazon S3-compatible method for storing and accessing data.

To learn how to use Object Storage, view the [Get Started with Object Storage](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-object-storage) guide or take a look through all the [Object Storage guides](https://techdocs.akamai.com/cloud-computing/docs/object-storage).

# [NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#nodebalancers)

[NodeBalancers](https://www.linode.com/products/nodebalancers/) provides load balancing for your applications and services ensuring that they are highly available for users. To learn how to get started with NodeBalancers using Cloud Manager, see our [Getting Started with NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-nodebalancers) guide.

# [Domains (DNS Manager)](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#domains-dns-manager)

The DNS Manager lets you control and manage your domains. You can access the DNS Manager by navigating to the **Domains** link in Cloud Manager's sidebar.

For more information on Cloud Manager's DNS Manager, see the following guides:

- [DNS Manager](https://techdocs.akamai.com/cloud-computing/docs/dns-manager).
- [Common DNS Configurations](https://techdocs.akamai.com/cloud-computing/docs/common-dns-configurations)
- [Configure rDNS (reverse DNS) on a  Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-rdns-reverse-dns-on-a-compute-instance)

# [Longview](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#longview)

The **Longview** section of Cloud Manager gives you access to the system data graphing service. It tracks metrics for CPU, memory, and network bandwidth, both aggregate and per-process, and it provides real-time graphs that can help expose performance problems. The Longview service offers both [free and paid plan tiers](https://techdocs.akamai.com/cloud-computing/docs/longview).

To get started using Longview, see [Get started with Longview](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview).

# [Marketplace](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#marketplace)

The **Marketplace** section of Cloud Manager gives you access to apps that make it easy to deploy and configure Marketplace Apps on a Linode. Some popular Marketplace Apps are [WordPress](https://www.linode.com/docs/marketplace-docs/guides/wordpress), [Minecraft](https://www.linode.com/docs/marketplace-docs/guides/minecraft), and [GitLab](https://www.linode.com/docs/products/tools/marketplace/guides/gitlab/). We are actively adding new and useful Marketplace apps. When a Marketplace App is deployed, a new Linode is created and the appropriate software is installed with the configurations you provide.

See [Get started](https://www.linode.com/docs/marketplace-docs/get-started/) to learn how to use Marketplace Apps in Cloud Manager.

# [Kubernetes (Linode Kubernetes Engine)](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#kubernetes-linode-kubernetes-engine)

The Kubernetes section of Cloud Manager gives you access to our managed Kubernetes service, the Linode Kubernetes Engine (LKE). LKE is a fully-managed container orchestration engine for deploying and managing containerized applications and workloads. LKE combines Akamai Cloud’s ease of use and [simple pricing](https://www.linode.com/pricing/) with the infrastructure efficiency of Kubernetes.

To get started using LKE, see our [Tutorial for Deploying and Managing a Cluster with Linode Kubernetes Engine](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine).

# [StackScripts](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#stackscripts)

[StackScripts](https://www.linode.com/stackscripts/) provide users with the ability to automate the deployment of custom systems on top of our default Linux distribution images. StackScripts are usually Bash scripts, stored in Cloud Manager, and can be accessed when you deploy a Linode. Linodes deployed with a StackScript run the script as part of the first boot process.

To get started using StackScripts in Cloud Manager, see the [Automate Deployment with StackScripts](https://techdocs.akamai.com/cloud-computing/docs/stackscripts) guide.

# [Images](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#images)

The Images section of Cloud Manager gives you access to Images, which allows you to take snapshots of your disks, and then deploy them to any Linode under your account. This can be useful for bootstrapping an image for a large deployment, or retaining a disk for a configuration that you may not need running, but wish to return to in the future.

To get started using Images with Cloud Manager, see [Images](https://techdocs.akamai.com/cloud-computing/docs/images).

# [Administration (management and billing)](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#administration-management-and-billing)

The **Administration** section of Cloud Manager lets you manage your account's billing information and users, and to configure various account-wide settings.

You can manage the following account and billing settings in the Administration section of Cloud Manager:

- [Update contact information](https://techdocs.akamai.com/cloud-computing/docs/update-billing-contact-information)
- [Adding a New Payment Method](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods#add-a-new-payment-method)
- [Making a One-Time Payment](https://techdocs.akamai.com/cloud-computing/docs/make-a-payment)
- [View recent invoices and payments](https://techdocs.akamai.com/cloud-computing/docs/view-invoices-and-payment-history)
- [Add new users and manage exiting user's profiles and permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions)
- [Enable Backup auto enrollment for all new Linodes on your account](https://techdocs.akamai.com/cloud-computing/docs/enable-backups#auto-enroll-new-compute-instance-in-the-backups-service)
- [Enable Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#global-account-wide-setting)
- [Cancel Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cancel-object-storage)
- [Add Managed Services to your account](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-managed-service)

## [Password management](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#password-management)

Cloud Manager does not support forcing password expirations. Forcing password resets on a schedule is [bad practice from a security perspective](https://pages.nist.gov/800-63-FAQ/#q-b05). Current security research indicates that forced password changes do more harm than good. If you want to force password resets for users of your account, we recommend using a password manager for this purpose.

# [Tags](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#tags)

Both Cloud Manager and [API v4](https://techdocs.akamai.com/linode-api/reference/api) allow you to create tags to help organize and group your Akamai Cloud resources. Tags can be applied to [Linodes](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#linodes), [Block Storage volumes](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#volumes), [NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#nodebalancers), and [Domains](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#domains-dns-manager). See the [Tags and Groups](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups) guide to learn how to create, apply, and search for tags.

# [Events and activity feeds](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#events-and-activity-feeds)

Tasks performed using Cloud Manager or other account specific tools like the Linode [CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli) or Linode [API](https://www.linode.com/products/api/) will be logged to an individual Linode's activity feed, or on your account’s [Events Page](https://cloud.linode.com/events). The events and activity pages are user accessible logs, or histories of events taking place on your account. They contain details regarding the most notable events affecting your Linodes, like reboots, shutdowns, migrations, and more.

For more details, see the [Understanding Events and Activity Feeds](https://techdocs.akamai.com/cloud-computing/docs/what-are-cloud-manager-events-and-activity-feeds) guide.

# [My profile](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#my-profile)

The **My Profile** section of Cloud Manager provides access to various settings related to your account's profile. This area of Cloud Manager contains access to the following features and settings:

- [Changing your account's associated email address](https://techdocs.akamai.com/cloud-computing/docs/change-your-email-address)
- [Resetting your Account password](https://techdocs.akamai.com/cloud-computing/docs/reset-your-user-password)
- [Enabling two-factor authentication](https://techdocs.akamai.com/cloud-computing/docs/security-controls-for-user-accounts#2fa-two-factor-authentication)
- [Enabling Third Party Authentication (TPA)](https://linode.com/docs/guides/third-party-authentication/)
- Managing trusted devices
- [Adding and managing public SSH keys](https://techdocs.akamai.com/cloud-computing/docs/manage-ssh-keys)
- [Managing LISH authentication methods](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#add-your-public-key)
- [Adding and managing personal and third party API v4 access tokens](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens)
- [Creating and managing OAuth Apps](https://linode.com/docs/guides/create-an-oauth-app-with-the-python-api-library/#obtaining-a-client-id-and-a-client-secret)
- [Akamai Cloud Referral Program](https://techdocs.akamai.com/cloud-computing/docs/referral-program)
- Enable email alerts for account activity

## [Oauth apps](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#oauth-apps)

Cloud Manager supports the OAuth 2 authorization protocol. OAuth 2 allows a user to safely grant a third-party app permission to act on their behalf. This means that a user could authorize an app to access data and / or make changes to their Akamai Cloud account and services that are exposed by the Linode API. For example, an app could create or destroy Linodes, manage a NodeBalancer, or alter a domain.

To learn how to get started with OAuth Apps see the [How To Create an OAuth App with the Linode Python API Library](https://linode.com/docs/guides/create-an-oauth-app-with-the-python-api-library/) guide. For details on the Linode API v4's OAuth workflow see the [Linode API v4 documentation](https://techdocs.akamai.com/linode-api/reference/get-clients).

## [Manage email event notifications](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#manage-email-event-notifications)

To learn more about events and how to enable or disable email notifications for these events, see the [Understanding Events and the Activity Feed](https://techdocs.akamai.com/cloud-computing/docs/what-are-cloud-manager-events-and-activity-feeds) guide.

## [Change the theme (dark mode)](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#change-the-theme-dark-mode)

Cloud Manager provides a way to set your preferred UI theme, including a light theme, dark theme, and the system theme.

1. Navigate to your profile by clicking on your username and select **My Settings**.

2. Within the **Theme** section, select your preferred theme from the available options: _Light_, _Dark_, or _System_. Once a selection is made, Cloud Manager's interface immediately switches to that theme.

## [Set the timezone](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#set-the-timezone)

All events displayed in Cloud Manager are shown using your user's timezone setting. The timezone can be modified in your display settings.

1. Navigate to your profile by clicking on your username and select **Display**.

2. In the **Timezone** field, select your preferred timezone from the menu.

3. Click the **Update Timezone** button to save your settings.

# [Accessibility](https://techdocs.akamai.com/cloud-computing/docs/overview-of-cloud-manager#accessibility)

Cloud Manager has been built with accessibility in mind. Currently, Cloud Manager is actively being developed to achieve [WCAG 2.0 Level AA](https://www.w3.org/TR/WCAG20/).

We have received much helpful feedback from our users regarding accessibility. While we have addressed a lot of your feedback, this is still a work in progress and will be iterated upon with time. If you have comments or requests regarding accessibility, let us know by filling out our [feedback form](https://www.linode.com/feedback/).