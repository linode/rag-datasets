# [Tags and groups](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tags-and-groups)

Both [Cloud Manager](https://cloud.linode.com) and the [Linode API](https://developers.linode.com) let you to create tags to help organize and group your Akamai Cloud resources. Tags can be applied to Linodes, [Block Storage volumes](https://techdocs.akamai.com/cloud-computing/docs/block-storage), [NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-nodebalancers), and [Domains](https://techdocs.akamai.com/cloud-computing/docs/dns-manager).

This guide demonstrates how to perform the following actions with Cloud Manager:

- Create and apply tags to your Akamai Cloud resources
- Search and group your Linode resources by tag
- Import tags from the Classic Manager

# [Tagging a Linode](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tagging-a-linode)

## [Tag a Linode at creation](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tag-a-linode-at-creation)

To tag a Linode at the time of its creation:

1. In the **Linodes/ Create** form, click the dropdown menu labeled **Add Tags** located below the **Linode Label** field.

2. Select one or more tags from the menu. To create a new tag, type in the desired tag name and click the **Create "new-tag-example"** option that appears:

   ![A screenshot of the Details section showing the text entry box within the Add Tags field.](https://techdocs.akamai.com/linode/tools/img/cloud-manager-tags-new-linode-v1.jpg)

3. Your tag will be applied when you finish creating the Linode.

## [Tag an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tag-an-existing-linode)

To tag an existing Linode:

1. Navigate to the Linode's detail page.

2. Click the **Add A Tag +** button.

  

3. Select one or more tags from the dropdown menu that appears. To create a new tag, type in the desired tag name and click the **Create "new-tag"** option that appears.

## [Remove a tag from a Linode](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#remove-a-tag-from-a-linode)

To remove a tag from a Linode:

1. Navigate to the Linode's detail page.

2. Click on the **Summary** tab.

3. Locate the **Tags** box. A list of your tags for the Linode will be displayed.

4. Click on the **X** icon attached to the tag you would like to remove from your Linode.

# [Tagging a volume](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tagging-a-volume)

## [Tag a volume at creation](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tag-a-volume-at-creation)

To tag a Volume at the time of its creation:

1. In the **Volumes/Create** form, click the dropdown menu labeled **Tags**.

2. Select one or more tags from the menu. To create a new tag, type in the desired tag name and click the **Create "new-tag"** option that appears.

   

3. Once you are done configuring the Volume, click **Create Volume**.

## [Tag an existing volume](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tag-an-existing-volume)

To tag an existing Volume:

1. Navigate to the Volumes page of Cloud Manager.

2. Select the more options **ellipsis (...)** corresponding to the Volume you would like to tag.

3. Select **Manage Tags** from the menu that appears.

4. The **Manage Volume Tags** form will appear. Click on the dropdown menu labeled **Tags**.

5. Select one or more tags from the form. To create a new tag, type in the desired tag name and click the **Create "new-tag"** option that appears.

6. When you are done, click **Save Changes**:

   ![A screenshot of the Manage Volume Tags form.](https://techdocs.akamai.com/linode/tools/img/cloud-manager-tags-existing-volume-v1.png)

## [Remove a tag from a volume](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#remove-a-tag-from-a-volume)

To remove a tag from a Volume:

1. Navigate to the Volumes page of Cloud Manager.

2. Select the more options **ellipsis (...)** corresponding to the Volume whose tags you would like to edit.

3. Select **Manage Tags** from the menu that appears.

4. The **Manage Volume Tags** form will appear. A list of your tags for the Volume will be displayed in the **Tags** field.

5. Click on the **x** icon attached to the tag you would like to remove from your Volume.

# [Tagging a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tagging-a-nodebalancer)

## [Tag a NodeBalancer at creation](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tag-a-nodebalancer-at-creation)

To tag a NodeBalancer at the time of its creation:

1. In the **NodeBalancers/ Create** form, click the dropdown menu labeled **Add Tags** under the **NodeBalancer Label** field.

2. Select one or more tags from the menu. To create a new tag, type in the desired tag name and click the **Create "new-tag"** option that appears.

   

3. Once you are done configuring the NodeBalancer, click **Create NodeBalancer**.

## [Tag an existing NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tag-an-existing-nodebalancer)

To tag an existing NodeBalancer:

1. Navigate to the NodeBalancer's detail page.

2. Click on the **Summary** tab.

3. Locate the **Tags** pane and click the **Add A Tag +** button.

4. Select one or more tags from the dropdown menu that appears. To create a new tag, type in the desired tag name and click the **Create "new-tag"** option that appears.

## [Remove a tag from a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#remove-a-tag-from-a-nodebalancer)

To remove a tag from a NodeBalancer:

1. Navigate to the NodeBalancer's detail page.

2. Click on the **Summary** tab.

3. Locate the **Tags** pane. A list of your tags for the NodeBalancer will be displayed.

4. Click on the **x** icon attached to the tag you would like to remove from your NodeBalancer.

# [Tagging a domain](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tagging-a-domain)

## [Tag an existing domain](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tag-an-existing-domain)

To tag an existing domain:

1. Navigate to the domain's detail page.

2. Scroll down to the bottom of the page.

3. Locate the pane labeled **Tags** and click on the **Add A Tag +** option.  
   ![A screenshot of the Add A Tag button within the Domains page.](https://techdocs.akamai.com/linode/tools/img/cloud-manager-tag-domain-existing-v1.jpg)

4. Select one or more tags from the dropdown menu that appears. To create a new tag, type in the desired tag name and click the **Create "new-tag"** option that appears.

## [Remove a tag from a domain](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#remove-a-tag-from-a-domain)

To remove a tag from a domain:

1. Navigate to the domain's detail page.

2. Scroll down to the bottom of the page.

3. Locate the pane labeled **Tags**. A list of your tags for the Domain will be displayed.

4. Click on the **x** icon attached to the tag you would like to remove from your domain.

# [Tagging an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tagging-an-lke-cluster)

## [Tag an existing LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#tag-an-existing-lke-cluster)

To tag an existing LKE cluster:

1. Navigate to the **Kubernetes** section of Cloud Manager and select the cluster you'd like to add a tag to.

2. Viewing your cluster's summary page, click the **Add A Tag +** button to begin adding tags to your cluster.

   

3. You can create a new tag and assign it to your cluster by typing the tag into the text entry box and clicking on the **Create my-new-tag** entry that appears.

   

   If you'd like to use an existing tag, select it from the dropdown list that appears.

     

   When your tag has been added to your cluster, you will see it appear on your cluster's summary page.

     

## [Remove a tag from an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#remove-a-tag-from-an-lke-cluster)

1. Navigate to the **Kubernetes** section of Cloud Manager and select the cluster from which you'd like to remove a tag.

2. Viewing the cluster's summary page, you will see a list of all of your cluster's tags. To remove a tag, click on the **x** next to the tag you'd like to remove.

   

# [Grouping by tag](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#grouping-by-tag)

You can group the following resources by tag: Linodes, Volumes, NodeBalancers, and Domains.

1. To group by tag, navigate to the resource's page and click the **Group by tag** icon at the top of the table:

   

     

2. You will now be able to view your resources grouped by tag:

   

# [Searching by tag](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups#searching-by-tag)

You can search your Akamai Cloud resources by a tag's name:

1. Type the tag name into the search bar at the top of Cloud Manager and the results will be populated in a dropdown list that appears:

   

2. To see a more organized view of your tagged resources, click on the blue **View search results page** banner inside the dropdown list, or hit the **Enter** key on your keyboard. You will be taken to the search results page:

   

3. A second way to search by tag is to click on a tag wherever it appears in Cloud Manager. For example, if you previously applied a tag named `my-new-tag` to one of your Linode, clicking on that tag where it is displayed in the Linode's detail page will take you to the search results page for `my-new-tag`.