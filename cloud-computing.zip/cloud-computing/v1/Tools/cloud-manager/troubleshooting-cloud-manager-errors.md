# [Troubleshooting errors in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-cloud-manager-errors#troubleshooting-errors-in-cloud-manager)

Have you ever encountered an error message while navigating Cloud Manager and wanted more information as to what may have triggered the error and what your best next steps may be? In this guide we'll go over some common error messages in a higher level of detail than are traditionally provided, and discuss your best path forward.

# [Error retrieving Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-cloud-manager-errors#error-retrieving-linodes)

**There was an error retrieving your Linodes. Please try again later.**

The above error means that there is an issue retrieving your Linodes from our backend servers. As a first step, you should check our status page at [status.linode.com](https://status.linode.com) to ensure that there are no current issues that may be affecting your Linodes or our service. If you see a current issue, you can rest assured that we're investigating and will work to bring your services back online as quickly as possible.

If the status page shows that everything is all clear, then the next step is to attempt to clear your web browser cache, as this can sometimes cause an issue in loading resources. The method for completing this process varies between browsers, however it usually involves opening your browsers full history and finding an option to clear it.

If all else fails, you should reach out to our 24/7 [Support Team](https://www.linode.com/support/) for more direct assistance. Additionally, we can also recommend attempting to access your resources through alternative means such as our [API](https://techdocs.akamai.com/linode-api/reference/api) or [CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli) if our Manager is inaccessible for any reason.

# [Error retrieving network information](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-cloud-manager-errors#error-retrieving-network-information)

**There was an error retrieving network information for this Linode.**

When you create a new Linode, it can take some time to gather enough data about your Linode's networking traffic to create an output for Cloud Manager. During the time that information is being gathered, the Network Tab will output the message **There was an error retrieving network information for this Linode** in place of the Network Transfer History graph. To confirm that there hasn't been enough analytical data gathered from the Linode, check the Metrics tab, which should state Graphs for this Linode are not yet available - check back later in place of its usual graphs.

The amount of time it takes the Network Transfer History graph to populate can vary depending on multiple factors including which distribution you've chosen for your Linode, which data center the Linode is in, and any scripts which were used to deploy the Linode.

If you are still seeing this message after a considerable amount of time, it is recommended that you attempt to clear your web browser cache, as this can sometimes cause an issue in loading resources. The method for completing this process varies between browsers, however it usually involves opening your browser's full history and finding an option to clear it.

If clearing the browser cache doesn't clear the message or you are noticing networking issues on your Linode beyond this message please see the [Troubleshooting Basic Connection Issues guide](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-basic-connection-issues-on-compute-instances).

# [Your account must be activated](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-cloud-manager-errors#your-account-must-be-activated)

**Your account must be activated before you can use this endpoint**

Generally the above message will occur when you've recently signed up for new services and your account has not yet fully activated. The best next step is to check your e-mail address for further instructions.

# [Account limit reached](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-cloud-manager-errors#account-limit-reached)

**Account Limit Reached. Please open a support ticket.**

If you see the following message, then you'll be unable to create a resource due to a limit currently set on your account. Our [Support Team](https://www.linode.com/support/) will be able to help to either increase this limit, or provide insight into why the limit may be in place.

The reasons behind these limits can vary, though in most cases are related to default resource limits set on your account.

# [Your DNS zones are not being served](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-cloud-manager-errors#your-dns-zones-are-not-being-served)

**Your DNS zones are not being served. Your domains will not be served by Akamai Cloud's name servers unless you have at least one Linode present on your account. You can create one here.**

This message is seen when using the DNS Manager without any active Linodes. While the DNS Manager is a free service, it does require that at least one active Linode is present on your account. See [DNS Manager Pricing and Availability](https://techdocs.akamai.com/cloud-computing/docs/dns-manager#pricing-and-availability).