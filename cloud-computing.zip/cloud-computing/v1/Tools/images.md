# [Images](https://techdocs.akamai.com/cloud-computing/docs/images#images)

The **Images** service lets you store complete disk images in the cloud for quick access in the future.

# [Retain a disk](https://techdocs.akamai.com/cloud-computing/docs/images#retain-a-disk)

Manually capture an image from an existing Linode's disk, or upload one from an image file you created, outside of Akamai. Both are what we refer to as a **Custom Image**. For example, you could pre-configure a disk with the exact software and settings you need for your applications and workloads —what's known as a "golden image"—and then save it as a custom image. You can quickly deploy that custom image to a new or existing Linode in the future. This saves you the time required to manually set up your entire system after each deployment. 

Custom images don't expire and they remain on your account until you manually delete them.

 > Note: 
  Images aren't intended to serve as a full backup solution. For more comprehensive backups, including automated backups, consider using our [Backups Service](https://techdocs.akamai.com/cloud-computing/docs/backup-service).

# [Recover a deleted Linode](https://techdocs.akamai.com/cloud-computing/docs/images#recover-a-deleted-linode)

If you accidentally deleted a production server, it would almost certainly impact your users and business. Our Images tool helps with this by automatically saving a temporary **Recovery Image** on your account after you delete one from a Linode. You can quickly restore the disk from the recovery image. We offer this service as a convenience. You should adopt a well-rounded [backup strategy](https://www.linode.com/docs/guides/backing-up-your-data/) that involves multiple solutions.

Recovery images have a defined expiration date. After this date, Cloud Manager automatically deletes them. The expiration timeline is typically equal to the number of hours the Linode was active, up to 21 days.

# [Regions and images](https://techdocs.akamai.com/cloud-computing/docs/images#regions-and-images)

When you create a new image, it’s stored in a specific compute region, using our Object Storage application. We offer multiple region types to best administer your Linodes. Review these sections to understand how regions can apply to your images.

## [Region types](https://techdocs.akamai.com/cloud-computing/docs/images#region-types)

There are two region types to consider:

- **Core compute region**. This describes our core data centers that offer the full set or majority of our cloud computing services. They're designed with scale in mind and are ideal for larger production workloads or applications.

- **Distributed compute region**. Also referred to as a distributed location, this data center offers limited computing services in underrepresented geographic areas. You can set up a Linode in these regions, so you can target them to create a custom image.

Check out our detailed, [Akamai Cloud map](https://www.linode.com/global-infrastructure/).

 > Note: Distributed compute regions is Limited Availability
  You need distributed compute region support on your account to maintain Linodes in a distributed compute region.

## [Regions and captured custom images](https://techdocs.akamai.com/cloud-computing/docs/images#regions-and-captured-custom-images)

You [capture an image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image) from an existing Linode and we store that image using our [Object Storage](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center#product-availability) service. There are two scenarios where regions can affect how you capture:

- **The Linode is in a core compute region that _supports_ Object Storage**. Here, the image is captured and stored in that same region.

- **The Linode is in a compute region that doesn't support Object Storage**. This can be a core compute region that doesn’t currently support Object Storage or a distributed compute region that offers limited services. In both cases, the image is captured and stored in a core region that supports Object Storage and is geographically closest.

 > Tip: 
  Regardless of where an image is stored, you can deploy it to a [new](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-a-new-compute-instance)  or [existing](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-an-existing-compute-instance)  Linode in any region.

### [North America](https://techdocs.akamai.com/cloud-computing/docs/images#north-america)

| Where the image was captured    | Where the image is stored     |
| :------------------------------ | :---------------------------- |
| US - Dallas, TX (us-central)\*  | US - Chicago, IL (us-ord)     |
| US - Denver, CO                 | US - Chicago, IL (us-ord)     |
| US - Fremont, CA (us-west)\*    | US - Los Angeles, CA (us-lax) |
| US - Houston, TX                | US - Chicago, IL (us-ord)     |
| CA - Toronto, ON (ca-central)\* | US - Chicago, IL (us-ord)     |
| MX - Querétaro                  | US - Los Angeles, CA (us-lax) |

\* Core compute region that doesn't currently support Object Storage.

### [Africa](https://techdocs.akamai.com/cloud-computing/docs/images#africa)

| Where the image was captured | Where the image is stored |
| :--------------------------- | :------------------------ |
| ZA - Johannesburg            | FR, Paris (fr-par)        |

### [Asia](https://techdocs.akamai.com/cloud-computing/docs/images#asia)

| Where the image was captured | Where the image is stored |
| :--------------------------- | :------------------------ |
| IN, Mumbai (ap-west)         | IN, Chennai (in-maa)      |
| IN, Mumbai 2 (in-bom-2)      | IN, Chennai (in-maa)      |
| JP, Tokyo 2 (ap-northeast)\* | JP, Osaka (jp-osa)        |
| JP, Tokyo 3 (jp-tyo-3)\*     | JP, Osaka (jp-osa)        |
| MY, Kuala Lumpur             | SG, Singapore (ap-south)  |
| SG, Singapore 2 (sg-sin-2)\* | SG, Singapore (ap-south)  |

\* Core compute region that doesn't currently support Object Storage.

### [Europe](https://techdocs.akamai.com/cloud-computing/docs/images#europe)

| Where the image was captured | Where the image is stored  |
| :--------------------------- | :------------------------- |
| DE, Frankfurt 2 (de-fra-2)\* | NL, Amsterdam (nl-ams)     |
| DE, Hamburg                  | DE, Frankfurt (eu-central) |
| FR, Marseilles               | FR, Paris (fr-par)         |
| GB, London (eu-west)\*       | SE, Stockholm (se-sto)     |
| GB, London 2 (gb-lon)\*      | SE, Stockholm (se-sto)     |

\* Core compute region that doesn't currently support Object Storage.

### [Oceania](https://techdocs.akamai.com/cloud-computing/docs/images#oceania)

| US - Dallas, TX (us-central)\* | US - Chicago, IL (us-ord) |
| :----------------------------- | :------------------------ |
| AU, Melbourne (au-mel)\*       | ID, Jakarta (id-cgk)      |
| AU, Sydney (ap-southeast)\*    | IN, Chennai (id-maa)      |

\* Core compute region that doesn't currently support Object Storage.

### [South America](https://techdocs.akamai.com/cloud-computing/docs/images#south-america)

| Where the image was captured | Where the image is stored |
| :--------------------------- | :------------------------ |
| CO, Bogotá                   | BR, Sao Paulo (br-gru)    |
| CL, Santiago                 | BR, Sao Paulo (br-gru)    |

## [Regions and uploaded custom images](https://techdocs.akamai.com/cloud-computing/docs/images#regions-and-uploaded-custom-images)

When you [upload a new custom image](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image), you select a specific _core region_ where you want it stored. Only core compute regions that support our [Object Storage](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center#product-availability) service can be used to store an uploaded image.

You can't upload an image to a distributed compute region.

## [Regions and recovery images](https://techdocs.akamai.com/cloud-computing/docs/images#regions-and-recovery-images)

A recovery image can be automatically created when you delete a disk from a Linode. They’re stored as follows:

- **Core compute region**. The recovery image is stored in the same core region where its deleted Linode was located. Recovery images are not stored using our Object Storage service, so Object Storage availability in a core region doesn't apply.
- **Distributed compute region**. Recovery images are not currently supported for Linodes in distributed compute regions.

 > Warning: 
  If you delete a disk on a Linode in a distributed compute region, a recovery image is _not_ generated. Ensure you want to delete a disk before you complete the operation.

### [Deploy an image to a region](https://techdocs.akamai.com/cloud-computing/docs/images#deploy-an-image-to-a-region)

You can deploy a custom or recovery image to any compute region you have access to. This includes both core compute regions or distributed compute regions.

## [Region support matrix](https://techdocs.akamai.com/cloud-computing/docs/images#region-support-matrix)

| Task                       | Core region w/ Object Storage                                                                                                 | Core region w/out Object Storage                                                                                                                                        | Distributed region                                                                                                   |
| :------------------------- | :---------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------- |
| **Capture a custom image** | **Yes**.                                                                                                                      | **Yes**.                                                                                                                                                                | **Yes**.                                                                                                             |
| **Store a captured image** | **Yes**. The captured image is stored in the same core region where it was taken.                                             | **No**. The captured image is stored in the core region that supports Object Storage, and is geographically closest.                                                    | **No**. The captured image is stored in the core region that supports Object Storage, and is geographically closest. |
| **Upload a custom image**  | **Yes**. You pick a specific core region where you want to store the image.                                                   | **No**. You can't store an uploaded image in a core region that doesn't support Object Storage. (These regions aren't available for selection when uploading an image.) | **No**. You can't upload a custom image to a distributed region.                                                     |
| **Save a recovery image**  | **Yes**. This happens automatically when a Linode is deleted from a core region.                                        | **Yes**. This happens automatically when a Linode is deleted from a core region.                                                                                  | **No**.  Distributed regions don't support recovery images.                                                          |
| **Store a recovery image** | **Yes**. The recovery image is stored in the same core region where it was deleted. Recovery images don't use Object Storage. | **Yes**. The recovery image is stored in the same core region where it was deleted. Recovery images don't use Object Storage.                                           | **No**. Distributed regions don't support recovery images.                                                           |
| **Deploy an image**        | **Yes**. You can deploy a stored image to any core region.                                                                    | **Yes**. You can deploy a stored image to any core region.                                                                                                              | **Yes**. You can deploy a stored image to any Distributed region.                                                    |

# [Recommended workloads](https://techdocs.akamai.com/cloud-computing/docs/images#recommended-workloads)

Here are some example workloads where the Images service might help you:

- If you're a web or software agency that deploys similar starter configurations for clients.
- If you have development workflows that require the same base image for all developers or applications.
- If you have workflows that use cloud-based distributions other than [those provided by Akamai Cloud](https://techdocs.akamai.com/cloud-computing/docs/choose-a-distribution).

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/images#pricing)

- **Custom Images**. You need to manually create these. They cost $0.10/GB per month.
- **Recovery Images**. Cloud Manager generates these automatically after you delete a Linode. They're provided at no charge, but have a [limited lifecycle](#recover-a-deleted-linode).

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/images#technical-specifications)

Specifications and requirements vary, based on how you create an image:

- [Capture an Image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image#requirements-and-considerations). This describes the process of targeting an existing Linode to create the image.

- [Upload an Image](https://techdocs.akamai.com/cloud-computing/docs/upload-an-image#requirements-and-considerations). This describes the process of creating an image "instance," and manually uploading your own disk image to it.

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/images#developer-resources)

## [Linode API](https://techdocs.akamai.com/cloud-computing/docs/images#linode-api)

The Linode API v4 lets you programmatically manage the full range of our products and services. It offers several operations you can use to interact with your images:

- [Create an image](https://techdocs.akamai.com/linode-api/reference/post-image). Create a new image.
- [List images](https://techdocs.akamai.com/linode-api/reference/get-images). View all of your images.
- [Get an image](https://techdocs.akamai.com/linode-api/reference/get-image). View a specific image.
- [Update an image](https://techdocs.akamai.com/linode-api/reference/put-image). Update various setting for an existing image.
- [Upload an image](https://techdocs.akamai.com/linode-api/reference/post-upload-image). Create a new private image instance and get the URL where you can upload image data.
- [Replicate an image](https://techdocs.akamai.com/linode-api/reference/post-replicate-image). Target an existing image and replicate it to another compute region.
- [Delete an image](https://techdocs.akamai.com/linode-api/reference/delete-image). Delete an existing image.

## [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/images#linode-cli)

The [Linode CLI](https://github.com/linode/linode-cli) is a wrapper around the Linode API v4 that allows you to manage your account and resources from the command line. Learn how to [use and install the Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli) to get started.