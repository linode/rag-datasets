# [CLI commands for Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-object-storage#cli-commands-for-object-storage)

# [Basic commands](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-object-storage#basic-commands)

List the current Object Storage clusters available to you:

```
linode-cli object-storage clusters-list
```

# [Manage access keys](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-object-storage#manage-access-keys)

List all access keys on the account:

```
linode-cli object-storage keys-list
```

Create a new access key with the label _example-label_:

```
linode-cli object-storage keys-create --label "example-label"
```

Update the label of an access key, replacing _[id]_ with the **ID** of the access key you wish to update:

```
linode-cli object-storage keys-update --keyId [id] --label "new-label"
```

Revoke an access key, replacing _[id]_ with the **ID** of the access key you wish to revoke:

```
linode-cli object-storage keys-delete [id]
```

# [TLS/SSL certificates](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-object-storage#tlsssl-certificates)

Upload a TLS/SSL certificate:

```
linode-cli object-storage ssl-upload us-east-1 example-bucket --certificate "my-full-certificate" --private_key "my-full-private-key"
```

View an Active TLS/SSL certificate:

```
linode-cli object-storage ssl-view us-east-1 example-bucket
```

Delete an Active TLS/SSL certificate:

```
linode-cli object-storage ssl-delete us-east-1 example-bucket
```

# [Cancel Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-object-storage#cancel-object-storage)

Cancel Object Storage on your account:

 > Note: 
  All buckets on the account need to be empty before Object Storage can be cancelled.

```
linode-cli object-storage cancel
```