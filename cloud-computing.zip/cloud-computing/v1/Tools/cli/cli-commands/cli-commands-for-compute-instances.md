# [CLI commands for standard Linodes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#cli-commands-for-standard-linodes)

Here are some common tasks for standard Linodes you can perform with the Linode CLI. A standard Linode uses a Dedicated CPU or Shared CPU Linode Plan. 

# [List your Linodes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#list-your-linodes)

## [List all](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#list-all)

Run this basic command to list all of the Linodes on your account—including _all_ Linode plans (types):

```
linode-cli linodes list
```

## [Filter the results](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#filter-the-results)

You can also expand the command to filter results to a particular region:

```
linode-cli linodes list --region us-east
```

Filtering works on many fields throughout the CLI. Use `--help` for each action to see which properties are filterable.

# [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#create-a-linode)

## [Create a standard Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#create-a-standard-linode)

Run this basic command to create a new standard Linode, using a dedicated CPU:

```
linode-cli linodes create --root_pass mypassword
```

The defaults you specified when you configured the CLI are used for the new Linode, including the Linode plan (type), region, and image.

## [Customize a standard Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#customize-a-standard-linode)

You can override the defaults you set during CLI configuration, by specifying them in the command:

```
linode-cli linodes create --root_pass mypassword --region us-east --image linode/debian9 --group webservers
```

If you're not writing a script, it's more secure to use `--root_pass` _without_ specifying a password. Instead, you'll be prompted to enter a password:

```
linode-cli linodes create --root_pass
```

# [Target a specific Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#target-a-specific-linode)

## [Get the Linode's ID](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#get-the-linodes-id)

You need a Linode's `linode_id` to interact with it. You can get it by [listing the Linodes](#list-all) on your account, and then storing the target Linode's `id` as your `linode_id` for later use:

```
export linode_id=

```

## [View a specific Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#view-a-specific-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to view details about it:

```
linode-cli linodes view $linode_id
```

## [Booting your Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#booting-your-linode)

With the `linode_id` [stored](#get-the-linodes-id), run each of these commands to boot, reboot, or shut down a Linode, respectively:

```
linode-cli linodes boot $linode_id
linode-cli linodes reboot $linode_id
linode-cli linodes shutdown $linode_id
```

## [View IP address on a Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#view-ip-address-on-a-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to view a list of available IP addresses for a specific Linode:

```
linode-cli linodes ips-list $linode_id
```

## [Add a private IP address](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#add-a-private-ip-address)

With the `linode_id` [stored](#get-the-linodes-id), run this command to add a private IP address to a Linode:

```
linode-cli linodes ip-add $linode_id --type ipv4 --public false
```

## [Create a new disk](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#create-a-new-disk)

With the `linode_id` [stored](#get-the-linodes-id), run this command to create a new disk on a specific Linode:

```
linode-cli linodes disk-create $linode_id --size 2700 --root_pass mypassword --filesystem raw --no-defaults
```

 > Note: 
  Even if you set the `--filesystem` to `raw`, the defaults you specified when configuring the CLI are used for setting a Linode's disk image for this disk, overriding the filesystem setting. To create a disk without the default image, using only the parameters you send in this command, use the `--no-defaults` flag.

## [List all disks](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#list-all-disks)

With the `linode_id` [stored](#get-the-linodes-id), run this command to list all of the provisioned disks on a specific Linode:

```
linode-cli linodes disks-list $linode_id
```

## [Upgrade your Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#upgrade-your-linode)

If an upgrade is available for your Linode, the system places it in the migration queue. Then, the system automatically shuts it down, migrates it, and returns to its last state:

```
linode-cli linodes upgrade $linode_id
```

## [Rebuild a Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#rebuild-a-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to rebuild a Linode:

```
linode-cli linodes rebuild $linode_id --image linode/debian9 --root_pass
```

You can also rebuild your Linode and add a populated `authorized_keys` file:

```
linode-cli linodes rebuild $linode_id --image linode/debian9 --root_pass --authorized_keys "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIEC+DOVfw+8Jsw1IPrYCcU9/HCuKayCsV8bXjsHqX/Zq email@example.com"
```

If your key exists on your filesystem, you can also substitute its value in the CLI command with `cat`. For example:

```
linode-cli linodes rebuild $linode_id --image linode/debian9 --root_pass --authorized_keys "$(cat ~/.ssh/id_rsa.pub)"
```

# [There's more](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances#theres-more)

Many other actions are available. Use `linode-cli linodes --help` for a complete list.