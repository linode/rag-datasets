# [CLI commands for GPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#cli-commands-for-gpu-linodes)

Here are some common CLI tasks for Linodes that use the GPU Linode plan type. GPU-optimized Linodes are accelerated by NVIDIA RTX 4000 Ada or NVIDIA Quadro RTX 6000 that harness the power of CUDA, Tensor, and RT cores to execute complex processing, transcoding, and ray tracing workloads.

 > Note: 
  GPU Linode availability is limited. See [GPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances) for complete details.

# [List your GPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#list-your-gpu-linodes)

Run this command to view all of the GPU type Linodes on your account:

```Text Command
linode-cli linodes types --class gpu
```
```Text Response example
┏━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━┳━━━━━━━┳━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃         id          ┃  disk   ┃ gpus ┃ vcpus ┃ class ┃               label                ┃ memory ┃ transfer ┃ successor ┃ network_out ┃ accelerated_devices ┃ price.hourly ┃ price.monthly ┃       region_prices       ┃
┡━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━╇━━━━━━━╇━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ g1-gpu-rtx6000-1    │ 655360  │ 1    │ 8     │ gpu   │ Dedicated 32GB + RTX6000 GPU x1    │ 32768  │ 16000    │ None      │ 10000       │ 0                   │ 1.5          │ 1000.0        │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g1-gpu-rtx6000-2    │ 1310720 │ 2    │ 16    │ gpu   │ Dedicated 64GB + RTX6000 GPU x2    │ 65536  │ 20000    │ None      │ 10000       │ 0                   │ 3.0          │ 2000.0        │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g1-gpu-rtx6000-3    │ 1966080 │ 3    │ 20    │ gpu   │ Dedicated 96GB + RTX6000 GPU x3    │ 98304  │ 20000    │ None      │ 10000       │ 0                   │ 4.5          │ 3000.0        │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g1-gpu-rtx6000-4    │ 2621440 │ 4    │ 24    │ gpu   │ Dedicated 128GB + RTX6000 GPU x4   │ 131072 │ 20000    │ None      │ 10000       │ 0                   │ 6.0          │ 4000.0        │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a1-s  │ 524288  │ 1    │ 4     │ gpu   │ RTX4000 Ada x1 Small               │ 16384  │ 0        │ None      │ 16000       │ 0                   │ 0.52         │ 350.0         │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a1-m  │ 524288  │ 1    │ 8     │ gpu   │ RTX4000 Ada x1 Medium              │ 32768  │ 0        │ None      │ 16000       │ 0                   │ 0.67         │ 446.0         │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a1-l  │ 524288  │ 1    │ 16    │ gpu   │ RTX4000 Ada x1 Large               │ 65536  │ 0        │ None      │ 16000       │ 0                   │ 0.96         │ 638.0         │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a1-xl │ 524288  │ 1    │ 32    │ gpu   │ RTX4000 Ada x1 X-Large             │ 131072 │ 0        │ None      │ 16000       │ 0                   │ 1.53         │ 1022.0        │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a2-s  │ 1048576 │ 2    │ 8     │ gpu   │ RTX4000 Ada x2 Small               │ 32768  │ 0        │ None      │ 16000       │ 0                   │ 1.05         │ 700.0         │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a2-m  │ 1048576 │ 2    │ 16    │ gpu   │ RTX4000 Ada x2 Medium              │ 65536  │ 0        │ None      │ 16000       │ 0                   │ 1.34         │ 892.0         │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a2-hs │ 2097152 │ 2    │ 16    │ gpu   │ RTX4000 Ada x2 Medium High Storage │ 65536  │ 0        │ None      │ 16000       │ 0                   │ 1.49         │ 992.0         │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a4-s  │ 2097152 │ 4    │ 32    │ gpu   │ RTX4000 Ada x4 Small               │ 131072 │ 0        │ None      │ 16000       │ 0                   │ 2.96         │ 1976.0        │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
├─────────────────────┼─────────┼──────┼───────┼───────┼────────────────────────────────────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g2-gpu-rtx4000a4-m  │ 2097152 │ 4    │ 48    │ gpu   │ RTX4000 Ada x4 Medium              │ 200704 │ 0        │ None      │ 16000       │ 0                   │ 3.57         │ 2384.0        │                           │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                     │         │      │       │       │                                    │        │          │           │             │                     │              │               │                           │
└─────────────────────┴─────────┴──────┴───────┴───────┴────────────────────────────────────┴────────┴──────────┴───────────┴─────────────┴─────────────────────┴──────────────┴───────────────┴───────────────────────────┘
```

# [Create a GPU Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#create-a-gpu-linode)

Run this command to create a new Linode, using an RTX4000 Ada x1 Small GPU:

```Text Command
linode-cli linodes create --region us-ord --type g2-gpu-rtx4000a1-s --image linode/ubuntu24.04 --root_pass 

```
```Text Response example
┌──────────┬────────────────┬────────┬────────────────────┬────────────────────┬──────────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type               │ image              │ status       │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼────────────────────┼────────────────────┼──────────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-ord │ g2-gpu-rtx4000a1-s │ linode/ubuntu24.04 │ provisioning │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴────────────────────┴────────────────────┴──────────────┴─────────────────┴─────────────────┴───────────────────────┘
```

# [Target a specific GPU Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#target-a-specific-gpu-linode)

Here are several common operations you can perform with a specific GPU Linode.

## [Get the Linode's ID](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#get-the-linodes-id)

You need a Linode's `linode_id` to interact with it. You can get it by [listing the GPU Linodes](#list-your-gpu-linodes) on your account, and then storing the target Linode's `id` as your `linode_id` for later use:

```
export linode_id=

```

## [View a specific GPU Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#view-a-specific-gpu-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to view details about it:

```Text Command
linode-cli linodes view $linode_id
```
```Text Response example
┌──────────┬────────────────┬────────┬────────────────────┬────────────────────┬─────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type               │ image              │ status  │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼────────────────────┼────────────────────┼─────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-ord │ g2-gpu-rtx4000a1-s │ linode/ubuntu24.04 │ running │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴────────────────────┴────────────────────┴─────────┴─────────────────┴─────────────────┴───────────────────────┘
```

## [Reboot your GPU Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#reboot-your-gpu-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to reboot your GPU Linode:

```Text Command
linode-cli linodes reboot $linode_id
```
```Text Response example
┌──────────┬────────────────┬────────┬────────────────────┬────────────────────┬───────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type               │ image              │ status    │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼────────────────────┼────────────────────┼───────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-ord │ g2-gpu-rtx4000a1-s │ linode/ubuntu24.04 │ rebooting │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴────────────────────┴────────────────────┴───────────┴─────────────────┴─────────────────┴───────────────────────┘
```

## [Shut down your GPU Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#shut-down-your-gpu-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to shut down your GPU Linode:

```Text Command
linode-cli linodes shutdown $linode_id
```
```Text Response example
┌──────────┬────────────────┬────────┬────────────────────┬────────────────────┬───────────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type               │ image              │ status        │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼────────────────────┼────────────────────┼───────────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-ord │ g2-gpu-rtx4000a1-s │ linode/ubuntu24.04 │ shutting_down │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴────────────────────┴────────────────────┴───────────────┴─────────────────┴─────────────────┴───────────────────────┘
```

## [Rebuild your GPU Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#rebuild-your-gpu-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command, including your root password (`root_pass`) to rebuild it, using Ubuntu 24.10:

```Text Command
linode-cli linodes rebuild $linode_id --image linode/ubuntu24.10 --root_pass 

```
```Text Response example
┌──────────┬────────────────┬────────┬────────────────────┬────────────────────┬────────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type               │ image              │ status     │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼────────────────────┼────────────────────┼────────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-ord │ g2-gpu-rtx4000a1-s │ linode/ubuntu24.10 │ rebuilding │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴────────────────────┴────────────────────┴────────────┴─────────────────┴─────────────────┴───────────────────────┘
```

## [Resize your GPU Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#resize-your-gpu-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to resize your GPU Linode to an RTX4000 Ada x2 Small Linode plan.

```Text Command
linode-cli linodes resize $linode_id --type g2-gpu-rtx4000a2-s
```
```Text Response example
┌──────────┬────────────────┬────────┬────────────────────┬────────────────────┬──────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type               │ image              │ status   │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼────────────────────┼────────────────────┼──────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-ord │ g2-gpu-rtx4000a2-s │ linode/ubuntu24.10 │ resizing │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴────────────────────┴────────────────────┴──────────┴─────────────────┴─────────────────┴───────────────────────┘
```

 > Note: 
  You can see the Linode plan types available to you by running this command:
  ```
 linode-cli linodes types
 ```

## [Delete your GPU Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-gpu-linodes#delete-your-gpu-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to delete your GPU Linode:

```Text Command
linode-cli linodes delete $linode_id
```
```Text Response example
┌──────────┬────────────────┬────────┬────────────────────┬────────────────────┬─────────-┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type               │ image              │ status   │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼────────────────────┼────────────────────┼─────────-┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-ord │ g2-gpu-rtx4000a2-s │ linode/ubuntu24.10 │ deleting │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴────────────────────┴────────────────────┴─────────-┴─────────────────┴─────────────────┴───────────────────────┘
```