# [CLI commands for LKE](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-lke#cli-commands-for-lke)

1. Lists current Kubernetes clusters available on your account:

   ```
   linode-cli lke clusters-list
   ```

2. Create a Kubernetes cluster. The system creates the cluster asynchronously. You can use the events system to determine when the cluster is ready to use:

   ```
   linode-cli lke cluster-create \
     --label cluster12345 \
     --region us-central \
     --k8s_version 1.16 \
     --node_pools.type g6-standard-4 --node_pools.count 6 \
     --node_pools.type g6-standard-8 --node_pools.count 3 \
     --tags ecomm
   ```

3. Update a Kubernetes cluster:

   ```
   linode-cli lke cluster-update $cluster_id \
     --label lkecluster54321 \
     --tags ecomm \
     --tags blog \
     --tags prod \
     --tags monitoring
   ```

4. Delete a cluster you have permission to `read_write`:

   ```
   linode-cli lke cluster-delete $cluster_id
   ```

5. List all active node pools on a Kubernetes cluster:

   ```
   linode-cli lke pools-list $cluster_id
   ```

6. Create a node pool on a Kubernetes cluster:

   ```
   linode-cli lke pool-create $cluster_id \
     --type g6-standard-4 \
     --count 6
   ```

7. Update a node pool in a Kubernetes cluster. When a node pool's count is changed, the system replaces the nodes in that pool in a rolling fashion.

   ```
   linode-cli lke pool-update $cluster_id $pool_id \
     --count 6
   ```

8. Delete a node pool from a Kubernetes cluster:

   ```
   linode-cli lke pool-delete $cluster_id $pool_id
   ```

9. View the Kubeconfig file for the Kubernetes cluster:

   ```
   linode-cli lke kubeconfig-view $cluster_id
   ```

Other actions are available. Use `linode-cli lke --help` for a complete list.