# [CLI commands for NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#cli-commands-for-nodebalancers)

Here are some common tasks to manage NodeBalancers using the Linode CLI.

# [List your NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#list-your-nodebalancers)

Run this command to list all of the NodeBalancers on your account:

```
linode-cli nodebalancers list
```

# [Create a new NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#create-a-new-nodebalancer)

Run this command to create a new NodeBalancer:

```
linode-cli nodebalancers create --region us-east --label new-balancer
```

# [Target a specific NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#target-a-specific-nodebalancer)

Here are some common operations you can perform with a specific NodeBalancer.

## [Get the NodeBalancer's ID](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#get-the-nodebalancers-id)

You need a NodeBalancer's `nodebalancer_id` to interact with it. You can get it by [listing the NodeBalancers](#list-your-nodebalancers) on your account, and then storing the target NodeBalancer's `id` as your `nodebalancer_id` for later use:

```
export linode_id=

```

## [Create a configuration](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#create-a-configuration)

With the `nodebalancer_id` [stored](#get-the-nodebalancers-id), run this command to create a new configuration on your NodeBalancer:

```
linode-cli nodebalancers config-create $nodebalancer_id
```

## [Attach a Node](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#attach-a-node)

To add a new node to your NodeBalancer, follow these steps:

1. Have your `nodebalancer_id` [stored](#get-the-nodebalancers-id).

2. List the configurations on your NodeBalancer to get the `id` for the target one:

   ```
   linode-cli nodebalancers configs-list $node_balancer_id
   ```

3. Store the `id` as your `config_id`:

   ```
   export config_id=

   ```

4. Run this command, replacing the `
` variable with the address for the node:

   ```
   linode-cli nodebalancers node-create --address 
 --label node-1 $nodebalancer_id $config_id
   ```

## [Delete a node](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#delete-a-node)

To delete an existing node, follow these steps:

1. Have your `nodebalancer_id` [stored](#get-the-nodebalancers-id).

2. List the configurations on your NodeBalancer to get the `id` for the target one:

   ```
   linode-cli nodebalancers configs-list $nodebalancer_id
   ```

3. Store the `id` as your `config_id`:

   ```
   export config_id=

   ```

4. List the nodes in your NodeBalancer configuration to get the `id` for the target one:

   ```
   linode-cli nodebalancers nodes-list $nodebalancer_id $config_id
   ```

5. Store the `id` as your `node_id`:

   ```
   export node_id=

   ```

6. Run this command to delete the node:

   ```
   linode-cli nodebalancers node-delete $nodebalancer_id $config_id $node_id
   ```

# [There's more](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers#theres-more)

Other actions are available. Use `linode-cli nodebalancers --help` for a complete list.