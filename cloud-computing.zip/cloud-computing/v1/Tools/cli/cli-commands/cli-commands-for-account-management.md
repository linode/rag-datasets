# [CLI commands for Account Management](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-account-management#cli-commands-for-account-management)

View or update your account information, add payment methods, view notifications, make payments, create OAuth clients, and do other related tasks through the `account` action:

# [View your account](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-account-management#view-your-account)

Run this command to view specific details on your Akamai Cloud account.

```
linode-cli account view
```

# [View your settings](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-account-management#view-your-settings)

Run this command to view setting that have been applied to your account:

```
linode-cli account settings
```

# [Make a payment](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-account-management#make-a-payment)

Run this command and set a desired amount to make a payment:

```
linode-cli account payment-create --cvv 123 --usd 20.00
```

# [View notifications](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-account-management#view-notifications)

Run this command to view any current notifications on your account:

```
linode-cli account notifications-list
```