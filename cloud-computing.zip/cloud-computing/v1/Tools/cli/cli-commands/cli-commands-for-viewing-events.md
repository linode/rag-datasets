# [CLI commands for events](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-viewing-events#cli-commands-for-events)

1.  View a list of events on your account:

        linode-cli events list

1.  View details about a specific event:

        linode-cli events view $event_id

1.  Mark an event as read:

        linode-cli events mark-read $event_id