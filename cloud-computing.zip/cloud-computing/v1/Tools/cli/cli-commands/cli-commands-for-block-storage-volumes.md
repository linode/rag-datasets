# [CLI commands for Block Storage volumes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-block-storage-volumes#cli-commands-for-block-storage-volumes)

1. List your current volumes:

   ```
   linode-cli volumes list
   ```

2. Create a new volume, with the size specified in GB:

   ```
   linode-cli volumes create --label my-volume --size 100 --region us-east
   ```

   Specify a `linode_id` to create the volume and automatically attach it to a specific Linode:

   ```
   linode-cli volumes create --label my-volume --size 100  --linode_id $linode_id
   ```

3. Attach or detach the volume from a Linode:

   ```
   linode-cli volumes attach $volume_id --linode_id $linode_id
   linode-cli volumes detach $volume_id
   ```

4. Resize a volume:

   ```
   linode-cli volumes resize $volume_id --size 200
   ```

   > > Note: 
   > 
   > You can only _increase_ a volume's size.

5. Delete a volume:

   ```
   linode-cli volumes delete $volume_id
   ```