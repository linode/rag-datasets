# [CLI commands for support tickets](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-support-tickets#cli-commands-for-support-tickets)

1. List your support tickets:

   ```
   linode-cli tickets list
   ```

2. Open a new ticket:

   ```
   linode-cli tickets create --description "Detailed description of the issue" --summary "Summary or quick title for the Ticket"
   ```

   If your issue concerns a particular Linode, Volume, Domain, or NodeBalancer, pass the ID with `--domain_id`, `--linode-id`, `--volume_id`, etc.

3. List replies for a ticket:

   ```
   linode-cli tickets replies $ticket_id
   ```

4. Reply to a ticket:

   ```
   linode-cli tickets reply $ticket_id --description "The content of your reply"
   ```