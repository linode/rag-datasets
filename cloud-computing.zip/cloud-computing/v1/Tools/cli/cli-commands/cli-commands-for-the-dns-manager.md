# [CLI commands for DNS Manager](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-the-dns-manager#cli-commands-for-dns-manager)

1. List the domains on your account:

   ```
   linode-cli domains list
   ```

2. View all domain records in a specific domain:

   ```
   linode-cli domains records-list $domain_id
   ```

3. Delete a domain:

   ```
   linode-cli domains delete $domain_id
   ```

4. Create a domain:

   ```
   linode-cli domains create --type master --domain www.example.com --soa_email email@example.com
   ```

5. Create a new A record in a domain:

   ```
   linode-cli domains records-create $domain_id --type A --name subdomain --target 192.0.2.0
   ```