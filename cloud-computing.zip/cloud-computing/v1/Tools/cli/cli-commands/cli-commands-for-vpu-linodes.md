# [CLI commands for Accelerated Linodes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#cli-commands-for-accelerated-linodes)

Here are some common CLI tasks for Linodes that use the Accelerated (VPU) Linode plan type. Accelerated Linodes are backed by NETINT Quadra T1U video processing units—ASIC-based media accelerator cards that are purpose-built for transcoding tasks.

 > Note: 
  Accelerated Linode availability is limited. See [Accelerated Linodes](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances) for complete details.

# [List your Accelerated Linodes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#list-your-accelerated-linodes)

Run this command to view all of the Accelerated Linodes on your account:

```Text Command
linode-cli linodes types --class vpu
```
```Text Response example
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━┳━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                id                ┃  disk  ┃ gpus ┃    class    ┃            label            ┃ vcpus ┃ memory ┃ transfer ┃ successor ┃ network_out ┃ accelerated_devices ┃ price.hourly ┃ price.monthly ┃       region_prices       ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━╇━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━╇━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ g1-accelerated-netint-vpu-t1u1-s │ 204800 │ 0    │ accelerated │ NETINT Quadra T1U x1 Small  │ 8     │ 16384  │ 0        │ None      │ 16000       │ 1                   │ 0.42         │ 280.0         │                           │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │                           │
├──────────────────────────────────┼────────┼──────┼─────────────┼─────────────────────────────┼───────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g1-accelerated-netint-vpu-t1u1-m │ 307200 │ 0    │ accelerated │ NETINT Quadra T1U x1 Medium │ 12    │ 24576  │ 0        │ None      │ 16000       │ 1                   │ 0.53         │ 352.0         │                           │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │                           │
├──────────────────────────────────┼────────┼──────┼─────────────┼─────────────────────────────┼───────┼────────┼──────────┼───────────┼─────────────┼─────────────────────┼──────────────┼───────────────┼───────────────────────────┤
│ g1-accelerated-netint-vpu-t1u2-s │ 307200 │ 0    │ accelerated │ NETINT Quadra T1U x2 Small  │ 12    │ 24576  │ 0        │ None      │ 16000       │ 2                   │ 0.73         │ 488.0         │                           │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │   id   hourly   monthly   │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │  ━━━━━━━━━━━━━━━━━━━━━━━  │
│                                  │        │      │             │                             │       │        │          │           │             │                     │              │               │                           │
└──────────────────────────────────┴────────┴──────┴─────────────┴─────────────────────────────┴───────┴────────┴──────────┴───────────┴─────────────┴─────────────────────┴──────────────┴───────────────┴───────────────────────────┘
```

# [Create an Accelerated Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#create-an-accelerated-linode)

Run this command to create a new Linode, using a NETINT Quadra T1U x1 small VPU:

```Text Command
linode-cli linodes create --region us-lax --type g1-accelerated-netint-vpu-t1u1-s --image linode/ubuntu24.04 --root_pass 

```
```Text Response example
┌──────────┬────────────────┬────────┬──────────────────────────────────┬────────────────────┬──────────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type                             │ image              │ status       │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼──────────────────────────────────┼────────────────────┼──────────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-lax │ g1-accelerated-netint-vpu-t1u1-s │ linode/ubuntu24.04 │ provisioning │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴──────────────────────────────────┴────────────────────┴──────────────┴─────────────────┴─────────────────┴───────────────────────┘
```

# [Target a specific Accelerated Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#target-a-specific-accelerated-linode)

Here are several common operations you can perform with a specific Accelerated Linode.

## [Get the Linode's ID](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#get-the-linodes-id)

You need a Linode's `linode_id` to interact with it. You get it by [listing the Accelerated Linodes](#list-your-vpu-linodes) on your account, and then storing the target Linode's `id` as your `linode_id` for later use:

```
export linode_id=

```

## [View a specific Accelerated Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#view-a-specific-accelerated-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to view details about it:

```Text Command
linode-cli linodes view $linode_id
```
```Text Example response
┌──────────┬────────────────┬────────┬──────────────────────────────────┬────────────────────┬─────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type                             │ image              │ status  │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼──────────────────────────────────┼────────────────────┼─────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-lax │ g1-accelerated-netint-vpu-t1u1-s │ linode/ubuntu24.04 │ running │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴──────────────────────────────────┴────────────────────┴─────────┴─────────────────┴─────────────────┴───────────────────────┘
```

## [Reboot your Accelerated Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#reboot-your-accelerated-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to reboot your Accelerated Linode:

```Text Command
linode-cli linodes reboot $linode_id
```
```Text Example response
┌──────────┬────────────────┬────────┬──────────────────────────────────┬────────────────────┬───────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type                             │ image              │ status    │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼──────────────────────────────────┼────────────────────┼───────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-lax │ g1-accelerated-netint-vpu-t1u1-s │ linode/ubuntu24.04 │ rebooting │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴──────────────────────────────────┴────────────────────┴───────────┴─────────────────┴─────────────────┴───────────────────────┘
```

## [Shut down your Accelerated Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#shut-down-your-accelerated-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to shut down your Accelerated Linode:

```Text Command
linode-cli linodes shutdown $linode_id
```
```Text Example response
┌──────────┬────────────────┬────────┬──────────────────────────────────┬────────────────────┬───────────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type                             │ image              │ status        │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼──────────────────────────────────┼────────────────────┼───────────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-lax │ g1-accelerated-netint-vpu-t1u1-s │ linode/ubuntu24.04 │ shutting_down │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴──────────────────────────────────┴────────────────────┴───────────────┴─────────────────┴─────────────────┴───────────────────────┘
```

## [Rebuild your Accelerated Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#rebuild-your-accelerated-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command, including your root password (`root_pass`) to rebuild it, using Ubuntu 24.10:

```Text Command
linode-cli linodes rebuild $linode_id --image linode/ubuntu24.10 --root_pass 

```
```Text Example response
┌──────────┬────────────────┬────────┬──────────────────────────────────┬────────────────────┬────────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type                             │ image              │ status     │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼──────────────────────────────────┼────────────────────┼────────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-lax │ g1-accelerated-netint-vpu-t1u1-s │ linode/ubuntu24.10 │ rebuilding │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴──────────────────────────────────┴────────────────────┴────────────┴─────────────────┴─────────────────┴───────────────────────┘
```

## [Resize your Accelerated Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#resize-your-accelerated-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to resize your Accelerated Linode to a NETINT Quadra T1U x2 small Accelerated Linode plan.

```Text Command
linode-cli linodes resize $linode_id --type g1-accelerated-netint-vpu-t1u2-s
```
```Text Response example
┌──────────┬────────────────┬────────┬──────────────────────────────────┬────────────────────┬──────────┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type                             │ image              │ status   │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼──────────────────────────────────┼────────────────────┼──────────┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-lax │ g1-accelerated-netint-vpu-t1u2-s │ linode/ubuntu24.10 │ resizing │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴──────────────────────────────────┴────────────────────┴──────────┴─────────────────┴─────────────────┴───────────────────────┘
```

 > Note: 
  You can see the Linode plan types available to you by running this command:
  ```
 linode-cli linodes types
 ```

## [Delete your Accelerated Linode](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-vpu-linodes#delete-your-accelerated-linode)

With the `linode_id` [stored](#get-the-linodes-id), run this command to delete your Accelerated Linode:

```Text Command
linode-cli linodes delete $linode_id
```
```Text Response example
┌──────────┬────────────────┬────────┬──────────────────────────────────┬────────────────────┬─────────-┬─────────────────┬─────────────────┬───────────────────────┐
│ id       │ label          │ region │ type                             │ image              │ status   │ ipv4            │ disk_encryption │ placement_group.label │
├──────────┼────────────────┼────────┼──────────────────────────────────┼────────────────────┼─────────-┼─────────────────┼─────────────────┼───────────────────────┤
│ 12345678 │ linode12345678 │ us-lax │ g1-accelerated-netint-vpu-t1u2-s │ linode/ubuntu24.10 │ deleting │ 123.123.123.123 │ enabled         │                       │
└──────────┴────────────────┴────────┴──────────────────────────────────┴────────────────────┴─────────-┴─────────────────┴─────────────────┴───────────────────────┘
```