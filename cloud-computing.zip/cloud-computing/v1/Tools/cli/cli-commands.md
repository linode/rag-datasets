# [CLI commands](https://techdocs.akamai.com/cloud-computing/docs/cli-commands#cli-commands)
