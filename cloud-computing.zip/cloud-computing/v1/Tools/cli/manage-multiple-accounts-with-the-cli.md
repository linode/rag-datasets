# [Manage multiple accounts with the Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/manage-multiple-accounts-with-the-cli#manage-multiple-accounts-with-the-linode-cli)

The Linode CLI can be configured to run commands from multiple users on separate accounts. This lets you control multiple accounts, all through the same system, using the Linode CLI. Once multiple users are configured, you can execute commands as a particular user or set a specific user as the default.

# [Configure an additional user](https://techdocs.akamai.com/cloud-computing/docs/manage-multiple-accounts-with-the-cli#configure-an-additional-user)

To manage another account, you must configure the Linode CLI with a user on that account. This is accomplished by re-running the Linode CLI configuration utility (see [Configure the Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#configure-the-cli)).

```
linode-cli configure
```

# [View users](https://techdocs.akamai.com/cloud-computing/docs/manage-multiple-accounts-with-the-cli#view-users)

To see which users have already been configured on the Linode CLI, run the following command:

```
linode-cli show-users
```

This outputs a list containing the usernames of each user. An asterisks (`*`) marks the user that is currently active (the default user).

```text Output
Configured Users:
*  example-user
   another-user
```

# [Change the default user](https://techdocs.akamai.com/cloud-computing/docs/manage-multiple-accounts-with-the-cli#change-the-default-user)

The default user is used when running Linode CLI commands. Run the following command to change the default user, replacing _[username]_ with the name of the user you wish to use.

```
linode-cli set-user [username]
```

# [Run a command as a different user](https://techdocs.akamai.com/cloud-computing/docs/manage-multiple-accounts-with-the-cli#run-a-command-as-a-different-user)

You can run a Linode CLI command as a specific user _without_ needing to change the default user. This is helpful if you need to run a one-off command on a different account. In the command below, replace _[username]_ with the name of the user you wish to use.

```
linode-cli set-user --as-user [username]
```

# [Remove a user from the Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/manage-multiple-accounts-with-the-cli#remove-a-user-from-the-linode-cli)

If you no longer wish to manage a particular user or account from the Linode CLI, you can remove that user. In the command below, replace _[username]_ with the name of the user you wish to remove.

 > Note: 
  This does not delete the user on Akamai Cloud. It only removes the user from the Linode CLI so you can no longer execute commands as that user.

```
linode-cli remove-user [username]
```