# [Get started with the Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli#get-started-with-the-linode-cli)

# [Installation](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli#installation)

To begin, you need to [install and configure](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli) the CLI for use.

# [Basic usage](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli#basic-usage)

To view a list of all Linodes on your account, run the following command:

```
linode-cli linodes list
```

The information shown is based on the information within your own account.

```text Output
┌──────────┬────────────────────┬────────────┬───────────────┬───────────────────────┬─────────┬───────────────────┐
│ id       │ label              │ region     │ type          │ image                 │ status  │ ipv4              │
├──────────┼────────────────────┼────────────┼───────────────┼───────────────────────┼─────────┼───────────────────┤
│ 00000001 │ example-instance   │ us-east    │ g6-standard-1 │ linode/ubuntu18.04    │ running │ 192.0.2.42         │
│ 00001111 │ centos-us-east     │ us-east    │ g6-nanode-1   │ linode/centos-stream9 │ running │ 192.0.2.108       │
└──────────┴────────────────────┴────────────┴───────────────┴───────────────────────┴─────────┴───────────────────┘
```

# [Help](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli#help)

View information about any part of the CLI, including available actions and required parameters, with the `--help` flag:

```
linode-cli --help
linode-cli linodes --help
linode-cli linodes create --help
```

# [Output](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli#output)

To make information easy to ready, the Linode CLI outputs responses in a text-based table format. The data is split into rows and columns, with the top row containing the fields.

```
linode-cli regions list
```

```text Output
┌──────────────┬─────────┬─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┬────────┐
│ id           │ country │ capabilities                                                                                                                                            │ status │
├──────────────┼─────────┼─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────┤
│ ap-west      │ in      │ Linodes, NodeBalancers, Block Storage, GPU Linodes, Kubernetes, Cloud Firewalls, VLANs, Block Storage Migrations, Managed Databases                      │ ok     │
│ ca-central   │ ca      │ Linodes, NodeBalancers, Block Storage, Kubernetes, Cloud Firewalls, VLANs, Block Storage Migrations, Managed Databases                                   │ ok     │
│ ap-southeast │ au      │ Linodes, NodeBalancers, Block Storage, Kubernetes, Cloud Firewalls, VLANs, Block Storage Migrations, Managed Databases                                   │ ok     │
│ us-central   │ us      │ Linodes, NodeBalancers, Block Storage, Kubernetes, Cloud Firewalls, Block Storage Migrations, Managed Databases                                          │ ok     │
│ us-west      │ us      │ Linodes, NodeBalancers, Block Storage, Kubernetes, Cloud Firewalls, Block Storage Migrations, Managed Databases                                          │ ok     │
│ us-southeast │ us      │ Linodes, NodeBalancers, Block Storage, Object Storage, GPU Linodes, Kubernetes, Cloud Firewalls, VLANs, Block Storage Migrations, Managed Databases      │ ok     │
│ us-east      │ us      │ Linodes, NodeBalancers, Block Storage, Object Storage, GPU Linodes, Kubernetes, Cloud Firewalls, Bare Metal, Block Storage Migrations, Managed Databases │ ok     │
│ eu-west      │ uk      │ Linodes, NodeBalancers, Block Storage, Kubernetes, Cloud Firewalls, Block Storage Migrations, Managed Databases                                          │ ok     │
│ ap-south     │ sg      │ Linodes, NodeBalancers, Block Storage, Object Storage, GPU Linodes, Kubernetes, Cloud Firewalls, Block Storage Migrations, Managed Databases             │ ok     │
│ eu-central   │ de      │ Linodes, NodeBalancers, Block Storage, Object Storage, GPU Linodes, Kubernetes, Cloud Firewalls, Block Storage Migrations, Managed Databases             │ ok     │
│ ap-northeast │ jp      │ Linodes, NodeBalancers, Block Storage, Kubernetes, Cloud Firewalls, Block Storage Migrations, Managed Databases                                          │ ok     │
└──────────────┴─────────┴─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┴────────┘
```

## [Fields](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli#fields)

By default, most Linode CLI responses do not contain all the available fields. To keep the information digestible, the Linode CLI outputs a smaller subset of all of available fields. This behavior can be adjusted using the commands below.

- **Limited** (default behavior): Outputs a limited subset of the available fields.
- **All fields** (`--all`): Output all available fields.
- **Specific fields** (`--format 'field1,field2'`): Outputs only the fields specified within the given comma separated list.

## [Output format](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli#output-format)

The Linode CLI can output data in a variety of formats, as disclosed below:

- **Tabular** (default): Data is split into rows and columns, with the top row containing the fields.
- **JSON** (`--json` or `--json --pretty`): Data is structured using JavaScript Object Notation (JSON), typically used for importing into applications that require JSON. The `--pretty` tag is optional and makes the output more human readable.
- **Plain text** (`--text` or `--text --delimiter ","`): Data is outputted as plain text. By default, it uses a _tab_ character as the delimiter, though this can be adjusted by specifying a custom character using the `--delimited ","` option.