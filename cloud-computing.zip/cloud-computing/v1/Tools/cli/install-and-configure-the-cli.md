# [Install and configure the CLI](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#install-and-configure-the-cli)

Review these sections to install the [Linode CLI](https://github.com/linode/linode-cli) locally.

# [Installation](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#installation)

## [Windows, macOS, and Linux (including Ubuntu 23.04 and earlier)](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#windows-macos-and-linux-including-ubuntu-2304-and-earlier)

1. Open a terminal application. For Windows, you can use either Powershell or the command prompt.

2. Run these commands to ensure that Python 3 and `pip3` are both installed. If they're not, see [Other installs: Python and pip](#other-installs-python-and-pip).

   ```
   python3 --version
   pip3 --version
   ```

3. To install Linode CLI, run this command:

   ```
   pip3 install linode-cli --upgrade
   ```

   > > Note: 
   > 
   > If you see an error like this, you need to add your Python's `bin` folder to your system `PATH` environment variable. Steps to do this vary based on your operating system.
   > 
   > ```
   > WARNING: The script normalizer is installed in '/Users/USERNAME/Library/Python/3.9/bin' which is not on PATH.
   > Consider adding this directory to PATH or, if you prefer to suppress this warning, use --no-warn-script-location.
   > ```

4. If you're using Linode's [Object Storage](https://techdocs.akamai.com/cloud-computing/docs/object-storage) service, you also need to install the `boto` library:

   ```
   pip3 install boto3
   ```

5. To confirm installation, run the help command:

   ```
   linode-cli --help
   ```

## [Linux (Ubuntu 23.04 and later)](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#linux-ubuntu-2304-and-later)

These releases of Ubuntu enforce [PEP 668](https://peps.python.org/pep-0668/), which prevents you from installing Python packages system-wide using `pip`. Instead, you can install using `apt` or using `pipx`.

You environment returns this error if `pip` is run:

```output
error: externally-managed-environment

× This environment is externally managed
╰─> To install Python packages system-wide, try apt install
    python3-xyz, where xyz is the package you are trying to
    install.

    If you wish to install a non-Debian-packaged Python package,
    create a virtual environment using python3 -m venv path/to/venv.
    Then use path/to/venv/bin/python and path/to/venv/bin/pip. Make
    sure you have python3-full installed.

    If you wish to install a non-Debian packaged Python application,
    it may be easiest to use pipx install xyz, which will manage a
    virtual environment for you. Make sure you have pipx installed.

    See /usr/share/doc/python3.12/README.venv for more information.

note: If you believe this is a mistake, please contact your Python installation or OS distribution provider. You can override this, at the risk of breaking your Python installation or OS, by passing --break-system-packages.
hint: See PEP 668 for the detailed specification.
```

### [Install using PipX](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#install-using-pipx)

You can use `pipx` to install the Linode CLI, system-wide in an automatically managed isolated environment.

1. Install `pipx`:

   ```command
   sudo apt install pipx -y
   ```

2. Ensure the `pipx` path is configured:

   ```command
   pipx ensurepath
   ```

3. Use `pipx` to install the Linode CLI:

   ```command
   pipx install linode-cli
   ```

4. You can verify installation of the CLI by running the `--help` command:

   ```command
   linode-cli --help
   ```

# [Configure the CLI](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#configure-the-cli)

You need to authenticate your access to the CLI to use it. Use either of these methods to set it up.

## [Interactive configuration](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#interactive-configuration)

With this method, you set up authentication via a token, as you initially interact with the CLI. Each time you interact with it again, you'll need to follow this same process.

1. Initiate the Linode CLI configuration process.

   - **Web-based authentication:** Prompts you to sign in to your account through a web browser.

     ```
     linode-cli configure
     ```

   - **Manually create a personal access token:** Prompts you for a token that you need to manually create. See [Linode API Keys and Tokens](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens).

     ```
     linode-cli configure --token
     ```

2. After authenticating or providing a token, you see a series of prompts to select your preferred defaults, such as the region, Linode type, and distribution. These are optional and can be overridden when running individual commands. Update these defaults at any time by running `linode-cli configure` again or by editing the `.config/linode-cli` configuration file.

## [Non-interactive configuration](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#non-interactive-configuration)

To configure the CLI without any interactive prompts, you can [manually generate a token](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens) and then set it using an environment variable, replacing `[token]`:

```
export LINODE_CLI_TOKEN="[token]"
```

If you don't set this variable, the Linode CLI stops working until you set it again or until you set up the CLI using the interactive configuration method.

# [Other installs: Python and pip](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#other-installs-python-and-pip)

If you don't already have python and pip installed on your system, follow these instructions to get the right versions.

## [Windows](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#windows)

Install Python 3 on Windows by downloading the installer package directly from Python's website:

1. Go to [Python's Downloads page](https://www.python.org/downloads/). Download the latest stable Python 3 package for Windows.

2. Open the installer package that was just downloaded. This is likely a `.exe` file.

3. Within the installer window, check "Add Python 3.x to PATH" and then select **Customize installation**.

4. Ensure that the `pip` option is checked and select **Next**.

5. Under _Advanced Options_, ensure that the following options are checked:

   - Install for all users
   - Associate files with Python
   - Create shortcuts for installed applications
   - Add Python to environment variables
   - Precompiled standard library

6. Select `Next` to proceed with the installation. Once the installation is complete, a message appears confirming that Python 3 was successfully installed.

## [macOS](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#macos)

Install Python 3 on macOS by downloading the package directly from Python's website: 

1. Go to [Python's Downloads page](https://www.python.org/downloads/). Download the latest stable Python 3 package for macOS.

2. Open the installer package to begin the installation.

3. Follow the prompts to install Python3 and pip.

## [Linux](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#linux)

On most Linux distributions, you can use the distribution's package manager to install both the `python3` and `python3-pip` packages.

- **Ubuntu and Debian:** _Ubuntu 22.x, 20.x, 18.x, and 16.x | Debian 11, 10, and 9_

  > > Note: 
  > 
  > If you're using Ubuntu Linux 23.04 or later, you need to [install](#linux-ubuntu-23xx-and-later) the proper version of Python and use `pipx`, rather than standard `pip`. (These versions of Linux don't support installs using `pip`.)

  ```
  sudo apt update
  sudo apt install python3 && sudo apt install python3-pip
  ```

- **CentOS Stream, RHEL 8, and Fedora:** _CentOS Stream 9 (and 8), CentOS 8, other RHEL derivatives (including AlmaLinux 8, and Rocky Linux 8), and Fedora._

  ```
  sudo dnf upgrade
  sudo dnf install python3 && sudo dnf install python3-pip
  ```

- **CentOS 7**

  ```
  sudo yum update
  sudo yum install python3 && sudo yum install python3-pip
  ```

## [Confirm installation](https://techdocs.akamai.com/cloud-computing/docs/install-and-configure-the-cli#confirm-installation)

You can run any of these commands for verify installation:

- `python3 --version` 
- `pip3 --version` (For standard `pip`)
- `pipx --version`

If you receive `command not found`, you may need to add Python3, Pip3, or PipX's locations to your $PATH.