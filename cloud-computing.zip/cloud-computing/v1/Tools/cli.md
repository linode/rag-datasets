# [CLI](https://techdocs.akamai.com/cloud-computing/docs/cli#cli)

The [Linode CLI](https://github.com/linode/linode-cli) is a wrapper around the [Linode API](https://techdocs.akamai.com/linode-api/reference/api), which gives you the ability to manage your Akamai Cloud Computing account from the command line. Almost any task that can be done through Cloud Manager can also be performed through the CLI.

# [Features](https://techdocs.akamai.com/cloud-computing/docs/cli#features)

- **Accelerate common tasks**. Running common tasks is trivial with the CLI. Create Linodes and NodeBalancers, and attach block or object storage volumes without leaving your terminal.
- **Customizable output**. The CLI prints easily readable output by default. You can also specify which fields are returned by the CLI and request JSON responses.
- **Easy scripting**. Everything you can do with the Cloud Manager can be done through the CLI. The CLI has an easy-to-use interface that makes it perfect for scripting.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/cli#availability)

The CLI can be used across [all regions](https://www.linode.com/global-infrastructure/).

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/cli#pricing)

The CLI is provided free of charge to all customers.