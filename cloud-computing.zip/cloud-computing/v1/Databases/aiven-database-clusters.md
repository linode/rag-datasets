# [Managed database clusters](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#managed-database-clusters)

Akamai Managed Databases powered by Aiven combine performance, reliability, and high availability into a fully managed database solution. Databases are used by most organizations to store their business and operational data, including customer information, financial details, application content, e-commerce transactions, and much more. Managing the database infrastructure to store and safeguard this data can put additional stress on the resources you have available. Managed Databases take care of managing this critical infrastructure for you, providing you with an easy to use DBaaS (database-as-a-service) solution built on top of Akamai's trusted and reliable global infrastructure.

# [Specification](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#specification)

Akamai Managed Databases powered by Aiven provide: 

- **Automated deployment**. When a database is deployed through Managed Databases, the infrastructure, software, and firewall, and high availability systems are configured automatically. This can save hours of time compared to manually setting up a database.

- **Automatic updates**. Updates to the underlying software of your database cluster are installed automatically using user-configurable maintenance windows. To learn more, see [Automatic updates and maintenance windows](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#automatic-updates-and-maintenance-window).

- **Access control**. Prevent unauthorized database access by only allowing connections from specific IP addresses or ranges. To learn more, see [Access control](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#access-control) .

- **Daily backups**. Automatic daily backups are provided at no additional cost and are retained for 14 days. You can perform a point in time recovery for each day over the last 14 days.

- Data encyption. To learn more, see [Data encryption](https://aiven.io/docs/platform/concepts/cloud-security#data-encryption) .

- Multiple database engines and versions.

- 100% SSD (Solid State Disk) storage.

- 40 Gbps inbound network bandwidth.

- Free inbound network transfer.

- Provisioning and management through [Linode API](https://techdocs.akamai.com/linode-api/reference/api).

# [High availability](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#high-availability)

Managed Databases powered by Aiven can be configured with one, two, or three underlying machines, also called _nodes_, for dedicated CPU and one or two for shared CPU plan. Three-node clusters provide a highly available database cluster, complete with data redundancy and automatic failover. Your data is replicated across every other node in the cluster. If one goes down, any traffic is redirected to other available nodes.

# [Database engines](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#database-engines)

There are two database management systems (DBMSs) available on Managed Databases:

- **MySQL**. An industry standard relational database management system that uses the SQL query language. Many popular applications (including WordPress) require MySQL or MySQL compatible databases.

- **PostgreSQL**. An object-relational database management system that can use either SQL or JSON queries. It's generally more flexible and feature-rich than MySQL, though it's not a drop-in replacement and applications need to have built-in support for it.

To learn more, see [Database engines and plans](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans).

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#availability)

Managed Databases can be created and deployed across [core compute regions](https://www.linode.com/global-infrastructure/), but aren't supported in distributed compute regions.

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#plans-and-pricing)

| Resource     | Dedicated CPU   | Shared CPU      |
| ------------ | --------------- | :-------------- |
| Cluster size | 1 – 3 nodes     | 1, 2 nodes      |
| vCPU cores   | 64 core         | 32 core         |
| Memory       | 4 GB – 512 GB   | 1 GB – 192 GB   |
| Storage      | 80 GB – 7200 GB | 25 GB – 7200 GB |

To learn about pricing for these database plans, visit the [Pricing](https://www.linode.com/pricing/#databases) page.

Managed Databases don't consume [network transfer](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs) or include a monthly transfer allowance. Transfer is consumed when connecting to a Managed Database from a Linode which is located in a different region.

# [Limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#limits-and-considerations)

Before you create a cluster, you need to be aware of these limitations:

- The root user can't be changed or removed, but its password can be reset at any time.

- You can't access the underlying operating system of a database cluster. Configuration files (such as `my.cnf` ) can't be directly edited and configuration changes done through the `SET PERSIST` command don't persist when the cluster is rebooted.

- Live replicas or standby nodes for high availability Managed Database clusters can't be created or hosted outside of the Managed Database service.

# [Recommended workloads](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#recommended-workloads)

Managed Databases is Akamai Cloud's own Database-as-a-Service (DBaaS) platform. These types of database services allow organizations to offload their database infrastructure and management so they can focus on their own applications and services. 

## [Cost reduction](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#cost-reduction)

Hosting your own database on-premise (or on your own custom cloud architecture) can require you to dedicate a significant budget and lots of IT resources towards its implementation and operation. Offloading this to a dedicated DBaaS solution like Managed Databases has the potential to significantly lower the cost and reduce the complexity. This lets you focus on your business - not your computing infrastructure.

## [Rapid deployment](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#rapid-deployment)

It's often necessary to create short-lived databases quickly and securely. You may want to do this for development, disaster recovery, ephemeral applications, traffic management, and much more. Managed Databases make this process incredibly efficient, allowing you to create databases quickly using Cloud Manager or programmatically through the Linode API.

## [Disaster recovery](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#disaster-recovery)

Every organization should have a comprehensive disaster recovery plan in place to safeguard their data. Every Managed Database provides daily backups that are retained for 14 days and can be restored through a click of a button. This provides an additional layer of data protection on top of your existing strategy. In addition, since Managed Databases can be provisioned quickly, you're able to use this service as part of a disaster recovery plan for on-premise or self-hosted databases.

## [High availability](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#high-availability)

Most production applications greatly benefit from the redundancy and extreme uptime that high availability solutions offer. Managed Databases, when configured with three nodes, provides built-in data replication, redundancy, and automatic failover. This ensures downtime is significantly minimized and applications are always available.

## [Reasons to consider Managed Databases](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters#reasons-to-consider-managed-databases)

You should consider Managed Databases if your organization:

- Has limited IT resources,
- Wants to save cost and reduce complexity,
- Needs to minimize any potential for downtime,
- Wants to extend their disaster recovery plans,
- Needs to rapidly deploy secure databases.

Or, if your applications could use: 

- Databases that require always-on 24/7 access,
- Databases that store critical data,
- Financial industry applications, such as banking and trading,
- Voice and communications platforms,
- E-commerce applications.