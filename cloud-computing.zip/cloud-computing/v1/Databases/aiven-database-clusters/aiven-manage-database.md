# [Create and manage database clusters](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#create-and-manage-database-clusters)

This guide walks you through creating Akamai Managed Databases powered by Aiven through Cloud Manager.

## [Create a new database cluster](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#create-a-new-database-cluster)

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**. 

2. Click **Create Database Cluster**.

3. In the **Cluster Label** field, enter a label allowing you to easily identify the cluster on your account. The label must be alphanumeric and between 3 and 32 characters.

4. Select the **Database Engine** for your new database. This setting determines the underlying database management system (DBMS) that your cluster uses. Each database engine is significantly different and you should choose the one that is required by the application you intend to use it with. For instance, WordPress requires MySQL. If you are building a custom application, work with your developers to determine the best selection. To learn more on available database engines, see [Database engines and plans](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans).

   > > Note: 
   > 
   > It's recommended to select the latest database version available, unless your application requires an older version.

5. Select the **Region** where the database cluster will reside. Regions correspond with individual data centers, each located in a different geographical area. If you will access this database from a Linode or LKE cluster, you should select the same region as those services. Otherwise, select the region closest to you and/or your customers. This helps reduce latency and can make a significant impact in connection speeds and quality. To learn more on available regions, check these resources:
   - [Global Infrastructure](https://www.linode.com/global-infrastructure/).
   - [Speed Tests for Data Centers](https://www.linode.com/speed-test/).
   - [How to Choose a Data Center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center).

6. Every node of a database cluster is built on its own Linode. In the _Choose a Plan_ section, select the Linode type and plan that the nodes will use. You can choose from either [Premium CPU](https://techdocs.akamai.com/cloud-computing/docs/premium-compute-instances), [Dedicated CPU](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances) and [Shared CPU](https://techdocs.akamai.com/cloud-computing/docs/shared-cpu-compute-instances) plans. In general, Dedicated CPU plans are recommended for high-performance production databases. To learn more about types and plans, see [Choose a Linode Instance plan](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan).

7. Determine the number of nodes the cluster will use:
   1. For Dedicated CPU and Premium CPU, you can choose:
      - **1 node standalone database**: This option is designed for development purposes or production databases where a lower cost is more beneficial than redundancy and failover.
      - **2 and 3 node high availability database cluster**: These options are designed for product databases. High availability database clusters have built-in data redundancy and automatic failover. Your data is replicated across every other node in the cluster. If one goes down, any traffic is redirected to the other available nodes.
   2. For Shared CPU, you can choose:
      - **1 node standalone database**: This option is designed for development purposes or production databases where a lower cost is more beneficial than redundancy and failover.
      - **3 node high availability database cluster**: This option is designed for product databases. High availability database clusters have built-in data redundancy and automatic failover. Your data is replicated across every other node in the cluster. If one goes down, any traffic is redirected to the other available nodes.

8. In the _Manage Access_ section, select whether you want to provide **Specific Access** or **No access**:

   1. For **Specific Access**, into the field, enter an IP address or ranges you want to allow access your new database cluster. Each Managed Database cluster has its own access control list, which grants specific IP addresses or ranges access to the database. Click **Add Another IP Address**, to add more entries. If you are testing the connection from your local machine, you may also wish to enter the IP address that your ISP has assigned to your machine. One way you can find this out is by typing ["What's my IP"](https://www.google.com/search?q=what%27s+my+ip) into Google.
   2. Or select **No access**. This blocks access to you database cluster to all IP addresses. 

9. **Optional (Beta)**: If you want to assign a VPC to the cluster to enhance security and performance of the cluster and you have a VPC in the same region as the cluster, in the _Assign a VPC_ section:

   1. Select a **VPC** you want the cluster to be assigned to. Note that the dropdown shows only VPCs from the region selected in step 5. If you see this option disabled, it means that you don't have any VPCs in the selected region.
   2. Select a **Subnet** you want the cluster to use.
   3. **Optional**:  To add a public endpoint to your database alongside the private VPC endpoint, select the **Enable Public Access** option. By default, the database cluster’s hostname resolves to a private IPv4 address within the VPC subnet. When public access is enabled, an additional hostname becomes available that resolves to a publicly routable IPv6 and/or IPv4 address.

   The public hostname for a cluster in a VPC will show once you create the database cluster, in the _Connection Details_ section. Replace the `private-` prefix with `public-` to obtain the publicly routable hostname.

   > > Warning: VPC integration limitations
   > 
   > - Private IPv6 addresses for databases with a VPC assigned are currently unavailable. We're working on enabling it soon.
   > - For additional security, when assigning a VPC to a cluster, we recommend you block inbound connections from the database cluster's VPC IP range with a Cloud Firewall on all Linodes in the VPC. To learn how, see [Manage firewall rules - Add rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules#add-rules). To get the database cluster's IP ranges on the subnet in which you place the database cluster, [view VPC subnets](https://techdocs.akamai.com/cloud-computing/docs/manage-vpc-subnets#view-subnets).
   > - Managed Database currently works only with VPC subnets that exclusively use an IPv4 subnet range. We're working on enabling the dual-stack IPv6/IPv4 VPC subnet support soon.

   > > Note: 
   > 
   > Clusters with no VPC assigned have public access enabled by default.

10. Click **Create Database Cluster**. It takes approximately 10 to 15 minutes to fully provision the cluster. You can track the status by reviewing the _Status_ column in the Database Clusters list.

  

# [Suspend a cluster](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#suspend-a-cluster)

If you don't use a database cluster, you can suspend it so that you won't be billed for it. If you won't use the cluster any more, you can [delete it](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#delete-a-managed-database-cluster).

To suspend a cluster:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.
2. Select a cluster from the list. 
3. Go to the **Settings** tab. In the _Suspend Cluster_ section, click **Suspend Cluster**. Confirm your decision in the pop-up.

**What to do next**: You can resume the cluster within 180 days from its suspension. After this time, it will be deleted automatically. 

## [Resume a cluster](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#resume-a-cluster)

You can resume a cluster within 180 days from its suspension. 

To resume:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.
2. Select a cluster from the list. 
3. Go to the **Settings** tab. In the _Suspend Cluster_ section, click **Resume Cluster**. Confirm your decision in the pop-up.

  

# [Access control](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#access-control)

Each Managed Database cluster has its own access control list, which allows specific IPv4 addresses or ranges to connect to the database. By default, all connections both public and private are blocked unless they appear on this list.

There are four types of access:

- No access. If you don't provide any IP addresses, the database won't allow any connections.

- Open access. Enter the _::/0_ (IPv6) or _0.0.0.0/0_ (IPv4) IP address to allow connections from any IP address.

- Individual access. Enter a specific IP address to grant an individual system access. 

- Range access. Enter a range to allow connections from an entire range of IP addresses by specifying the prefix and the prefix length. 

 > Note: Private IP connectivity
  The connection to a database cluster over a private IP address is not supported. We recommend connecting over public IPv6 addresses which saves [egress cost](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#usage-costs). You can also use public IPv4 but this incurs egress cost. 
  We’re working on the integration of managed databases with VPC which will enable private connectivity. However, apart from VPC, private connectivity will not be supported.

## [IPv6 support](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#ipv6-support)

Use an IPV6 address (AAAA record) for a hostname to avoid [network transfer charges](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs)  when connecting to your database from Linodes within the same region. 

To avoid connection timeouts:

1. Use one of the popular websites like `whatismyip.com` to check if your ISP supports an IPv6 public address.  
   1. If the website returns no IPv6, it means that you're connecting from an ISP that doesn't support IPv6 and there are no further actions for you to do.  
      
   2. If you're connecting from an ISP that does support IPv6, copy the IPv6 address and add it to your [access control settings](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#edit-access-control-settings).
   3. If you're connecting from Linodes, [check IPv6 address of your instance](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#viewing-ip-addresses) and add it to your [access control settings](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#edit-access-control-settings).

## [LKE and database clusters connectivity](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#lke-and-database-clusters-connectivity)

To  simplify and automate connectivity between your Linode Kubernetes Engine (LKE) nodes and Managed Databases there's a backgroud process that runs automatic updates to your database Access Control Lists (ACLs)  and manages database access permissions for you.

Things you need to know about the process:

- Each Managed Database cluster in your account automatically updates its ACL every 10 minutes to include the IP address (IPv4 and IPv6) from all LKE nodes in your account, ensuring that newly created, recycled, or auto-scaled nodes can connect to your databases without requiring manual IP access list changes.
- The firewall rules remain unchanged. The process only affects database ACLs used to authorize LKE node connections. Your existing firewall rules and security policies remain fully under your control and won't be modified. If you already added IP addresses to database ACL not related to LKE clusters, those entries remain unchanged.

### [Opt-out options](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#opt-out-options)

If you prefer not to use automatic ACL updates, you can opt out on two levels:

1. Account-level opt-out. Disable automatic ACL updates for all Managed Database clusters in your account.
2. Database cluster-level opt-out. Disable automatic ACL updates for specific clusters.

To use one of those options, contact our [customer support team](https://techdocs.akamai.com/cloud-computing/docs/help-and-support#contact-customer-support). We're working on offering more options to manage this setting through the LKE platform and tools.

## [Edit access control settings](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#edit-access-control-settings)

To edit access control settings:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.

2. Select a cluster from the list. 

3. Go to the **Networking** tab and in the _Manage Access_ section, click **Manage Access**. 

4. Depending on the action you want to perform, follow the corresponding procedure:

- To add an IP or a range, click **Add an IP**. Enter a value and click **Update Access Controls**.
- To edit an entry, click the field with the value you want to edit and make necessary changes. Click **Update Access Controls**.
- To remove an entry, click **x** next to the value you want to remove and click **Update Access Controls**. You can also remove entries directly in the **Settings** tab, in the **Access Controls** section, by clicking **Remove** next to the entry of interest and confirming the decision.

  

# [Manage networking (Beta)](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#manage-networking-beta)

You can use the _Manage Networking_ section to:

- Assign a VPC, if your cluster has no VPC assigned yet. This enhances security and performance of your managed database cluster. You can only assign VPCs that are in the same region as the database cluster. The assignment can be also configured while creating a new cluster, to learn more see [Create a new database cluster](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#create-a-new-database-cluster).
- Change the VPC assignment, if the cluster already have a VPC assigned but you want to change it.
- Unassign the VPC from the cluster.

  

 > Warning: VPC integration limitations
  - Private IPv6 addresses for databases with a VPC assigned are currently unavailable. We're working on enabling it soon.
 - For additional security, when assigning a VPC to a cluster, we recommend you block inbound connections from the database cluster's VPC IP range with a Cloud Firewall on all Linodes in the VPC. To learn how, see [Manage firewall rules - Add rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules#add-rules). To get the database cluster's IP ranges on the subnet in which you place the database cluster, [view VPC subnets](https://techdocs.akamai.com/cloud-computing/docs/manage-vpc-subnets#view-subnets).
 - Managed Database currently works only with VPC subnets that exclusively use an IPv4 subnet range. We're working on enabling the dual-stack IPv6/IPv4 VPC subnet support soon.

With a VPC assigned, the database resources operate within completely isolated network boundaries and database traffic uses private addresses which eliminates external exposure.

 > Warning: 
  Any change of the networking settings causes a temporary downtime during the transition.

To manage networking:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.

2. Select a cluster from the list. 

3. Go to the **Networking** tab and in the _Manage Networking_ section, click **Manage Networking**.

4. To assign a VPC, if your cluster has no VPC assigned yet, or to change the VPC assignment:
   1. Select a **VPC** you want the cluster to be assigned to. Note that the dropdown shows only VPCs from the region of your database cluster. If you see this option disabled, it means that you don't have any VPCs in the selected region.
   2. Select a **Subnet** you want the cluster to use.
   3. **Optional**:  To add a public endpoint to your database alongside the private VPC endpoint, select the **Enable Public Access** option. By default, the database cluster’s hostname resolves to a private IPv4 address within the VPC subnet. When public access is enabled, an additional hostname becomes available that resolves to a publicly routable IPv6 and/or IPv4 address.  
      The public hostname for a cluster in a VPC will show once you create the database cluster, in the _Connection Details_ section. Replace the `private-` prefix with `public-` to obtain the publicly routable hostname.

5. To unassign a VPC from the cluster:

   1. Click **Unassign VPC**.

   > > Note: 
   > 
   > The unassignment of the VPC will make the cluster accessible only via its public IP.

   2. Confirm your decision.
   3. Review the allowed IP list in the [Manage Access](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#edit-access-control-settings)  sectionto help prevent unauthorized access.
   4. Clear DNS caches to ensure that applications resolve the new IP addresses correctly.

# [Automatic updates and maintenance window](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#automatic-updates-and-maintenance-window)

With the Managed Databases service, the database cluster is updated regularly. This includes security updates and patches for the underlying operating system. These updates occur on a maintenance window that you can configure. By default, the maintenance window is set to start _every week_ on _Sunday_ at _20:00 UTC_ and lasts for 3 hours.

 > Warning: 
  If your database cluster is configured with a single node, the cluster will experience downtime during this maintenance window when any updates occur. 
  - Adjust this window to match a time that's the least disruptive for your application and users. 
 - Consider upgrading to a high availability plan, which provides additional nodes and enables automatic failover between them. 
  While the cluster may still experience a momentary loss of connectivity when a failover occurs, downtime is greatly reduced.

 > Note: 
  **The database software is not updated automatically.** To upgrade to a new version (such as from MySQL 5.7.30 or 8.0.25 to 8.0.26), consider deploying a new Managed Database with the version you want to use. Then, you can migrate your databases from the original Managed Database cluster to the new one.

## [View and modify the maintenance window](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#view-and-modify-the-maintenance-window)

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.

2. Select a cluster from the list. 

3. Go to the **Settings** tab. In the _Set a Weekly Maintenance Window_ section, you can see how often the maintenance happens and when.

4. To edit the maintenance window, edit the settings and click **Save Changes**.

  

# [Reset the root password](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#reset-the-root-password)

If someone should no longer have access to the `linroot` user or if you believe your password may have been compromised, you can reset the root password to assign a new randomly generated password to the `linroot` user.

 > Error: 
  Resetting the root password will prevent you from restoring all previously taken backups. Ensure that you have offsite backups available if needed.

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.

2. Select a cluster from the list you want to reset the password for. 

3. Go to the **Settings** tab.

4. In the _Reset the Root Password_ section, click **Reset Root Password** and confirm your decision. A new password gets generated automatically within a few minutes. To view the new password, go to the **Summary** tab and in the _Connection Details_ section, click  **Show** next to the _password_.

  

# [Manage backups](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#manage-backups)

Each Managed Database includes daily backups of your data, taken on a 24 hour cadence. Up to 14 days backups are stored for each database cluster, which provides you with a restore point for each day in the last week. 

## [Restore managed backups](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#restore-managed-backups)

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.

2. Select a cluster from the list.

3. Go to the **Backups** tab. 

4. In the _Restore a Backup_ section, select either: 
   - **Newest full backup plus incremental**
   - Or **Specific date & time** and from the calendar below select the specific point in time.

5. Click **Restore**.

6. To confirm, click **Restore**. A forked cluster is getting provisioned. 

  

**What to do next**:

To prevent additional billing for the increased number of clusters running, [delete the original cluster](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#delete-a-managed-database-cluster).

  

# [Resize a Managed Database cluster](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#resize-a-managed-database-cluster)

You can upscale database clusters to adapt them to your needs.  Clusters cannot be resized to smaller plans.

 > Error: 
  This operation causes downtime for the resized node clusters.

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.

2. Select a cluster from the list. 

3. Go to the **Resize** tab.

4. In the _Choose a plan_ or _Set Number of Nodes_ sections, implement your changes to resize the cluster.

5. In the _Summary_ section, verify the changes. Click **Resize Database Cluster**.

6. Follow the on-screen instructions and click **Resize Cluster** to confirm. The cluster will be upscaled within two hours.

# [Manage advanced configuration of a cluster](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#manage-advanced-configuration-of-a-cluster)

You may need to configure advanced parameters of your database cluster. For the full list of available parameters, see [Advanced configuration parameters](https://techdocs.akamai.com/cloud-computing/docs/advanced-configuration-parameters).

 > Warning: 
  Addition of some parameters causes restart of the database cluster.

To manage advanced configuration:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.
2. Select a cluster from the list. 
3. Go to the **Advanced Configuration** tab.
4. If your cluster doesn't have any configuration saved yet, click **Configure**.
   1. From the **Add a Configuration Option** dropdown, select a parameter you want to add and click **Add**. The parameter is now available below for configuration. 
   2. Specify the parameter's value.
   3. **Optional**: Continue adding parameters.
   4. Click **Save** or, if you added a parameter that causes restart of the cluster, **Save and restart service**.
5. If your cluster already has an advanced configuration saved, click **Configure**.
   1. Modify the values of added parameters.
   2. **Optional**: Continue adding parameters.
   3. Click **Save** or, if you added a parameter that causes restart of the cluster, **Save and restart service**.

# [Delete a Managed Database cluster](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#delete-a-managed-database-cluster)

To prevent additional costs for clusters you're no longer using, you need to delete them.

To delete a cluster:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.

2. Select a cluster from the list. 

3. Go to the **Settings** tab.

4. In the _Delete the Cluster_ section, click **Delete cluster**.

5. Follow the on-screen instructions and click **Delete**.