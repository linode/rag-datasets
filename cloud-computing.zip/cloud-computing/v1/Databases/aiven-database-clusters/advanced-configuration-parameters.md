# [Advanced configuration parameters](https://techdocs.akamai.com/cloud-computing/docs/advanced-configuration-parameters#advanced-configuration-parameters)

Check the advanced configuration parameters available for your database:

- [MySQL](https://techdocs.akamai.com/cloud-computing/docs/advanced-configuration-parameters#mysql-parameters) 
- [PostgreSQL](https://techdocs.akamai.com/cloud-computing/docs/advanced-configuration-parameters#postgresql-parameters) 

# [MySQL parameters](https://techdocs.akamai.com/cloud-computing/docs/advanced-configuration-parameters#mysql-parameters)

| Parameter | Description |
|---|---|
| `binlog_retention_period` | Minimum number of seconds to keep `binlog` entries before deletion. This may be extended for services that require `binlog` entries for longer than the default, for example the MySQL Debezium Kafka connector. |
| `mysql.connect_timeout`\* | Number of seconds the MySQL server waits for a connect packet before responding with the Bad Handshake error. |
| `mysql.default_time_zone`\* | Default server time zone as an offset from UTC (from -12:00 to +12:00), a time zone name, or `SYSTEM` to use the MySQL server default. |
| `mysql.group_concat_max_len`\* | Maximum permitted result length in bytes for the `GROUP_CONCAT()` function. |
| `mysql.information_schema_stats_expiry`\* | Number of seconds before cached statistics expire. |
| `mysql.innodb_change_buffer_max_size`\* | Maximum size for the `InnoDB` change buffer, as a percentage of the total size of the buffer pool. The default value is `25`. |
| `mysql.innodb_flush_neighbors`\* | Specifies whether flushing a page from the `InnoDB` buffer pool also flushes other dirty pages in the same extent. Available values: - `0` - dirty pages in the same extent are not flushed, - `1` - flush contiguous dirty pages in the same extent, - `2` - flush dirty pages in the same extent The default value is `1`. |
| `mysql.innodb_ft_min_token_size`\* | Minimum length of words to be stored in an `InnoDB` full-text index. Change of this parameter causes a restart of the MySQL service. |
| `mysql.innodb_ft_server_stopword_table`\* | Specifies your own `InnoDB` full-text index stopword list for all `InnoDB` tables. |
| `mysql.innodb_lock_wait_timeout`\* | Number of seconds an `InnoDB` transaction waits for a row lock before giving up. The default value is `120`. |
| `mysql.innodb_log_buffer_size`\* | Number of bytes of the buffer that `InnoDB` uses to write to the log files on disk. |
| `mysql.innodb_online_alter_log_max_size`\* | Upper limit in bytes of the size of the temporary log files used during online DDL operations for `InnoDB` tables. |
| `mysql.innodb_read_io_threads`\* | Number of I/O threads for read operations in `InnoDB`. The default value is `4`. Change of this parameter causes the restart of the MySQL service. |
| `mysql.innodb_rollback_on_timeout`\* | Whether a transaction timeout causes `InnoDB` to abort and roll back the entire transaction. Change of this parameter causes the restart of the MySQL service. |
| `mysql.innodb_thread_concurrency`\* | Maximum number of threads permitted inside of `InnoDB`. The default value is `0`, meaning infinite concurrency (no limit). |
| `mysql.innodb_write_io_threads`\* | Number of I/O threads for write operations in `InnoDB`. The default value is `4`. Change of this parameter causes the restart of the MySQL service. |
| `mysql.interactive_timeout`\* | Number of seconds the server waits for activity on an interactive connection before closing it. |
| `mysql.internal_tmp_mem_storage_engine`\* | Storage engine for in-memory internal temporary tables. |
| `mysql.max_allowed_packet`\* | Size of the largest message in bytes that can be received by the server. The default value is `67108864` (64M). |
| `mysql.max_heap_table_size`\* | Upper limit of the size of internal in-memory tables. The default value is `16777216` (16M). Combine this parameter with `mysql.tmp_table_size`. |
| `mysql.net_buffer_length`\* | Start sizes of the connection and result buffers. The default value is `16384` (16K). Change of this parameter causes the restart of the MySQL service. |
| `mysql.net_read_timeout`\* | Number of seconds to wait for more data from a connection before aborting the read. |
| `mysql.net_write_timeout`\* | Number of seconds to wait for a block to be written to a connection before aborting the write. |
| `mysql.sort_buffer_size`\* | Sort buffer size in bytes for the `ORDER BY` optimization. The default value is `262144` (256K). |
| `mysql.sql_mode`\* | Global SQL mode. To use MySQL server defaults, set it to empty. If this field is not set when creating a new service, the Aiven default SQL mode (strict, SQL standard compliant) is assigned. |
| `mysql.sql_require_primary_key`\* | Requires a primary key to be defined for new tables or old tables modified with `ALTER TABLE` and fails if missing. It's recommended to always have primary keys because various functionality may break if any large table is missing them. |
| `mysql.tmp_table_size`\* | Upper limit of the size of internal in-memory tables. The default value is `16777216` (16M). Combine this parameter with `mysql.max_heap_table_size`. |
| `mysql.wait_timeout`\* | Number of seconds the server waits for activity on a noninteractive connection before closing it. |

\*`mysql.conf` configuration values

# [PostgreSQL parameters](https://techdocs.akamai.com/cloud-computing/docs/advanced-configuration-parameters#postgresql-parameters)

| Parameter | Description |
|---|---|
| `pg.autovacuum_analyze_scale_factor`\*\* | Fraction of the table size to add to `autovacuum_analyze_threshold` when deciding whether to trigger an `ANALYZE`. The default value is `0.2` (20% of the table size). |
| `pg.autovacuum_analyze_threshold`\*\* | Minimum number of inserted, updated, or deleted tuples needed to trigger an `ANALYZE` in any one table. The default value is `50`. |
| `pg.autovacuum_max_workers`\*\* | Maximum number of autovacuum processes (other than the autovacuum launcher) that may be running at any one time. The default value is `3`. This parameter can only be set at server start. |
| `pg.autovacuum_naptime`\*\* | Minimum delay in seconds between autovacuum runs on any given database. The default value is `60`. |
| `pg.autovacuum_vacuum_cost_delay`\*\* | Cost delay in milliseconds to be used in automatic `VACUUM` operations. If it's set to `-1`, the regular `vacuum_cost_delay` value is used. The default value is `20`. |
| `pg.autovacuum_vacuum_cost_limit`\*\* | Cost limit that will be used in automatic `VACUUM` operations. If it's set to `-1`, the regular `vacuum_cost_limit` value is used. The default value is `-1`. |
| `pg.autovacuum_vacuum_scale_factor`\*\* | Fraction of the table size to add to `autovacuum_vacuum_threshold` when deciding whether to trigger a `VACUUM`. The default value is `0.2` (20% of table size). |
| `pg.autovacuum_vacuum_threshold`\*\* | Minimum number of updated or deleted tuples needed to trigger a `VACUUM` in any one table. The default value is `50`. |
| `pg.bgwriter_delay`\*\* | Delay between activity rounds for the background writer in milliseconds. The default value is `200`. |
| `pg.bgwriter_flush_after`\*\* | Whenever more than this amount of data in kilobytes has been written by the background writer, attempt to force the OS to issue these writes to the underlying storage. The default value is `512`. Setting this to `0` disables forced writeback. |
| `pg.bgwriter_lru_maxpages`\*\* | Number of buffers to be written by the background writer in each round. Setting this to zero disables background writing. The default value is `100`. |
| `pg.bgwriter_lru_multiplier`\*\* | Number by which the average recent need for new buffers is multiplied by to arrive at an estimate of the number to be needed during the next round, (up to `bgwriter_lru_maxpages`). `1.0` represents a _just-in-time_ policy of writing exactly the number of buffers predicted to be needed. Larger values provide some cushion against spikes in demand. Smaller values intentionally leave writes to be done by server processes. The default value is `2.0`. |
| `pg.deadlock_timeout`\*\* | Number of milliseconds to wait on a lock before checking to see if there is a deadlock condition. |
| `pg.default_toast_compression`\*\* | Specifies the default `TOAST` compression method for values of compressible columns. The default value is `lz4`. |
| `pg.idle_in_transaction_session_timeout`\*\* | Number of milliseconds for sessions with open transactions to time out. |
| `pg.jit`\*\* | Controls system-wide use of Just-in-Time Compilation (JIT). |
| `pg.max_files_per_process`\*\* | Maximum number of files that can be open per process. |
| `pg.max_locks_per_transaction`\*\* | Maximum number of locks per transaction. |
| `pg.max_logical_replication_workers`\*\* | Maximum number of logical replication workers taken from the pool of `max_parallel_workers`. |
| `pg.max_parallel_workers`\*\* | Maximum number of workers that the system can support for parallel queries. |
| `pg.max_parallel_workers_per_gather`\*\* | Maximum number of workers that can be started by a single Gather or Gather Merge node. |
| `pg.max_pred_locks_per_transaction`\*\* | Maximum number of prepared transactions. |
| `pg.max_replication_slots`\*\* | Maximum number of replication slots. |
| `pg.max_slot_wal_keep_size`\*\* | Maximum WAL size in megabytes reserved for replication slots. The default value is `-1`, meaning unlimited. The `wal_keep_size` minimum WAL size setting takes precedence over this. |
| `pg.max_stack_depth`\*\* | Maximum depth of the stack in bytes. |
| `pg.max_standby_archive_delay`\*\* | Maximum standby archive delay in milliseconds. |
| `pg.max_standby_streaming_delay`\*\* | Maximum standby streaming delay in milliseconds. |
| `pg.max_wal_senders`\*\* | Maximum number of WAL senders. |
| `pg.max_worker_processes`\*\* | Maximum number of background processes that the system can support. |
| `pg.password_encryption`\*\* | Algorithm for encrypting passwords. |
| `pg.pg_partman_bgw.interval`\*\* | Time interval to run `pg_partman` scheduled tasks. |
| `pg.pg_partman_bgw.role`\*\* | Sets the role to use for `pg_partman` scheduled background tasks. |
| `pg.pg_stat_monitor.pgsm_enable_query_plan` | Enables or disables query plan monitoring. |
| `pg.pg_stat_monitor.pgsm_max_buckets` | Maximum number of buckets. |
| `pg.pg_stat_statements.track`\*\* | Controls which statements are counted. Available values are: - `top`. Tracks top-level statements (issued directly by clients). - `all`. Tracks nested statements (such as statements invoked within functions). - `none`. Disables statement statistics collection. The default value is `top`. |
| `pg.temp_file_limit`\*\* | Temporary file limit in kilobytes, `-1` is for unlimited. |
| `pg.timezone`\*\* | Service timezone. |
| `pg.track_activity_query_size`\*\* | Number of bytes reserved to track the currently executing command for each active session. |
| `pg.track_commit_timestamp`\*\* | Record commit time of transactions. |
| `pg.track_functions`\*\* | Enables tracking of function call counts and time used. |
| `pg.track_io_timing`\*\* | Enables timing of database I/O calls. By default, this parameter is `off`, because it will repeatedly query the operating system for the current time, which may cause significant overhead on some platforms. |
| `pg.wal_sender_timeout`\*\* | Number of milliseconds for which replication connections need to be inactive to be terminated. Setting it to `0` disables the timeout. |
| `pg.wal_writer_delay`\*\* | WAL flush interval in milliseconds. Setting this value to lower than the default `200` may negatively impact performance. |
| `pg_stat_monitor_enable` | Enables the `pg_stat_monitor` extension. With the extension enabled, `pg_stat_statements` results for utility commands are unreliable. Use of this parameter causes restart of the cluster. |
| `pglookout.max_failover_replication_time_lag`\*\*\* | Number of seconds of master unavailability before triggering database failover to standby. |
| `shared_buffers_percentage` | Percentage of total RAM that the database server uses for shared memory buffers. Valid range is 20-60 (float), which corresponds to 20% - 60%. This setting adjusts the `shared_buffers` configuration value. |
| `work_mem` | Maximum amount of memory in megabytes to be used by a query operation (such as a sort or hash table) before writing to temporary disk files. The default value is `1` + 0.075% of total RAM (up to 32MB). |

\*\* - `postgresql.conf` configuration values.

\*\*\* - System-wide settings for `pglookout`.