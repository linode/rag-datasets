# [Monitor database clusters (Beta)](https://techdocs.akamai.com/cloud-computing/docs/monitor-database-cluster#monitor-database-clusters-beta)

Akamai Cloud Pulse (ACLP) is a comprehensive monitoring solution designed to provide visibility for cloud core services and managed services. 

To see the data it collects for Databases:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and from the main menu, select **Databases**.

2. Select a cluster from the list. 

3. Open the **Metrics** tab.

## [Collected data](https://techdocs.akamai.com/cloud-computing/docs/monitor-database-cluster#collected-data)

Akamai Cloud Pulse supports the following parameters for Databases:

| Dimension        | Definition                                                                                                     |
| :--------------- | :------------------------------------------------------------------------------------------------------------- |
| Database Cluster | Group of databases or servers connected to a system to improve performance, availability, and scalability.     |
| Database Engine  | Underlying system that a database uses to operate. Currently we support MySQL and PostgreSQL database engines. |
| Node Type        | Represents whether a node in a cluster is primary or secondary.                                                |
| Region           | Localized geographic area where one or more data centers are located.                                          |

| Metric               | Definition                                                                                                                                                    | Unit |
| :------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------ | :--- |
| Available Disk Space | Amount of storage space on a disk drive that is not currently being used.                                                                                     | GB   |
| Available Memory     | Amount of memory which is available for allocation to a new process or to existing processes.                                                                 | GB   |
| CPU Usage            | Amount of load handled by individual processor cores to run various programs on a Virtual Machine (VM), expressed as a percentage of the total available CPU. | %    |
| Disk I/O Read        | Amount of the read operations a storage disk can perform per second.                                                                                          | IOPS |
| Disk I/O Write       | Amount of the write operations a storage disk can perform per second.                                                                                         | IOPS |
| Disk Space Usage     | Measurement of a VM's disk usage for tasks and programs expressed as a percentage of the total available disk space.                                          | %    |
| Memory Usage         | Amount of memory a VM uses at any given time expressed as a percentage of the total available memory.                                                         | %    |