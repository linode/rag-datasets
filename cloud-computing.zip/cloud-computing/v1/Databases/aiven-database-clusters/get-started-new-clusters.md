# [Get started with managed databases](https://techdocs.akamai.com/cloud-computing/docs/get-started-new-clusters#get-started-with-managed-databases)

The managed database service is a convenient and reliable way to host your database workloads in the cloud.

# [Create a managed database](https://techdocs.akamai.com/cloud-computing/docs/get-started-new-clusters#create-a-managed-database)

A Managed Database can be deployed using Cloud Manager or the Linode API. For instructions on deploying it through Cloud Manager, check out these guides:

- [Create a managed database](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#create-a-new-database-cluster).
- [Database engines and plans](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans).

# [Connect to your database](https://techdocs.akamai.com/cloud-computing/docs/get-started-new-clusters#connect-to-your-database)

Once a managed database has been provisioned, you can connect to it from any compatible system or applications. Before you do so, the system's IP address needs to be added to the database cluster's access control list.

- [Manage Access Controls](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#access-control)
- [Connect to a MySQL Managed Database](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-to-a-mysql-managed-database)
- [Connect to a PostgreSQL Managed Database](https://techdocs.akamai.com/cloud-computing/docs/aiven-postgresql#connect-to-a-postgresql-database)

# [Monitor your database](https://techdocs.akamai.com/cloud-computing/docs/get-started-new-clusters#monitor-your-database)

Akamai Cloud Pulse (ACLP) is a comprehensive monitoring solution designed to provide visibility for cloud core services and managed services. It provides also data for the Database service. To learn more, see [Monitor database clusters](https://techdocs.akamai.com/cloud-computing/docs/monitor-database-cluster).

# [Migrate an existing database](https://techdocs.akamai.com/cloud-computing/docs/get-started-new-clusters#migrate-an-existing-database)

If you're replacing an existing database with our Managed Database service, you need to migrate that data after the database cluster has fully provisioned. See [Migrate a MySQL database to a Managed Database](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#migrate-a-mysql-database-to-a-managed-database)  or [Migrate a PostgreSQL database to a Managed Database](https://techdocs.akamai.com/cloud-computing/docs/aiven-postgresql#migrate-a-postgresql-database-to-a-managed-database) 

# [Integrate the database into an application](https://techdocs.akamai.com/cloud-computing/docs/get-started-new-clusters#integrate-the-database-into-an-application)

While it's possible to add data directly to a database using CLI or GUI tools, it's much more common to integrate the database into an existing application. For instance, you can use the database with any web stack that uses your chosen database engine (DBMS) such as [LEMP](https://linode.com/docs/guides/web-servers/lemp/) / [LAMP](https://linode.com/docs/guides/web-servers/lamp/) for MySQL. When using a Managed Database, you can forgo installing the database locally on the system and instead use the credentials and connection details for your Managed Database. The instructions for connecting to a remote database vary by application. For example, here's a guide for WordPress: [Configure WordPress to use a Remote Database](https://linode.com/docs/guides/configure-wordpress-remote-database/).