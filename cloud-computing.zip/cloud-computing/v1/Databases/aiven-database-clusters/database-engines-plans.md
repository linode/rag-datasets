# [Database engines and plans](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans#database-engines-and-plans)

When deploying Akamai Managed Databases powered by Aiven, you are able to select from a variety of database engines and plans. While each database engine enables you to store data, application compatibility and the way in which they store and access data can vary greatly. 

# [Database engines](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans#database-engines)

## [MySQL](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans#mysql)

MySQL is an industry standard relational database management system (RDMBS) that uses the SQL query language. Compared to other databases, it's relatively easy to use and its large community means there are lots of online resources available. MySQL values performance and accessibility over pure SQL compliance, so its syntax can slightly differ from strict SQL. Many popular applications (including WordPress) require MySQL or a MySQL compatible database.

MySQL Managed Databases are recommended for general-purpose websites and applications, e-commerce sites, applications employing LAMP or LEMP stacks, and for beginner database developers looking for robust online resources.

## [PostgreSQL](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans#postgresql)

PostgreSQL is an object-relational database management system (ORDBMS) that can use SQL. It's more flexible and feature-rich than MySQL, though it's not a drop-in replacement and applications need to have built-in support for it. It also has support for more data types, including JSON, and adopts some features of NoSQL databases. While PostgreSQL is generally more challenging to implement, it can support more advanced queries and is a popular choice for enterprise applications.

PostgreSQL Managed Databases are recommended for experienced SQL developers, applications that perform complex queries, using PostgreSQL-specific features, and for business users looking for dedicated commercial support.

# [Database plans](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans#database-plans)

Each Managed Database can be deployed with a specific set of resources. This collection of resources is called the _plan_. Akamai offers three plan types for Managed Databases: [Premium CPU](https://techdocs.akamai.com/cloud-computing/docs/premium-compute-instances), [Dedicated CPU](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances), and [Shared CPU](https://techdocs.akamai.com/cloud-computing/docs/shared-cpu-compute-instances).

## [Maximum number of connections](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans#maximum-number-of-connections)

 > Tip: 
  To extend the default limits for number of connections, contact the Support team.

### [MySQL](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans#mysql)

The number of maximum simultaneous connections for MySQL depends on RAM your service plan offers:

- Below 4GiB: 100/GiB
- 4 GiB or more: 200/GiB

### [PostgreSQL](https://techdocs.akamai.com/cloud-computing/docs/database-engines-plans#postgresql)

The number of maximum simultaneous connections for PostgreSQL equals 100/GiB on RAM your service plan offers, with the maximum value of 2000.

To learn more about connection pooling and maximum number of connections for PostgreSQL, see [Connection pooling](https://aiven.io/docs/products/postgresql/concepts/pg-connection-pooling). For related troubleshooting, refer to [Troubleshoot connection pooling problems](https://aiven.io/docs/products/postgresql/troubleshooting/troubleshooting-connection-pooling).

 > Note: 
  By default, the connection pooling is disabled. To enable it, contact [Akamai Compute Support](https://www.linode.com/support/).