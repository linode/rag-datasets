# [MySQL](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#mysql)

# [Connect to a MySQL Managed Database](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-to-a-mysql-managed-database)

You can connect to a MySQL Managed Database using:

- [CLI](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-using-a-cli),
- [MySQL workbench](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-using-mysql-workbench-gui),
- [DBeaver](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-using-dbeaver).

**Before you begin**:

To connect to a MySQL Managed Database, you need to know your username, password, a host or IP, and a MySQL client. To learn how, see [View connection details](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#view-connection-details).

## [View connection details](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#view-connection-details)

To view connection details:

1. Log in to [Cloud Manager](https://cloud.linode.com/) 

2. From the main menu, select **Databases**.

3. Select the Managed Database cluster of interest from the list. 

   The _Connection Details_ section contains information and credentials needed to connect to your database.

   - **Username**. The default user for all MySQL Managed Databases is `akmadmin` which replaces the non-accessible root user. 
   - **Password**. The randomly generated password for your database cluster. 
   - **Host**. The fully qualified domain name you can use to reach your database cluster through the public network.

   > > Note: IPv6 support
   > 
   > Use the IPv6 address (AAAA record) for this hostname to avoid network transfer charges when connecting to your database from Linodes within the same region.

   - **Read-only Host**: A virtual hostname that redirects client connection to replicas. (In clusters with more than one nodes, the 1 node is primary and others are replicas).
   - **Port**. 
   - **SSL**. This field is set to `ENABLED`, which means that it is required to use an encrypted TLS/SSL connection.

4. To verify the Certificate Authority (CA) certificate when connecting to the database, download the certificate by clicking the **Download CA Certificate** link.

## [Connect using a CLI](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-using-a-cli)

To connect directly to the database using a CLI, you can use the `mysql` tool. This tool is typically not available by default on most operating systems, but is included along with many MySQL clients (and servers).

**Before you begin**:

- Make sure the IP address assigned to your system is included within your database's access controls. If not, add it. To learn how, see [Edit access control settings](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#edit-access-control-settings).
- Verify that the `mysql` tool is installed on your system by running the `mysql --version` command. If it is not installed, install it. To learn how, see [Installing MySQL: A Definitive Guide](https://linode.com/docs/guides/install-mysql/).

To connect to a MySQL Managed Database:

1. Run the following`mysql` command replacing:

   - `[host]`, `[port]`,  and `[username]` with the corresponding values from the [Connection Details](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#view-connection-details) section.
   - `[path]` and `[database name]` with the location and name of the downloaded CA certificate.

   ```json
   mysql --host=[host] --port=[port] --user=[username] --password --ssl-mode=VERIFY_CA --ssl-ca=/[path]/[database name]-ca-certificate.crt
   ```

2. Enter your password at the prompt. The MySQL prompt appears and you're connected to your database and can enter SQL queries. For examples, see [Introduction to SQL Commands](https://linode.com/docs/guides/sql-commands/).

3. **Optional**: To verify the CA certificate using OpenSSL, run the following command replacing:

   - `[host]`, `[port]` with the corresponding values from the [Connection Details](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#view-connection-details) section.
   - `[path]` and `[database name]` with the location and name of the downloaded CA certificate.

   ```json
   echo | openssl s_client -starttls mysql -connect [host]:[port] -CAfile /[path]/[database name]-ca- 
   certificate.crt 2>/dev/null | grep -i "Verify return code"
   ```

    The expected response is:

   ```json
   Verify return code: 0 (ok)
   ```

  

To learn more, see:

- [Connect to a MySQL Database Using the mysql Command](https://www.linode.com/docs/guides/mysql-command-line-client/) 
- [Connecting to the MySQL Server Using Command Options](https://dev.mysql.com/doc/refman/8.0/en/connecting.html).

## [Connect using MySQL workbench GUI](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-using-mysql-workbench-gui)

The MySQL Workbench provides a graphical interface for connecting to MySQL databases. Using this tool, you can visualize your database, its structure, and the data it contains.

**Before you begin**:

- Make sure the IP address assigned to your system is included within your database's access controls. If not, add it. To learn how, see [Edit access control settings](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#edit-access-control-settings).
- Install the MySQL Workbench software from the [MySQL Community Downloads](https://dev.mysql.com/downloads/workbench/) page. Select the operating system you're using locally.

To connect using MySQL workbench GUI:

1. Open MySQL Workbench and go to **Database > Manage Connections**. 

2. In the **Manage Server Connections** window, enter a **Connection Name**.

3. In the _Parameters_ tab:

   1. Enter **Hostname**, **Username**, and **Port** with the corresponding values from the [Connection Details](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#view-connection-details) section and **Password**.
   2. **Optional**: If you want to store the password so that you don't have to enter it manually every time you connect, click **Store in Keychain...** and enter your password. For security reasons, it's recommended _not_ to store your password.

      

4. In the _SSL_ tab, set **Use SSL** to _Require_ or _Required and Verify CA_. The _Required and Verify CA_ verifies the CA certificate each time you connect. If you choose this option, download the CA certificate from Cloud Manager and in the **SSL CA File** field, enter the path to the downloaded file.  To learn how to download the file, see [View connection details](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#view-connection-details) . 

   

5. Click **Test Connection** to verify you can successfully connect to the database and then click **Close** to store the connection settings. Return to the main screen.

6. To connect to the database, go to **Database > Connect to Database** and select the stored connection. Click **OK**.

To learn more, see:

- [Install MySQL Workbench for Database Administration](https://linode.com/docs/guides/deploy-mysql-workbench-for-database-administration/#creating-and-populating-databases) 
- [MySQL Workbench Manual](https://dev.mysql.com/doc/workbench/en/).

## [Connect using DBeaver](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-using-dbeaver)

[DBeaver](https://dbeaver.io/) is a free and open source universal database tool for developers and database administrators. DBeaver provides a powerful SQL-editor, administration features, ability to migrate data and schema, monitor database connection sessions, and others.

**Before you begin**:

- Make sure the IP address assigned to your system is included within your database's access controls. If not, add it. To learn how, see [Edit access control settings](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#edit-access-control-settings).
- Install the DBeaver Community or Pro software from the [DBeaver Downloads](https://dbeaver.io/download/) page. Select the operating system you're using locally.

1. Open DBeaver and go to **Database > New Connection**.

2. In the _Connect to a database_ window, select **MySQL** and click **Next**.

   

3. In the _Main_ tab, enter **Server Host** (hostname) **Port**, and **Username** with the corresponding values from the [Connection Details](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#view-connection-details) section and **Password**. If you want to store the password so that you don't have to enter it manually every time you connect, click **Save password locally** and enter your password. For security reasons, it's recommended _not_ to store your password.

   

4. In the _SSL_ tab:

   1. Select the **Use SSL** and **Require SSL** options. 
   2. Deselect the **Verify server certificate** option.

      

5. Click **Test Connection**.

# [Migrate a MySQL database to a Managed Database](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#migrate-a-mysql-database-to-a-managed-database)

This guide covers how to migrate an existing MySQL or MariaDB database to a Managed Database. When migrating a database, there are two important terms to keep in mind: the _source_ database and the _target_ database.

- **Source database:** The original database running on a software, system, or machine that you wish to decommission. This could be MySQL running within your own Linux server, a development database on your local machine, or even a cloud database.
- **Target database:** The new replacement database that you wish to use. For this guide, the target database will be a Managed Database running on Akamai Cloud.

Your individual migration workflow could deviate from the instructions provided here. You may need to consult your own developers or application's documentation to learn how to perform some of these steps and to gather any best practices. You should also perform the migration on a staging server first or during a time when downtime least affects your users and/or business.

## [Before you begin](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#before-you-begin)

- **Create a Managed Database:** To minimize downtime, make sure to create your Managed Database database cluster _before_ continuing. This ensures that your database has been fully provisioned (which can take up to 30 minutes) and that you have the new database credentials available. See [Create a Managed Database](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#create-a-new-database-cluster).

- **Ensure proper MySQL user grants:** The MySQL user you intend to use to export your existing database must have SELECT, LOCK TABLES, SHOW VIEW and TRIGGER grants.

## [Export the source database](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#export-the-source-database)

Export the data from the source database into a `.sql` file. While this file is eventually used to import your data to a different machine, it can also be stored as backup. The best method for generating a backup of your data highly depends on the applications you are using and what other databases are also stored on that same system.

- **mysqldump:** In most cases, you can export the data using the mysqldump command-line tool. 

  - **For Linux/UNIX/Mac OS**: The following command exports the specified databases within the local mysql instance into a file called `db-backup.sql`. Replace _[host]_ , _[port]_ , _[user]_, and _[password]_ with the appropriate values for your database cluster.

    ```json
    mysqldump -h [host] -P [port] -u [user] -p'[password]'  \
    --compress --skip-lock-tables --single-transaction --hex-blob --routines --triggers --events --force --set-gtid-purged=OFF --ssl-mode=REQUIRED \
    --skip-column-statistics --databases [database1 database2…]  \
    |sed -e '1i SET SQL_REQUIRE_PRIMARY_KEY = 0;' \
    -e '/SET @@SESSION.SQL_LOG_BIN= 0;/d' \
    -e '/SET GLOBAL INNODB_STATS_AUTO_RECALC=OFF;/d' \
    -e '/SET GLOBAL INNODB_STATS_AUTO_RECALC=@OLD_INNODB_STATS_AUTO_RECALC;/d' \
    -e '/SET @@GLOBAL.GTID_PURGED=/,/;/d' \
    -e '/SET @@GLOBAL.GTID_PURGED=.*;/d' \
    > db-backup.sql  
    ```

    **Notes on additional command options:**

    - `-h`: If you prefer to run this command remotely and have access to MySQL from a remote system, add `-h [hostname]`, where _[hostname]_ is the IP address or hostname of the remote database server.

    - `--ssl-mode=REQUIRED`: Force SSL when your existing database has SSL enabled.

    - `--set-gtid-purged=OFF`: Use this option if you have [GTID-based replication](https://dev.mysql.com/doc/refman/8.0/en/replication-gtids-howto.html) enabled.

    - `--databases`: List your databases. **Do not use the `--all-databases` option**. 

  - **For Windows**: The following command exports the specified databases within the local mysql instance into a file called `db-backup.sql`. Replace _[host]_ , _[port]_ , _[user]_, and _[password]_ with the appropriate values for your database cluster.

  ```json
  mysqldump -h [host] -P [port] -u [user] -p'[password]' `
  --compress --skip-lock-tables --single-transaction --hex-blob --routines --triggers --events --force --set-gtid-purged=OFF --ssl-mode=REQUIRED `
  --skip-column-statistics --databases [database1 database2…] `
  > temp-backup.sql

  # Modify the output file in PowerShell
  Get-Content temp-backup.sql |
  ForEach-Object {
      if ($_ -notmatch 'SET @@SESSION.SQL_LOG_BIN= 0;' -and
          $_ -notmatch 'SET GLOBAL INNODB_STATS_AUTO_RECALC=OFF;' -and
          $_ -notmatch 'SET GLOBAL INNODB_STATS_AUTO_RECALC=@OLD_INNODB_STATS_AUTO_RECALC;' -and
          $_ -notmatch 'SET @@GLOBAL.GTID_PURGED=' -and
          $_ -notmatch 'SET @@GLOBAL.GTID_PURGED=.*;') {
          $_
      }
  } | Set-Content -Path db-backup.sql

  # Prepend the line "SET SQL_REQUIRE_PRIMARY_KEY = 0;" to the final backup file
  Add-Content -Path db-backup.sql -Value "SET SQL_REQUIRE_PRIMARY_KEY = 0;" -PassThru -AsByteStream 
  ```

    

See [Backing Up MySQL Databases Using mysqldump](https://linode.com/docs/guides/mysqldump-backups/) for more details on running the mysqldump command.

- **cPanel:** See [Backup Wizard > Create a partial backup](https://docs.cpanel.net/cpanel/files/backup-wizard/#create-a-partial-backup) and [How to Back Up and Restore MySQL® Databases in cPanel](https://blog.cpanel.com/how-to-back-up-and-restore-mysql-databases-in-cpanel/).

- **Plesk:** See [Exporting and Importing Database Dumps](https://docs.plesk.com/en-US/obsidian/reseller-guide/website-management/website-databases/exporting-and-importing-database-dumps.69538/#).

### [Preventing corruption](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#preventing-corruption)

If data is modified during the export, your dataset may become inconsistent or corrupted. Because of this, you may want to prevent new data from being written during the time. This can be accomplished by stopping any services or applications that are currently using your database. In many cases, stopping the web server software is one of the quickest ways to do this, though its not recommended if that web server is also running other websites that need to maintain access. The following instructions cover stopping the two most popular web services, NGINX and Apache.

- **Stop NGINX:**

  ```
  sudo systemctl stop nginx
  ```

- **Stop Apache on Ubuntu/Debian:**

  ```
  sudo systemctl stop apache2
  ```

- **Stop Apache on RHEL/CentOS:**

  ```
  sudo systemctl stop httpd
  ```

Alternatively, you can activate a _maintenance mode_ (or whatever it may be called for your application) on any applications or services using your database. This typically disables some of your site's functionality and may present a web page to visitors to notify them of the downtime. The process for this varies greatly depending on the application you may be using.

## [Import the database](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#import-the-database)

Next, you'll need to import the `.sql` file to your Managed Database (the target database). This process can be accomplished through the mysql command-line tool. Run the following command on a system that has the MySQL client or server software installed. Replace _[host]_ , _[port]_, _[user]_ , and _[password]_ with the appropriate values for your database cluster. To learn more, see [Connect to a MySQL Database](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#connect-to-a-mysql-managed-database).

```
mysql -h [host] -P [port] -u [user] -p'[password]' --compress --force < db-backup.sql  
```

## [Update the database connection details within your application](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#update-the-database-connection-details-within-your-application)

After the data has been imported into the Managed Database, you should update any applications that were using the original source database so that they use the new Managed Database instead. This typically involves editing the database connection details (such as the host, username, password, and port) within the code or within your application's GUI. Please consult the documentation for your application to learn how to adjust the database settings. In WordPress, for instance, the database connection details are stored within the `wp-config.php` file on your web server (see [Editing wp-config.php > Configure Database Settings](https://wordpress.org/support/article/editing-wp-config-php/)).

## [Enable your application](https://techdocs.akamai.com/cloud-computing/docs/aiven-mysql#enable-your-application)

If you turned off your web server or placed your application in a _maintenance mode_, you can now enable your application again. While the instructions for turning off _maintenance mode_ vary depending on your application, here are the commands for starting the two most common web servers:

- **Start NGINX:**

  ```
  sudo systemctl start nginx
  ```

- **Start Apache on Ubuntu/Debian:**

  ```
  sudo systemctl start apache2
  ```

- **Start Apache on RHEL/CentOS:**

  ```
  sudo systemctl start httpd
  ```