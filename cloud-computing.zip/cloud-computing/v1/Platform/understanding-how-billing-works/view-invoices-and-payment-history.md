# [View invoices and payment history](https://techdocs.akamai.com/cloud-computing/docs/view-invoices-and-payment-history#view-invoices-and-payment-history)

All of your billing history, including previous invoices and payments, is accessible in [Cloud Manager](https://cloud.linode.com).

1. Log in to [Cloud Manager](https://cloud.linode.com) on a user account with one of the following permissions. See [Setting User Permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions) for more details.

   - **Full account access**. The account has unlimited access.

   - **Restricted user with _Read-Write_ permissions under Billing Access**. Users with _Read Only_ permissions can see most billing information, but they can't make changes.

2. Navigate to the **Billing** page (under **Administration**) in the sidebar menu.

3. Scroll down to the _Billing & Payment History_ section to see your invoices.

   > > Note: 
   > 
   > By default, all transactions (both invoices and payments) from the last _6 months_ are shown. You can customize this using the **Transaction Types** and **Transactions Dates** menus.

4. Find the desired invoice in the table and click its invoice number. The invoice opens displaying specific information for each service on your account: 

   - **Description:** The type of service and the unique label you've given it.

   - **From:** The date the service started billing during this billing cycle. This could either be the date and time this billing cycle started _or_ the date and time the service was added to the account.

   - **To:** The date the service ended billing during this billing cycle. This could either be the date and time this billing cycle ended _or_ the date and time the service was removed from the account.

   - **Quantity:** The number of hours the service is being billed.

   - **Region:** The data center and region ID for the service.

   - **Unit Price:** The hourly rate for this service.

   - **Amount:** The cost for this service excluding taxes.

   - **Taxes:** The taxes that are charged for this service.

   - **Total:** The cost for this service including taxes.

# [Download an invoice](https://techdocs.akamai.com/cloud-computing/docs/view-invoices-and-payment-history#download-an-invoice)

Find the target invoice you want in the _Billing & Payment History_ table and click its associated **Download PDF** link.