# [Stop further billing](https://techdocs.akamai.com/cloud-computing/docs/stop-further-billing#stop-further-billing)

To prevent additional charges from accruing and stop further billing, you can remove any paid services from your account or cancel your account entirely.

# [Remove services](https://techdocs.akamai.com/cloud-computing/docs/stop-further-billing#remove-services)

Akamai Cloud services are typically provided without a contract or commitment. You can remove them from your account at any time. Here are instructions for removing a Linode:

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Linodes** from the sidebar menu.
2. Locate the Linode you wish to delete.
3. Click its **...** menu and select **Delete**.
4. Select **Delete Linode** in the confirmation box that appears.

To delete other services, check out their specific instructions:

- [Backups Service](https://techdocs.akamai.com/cloud-computing/docs/cancel-backups)
- [Delete Block Storage volume](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes#delete-volume)
- [Cancel Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cancel-object-storage)
- [Delete a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#delete-a-nodebalancer)

 > Error: 
  Removing a service from your account makes its data irretrievable. With a Linode, any corresponding Backup service is also deleted and you won't be able to restore from those backup snapshots.
  To preserve your data before removing a service from your account, create an external backup. Check out the [Backing Up Your Data](https://linode.com/docs/guides/backing-up-your-data/) guide for some examples on how to do this.
  When removing a Linode from your account that has been active for at least 24 hours, a [Recovery Image](https://techdocs.akamai.com/cloud-computing/docs/images#recover-a-deleted) is automatically created. To learn how to deploy this image, see [Deploy an Image to a New Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-a-new-compute-instance).
  There is a very small chance that Support can restore your data outside of these circumstances. The sooner you reach out to support, the more likely this can occur. Open [a Support ticket](https://cloud.linode.com/support/tickets) to explore this possibility.

# [Cancel account](https://techdocs.akamai.com/cloud-computing/docs/stop-further-billing#cancel-account)

If you no longer wish to use any services on Akamai Cloud, you can also cancel your account. When an account is cancelled, you may receive a final bill. This bill includes all charges that have already accrued during the billing period. 

See [Cancel Your Account](https://techdocs.akamai.com/cloud-computing/docs/cancel-an-account) to learn more.