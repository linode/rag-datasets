# [Update billing contact information](https://techdocs.akamai.com/cloud-computing/docs/update-billing-contact-information#update-billing-contact-information)

Use the **Billing** page to update the contact information for your account. The email address saved here receives invoices, receipts, and credit card expiration warnings.

 > Note: 
  Support tickets are _not_ sent to your Billing Contact email address, but to the email address for the relevant user.

Here's how to update the contact information and the email address on the **Billing** page:

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Billing** (under **Administration**) in the sidebar menu.

2. In the **Billing Contact** section, click **Edit**. The **Edit Billing Contact Info** window opens.

   ![A screenshot of the Edit Billing Contact Info window showing the following fields: Email, First Name, Last Name, Company Name, Address, Address 2, Country, State, City, Postal Code, Phone, Tax ID.](https://techdocs.akamai.com/linode/platform/img/billing-edit-billing-contact-info-v1.jpg)

3. Update the contact information and the email address for the account.

4. Click **Save Changes**.

The account's billing contact information is now updated.