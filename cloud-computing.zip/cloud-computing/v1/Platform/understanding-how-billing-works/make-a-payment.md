# [Make a payment](https://techdocs.akamai.com/cloud-computing/docs/make-a-payment#make-a-payment)

# [Pay your bill](https://techdocs.akamai.com/cloud-computing/docs/make-a-payment#pay-your-bill)

When we generate an invoice, the default payment method on your account is automatically charged within a few hours. See [View and Change the Default Payment Method](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods#view-and-change-the-default-payment-method) for instructions on changing the default payment method.

If you want to pay in advance, you can make a one-time payment.

# [Make a one-time payment](https://techdocs.akamai.com/cloud-computing/docs/make-a-payment#make-a-one-time-payment)

You can manually add funds to your account at any time. Manual payments can be used to pay an outstanding balance or prepay for future services.

1. Navigate to the **Billing** page in [Cloud Manager](https://cloud.linode.com/account/billing) See [Accessing Billing Information](https://techdocs.akamai.com/cloud-computing/docs/access-billing-information) for more information.

2. Click **Make a Payment** on the top right of the page. The **Make a Payment** panel opens.

3. Enter the amount of money you want to add in the **Payment Amount** field. The current balance on the account is displayed above this field.

4. Make the payment using any of these methods:

   - **Pay with a saved payment method** Select the saved payment method you wish to use in the  **Payment methods** section and click the **Pay now** button.

   - **Pay with PayPal**. Click **PayPal** towards the bottom of the panel. PayPal's own payment form opens, where you can log in to your PayPal account and select your payment method. Once finished, you will be returned to Cloud Manager.

   - **Pay with Google Pay**. Click **Google Pay** towards the bottom of the panel. Google's own payment form opens where you can log in to your Google account and select your payment method. Once finished, you will be returned to Cloud Manager.

The payment may take a few minutes to be applied to your account.