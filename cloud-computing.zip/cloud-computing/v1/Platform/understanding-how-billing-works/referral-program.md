# [Referral program](https://techdocs.akamai.com/cloud-computing/docs/referral-program#referral-program)

When you refer a new user to Akamai Cloud through our referral program, both you and the new user can receive a promotional credit. Here are the program details:

- **A new user receives a $100 60-day credit**. They get the credit when they sign up through a referral link. Before the credit is applied, they need to add a valid payment method to their account.

- **The referrer receives a $25 non-expiring credit**. This is applied after the new user has been active for 90-days and spends $25 or more on services, after their promotional credit has been used or has expired.

To learn more about this program, check out our [Referral Program](https://www.linode.com/referral-program/) page.

## [Find your referral link](https://techdocs.akamai.com/cloud-computing/docs/referral-program#find-your-referral-link)

To activate the referral program and obtain a referral link, spend at least $25 on Akamai Cloud services, not including any promotional credits added to your account. Once activated, you can see your referral link and its unique referral code in Cloud Manager:

1. Log in to the [Cloud Manager](https://cloud.linode.com).
2. Click **
** in the top-right and select **Referrals** from the drop-down.
3. Select the **Referrals** tab.

You can provide the referral link to friends and colleagues as well as post it to your website and social media.