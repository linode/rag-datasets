# [Manage payment methods](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods#manage-payment-methods)

# [Payment methods](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods#payment-methods)

- **Credit card**. Pay using all popular credit (and debit) cards, including those issued by Visa, MasterCard, Discover, American Express, and UnionPay.

- **Google Pay**. Pay using a credit card, debit card, or PayPal through your Google Pay account. Paying with your Google Pay balance or any associated bank accounts are not supported at this time.

  > > Note: 
  > 
  > To add a PayPal account to your Google Pay account, you currently must do so through the [Google Play Store](https://play.google.com/store/paymentmethods). PayPal cannot currently be added through the Google Pay website or mobile apps. When adding PayPal through Google Pay, it appears as a Discover Card within Cloud Manager and the Linode API.

- **PayPal**. Pay using your PayPal balance, a credit or debit card, or bank account through your PayPal account.

- **Check, ACH, or wire transfer**. [Contact support](https://www.linode.com/support/) if you wish to pay through one of these methods.

See [Adding a New Payment Method](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods#add-a-new-payment-method) for instructions on adding a new payment method to your account.

# [Add a new payment method](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods#add-a-new-payment-method)

New payment methods can be added to an account through Cloud Manager. Up to **6 payment methods** can be active on an account at any given time, including multiple credit cards, Google Pay methods, and PayPal methods.

1. Navigate to the **Billing** page in [Cloud Manager](https://cloud.linode.com/account/billing). See [Accessing Billing Information](https://techdocs.akamai.com/cloud-computing/docs/access-billing-information) for more information.

2. If you're directly adding a credit card, it needs to match the account's billing contact information and address. Review the **Billing Contact** section and edit it as necessary (see [Update Billing Contact Information](https://techdocs.akamai.com/cloud-computing/docs/update-billing-contact-information)).

3. In the **Payment Method** section, click _Add Payment Method_. The **Add Payment Method** panel opens.

4. Complete the form according to the payment method you want to add:

   - **Pay with a credit card**. Enter the credit card number, expiration date, and the security code (CVV) of the new card. Then click **Add Credit Card**.

     

     > > Note: 
     > 
     > A $1.00 authorization hold may be placed on your credit card by your banking institution when our payment processor tests the validity of the card. This is normal behavior and does not result in a charge on your card.

   - **Pay with Google Pay**. Click **Google Pay** to open Google's own Google Pay form. Log in to your Google account and select the payment method you want to use. Complete the form as necessary and click **continue**, to be taken back to Cloud Manager.

      

   - **Pay with PayPal**. Click **PayPal** to open PayPal's own form. Log in to your PayPal account and select the credit card or bank account you want to use. Fill out the form as necessary and click **Save and Continue** to be taken back to Cloud Manager.

      

We'll add you're selected payment method and assign it as the _default_ payment method for future recurring payments. You can [change](#view-and-change-the-default-payment-method) this as necessary.

 > Note: 
  This process doesn't immediately charge any past due balance on the account to the new payment method. If you have an outstanding balance, you need to make a manual payment to bring your account up to date. See [Make a One-Time Payment](https://techdocs.akamai.com/cloud-computing/docs/make-a-payment#make-a-one-time-payment) for more information.

# [Remove a payment method](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods#remove-a-payment-method)

To delete a payment method from your account, follow the instructions below.

1. Navigate to the **Billing** page in [Cloud Manager](https://cloud.linode.com/account/billing). See [Accessing Billing Information](https://techdocs.akamai.com/cloud-computing/docs/access-billing-information) for more information.
2. Under the **Payment Methods** section, locate the payment method you wish to remove.
3. Click the corresponding ellipsis menu and select **Delete** from the dropdown menu. If the payment method is the default payment method on the account, the **Delete** button will be disabled and you will first need to change the default method.

# [View and change the default payment method](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods#view-and-change-the-default-payment-method)

When an invoice is generated, the amount of that invoice (as well as any past due balance) will be charged to the _default_ payment method on the account. The default payment method can be viewed and changed by following the instructions below.

1. Navigate to the **Billing** page in [Cloud Manager](https://cloud.linode.com/account/billing) (see [Accessing Billing Information](https://techdocs.akamai.com/cloud-computing/docs/access-billing-information)).
2. Under the **Payment Methods** section, the payment method currently used by default has a label of _default_ (located to the right of the last 4 digits and expiration date).
3. To change the default payment method, click the ellipsis menu next to the payment method you wish to use and select **Make Default** from the dropdown menu.
