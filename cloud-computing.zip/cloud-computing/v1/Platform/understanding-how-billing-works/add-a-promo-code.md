# [Add a promo code](https://techdocs.akamai.com/cloud-computing/docs/add-a-promo-code#add-a-promo-code)

A _promo code_ adds a positive credit to your account, allowing you to pay for services using that credit. You can add a promo code when signing up for an account. If you already signed up, but haven't entered a promo code, you may be able to do so from Cloud Manager. To add a promo code to an existing account, certain conditions must be met:

- The account needs to be less than 90 days old.
- There can't be a negative balance on the account.
- No other promo codes can already be applied to the account.
- The user that's logged in needs to have unrestricted permissions.

If you meet all of these conditions, you can add a promo code:

1. Log in to [Cloud Manager](https://cloud.linode.com) on a user account with one of the following permissions. See [Setting User Permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions) for more details.

   - **Full account access**. The account has unlimited access.

   - **Restricted user with _Read-Write_ permissions under Billing Access**. Users with _Read Only_ permissions can see most billing information, but they can't make changes.

2. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Billing** (under **Administration**) in the sidebar menu.

3. Under the **Account Balance** section, click **Add a promo code**. The _Add promo code_ dialog box opens.

   

4. Enter the promo code and click **Apply Promo Code**. 

You should now see the promotional credit amount reflected in your account balance.