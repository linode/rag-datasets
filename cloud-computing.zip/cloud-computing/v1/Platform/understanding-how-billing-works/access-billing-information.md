# [Access billing information](https://techdocs.akamai.com/cloud-computing/docs/access-billing-information#access-billing-information)

Most information and settings pertaining to billing are located within the [Billing](https://cloud.linode.com/billing) page in Cloud Manager. To access this information:

1. Log in to [Cloud Manager](https://cloud.linode.com) on a user account with one of the following permissions. See [Setting User Permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions) for more details.

   - **Full account access**. The account has unlimited access.
   - **Restricted user with _Read-Write_ permissions under Billing Access**. Users with _Read Only_ permissions can see most billing information, but they can't make changes.

2. Navigate to the **Billing** page (under **Administration**) in the sidebar menu. This page contains several sections:

   - **Account Balance:** The current balance on the account. This includes any past due amounts from unpaid invoices as well as any positive balance remaining from credits or promo codes.
   - **Promotions:** If there is an active promotion or coupon applied to the account, it's displayed here along with the remaining balance and any expiration date. If there are no active promotions, this section is hidden.
   - **Accrued Charges**. The charges that have accrued since your last invoice. This updates frequently to include the hourly charges (up to the monthly cap) for all paid services on the account, as well as any other charges. See the [Billing Overview](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works) guide for help understanding these charges.
   - **Billing Contact**. The name, address, phone number, and email address for the primary billing contact on the account. See [Update billing contact information](https://techdocs.akamai.com/cloud-computing/docs/update-billing-contact-information) for more information.
   - **Payment Methods**. The payment methods that have been added to the account.
   - **Billing & Payment History**. Displays a list of previous invoices and payments, along with links to view or download each entry. See [View invoices and payment history](https://techdocs.akamai.com/cloud-computing/docs/view-invoices-and-payment-history) for more information.
