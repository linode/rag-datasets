# [Quotas](https://techdocs.akamai.com/cloud-computing/docs/quotas#quotas)

Quotas are predetermined limits that control resource usage for Akamai Cloud services. Quotas aim to ensure efficient resource allocation, maintain system stability, and provide predictable usage for all customers.

You can view your quotas and usage details on the Quotas page of Cloud Manager or using the [API](https://techdocs.akamai.com/linode-api/reference/get-object-storage-quotas). You can also request increases when quotas are reached.
