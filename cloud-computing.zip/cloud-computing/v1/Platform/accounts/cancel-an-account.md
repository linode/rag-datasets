# [Cancel your account](https://techdocs.akamai.com/cloud-computing/docs/cancel-an-account#cancel-your-account)

Your account enables you to deploy and use services on Akamai Cloud. If you no longer wish to use our platform, you can cancel your account at any time. When you cancel your account, any past due balance and uninvoiced balance remaining on your account is immediately charged to the default payment method on file, minus any remaining account credits.

 > Error: 
  Closing your account is an extremely destructive action. All services, Linodes, volumes, DNS records, and user accounts will be permanently lost.

You do not have to cancel your account to prevent recurring charges. Instead, you can remove all services from your account via Cloud Manager, Linode API, or Linode CLI. This lets you retain your account if you intend to use it in the future. See [Removing Services](https://techdocs.akamai.com/cloud-computing/docs/stop-further-billing) for more information.

 > Note: 
  Akamai provides a 7-day guarantee for all paid services on Akamai Cloud. If you cancel your account within the first 7 days, you are likely eligible to receive a full refund for any service charges paid with a valid payment method (not with an account credit or promotional code). To request this refund, enter a note in the cancellation form or email [support@linode.com](mailto:support@linode.com) with your request.

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Settings** (under **Administration**) in the sidebar menu.
2. Under the **Close Account** panel, click the **Close Account** button.
3. A confirmation form appears. Check both boxes to confirm that you want to close your account. Enter your email address in the first field and optionally enter any comments you'd like to leave in the second field. Any refund requests can be entered here as well. See the [Refunds](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#refunds) section of the Billing guide.
4. Click the **Close Account** button to complete your account cancellation. Any past due balance and uninvoiced balance is immediately charged to the credit card on file for your account. After that, you will receive no further charges regarding this account.

After following these instructions, all of your services are immediately marked for deletion and your account is immediately cancelled. You are no longer able to log in through Cloud Manager.