# [Manage personal access tokens](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens#manage-personal-access-tokens)

# [View personal access tokens](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens#view-personal-access-tokens)

To view your personal access tokens, dates when they were created, and when they expire:

1. Log in to [Cloud Manager](https://cloud.linode.com)

2. Click your username in the top corner of the screen and select **API Tokens** under the _My Profile_ section.

   

This displays the **API Tokens** tab on the **My Profile** page.

# [Create an API token](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens#create-an-api-token)

Whenever you need to authorize API access to an application or service, you should create a new personal access token. This token should only allow the level of access needed by the application.

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Click your username at the top of the screen and select **API Tokens**

3. Click **Create a Personal Access Token**.

4. In the _Add Personal Access Token_ window:

   1. Enter a **Label** for the token to identify it and understand its intended use in the future.

   2. Select the **Expiry** time for the token.  

   3. For each product or service on the list, select the level of access the token should have.

      

   4. Click **Create Token**. 

   The token is displayed in the pop-up. Save the token in a safe place, such as a password manager. 

 > Warning: After closing this pop-up, you won't be able to view the token again.

# [Revoke a personal access token](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens#revoke-a-personal-access-token)

If you wish to decommission a token or think it may have been compromised, you can revoke access. Once revoked, any application using this token will no longer be authorized to access your account through the Linode API.

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to the API Tokens page of the My Profile section. See [View Personal Access Tokens](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens#view-personal-access-tokens).

2. Find the token you wish to revoke and click the corresponding **Revoke** button, which may be visible within the **_more options ellipsis_** menu.

   

3. A pop-up appears asking you to confirm that you wish to revoke this token. Click the **Revoke** button to delete the token and revoke access to any application using that token.