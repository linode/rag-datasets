# [Accounts FAQ](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-creating-and-managing-linode-accounts#accounts-faq)

# [I no longer remember my user password. How can I reset it?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-creating-and-managing-linode-accounts#i-no-longer-remember-my-user-password-how-can-i-reset-it)

If you forget the password associated with your user account, you can reset it using the [forgot password](https://login.linode.com/forgot/password) form. Once you enter your username and submit the form, a password reset is emailed to the user's email address. See [Reset Your User Password](https://techdocs.akamai.com/cloud-computing/docs/reset-your-user-password).

If you instead need assistance resetting the root user on a Linode, review the [Reset the Root Password on a Linode](https://techdocs.akamai.com/cloud-computing/docs/reset-the-root-password-on-a-compute-instance) guide.

# [How can I recover the username associated with my account?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-creating-and-managing-linode-accounts#how-can-i-recover-the-username-associated-with-my-account)

If you forget your username, you can recover it using the [forgot username](https://login.linode.com/forgot/username) form. Enter the email address you might have used during signup. If a username is associated with that address, a message containing the username(s) is sent to that email address. See [Recover a Lost Username](https://techdocs.akamai.com/cloud-computing/docs/manage-users-on-your-account#recover-a-lost-username).

# [I'm not receiving login-related emails, including username recovery, password reset, and one-time passcode emails.](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-creating-and-managing-linode-accounts#im-not-receiving-login-related-emails-including-username-recovery-password-reset-and-one-time-passcode-emails)

Login-related emails are sent to the email address of your user account (not to the billing contact email) and are sent from _[support@linode.com](mailto:support@linode.com)_. If you are expecting an OTP, password reset, or user recovery email but not seeing one in your inbox, follow the steps below:

- Search your inbox for the sender email (_[support@linode.com](mailto:support@linode.com)_).
- Check your spam or junk folder for the email.
- If you are using a Microsoft email service (like Outlook.com, Microsoft 365, or Exchange), verify that _linode.com_ is on the [safe senders list](https://support.microsoft.com/en-us/office/block-or-allow-junk-email-settings-48c9f6f7-2309-4f95-9a4d-de987e880e46#bkmk_safesenders).
- For Microsoft 365 (business users), you may need to review your [quarantined email messages](https://learn.microsoft.com/en-us/microsoft-365/security/office-365-security/quarantine-end-user?view=o365-worldwide). When viewing the [quarantine portal](https://protection.office.com/quarantine), search for your email address, locate the email you wish to receive, and release/allow that email. and release any emails from _linode.com_.

If you are still not receiving this email, submit a support request through the [Can't sign in to your account?](https://www.linode.com/support/contact/) form.

# [2FA is enabled on my account but I no longer have access to my 2FA device or application. How can I regain access to my account?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-creating-and-managing-linode-accounts#2fa-is-enabled-on-my-account-but-i-no-longer-have-access-to-my-2fa-device-or-application-how-can-i-regain-access-to-my-account)

2FA (two-factor authentication) adds a layer of security to protect your account from unauthorized access. When switching devices or 2FA applications, it's important to [reset 2FA](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#switching-to-a-new-device-or-2fa-provider) before decommissioning your original device. If you lose access to your device before resetting 2FA, use one of the scratch codes that were provided to when 2FA was first enabled. As a best practice, these should always be stored in a secure manner separate from your 2FA provider. If you do not have your scratch code, review the options available within the [2FA Recovery Procedures](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#recovery-procedure).

# [I'd like to provide a developer with access to my account. How should I do this?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-creating-and-managing-linode-accounts#id-like-to-provide-a-developer-with-access-to-my-account-how-should-i-do-this)

When working with an outside developer or web administrator, you will likely need to provide them access to your account, your Linodes, or both. It's important to keep in mind the level of access they will need. You, as the account owner, are ultimately responsible for the services on the account and the bill that those services generate. Review the [Grant a developer access to your services](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access) guide for instructions on creating a user account for your developer, providing them with access to Linodes, and granting other types of access.