# [Enable third-party authentication on your user account](https://techdocs.akamai.com/cloud-computing/docs/enable-third-party-authentication#enable-third-party-authentication-on-your-user-account)

Cloud Manager supports third-party authentication (TPA). This lets you log in to Cloud Manager with another provider's login credentials.

 > Note: 
  Enabling TPA disables two-factor authentication (2FA) on your user account. You should enable 2FA with the TPA provider with which you choose to authenticate to Cloud Manager.
  Additionally, enabling TPA disables password authentication in the Lish console. You can still authenticate to Lish with an SSH key. For more information on SSH key authentication with Lish, visit our [Using the Lish Console](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#add-your-public-key) guide.

 > Note: Single sign-on (SSO) with Akamai Control Center
  Separate from your selected login provider, you can also log in to Cloud Manager using your [Akamai Control Center](https://control.akamai.com/) account credentials. To learn more about this feature, see [Single sign-on (SSO) with Akamai Control Center](https://techdocs.akamai.com/cloud-computing/docs/security-controls-for-user-accounts#single-sign-on-sso-with-akamai-control-center).

# [Enabling third-party authentication](https://techdocs.akamai.com/cloud-computing/docs/enable-third-party-authentication#enabling-third-party-authentication)

1. To get started with TPA, log in to [Cloud Manager](https://cloud.linode.com) using your existing username and password.

2. Click your username in the top right of the screen and select **Login & Authentication**.

   

3. Within the **Login Method** section, select the _Login Provider_ you'd like to use for authentication. You can chose to use your own Cloud Manager credentials or chose from several third-party authentication (TPA) providers, such as Google and GitHub. Only one login provider can be active at a time. Once selected, you will be asked to confirm that you'd like to enable TPA with this provider.

   

   > > Error: 
   > 
   > Enabling third-party authentication disables your current Cloud Manager password and 2FA settings. If you would like to continue using 2FA, make sure it is handled by your chosen TPA provider.

4. Once a TPA provider is selected, you are taken to that provider's website and are prompted to give access to your user account. Review the list of permissions and confirm.

5. After granting permissions, you will see a confirmation screen. You can now log in to your user account through the selected TPA provider.

# [Disabling third-party authentication](https://techdocs.akamai.com/cloud-computing/docs/enable-third-party-authentication#disabling-third-party-authentication)

1. Log in to [Cloud Manager](https://cloud.linode.com) using your TPA credentials.

2. Navigate to the Login & Authentication page of your profile by clicking on your **username** in the top right of the screen. Select **Login & Authentication** from the dropdown menu.

   

3. Within the **Login Method** section, select **Cloud Manager** as the login provider.

   

4. A prompt will appear confirming your intent to disable third-party authentication. You will need to click on the **Reset Password** button to send a password reset link to your email. This will be delivered to the email address associated with your user account, and not the email associated with the TPA provider. You will need to follow the link in that email to reset your user's password.

   

5. Once reset, you can use your new password to log in to Cloud Manager.