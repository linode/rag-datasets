# [Manage 2FA on a user account](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#manage-2fa-on-a-user-account)

2FA (_two-factor authentication_) increases the security of your Cloud Manager account by requiring two forms of authentication: your password and an expiring token, also called an OTP (one-time passcode) or 2FA code. This follows the security principle of authenticating with something you _know_ (a password) and something you _have_ (the device used to generate the token). This additional layer of security reduces the risk that an unauthorized individual can gain access to your Cloud Manager account. Akamai highly recommends enabling 2FA.

 > Warning: 
  Managing 2FA through Cloud Manager is only available if _Cloud Manager_ is selected as the **Login Method**. If you select a third-party authentication provider (such as Google or GitHub), 2FA is managed directly through that provider and not through Cloud Manager.

 > Note: Account protection for users without 2FA enabled
  If you _do not_ have 2FA enabled and it has been 30 days or more since your last login, you are required to enter a unique one-time passcode (OTP). This passcode is sent to the email address on your user account and is valid for 60 minutes. If the passcode expires before you enter it, attempt another login to generate a new passcode.

# [Choosing a 2FA provider](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#choosing-a-2fa-provider)

Before enabling 2FA on your user account, you need to determine which application you wish to use for managing your authentication and generating the expiring tokens (OTPs). You may want to consider using your existing password manager or using a dedicated authenticator app.

## [Use your password manager](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#use-your-password-manager)

Most password managers offer a built-in OTP feature. If convenience is a large factor for you, using your password manager is typically faster and no extra applications are needed. Once configured, you can copy your OTP token from the same application that stores your usernames and passwords. In many cases, your OTP token can automatically be pasted into the appropriate field on your web browser when logging in. Here are some password managers that support OTP / 2FA tokens:

- [1Password](https://1password.com/)
- [Bitwarden](https://bitwarden.com/)
- [Keeper](https://www.keepersecurity.com/)

The primary downsides of using your password manager as your OTP provider are security and cost. If a malicious actor gains access to your password manager, they also now have access to your OTPs. To prevent this, consider using a dedicated application (see below).

## [Use a dedicated authenticator app](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#use-a-dedicated-authenticator-app)

There are quite a few free (and paid) third-party authenticator applications available. They are typically more secure than using your password manager's OTP functionality as a malicious actor cannot gain access to your Cloud Manager account (or any other 2FA protected account) unless they know your password and have access to the particular device on which the authenticator app is installed, typically your smartphone.

- [Authy](https://authy.com/features/setup/)
- [Duo Mobile](http://guide.duosecurity.com/third-party-accounts)
- [Google Authenticator](http://support.google.com/accounts/bin/answer.py?hl=en&answer=1066447)
- [Microsoft Authenticator](https://www.microsoft.com/en-us/security/mobile-authenticator-app)

# [Enabling 2FA](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#enabling-2fa)

Enable two-factor authentication to start using it with your Cloud Manager account.

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Click your username in the top right of the screen and select **Login & Authentication**.

   

3. Within the **Login Method** section, select **Cloud Manager** as the login provider. If you configure a third-party provider (such as Google or GitHub), you instead can manage 2FA directly through that provider and not through Cloud Manager.

   

4. Under **Security Settings**, verify that you have configured all 3 security questions. If not, follow the instructions within the [Security Questions](https://techdocs.akamai.com/cloud-computing/docs/security-controls-for-user-accounts#security-questions) guide.

5. Within the **Two-Factor Authentication** section, click the toggle switch to enable 2FA.

   

   A QR code should appear, along with a secret key and a field to enter your 2FA token.

6. Open the app for your preferred 2FA provider on your smartphone or desktop. For help choosing a provider, see [Choosing a 2FA Provider](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#choosing-a-2fa-provider).

7. The next step is to configure the app to automatically generate OTP tokens for use with Cloud Manager's 2FA feature. The process varies depending on the app you are using. Within most dedicated authenticator apps, you can add an account. For password managers, edit or add a Cloud Manager login entry and add a one-time passcode (1Password), two-factor code (Keeper), or the equivalent field within your app. Then either scan Cloud Manager's 2FA QR code or manually enter the secret key (also called a setup key or code). On mobile devices, you can use your phone's camera to scan the QR code. Desktop applications instead can typically scan the QR through their own custom screen capture tool. If you need further help, you can consult the documentation for your 2FA provider.

8. Once 2FA has been configured in your 2FA provider, a time-sensitive OTP token is generated. This token refreshes every 30 seconds. Copy this token and, within Cloud Manager, paste it to the **Token** field and click **Confirm Token**.

   

9. Once the token is successfully confirmed, a scratch code appears. Save this code to a secure place, such as a password manager. If you ever lose access to your authenticator app, this scratch code can be used once in place of the OTP token. Two-factor authentication is enabled on your account.

# [Logging in when 2FA is enabled](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#logging-in-when-2fa-is-enabled)

If 2FA is enabled on your account, you must enter the OTP generated by your 2FA provider when you log in to Cloud Manager.

1. Open [Cloud Manager](https://cloud.linode.com) in your web browser. If you are not already logged in, the Login page appears.

2. Enter your username and password and click **Log in**. If you wish, you can also select _Trust this device for 30 days_ to stay logged in for 30 days. If 2FA is enabled on your account, a form appears requesting your OTP token or scratch code.

3. Open the authenticator app you are using to manage your 2FA and OTP tokens. Within this app, open the Cloud Manager account or login entry to view the time-sensitive OTP code.

4. Enter your OTP token into the **Token** field in Cloud Manager and then click the **Verify** button. Provided the token is correct, you are successfully logged in.

   

   > > Note: 
   > 
   > If you entered your one-time use scratch code instead of an OTP token, a new scratch code is automatically generated and provided to you. Save this code for the next time you do not have access to your authenticator app.

# [Switching to a new device or 2FA provider](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#switching-to-a-new-device-or-2fa-provider)

If you need to switch your 2FA provider or change the device in use by your two-factor authenticator app, you can do so within Cloud Manager. To successfully log in to Cloud Manager, you must have access to your original 2FA provider or device. If you've lost your device or otherwise don't have access, see the [Recovery Procedure](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#recovery-procedure) below.

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Navigate to the Login & Authentication page of your profile by clicking on your **username** in the top right of the screen. Select **Login & Authentication** from the dropdown menu.

3. In the **Two-Factor Authentication (2FA)** section, click **Reset two-factor authentication**, as shown below.

   

4. A new QR code and secret key is generated for your account and displayed on the screen. Follow the instructions in the [Enabling Two-Factor Authentication](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#enabling-2fa) section.

# [Disabling 2FA](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#disabling-2fa)

You can disable two-factor authentication for your Cloud Manager account at any time. Here's how:

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Navigate to the Login & Authentication page of your profile by clicking on your **username** in the top right of the screen. Select **Login & Authentication** from the dropdown menu.

3. In the **Two-Factor Authentication (2FA)** section, toggle the **Enabled** switch to disable two-factor Authentication.

4. A confirmation window appears asking if you want to disable two-factor authentication. Click **Disable Two-Factor Authentication**.

You have successfully disabled the two-factor authentication feature for your Cloud Manager account.

# [Recovery procedure](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#recovery-procedure)

If you lose access to your 2FA provider, you can still log in using the scratch code that was generated when you first enabled 2FA. If you do not have that scratch code, you will be unable to log in to Cloud Manager and will need to contact the Customer Support team to request 2FA removal. See the instructions below for specific recovery steps.

- [With Scratch Code](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#with-scratch-code)
- [With Security Questions](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#with-security-questions)
- [Without Security Questions](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#without-security-questions)

Please keep in mind that if you cannot provide the information required for the recovery options below, we will be unable to remove 2FA from your account.

## [With scratch code](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#with-scratch-code)

You should have received a one-time scratch code when you initially enabled two-factor authentication on your user account. If you have this scratch code, you can provide it in place of a token when prompted during the login process. Once logged in, you can proceed to [disable 2FA](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#disabling-2fa) and [enable it again on your preferred device](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#enabling-2fa).

It is not possible to generate a new scratch code. If you do not have access to this scratch code and you’re unable to log in to your account, follow the instructions in one of the next sections ([With Security Questions](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#with-security-questions) or [Without Security Questions](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#without-security-questions)).

## [With security questions](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#with-security-questions)

1. Contact the [Support](https://www.linode.com/support/) team via phone and state that you are locked out of your account and would like to remove 2FA. Be prepared to provide Support with your username and/or email address associated with the account.

   - U.S. toll-free: 855-454-6633
   - Global: +1-609-380-7100

2. A member of the Support team will ask you to provide valid answers to each of your security questions.

3. Your answers and any other details provided will be reviewed. If the information provided is sufficient, the team member will remove 2FA from your account. If additional details are needed, you will be provided with further instructions.

## [Without security questions](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#without-security-questions)

Fill out our [Support Contact Form](https://www.linode.com/support/contact/) after selecting the option “I’ve lost my 2FA device." A member of the Support team will review your submission and respond to your ticket with next steps.

 > Warning: 
  This recovery procedure will soon be deprecated and our team will instead use your security questions to verify your identity to proceed with 2FA removal. Once you’re able to log in to your account, we suggest updating your security questions to ensure you are able to regain access to your account in the event of another login issue.

# [FAQs](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#faqs)

## [What should I do if I have access to my 2FA application, but each code I use is invalid when I try to log in?](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#what-should-i-do-if-i-have-access-to-my-2fa-application-but-each-code-i-use-is-invalid-when-i-try-to-log-in)

This usually occurs if the time on the application or device is inaccurate. Make sure the time on the device you’re using is accurate or within 30 seconds of your timezone - official time can be observed from 
. If you have confirmed that the time on your application is accurate and this doesn’t resolve the issue, follow the steps within the [Recovery Procedure](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#recovery-procedure) section.

## [What should I do if I no longer have access to the application I use to manage 2fa?](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#what-should-i-do-if-i-no-longer-have-access-to-the-application-i-use-to-manage-2fa)

A scratch code was generated and displayed when you enabled 2FA on your user account. Provide this scratch code in place of the OTP token when prompted during the login process. Scratch codes can only be used once.

## [I don’t have access to my 2FA application or my scratch code. how can I remove 2FA from my account?](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#i-dont-have-access-to-my-2fa-application-or-my-scratch-code-how-can-i-remove-2fa-from-my-account)

Review all of the alternative recovery options available in the [Recovery Procedure](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#recovery-procedure) section. Keep in mind that if you don’t have access to any recovery mechanisms, you may not be able to recover access to your account.

## [Do you support yubikeys?](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#do-you-support-yubikeys)

We hope to have this functionality soon. In the meantime, we have detailed a workaround in a Community Questions Site Post, [Yubikey as a 2FA Option](https://www.linode.com/community/questions/17374/yubikey-as-2fa-option-for-manager#answer-82565).

## [I’ve lost my scratch code - how do I generate a new one?](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#ive-lost-my-scratch-code-how-do-i-generate-a-new-one)

It is not possible to regenerate a new scratch code on an existing 2FA provider. If you have not previously saved your scratch code and wish to do so, you must [disable 2FA](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#disabling-2fa) from your account and then enable it again.

## [Can I submit answers to my security questions through a ticket or email?](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa#can-i-submit-answers-to-my-security-questions-through-a-ticket-or-email)

It’s not secure to submit answers via ticket, therefore we ask that you call the Support line to provide your answers.