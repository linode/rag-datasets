# [Reset your user password](https://techdocs.akamai.com/cloud-computing/docs/reset-your-user-password#reset-your-user-password)

Creating strong passwords is essential to protecting your Linodes and your [Cloud Manager](http://cloud.linode.com) account. If you suspect that an unauthorized user has gained access to one of your accounts, you should change the password immediately.

# [Password requirements and recommendations](https://techdocs.akamai.com/cloud-computing/docs/reset-your-user-password#password-requirements-and-recommendations)

User passwords must be a minimum of 11 characters in length and be sufficiently complex. Each password is individually analyzed by an algorithmic tool to determine it's strength. When creating a password, follow the recommendations listed below:

- Password should be _at least_ 11 characters in length (though longer passwords are considered stronger).
- Avoid using simple passwords based on dictionary words.
- Use a mixture of unpredictable uppercase letters, lowercase letters, numbers, and symbols.
- Avoid repeating characters (`aaa`), sequences (`abcd`), and keyboard patterns (`qwerty`).

# [Change (or reset) your cloud manager password](https://techdocs.akamai.com/cloud-computing/docs/reset-your-user-password#change-or-reset-your-cloud-manager-password)

If you want to change your password, or you forgot your password and need a new one, follow these steps:

1. Visit the [Forgot Password](https://login.linode.com/forgot/password) webpage.

2. Enter your username in the **Username** field.

   > > Note: 
   > 
   > If you've forgotten your Cloud Manager username, see [Recovering a Lost Username](https://techdocs.akamai.com/cloud-computing/docs/manage-users-on-your-account#recover-a-lost-username).

3. Click the **Reset password** button.

4. Check your email for a message containing further instructions.

5. Follow the instructions in the email message to reset your password.