# [Manage user account permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions#manage-user-account-permissions)

Each user on an account can be given individualized permissions that provides unrestricted access to an account or limits their access to specific information or services. For example, you could give your core team members full unrestricted access, grant your accounts payable team access only to view and modify billing details, and limit an outside developer to only access specific Linodes or other services.

 > Note: 
  The permissions discussed within this guide apply to accessing Akamai Cloud through Cloud Manager, Linode API, and Linode CLI. If you wish to only provide someone with direct access to the internal system of a Linode (or revoke their access), that can be accomplished through limited user accounts within your operating system. See [Grant a developer access to your services](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access).

# [View and set permissions for a user](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions#view-and-set-permissions-for-a-user)

You can view and edit permissions for a user directly in Cloud Manager by following the instructions below.

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Users & Grants** (under **Administration**) in the sidebar menu. This displays a list of existing users for the account.

   

2. Locate the user for which you wish to view or modify permissions and click the corresponding **User Permissions** link.

   

3. Modify the settings as needed. Reference the [Permission Settings](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions#permission-settings) section below for more information on user permission settings.

4. When you have finished configuring the user's permissions, click **Save**. The user's permissions are saved and become effective immediately.

# [Permission settings](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions#permission-settings)

## [Full account access](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions#full-account-access)

![A screenshot of the Full Account Access toggle.](https://techdocs.akamai.com/linode/platform/img/user-permissions-account-access-v2.png)

A user can either be given unrestricted (full) access to an account or they can be restricted by default. If **Full Account Access** is set to _ON_, the user has full access to the account and no further permission settings are available. When set to _OFF_, the user has no access and individual permissions can be granted using the other settings (covered below).

## [Create services (general permissions)](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions#create-services-general-permissions)

The **General Permissions** settings enable users to add various types of services. There is a setting that corresponds to each type of service. For instance, to allow the user to add NodeBalancers, enable the _Can add NodeBalancers to this account_ setting.

 > Note: 
  Granting access to settings denoted with a dollar sign ($) allows the user to perform actions that incur billing costs, such as adding or resizing a Linode.

## [Billing access](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions#billing-access)

This section provides various levels of access to view or modify billing information:

- **None**: The user is unable to view any billing information. This does not prevent a user from creating billable resources, which are instead applied as **Global Permissions** in the previous section.
- **Read Only**: The user can [View Invoices](https://techdocs.akamai.com/cloud-computing/docs/view-invoices-and-payment-history) and [Access Billing Info](https://techdocs.akamai.com/cloud-computing/docs/access-billing-information).
- **Read-Write**: The user has full access to [Billing Information](https://techdocs.akamai.com/cloud-computing/docs/access-billing-information), can make payments, edit billing information, view billing information, receive copies of all invoices, and receive email related to payments.

## [Specific services](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions#specific-services)

A user can be granted individual permissions to each instance of a service, such as Linodes, Block Storage volumes, NodeBalancers, and more. Unlike **Global Permissions**, **Specific Permissions** apply to individual resources — not the service as a whole.

- **None**: The user cannot view or otherwise interact with the selected resource.
- **Read Only**: The user can view the resource and all of its associated information typically visible within Cloud Manager, however they cannot otherwise interact with it.
- **Read-Write**: The user has full access to the selected resource and can make any changes that only an administrator is otherwise able to. This includes resource deletion, cloning, and all other applicable edits. The user also receives an email notification when a ticket is created or updated for this resource.