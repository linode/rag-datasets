# [Select network interfaces for new Linodes (BETA)](https://techdocs.akamai.com/cloud-computing/docs/select-network-interfaces-for-new-linodes#select-network-interfaces-for-new-linodes-beta)

Each Linode can use either **Configuration Profile Interfaces** or **Linode Interfaces**. These interface types differ in the following ways:

- **Network settings**. Unlike configuration profile interfaces, Linode interfaces are directly integrated into the Linode’s networking settings.
- **Management**. You can create, delete, or update Linode interface addresses only when the Linode is powered off. This ensures a clear and reliable association between the Linode and its network interface settings.
- **Cloud Firewalls**. You can assign a Cloud Firewall directly to a Linode interface. Firewall templates are available for both Linode VPC interfaces and Public Internet interfaces, and come with pre-configured protection rules.

 > Note: 
  You can upgrade a Linode with a legacy configuration profile interface to use a Linode interface. However, this action is irreversible and configuration profile interfaces can't be used afterwards. This means that such Linode can no longer be used with many of the Akamai Cloud products that require Private IPs (for example, NodeBalancer). For more information, see [Upgrade Configuration profile interfaces to Linode interfaces](https://techdocs.akamai.com/cloud-computing/docs/upgrading-config-profile-interfaces-to-linode-interfaces)

# [Select a network interface for new Linodes](https://techdocs.akamai.com/cloud-computing/docs/select-network-interfaces-for-new-linodes#select-a-network-interface-for-new-linodes)

You can select a network interface for new Linodes in Cloud Manager by following the instructions below.

1. Log in to [Cloud Manager](https://cloud.linode.com/) and click the **Administration** link in the sidebar.
2. Navigate to the **Account Settings** tab.
3. Within the **Network Interface Type** panel, select the interface from the dropdown.
4. Click **Save**.

## [Interfaces](https://techdocs.akamai.com/cloud-computing/docs/select-network-interfaces-for-new-linodes#interfaces)

| Interface | Description |
|---|---|
| Configuration Profile Interfaces but allow Linode Interfaces | This is the default setting for existing accounts. New Linodes can use either legacy configuration profile interfaces or new Linode interfaces, depending on the Network Interface Type setting specified during the Linode creation. By default, new Linodes use configuration profile interfaces unless specified otherwise. Linodes using Configuration Profile Interfaces can be upgraded to Linode Interfaces. |
| Linode Interfaces but allow Configuration Profile Interfaces | This is the default setting for new accounts. New Linodes can use either legacy configuration profile interfaces or new Linode interfaces, depending on the Network Interface Type setting during the Linode creation. By default, new Linodes use Linode interfaces unless specified otherwise. Linodes using configuration profile interfaces can be upgraded to Linode interfaces. |
| Configuration Profile Interfaces Only | All new Linodes use legacy configuration profile interfaces. Linodes created with Linode Interfaces can still exist. Linodes using configuration profile interfaces cannot be upgraded to use Linode interfaces.  |
| Linode Interfaces Only | All new Linodes use Linode interfaces. Linodes that were created with configuration profile interfaces can still exist if they were created under a previous setting. Linodes using configuration profile interfaces can be upgraded to Linode interfaces. |