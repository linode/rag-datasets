# [Select default Cloud Firewalls for new Linodes (BETA)](https://techdocs.akamai.com/cloud-computing/docs/select-default-firewalls-for-new-linodes#select-default-cloud-firewalls-for-new-linodes-beta)

Linode [Cloud Firewalls](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall) is a cloud-based firewall solution available at no additional charge.

For Linodes using Linode interfaces (Beta), Cloud Firewalls are assigned to the individual interface.

For Linodes using configuration profile interfaces, the Cloud Firewall is assigned to the Linode itself and applies to all non-VLAN interfaces.

Default Cloud Firewalls can be selected for Linodes (using configuration profiles), VPC interfaces and public interfaces. These Firewalls are applied automatically when creating Linodes and Linode interfaces.

To select default Cloud Firewalls for new Linodes, follow the instructions below:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and click the **Administration** link in the sidebar.
2. Navigate to the **Account Settings** tab.
3. Within the **Default Firewalls** panel, select the firewall from the relevant dropdown. The dropdowns contain only existing Cloud Firewalls. See [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall) for instructions on how to create a new one. 
4. Click **Save**. 

You can always select a different Cloud Firewall when creating or editing a Linode. For more information, see [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance) and [Networking interfaces](https://techdocs.akamai.com/cloud-computing/docs/networking-interface).