# [Change your email address on your account](https://techdocs.akamai.com/cloud-computing/docs/change-your-email-address#change-your-email-address-on-your-account)

The contact information on file for your account is used to notify and bill you. Keep this information current to prevent service interruptions. It's especially important to keep your email address current.

The **Billing** and **User & Grants** pages both have email address fields. The email addresses saved on these pages receive different notifications, as described in the following sections. If you are the only user, you should enter your email address on both pages. If there are multiple users, verify that the primary account holder's email address is current on the **Billing** page.

# [Modify billing contact email](https://techdocs.akamai.com/cloud-computing/docs/change-your-email-address#modify-billing-contact-email)

See [Update Billing Contact Information](https://techdocs.akamai.com/cloud-computing/docs/update-billing-contact-information).

# [Modify user account email](https://techdocs.akamai.com/cloud-computing/docs/change-your-email-address#modify-user-account-email)

Use the **Users & Grants** page to modify the email address associated with a user account. The email addresses listed on this page receive password reset messages and support tickets for services that their associated users have permission to access. Users with limited account access can also receive invoices and receipts if granted access to that information.

 > Note: 
  Only full account access users can receive threshold notification emails.

Here's how to change a user's email from the **Users & Grants** page:

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Users & Grants** (under **Administration**) in the sidebar menu.

2. Click the **User Profile** link next to the user for which you want to update the email address.

3. Enter the updated email address in the **Email** field.

   

4. Click **Save**.

The user's email address is now updated.

 > Note: 
  If you do not have full account access, you can view your user profile settings and update your email address by clicking on your username at the top of Cloud Manager and selecting **Display**.