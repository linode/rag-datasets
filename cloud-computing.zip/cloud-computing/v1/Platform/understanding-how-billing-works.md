# [Billing](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#billing)

Akamai strives to provide transparent and uncomplicated pricing structures and billing policies. As a supplement to our [Pricing](https://www.linode.com/pricing/) page, read through this guide to understand how we bill for services and how you can pay for them. If you have a question that isn't answered in the guide, don't hesitate to [contact support](https://www.linode.com/support/).

# [Understand how billing works](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#understand-how-billing-works)

Akamai uses a hybrid hourly billing model that's simple and flexible. You can continuously add, modify, and remove services throughout the month. Once the month ends, you receive an invoice for the hourly usage of each service **up to the monthly cap**. Here are some important billing considerations:

- Every paid service offered on Akamai Cloud has a predictable monthly rate (also called the monthly cap) in addition to a flexible hourly rate.

- When you add a service, charges accrue on the account at the hourly rate up to the monthly cap. These _accrued charges_ are displayed on the **Billing** page (under **Administration** in the sidebar menu) of Cloud Manager. Usage is always rounded up to the nearest hour.

- Akamai Cloud uses a monthly billing cycle. An invoice is automatically generated on the first day of each month which includes the previous month's usage.

If your services stay the same month over month, your bill remains predictable. You're never billed more than the monthly rate for each service, excluding [network transfer overages](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs). If you use a service for just part of the month, hourly billing only charges for the time the service is present on the account.

## [Storage units](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#storage-units)

Storage usage is calculated in binary gigabytes (GB), where 1 GB is 2
30
 bytes. This unit of measurement is also known as a gibibyte (GiB), defined by the International Electrotechnical Commission (IEC). Similarly, 1 TB is 2
40
 bytes, i.e. 1024 GBs.

## [Example billing scenarios](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#example-billing-scenarios)

Here are a few examples of common billing scenarios you might encounter. The following apply in these examples:

- **The month is 30 days** (720 hours). 
- **A 4GB Dedicated CPU Linode is in place**. This has a rate of $0.054/hour and a monthly rate/cap of $36.00.

### [A service is present on an account for the _entire_ month](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#a-service-is-present-on-an-account-for-the-entire-month)

You create the Linode before the start of the month and it remains on your account for the entire month. Calculating the service fees at the hourly rate for 720 hours (again, assuming a 30 day month), the total would have come to $38.88. Since this exceeds the monthly cap for this service, you are instead charged the predictable $36 monthly rate.

### [A service is present on an account for _almost_ the entire month](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#a-service-is-present-on-an-account-for-almost-the-entire-month)

You create the Linode on the second day of the month, half-way through the day. It remains on your account for the remainder of the month and, in total, was used for 684 hours. Calculating the service fees at the hourly rate, the total would have come to $36.94. Since this still exceeds the monthly cap for this service, you are instead charged the predictable $36 monthly rate.

### [A service is present on an account for _just some_ of the month](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#a-service-is-present-on-an-account-for-just-some-of-the-month)

You created the Linode mid-way through the month and deleted it exactly 5 days later. In total, it was used for 120 hours. Calculating the service fees at the hourly rate, the total is $6.48. Since this is less than the monthly cap, you are indeed billed at the hourly rate and charged $6.48 for your usage.

### [A service is resized during the billing cycle](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#a-service-is-resized-during-the-billing-cycle)

Resizing a service, such as a Linode effectively creates a new billable service. Each of these billable services will appear as separate line items on your monthly invoice. For instance, you create a 4GB Linode before the start of the month and resize it to an 8GB Linode mid-way through the month. Your invoice will have two services as separate line items corresponding with the two different Linode sizes that existed on your account during the billing cycle. Each line item will reflect the hourly rate for the time the service was active (up to the monthly cap).

 > Warning: 
  If a service is resized to a new plan and then resized back to the original plan all in a single billing cycle, there will be 3 billable services. The combined hourly rate for these services may exceed the monthly cap of the original service plan.

## [Mid-month billing](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#mid-month-billing)

You may receive a mid-month bill if you reach a certain monetary threshold within a single month. For many users, this amount will initially be **$50.00**. That amount can be adjusted over time by accruing a positive account history. In general, a history of on-time payments to Akamai will increase the threshold amount.

## [Will I be billed for powered off or unused services?](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#will-i-be-billed-for-powered-off-or-unused-services)

**Charges will accrue for any service present on an account, even if it is powered off or otherwise not actively being used.**  This is because data is still maintained and resources, such as RAM and network capacity are still reserved. To avoid additional charges, [remove](https://techdocs.akamai.com/cloud-computing/docs/stop-further-billing) any services you no longer need from your account.

## [Data center-specific pricing](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#data-center-specific-pricing)

In general, plans and services are billed at the same, flat rate across data centers. However, services and network transfer in some newer data centers may be billed at separate rates due to higher region-based infrastructure costs.

For more information about pricing in these regions, refer to our [Pricing](https://www.linode.com/pricing/) page.

# [Payments](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#payments)

When an invoice is generated on the first of the month (or mid-month), your account's default payment method is automatically charged. In addition to these automatic payments, you can make one-time payments to add funds to your account, which will then be used to pay future invoices.

## [Manual payments](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#manual-payments)

At any time, you can make a manual one-time payment to add funds to your account. This is used to pay a past-due balance or to _pre-pay_ for services, which adds a positive account balance that will be used towards future invoices. Review the [Make a one-time payment](https://techdocs.akamai.com/cloud-computing/docs/make-a-payment) for instructions when submitting a manual payment.

## [Refunds](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works#refunds)

A refund can be requested for any _positive account balance_ (excluding promotion credits). You can also receive a full refund as part of our cancellation policy if you cancel within the first 7 days. To learn more about this cancellation policy, see the [Cancel Your account](https://techdocs.akamai.com/cloud-computing/docs/cancel-an-account) guide.

To request a refund, contact the [support](https://www.linode.com/support/) team with the reason for your request. Refunds can only be considered for payments made within the last 180 days. Once the request is approved, the refund is issued to the original payment method. A $5 processing fee is deducted from all refunds, with the exception of cancelling an account within the first 7 days.