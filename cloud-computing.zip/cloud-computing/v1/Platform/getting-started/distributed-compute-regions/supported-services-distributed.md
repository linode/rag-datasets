# [Supported services](https://techdocs.akamai.com/cloud-computing/docs/supported-services-distributed#supported-services)

 > Note: 
  This topic focuses on [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions). If you are looking for information about supported features and services in core compute regions, see [Choose a data center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center)

Distributed compute regions support essential features and services for building highly available edge-native applications across an expanding distributed footprint. The list of supported services will grow over time. 

Services such as Block Storage, Object Storage, and Backups are not directly supported in distributed regions, but can be leveraged as part of a larger distributed ecosystem. If state or storage are key components of your application, distributed regions can seamlessly connect to core region deployments of such services. 

You can deploy custom images to Linodes in distributed regions, but these images must be stored in a core region. For more information, see [Region and images](https://techdocs.akamai.com/cloud-computing/docs/images#regions-and-images).

| Service                                                                         | Core | Distributed |
| :------------------------------------------------------------------------------ | :--: | :---------: |
| [Cloud Firewalls](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall)                                           |   ✔  |      ✔      |
| [VLANs](https://techdocs.akamai.com/cloud-computing/docs/vlan)                                                               |   ✔  |      ✔      |
| [Virtual Private Cloud (VPC)](https://techdocs.akamai.com/cloud-computing/docs/vpc)                                          |   ✔  |      ✔      |
| [Images - custom images](https://techdocs.akamai.com/cloud-computing/docs/images)                                            |   ✔  |      ✔      |
| Images - recovery images                                                        |   ✔  |             |
| [Metadata service](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service)                        |   ✔  |      ✔      |
| [Lish/Glish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) (through Cloud Manager) |   ✔  |      ✔      |
| [IPv4 configuration via DHCP](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance)  |   ✔  |      ✔      |
| [IPv6](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode)                                       |   ✔  |      ✔      |
| [IP Sharing and failover](https://techdocs.akamai.com/cloud-computing/docs/ip-sharing-distributed)                           |   ✔  |      ✔      |
| Private IP                                                                      |   ✔  |             |
| [Disk encryption](https://techdocs.akamai.com/cloud-computing/docs/local-disk-encryption)                                    |   ✔  |      ✔      |
| Linode Kubernetes Engine (LKE)                                                  |   ✔  |             |
| NodeBalancers                                                                   |   ✔  |             |
| Block Storage                                                                   |   ✔  |             |
| Object Storage                                                                  |   ✔  |             |
| Backups                                                                         |   ✔  |             |
| Managed Databases                                                               |   ✔  |             |
| Managed Services                                                                |   ✔  |             |
| Marketplace Apps                                                                |   ✔  |             |
| Stackscripts                                                                    |   ✔  |             |
| Placement groups                                                                |   ✔  |             |
| Cloning Linodes                                                                 |   ✔  |             |.