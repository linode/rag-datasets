# [IP Sharing and failover in distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/ip-sharing-distributed#ip-sharing-and-failover-in-distributed-compute-regions)

 > Note: 
  This topic focuses on [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions). If you are looking to configure failover on a Linode deployed to a core compute region, see [Configure failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance).

IP Sharing enables two Linodes to be assigned the same IP address for the purpose of configuring failover. In a typical failover setup, traffic on the shared IP address is routed to the primary Linode. If Linode fails or goes down, traffic is automatically re-routed to the secondary Linode. While IP Sharing can be configured in Cloud Manager, failover must be manually configured within the internal system of both Linodes. 

To learn how to enable IP Sharing, see [Configuring IP Sharing](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuring-ip-sharing).

To learn more about configuring failover, see [Configure failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance).

The following table contains the data center IDs you'll need to enable IP Sharing for Linodes in distributed compute regions. 

| Data center                 | Region   | ID |
| --------------------------- | -------- | -- |
| Auckland (New Zealand)      | nz-akl-1 | 32 |
| Berlin (Germany)            | de-ber-1 | 50 |
| Bogotá (Colombia)           | co-bog-1 | 40 |
| Denver, CO (USA)            | us-den-1 | 34 |
| Hamburg (Germany)           | de-ham-1 | 35 |
| Houston, TX (USA)           | us-hou-1 | 42 |
| Johannesburg (South Africa) | za-jnb-1 | 37 |
| Kuala Lumpur (Malaysia)     | my-kul-1 | 38 |
| Marseille (France)          | fr-mrs-1 | 36 |
| Querétaro (Mexico)          | mx-qro-1 | 41 |
| Santiago (Chile)            | cl-scl-1 | 43 |