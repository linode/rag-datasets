# [Plans](https://techdocs.akamai.com/cloud-computing/docs/plans-distributed#plans)

To deploy a Linode to a distributed compute region, you'll need a Dedicated CPU Linode plan.

Dedicated CPU Linodes provide you with dedicated CPU resources. Their virtual CPU (vCPU) cores operate competition-free to ensure performance without CPU-related degradation. You can confidently run production applications knowing that other workloads won't affect performance. These Linodes are CPU-optimized and can sustain 100% CPU usage for as long as your application or workload requires.

| Plan            | Service name         | RAM   | CPUs | Storage | Network In/Out  |
| :-------------- | :------------------- | :---- | :--- | :------ | :-------------- |
| Dedicated 4 GB  | g6-dedicated-edge-2  | 4 GB  | 2    | 40 GB   | 4 Gbps / 4 Gbps |
| Dedicated 8 GB  | g6-dedicated-edge-4  | 8 GB  | 4    | 80 GB   | 5 Gbps / 5 Gbps |
| Dedicated 16 GB | g6-dedicated-edge-8  | 16 GB | 8    | 160 GB  | 6 Gbps / 6 Gbps |
| Dedicated 32 GB | g6-dedicated-edge-16 | 32 GB | 16   | 320 GB  | 7 Gbps / 7 Gbps |
| Dedicated 64 GB | g6-dedicated-edge-32 | 64 GB | 32   | 640 GB  | 8 Gbps / 8 Gbps |
| Dedicated 96 GB | g6-dedicated-edge-48 | 96 GB | 48   | 960 GB  | 9 Gbps / 9 Gbps |

  \#Differences in core vs. distributed regions

- **Plan availability and specifications**. Six Dedicated CPU plans offer different resource levels to meet the needs of your application or workload.
- **Plan pricing**. Plans start at $43.20 per month ($0.0648 per hour). For pricing details, see the Linode Plan section of the Cloud Manager Create form or use the API.
- **Outbound network transfer**.  These plans don't include outbound network transfer, and transfer isn't pooled with other services. Transfer costs $0.01/GB. For more information, see [Network transfer usage and costs](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs) .