# [Create a Linode in a distributed compute region](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#create-a-linode-in-a-distributed-compute-region)

 > Note: 
  This topic focuses on [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions). If you need help creating and deploying a Linode to a core compute region, see [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance).

Creating a Linode in a distributed compute region follows a process similar to creating a Linode in a core compute region, with key differences in the available plan types and services.  

You can deploy a Dedicated CPU Linode in a distributed compute region using [Cloud Manager](https://cloud.linode.com/), the [Linode API](https://techdocs.akamai.com/linode-api/reference/api), or the [Linode CLI](https://github.com/linode/linode-cli). You can also use our official [Terraform Provider](https://registry.terraform.io/providers/linode/linode/latest/docs) to [provision Akamai Cloud resources](https://www.linode.com/docs/guides/how-to-build-your-infrastructure-using-terraform-and-linode/).

This guide walks you through creating a Linode in a distributed compute region using Cloud Manager. 

# [Steps to create a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#steps-to-create-a-linode)

1. [Open the Create form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#open-the-create-form-in-cloud-manager)
2. [Select a region](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#select-a-region)
3. [Select a distribution](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#select-a-distribution)
4. [Select a plan](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#select-a-plan)
5. [Set the label and add tags](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#set-the-label-and-add-tags)
6. [Create a password and add SSH keys](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#create-a-password-and-add-ssh-keys)
7. [Assign to a VPC (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#assign-to-a-vpc-optional)
8. [Assign a Cloud Firewall (recommended)](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#assign-a-cloud-firewall-recommended)
9. [Assign to a VLAN (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#assign-to-a-vlan-optional)
10. [Add user data](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#add-user-data)
11. [Deploy your Linode](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#deploy-your-linode)
12. [Verify your Linode](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#verify-your-linode)

# [Open the Create form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#open-the-create-form-in-cloud-manager)

Log in to [Cloud Manager](https://cloud.linode.com/), click **Create** in the top navigation bar, and select _Linode_. This opens the **Create** form.

# [Select a region](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#select-a-region)

Regions correspond to individual data centers located in a different geographical areas. To minimize latency and optimize connection speed and quality, select the distributed compute region closest to your users. All distributed regions support the same [features and services](https://techdocs.akamai.com/cloud-computing/docs/supported-services-distributed).

Select the **Distributed** tab. Select a continent from the **Geographic Area** dropdown list to narrow the regions available. and then select a distributed region from the **Regions** dropdown list.  

# [Select a distribution](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#select-a-distribution)

![A screenshot of the Choose an OS section.](https://techdocs.akamai.com/linode/compute/img/distributed-linux-distribution-v1.png)

When deploying a Linode, you can either deploy a Linux distribution for a barebones install, or a custom image stored on your account.

- **Distributions:** Akamai supports many [Linux distributions](https://www.linode.com/distributions/), including the latest LTS releases of Ubuntu, Debian, CentOS Stream, and RHEL-derivatives such AlmaLinux and Rocky Linux. If you select a distribution from the list, you'll start with a stable Linux operating system and build your own software stack from scratch. Each distribution comes with a set of preinstalled software and commands. See [Choose a Linux distribution](https://techdocs.akamai.com/cloud-computing/docs/choose-a-distribution) for the list of distributions.

- **Images:** Custom Images are created based on existing Linodes or image files. You can select any [Custom Image](https://techdocs.akamai.com/cloud-computing/docs/images) stored in your account. Recovery Images are not supported.

This guide assumes you are creating a Linode from a **Distribution**. If you are creating a Linode from a custom image, see [Deploy an image to a new Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-a-new-compute-instance).

# [Select a plan](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#select-a-plan)

Choose the Dedicated CPU plan that meets the resource requirements of your application or workload. Dedicated CPU plans reserve physical CPU cores for your Linode, letting you use 100% of the resources continuously. For more details, see [Distributed compute region plans](https://techdocs.akamai.com/cloud-computing/docs/plans-distributed).

You can resize your plan at any time. See [Resize a Linode](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance) for instructions

# [Set the label and add tags](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#set-the-label-and-add-tags)

![A screenshot of the Details section](https://techdocs.akamai.com/linode/compute/img/distributed-label-tag-v1.png)

Set the label and add tags for your Linode:

- **Label:** The label identifies the Linode.  Use a descriptive name that indicates its purpose, for example, `acme-web-prod` to ndicate that the Linode is the production website for Acme. Labels must only use letters, numbers, underscores, dashes, and periods. If you have already implemented naming conventions for your cloud infrastructure, follow those conventions. 

- **Tags:** Tags help you to categorize your services. For example, a web development agency might add a tag for each client. You can also add tags to categorize services by environment: development, staging, or production.

# [Create a password and add SSH keys](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#create-a-password-and-add-ssh-keys)

![A screenshot of the Security section.](https://techdocs.akamai.com/linode/compute/img/distributed-password-ssh-v1.png)

- **Root Password:** This password is used to log in to the system as the root user, who has full system access. Use a strong password to prevent attackers from gaining access to your system.

- **SSH Keys:** Add SSH Keys to the root user account to enable authentication without a password. SSH keys are created as a pair: a _private key_ stored on your local computer and a _public key_ that you can upload to remote systems and services. Because you only share your public key while your private key is kept secure, this method is more secure than password-based authentication. See [Manage SSH keys](https://techdocs.akamai.com/cloud-computing/docs/manage-ssh-keys) for guidance.

# [Assign to a VPC (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#assign-to-a-vpc-optional)

Consider using a [VPC](https://techdocs.akamai.com/cloud-computing/docs/vpc) (Virtual Private Network) to isolate your new Linode from other systems on Akamai Cloud and the internet. This adds an additional layer of privacy and can be used alongside Cloud Firewalls. If you are not sure you need a VPC, you can skip this step. You can add this new Linode to a VPC at any time in the future by following the steps within the [Assign a Linode to a VPC](https://techdocs.akamai.com/cloud-computing/docs/assign-a-compute-instance-to-a-vpc) guide.

- **Select VPC:** To assign this Linode to a VPC, select the VPC from the **Assign VPC** dropdown menu. If you do not yet have a VPC in the selected data center, click the **Create a VPC** button and follow the instructions on the [Create a VPC](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc) guide.

- **Select Subnet:** A Linode can be assigned to a single subnet, which lets you further segment traffic and services within a VPC. Select the desired subnet within the **Subnet** dropdown menu.

- **Auto-Assign IPv4 address:** By default, an IPv4 address will be automatically generated for the Linode on the subnet’s defined CIDR range. If you want to manually assign an IP address, uncheck the **Auto-assign a VPC IPv4 address for this Linode** option and enter your custom IPv4 address. This address must still be within the subnet’s IP range.

- **Public IPv4 address:** If you wish to enable public internet access on this new Linode, check the **Assign a public IPv4 address for this Linode** option. By default, this is unchecked and you will not be able to access the internet from this Linode.

- **Additional IPv4 ranges:** You can assign additional IPv4 ranges that can be used to reach this Linode and/or the services running on it. For example, you may wish to assign additional IPv4 ranges to directly expose Docker containers to the VPC.

For additional information and considerations, review the [Assign a Linode to a VPC](https://techdocs.akamai.com/cloud-computing/docs/assign-a-compute-instance-to-a-vpc) guide.

# [Assign a Cloud Firewall (recommended)](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#assign-a-cloud-firewall-recommended)

![A screenshot showing the Firewall section.](https://techdocs.akamai.com/linode/compute/img/distributed-firewall-v1.png)

Assign a cloud firewall to protect your new Linode from unwanted traffic.

Select an existing firewall from the **Assign Firewall** dropdown menu. If you don't have one, click **Create Firewall** to create a new one. Follow the instructions in the [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall) guide. 

If you prefer to assign a firewall at a later time, you can do so by following the instructions in [Apply firewall rules to a service](https://techdocs.akamai.com/cloud-computing/docs/apply-firewall-rules-to-a-service).

# [Assign to a VLAN (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#assign-to-a-vlan-optional)

![A screenshot showing VLAN options.](https://techdocs.akamai.com/linode/compute/img/distributed-vlan-v1.png)

Assign yourLinode to an isolated private L2 network. VLANs are available at no extra cost. See [VLANs](https://techdocs.akamai.com/cloud-computing/docs/vlan) to learn more.

# [Add user data](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#add-user-data)

If you provide user data to the Metadata service, it will be consumed by cloud-init the first time your Linode boots. To learn more about the Metadata service, user data formats, and our cloud-init integration, see [Metadata service](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service).

# [Deploy your Linode](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#deploy-your-linode)

Review the details in the _Linode Summary_ section. If you're satisfied, click **Create Linode** to start the deployment, which can take anywhere from 3 to 30 minutes. After deployment begins, you're redirected to the details page where you can track progress and view additional information about your new Linode, such as IP addresses.

# [Verify your Linode](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#verify-your-linode)

In [Cloud Manager](https://cloud.linode.com/) , click **Linodes** in the side menu and locate your newly created Linode. Check the status column to verify that your Linode is running.

Click the label for your Linode to open a details page with performance analytics and additional configuration options.

# [Next steps](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed#next-steps)

After your Linode has been created and is initialized, configure and secure it. See [Set up and secure a Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance) for guidance.

