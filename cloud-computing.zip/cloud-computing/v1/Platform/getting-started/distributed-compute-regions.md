# [Distributed compute regions (limited availability)](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#distributed-compute-regions-limited-availability)

Distributed compute regions bring the power of full-stack computing to underserved and remote locations, enabling you to build and deploy edge-native applications near users and devices around the world. These distributed regions spread resiliency across multiple locations rather than relying on the availability of a single region.

Distributed regions support a subset of Akamai Cloud features and services supported by core compute regions, and cater to different use cases. While core regions can handle full-duty workloads, distributed regions are ideal for applications that require proximity to end users. 

## [When to deploy to a distributed compute region](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#when-to-deploy-to-a-distributed-compute-region)

You can deploy to a distributed compute region if you have an account and have already deployed Linodes to one or more core regions. 

Consider deploying to a distributed region if you:

- Need to offer a high performing and highly available service to a distributed audience.
- Need to run multiple instances of your application.
- Require very low latency for your application. 
- Want to deliver a consistent user experience, even for users far from core regions

# [Core vs. distributed regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#core-vs-distributed-regions)

**Core compute regions**. These regions are centrally located, offering full features, long-term durability, and scalability for enterprise workloads.  

**Distributed compute regions**. These regions let you deploy parts of your application or workload closer to your users. They enable you to spread resiliency across multiple locations instead of relying on the availability of a single region. Applications deployed to distributed regions should be designed so that any single region or server could fail without impacting overall availability. 

Distributed regions support essential features and services for building highly available, edge-native applications across a growing distributed footprint. These include Dedicated CPU Linodes, Cloud Firewalls, Metadata service (cloud-init), VLANs, IP Sharing, and more. 

Block Storage, Object Storage, and Backups are not directly supported in distributed compute regions, but can be leveraged as part of a larger distributed ecosystem. When state or storage is a key component of your application, distributed regions can connect seamlessly to core region deployments of these services.

For a complete list of features and services, see [Distributed compute region features and services](https://techdocs.akamai.com/cloud-computing/docs/supported-services-distributed). 

To learn more about Service Level Objective targets, contact [Support](https://www.linode.com/support/).

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#availability)

## [Limited availability](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#limited-availability)

Access to distributed compute regions is currently limited. If you want to deploy an application or workload to a distributed region, contact us. 

## [Locations](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#locations)

You can deploy Linodes to these distributed compute regions: 

- Auckland, NZ 
- Berlin, DE
- Bogotá, CO
- Denver, CO, USA
- Hamburg, DE
- Houston, TX, USA
- Johannesburg, ZA 
- Kuala Lumpur, MY
- Marseille, FR
- Querétaro, MX 
- Santiago, CL

View these locations on the [Akamai Cloud map](https://www.linode.com/global-infrastructure/).

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#plans-and-pricing)

To deploy a Linode in a distributed compute region, you need a [Dedicated CPU Linode plan](https://techdocs.akamai.com/cloud-computing/docs/plans-distributed).

Pricing differs between core and distributed regions. For details, see the Linode Plan section of the Cloud Manager Create form, or use the API. 

# [Linux distributions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#linux-distributions)

For the list of supported distributions, see the **Linux Distribution** dropdown menu on the Cloud Manager Create form, or use the API.

# [Use cases](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#use-cases)

Deploying Linodes to distributed compute regions works well for several uses cases, including:

**Gaming:**

- **Matchmaking**. Support digital experiences like player matchmaking that rely on short wait times, high performance, and adaptive decision-making. 
- **Game servers**. Deliver real-time responsiveness essential for competitive gaming.

**Social Media:**

- **User-generated content in live streams**. Optimize interactive experiences such as user reactions to live streams and chats by minimizing latency.
- **WebRTC**. Facilitate low-latency direct communication between geographically close users.

**Media Streaming**

- **Manifest Manipulation**. Enhance video quality, enable seamless ad insertion, and improve the user experience based on real-time edge and device data.
- **Live Streaming**. Optimize streaming performance for viewers near distributed regions.

**Data and AI:**

- **Distributed Data**. Enable global data distribution to power real-time decisioning and scaled computing at the edge.
- **AI Inferencing**. Leverage near-user generalized computing to deliver large language model (LLM) services at a global scale.

# [Limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions#limits-and-considerations)

- **Available features and services**: Distributed compute regions support the subset of Akamai Cloud services that are essential for edge-native applications. To learn more, see [Distributed compute region features and services](https://techdocs.akamai.com/cloud-computing/docs/supported-services-distributed).
- **Bandwidth**: Egress limits for Linodes in distributed regions are similar to core regions. If abnormal usage occurs, Akamai may implement traffic management procedures to maintain network stability and fair usage of impacted resources.
- **Workload migration**: You can migrate Linodes between distributed regions through cold or warm migration. Live migration, and migration between distributed and core regions, are not supported. To learn more, see [Maintenance and migrations](https://techdocs.akamai.com/cloud-computing/docs/compute-migrations#types-of-migrations).
- **Disk encryption**: Local disk encryption is on by default for Linodes in distributed regions, and can't be turned off. For more information, see [Disk encryption](https://techdocs.akamai.com/cloud-computing/docs/local-disk-encryption).