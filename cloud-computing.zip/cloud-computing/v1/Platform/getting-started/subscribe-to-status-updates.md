# [Subscribe to status updates](https://techdocs.akamai.com/cloud-computing/docs/subscribe-to-status-updates#subscribe-to-status-updates)

The [Linode Status page](https://status.linode.com/) provides real-time system status and maintenance updates via email. All customers are encouraged to subscribe to status notifications to stay up-to-date with any events that may impact our services. When you sign up for status updates, you can fine-tune which service updates you receive. These different topic areas are referred to as _components_. If, for example, all your services are restricted to the Newark data center, you may only wish to subscribe to the Newark component.

You can also subscribe to individual incident notifications. In this case, you can be notified of new updates to an incident via email or SMS.

# [Subscribe to email updates](https://techdocs.akamai.com/cloud-computing/docs/subscribe-to-status-updates#subscribe-to-email-updates)

To subscribe to system status and maintenance updates, follow the instructions below.

1. Navigate to the [Linode Status page](https://status.linode.com/).

2. Click on the **Subscribe to Updates** button.

   

3. In the form that appears, enter your email address and click the **Subscribe via email** button.

4. You are brought to another web page with a list of components. Select which components you'd like to receive status updates for and then click the **Save** button.

5. You will receive a confirmation email shortly. In that email, click the **Confirm subscription** button.

# [Subscribe to RSS updates](https://techdocs.akamai.com/cloud-computing/docs/subscribe-to-status-updates#subscribe-to-rss-updates)

Within your RSS aggregator, go through the process of adding a new RSS feed. When prompted, use the following URL for a raw XML list of recent incidents: `https://status.linode.com/history.rss`.

# [Subscribe to an incident](https://techdocs.akamai.com/cloud-computing/docs/subscribe-to-status-updates#subscribe-to-an-incident)

To subscribe to updates for a specific incident:

1. Navigate to the [Linode Status page](https://status.linode.com/).

2. Find the incident you would like to follow and click on its heading. You are brought to that incident's page.

3. Click on the **Subscribe to Updates** button and provide your email and/or telephone number.

# [Update notification preferences or unsubscribe](https://techdocs.akamai.com/cloud-computing/docs/subscribe-to-status-updates#update-notification-preferences-or-unsubscribe)

You can update your component preferences or cancel your subscription to Linode Status and maintenance updates at any time. To update your preferences or to unsubscribe:

1. Navigate to the [Linode Status page](https://status.linode.com/).

2. Click on the **Subscribe to Updates** button and enter your email address.

3. You are brought to your Notification Subscription page. Update your preferences, as needed, and click on the **Update Preferences** button.

4. If you would like to unsubscribe, click on the **Cancel Subscription** link in the Subscriber section of the page and follow the prompt.

 > Note: 
  You can unsubscribe from SMS notifications by replying to any text message notification with the word "STOP".