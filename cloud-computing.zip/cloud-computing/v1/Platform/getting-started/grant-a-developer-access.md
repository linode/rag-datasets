# [Grant a developer access to your services](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#grant-a-developer-access-to-your-services)

One of the most powerful features of Akamai Cloud is the amount of control users have over their account and the software installed on their systems. If you're a business owner that does not have expertise with installing or maintaining software on Linux, or if you do have experience with Linux but don't have the time to set up a new server, then contracting with a developer or administrator is a popular way to get your services up and running.

# [What to keep track of when hiring a developer](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#what-to-keep-track-of-when-hiring-a-developer)

When you hire someone to work on your account, there are a variety of ways to grant access to the Linodes on it, and the system and applications on those Linodes. Recording which of these credentials you've shared is important if you need to end your contract with your developer.

This guide explains and answers some of the most frequently asked questions about account access. The sections are separated in order of granularity, starting with service-level access at the top, and working towards application-specific access.

For security and privacy, [Support](https://techdocs.akamai.com/cloud-computing/docs/help-and-support) is not able to troubleshoot issues related to users and application access. Instead, an in-house Professional Services team can be hired to help with projects. You can reach out to that team through the [Contact Sales](https://www.linode.com/company/contact/) form.

 > Note: 
  The following sections include commands that show how to manipulate credentials on your Linodes, and these commands use `exampleUser` in place of your users' names. Replace `exampleUser` with whatever you would like to name your users.

# [Cloud Manager access](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#cloud-manager-access)

Access to Cloud Manager provides high-level methods for controlling your Linodes and billing, including but not limited to: powering Linodes down, powering them on, removing services, and adding services. Cloud Manager does not have interfaces for manipulating the files and software on your systems--instead, that access is governed by service-specific credentials outlined in the next sections.

## [Who has access to my account?](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#who-has-access-to-my-account)

Log in to Cloud Manager and navigate to the [**Users & Grants**](https://cloud.linode.com/users) section of the **Administration** tab. You may be prompted to reauthenticate your password. This section will display all of your account's users.

If you're not sure whether you're logged in as the account administrator, look for a `No` in the **Restricted** column of your username's row in the User Manager.

## [Add a user to your account](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#add-a-user-to-your-account)

Keep your account administrator credentials secret. When hiring an external individual or agency to work on your site or application, create a _restricted_ user and assign specific access to the account. Learn more about how to manage users and permissions and how to recover a lost username in our [Accounts and Passwords](https://techdocs.akamai.com/cloud-computing/docs/manage-users-on-your-account#recover-a-lost-username) guide.

Useful _Global Grants_ for a limited access user might include the ability to:

- Add a [NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer).
- Add [Longview](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview) clients.
- Use the [DNS Manager](https://techdocs.akamai.com/cloud-computing/docs/dns-manager) to add domains.
- Create [StackScripts](https://techdocs.akamai.com/cloud-computing/docs/stackscripts).
- Create [Images](https://techdocs.akamai.com/cloud-computing/docs/images).
- Add [Block Storage volumes](https://techdocs.akamai.com/cloud-computing/docs/block-storage).

## [Revoke a user's access to the account](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#revoke-a-users-access-to-the-account)

1. If you suspect that the user may have access to their Cloud Manager password, [change that first](https://techdocs.akamai.com/cloud-computing/docs/reset-your-user-password).

2. Log in to [Cloud Manager](https://cloud.linode.com/) and click [**Users & Grants**](https://cloud.linode.com/users) in the **Administration** tab. You may be prompted to reauthenticate your password.

3. Locate the user in the Username column and click **Delete** to remove the user. In the window that appears, click **Delete** to confirm deletion.

# [SSH logins](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#ssh-logins)

The primary method for directly administering files and software on a Linode is through SSH. SSH is a service that runs on a system and listens for and accepts remote terminal connections. Once an SSH connection is opened, a user can issue commands to your server. **Your Linode's SSH users are not the same as your Cloud Manager users.**

For the steps in this section, [connect to your Linode via SSH](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode) to log in to the system as `root`, which is the primary administrative (and most powerful) user on every Linux system. Alternatively, you can login as non-root user with _sudo_ (i.e. administrative) permissions.

 > Note: 
  If you don't remember your root password, [reset it through the Manager](https://techdocs.akamai.com/cloud-computing/docs/reset-your-user-password).

## [Who has SSH access to your Linode?](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#who-has-ssh-access-to-your-linode)

Use `getent` to display the list of users. Keep in mind that some applications create Linux users as part of their normal operation, and those users will be listed here too.

```
getent passwd
```

## [Add an SSH user](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#add-an-ssh-user)

[Create a limited Linux user account](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#add-a-limited-user-account) on your Linode. Set a unique and secure password for this user.

## [Create a user group with specific permissions](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#create-a-user-group-with-specific-permissions)

As an optional alternative to setting permissions for each user, create a limited privilege user group that can be reused and combined with other groups if needed.

1. Add the group. Replace `devGroup` in these examples to a group name you'll remember:

   ```
   groupadd devGroup
   ```

2. Add the user to the group and specify a new home directory for the user:

   ```
   usermod -g devGroup -d /var/www/html/example.com exampleUser
   ```

## [Restrict a user to a specific directory](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#restrict-a-user-to-a-specific-directory)

If your user should only have access to a specific directory and its subdirectories, for example `/var/www/html/example.com/`, use `chroot` _jails_, as described in the [Advanced SSH Security](https://linode.com/docs/guides/advanced-ssh-server-security/#chroot-users) guide.

## [Restrict a user to SFTP only](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#restrict-a-user-to-sftp-only)

For some applications, a user may only need to transfer files to or from the server. In this case, create a user that can transfer files through SFTP but that can't access the server with SSH.

 > Error: 
  The steps in this section disable a user's SSH access. Do not follow the steps in this section for any user who needs SSH access.

Consult our guide to configure this using [SFTP jails on Debian or Ubuntu](https://linode.com/docs/guides/limiting-access-with-sftp-jails-on-debian-and-ubuntu/).

1. Change the `sftp` subsystem line and add a `Match Group sftpOnly` section in `sshd_config`:

   ```text /etc/ssh/sshd_config
   ...
   Subsystem sftp internal-sftp
   ...
   Match Group sftpOnly
       ChrootDirectory %h
       X11Forwarding no
       AllowTcpForwarding no
       ForceCommand internal-sftp
   ```

2. Create an `sftpOnly` group that will only have SFTP access:

   ```
   groupadd sftpOnly
   ```

3. Add a user to the group and disable their SSH access. Change both the user name and home directory:

   ```
   usermod -g sftpOnly -d /home/exampleUser -s /sbin/nologin exampleUser
   ```

4. Restart the SSH service:

   ```
   systemctl restart ssh
   ```

5. Change the ownership of the directory the user should have access to:

   ```
   chown -R exampleUser:sftpOnly /var/www/html/example.com
   ```

The user can now `sftp` to the system and transfer files to and from the specified directory.

## [Revoke access for an SSH user](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#revoke-access-for-an-ssh-user)

To revoke access to an SSH user, change the password for that user:

```
passwd exampleUser
```

In addition to password authentication, a user may rely on [public key authentication](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#harden-ssh-access) to connect via SSH. For any users that you would like to revoke access on, you should also check for the presence of a public key.

These public keys are listed as line in a text file in the user's home directory named `/home/exampleUser/.ssh/authorized_keys`. To see which keys are present, run:

```
cat /home/exampleUser/.ssh/authorized_keys
```

The output will resemble the following:

```text Output
ssh-rsa MIIEpQIBAAKCAQEAqOT7+bo5YUnzmBJYifL5b/VrLhHNjI0Sjm0miyZ4HocvSjIJ+Kx1nWP1LjDG0wt6gimXjRrfPCykHFyJwdZO69dK/gJ0GdcejWtC1sJBCSvI9TISXISLBNXr5rLHedhR2wFOJTRkKTquHP5dw2o5UNBBMyuM0wfkv5ggw8ShecIuO6xCw7yYQIg66BIe2G5toL6uasVOBjvJv5iKWKQNx1sf5ICfDJdVjQojtfHiPAyufidAjm4qO4/jOyfTTncu5+IEJCk12YpO66H3COJwbjPcRXlAcHM4CrBdTb8TmYmmStetY5Lmso++OaD4QjlO2TrhIXjoXDccU7/1BpkdpnPiapPuGKlWYa1vLEeUoIYV6NC9rxJCiYd/V//rBupYt4hkbSAbKl3o24gl1qOw/U7p+yelAZmDVWQCqOOdz3RttXyO/MoET9v0z2+1/57/gxLpHdsrPli7SeyrWMax18GM8DyfjVG5DFxYb/V0uTeew3xVzwXL+OnRdfnIsliSPXkmv15Yqbh10AEarK0EjfHR/VOMEgozrRoL8g9t4Yt5xhiWpbG9wk/EKfj3eaVg2AssQcw6IhzsaS5Kj4qr6aj3I6nx4fhTGUdfvmGqRETR8Hcyg7cDZId9qXve5PVxtxE2ROoszpTLkls+rL7L6+e2y9qfO4Np1ssTWz8495QPojjoMUnMIm6ZTVALjudn+eQ== user@example.com
```

Each SSH public key entry will begin with `ssh-rsa` and end with a corresponding email address (e.g. `user@example.com`).

To remove a public key, edit the `authorized_keys` file and remove the corresponding line. `nano` is a simple text editor in Linux that can be used to do this:

```
nano /home/exampleUser/.ssh/authorized_keys
```

Use the cursor keys to navigate the file, enter `CTRL-O` to save the file, and enter `CTRL-X` to exit the editor.

If you instead want to fully remove the file, run:

```
rm /home/exampleUser/.ssh/authorized_keys
```

 > Error: 
  Files removed in this way can't be easily restored.

# [Add or remove WordPress users](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#add-or-remove-wordpress-users)

If your site runs WordPress, add a user with the appropriate permissions.

WordPress user roles are useful for authors and content contributors, but might not be enough for a developer to work on the site. If you don't feel comfortable sharing the existing administrator account credentials, create an administrator account.

1. Log in to your WordPress admin, typically through `www.example.com/wp-admin` (where `example.com` is your site).

2. Click **Users**, then **All users** to view a list of current users.

3. To add a user:

   1. Click **Add New**, enter the information, and for _Role_, select **Administrator**.
   2. Click **Add New User**

   To revoke privileges or delete a user:

   1. Click the check box next to the user's thumbnail.
   2. To change the role:

      - Select a different role in **Change role to...**, then click **Change**.

      To delete the user:

      - Click **Bulk Actions**, select **Delete**, then click **Apply**. Click **Confirm Deletion** to delete the user.

# [Add and manage Drupal users](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#add-and-manage-drupal-users)

Drupal's main administrator account is the **User 1** account. This account serves as the _root_ user and can create other users with different _permissions_ and _roles_.

Create a new user with administrative-level permissions to grant someone the necessary access to maintain your Drupal site.

1. Log in to the Drupal admin (this may be through your site's `www.example.com/admin`), and click **Manage**, then **People** in the Admin menu.

2. To create a user with administrative privileges, click **Add user** and fill out the information on the page that follows. Select the **Administrator** role when prompted.

To view a list of permissions allowed to the Administrator role, return to the **People** page and click **Permissions**.

## [Configure Drupal roles](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#configure-drupal-roles)

If you don't feel comfortable granting the full list of administrative privileges, create a new Role that can be reused and applied to many users.

1. Select the **Roles** tab, then click **Add role** and give the role an appropriate name on the next page. Click **Save** to return to the Roles list.

2. To assign permissions to the new role, click the **Permissions** tab and locate the new role's column on the right.

3. Create a new user as shown above and select the new role when prompted in Step 2.

## [Remove a Drupal user or revoke user permissions](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#remove-a-drupal-user-or-revoke-user-permissions)

1. Log in to the site's Drupal admin (this may be through your site's `www.example.com/admin`), and click **Manage**, then **People** in the Admin menu.

2. Click **Edit** in the _Operations_ column of the user's name.

3. Change the role, or click **Cancel account** and then choose what should happen with the user's content of the page that follows.

   Once cancelled, the user will appear in the User List with a _Blocked_ status.

# [MySQL/MariaDB database access](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#mysqlmariadb-database-access)

In the background of most web servers is a database that keeps track of users, pages, and other information. The database is configured before a content management system (CMS) like WordPress or Drupal is installed.

While some systems allow the Linux root user to circumvent root database login, you may need to know the SQL root user's password for these steps.

## [Log in to MySQL](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#log-in-to-mysql)

1. [SSH to your Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode) as a user with sudo privileges.

2. Connect to MySQL with `sudo`:

   ```
   sudo mysql -u root
   ```

## [View existing MySQL database users](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#view-existing-mysql-database-users)

To display users and their passwords:

```
SELECT User, Host, Password FROM mysql.user;
```

## [View existing MySQL databases](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#view-existing-mysql-databases)

While logged in to MySQL:

```
SELECT DATABASE();
```

## [Change a MySQL or MariaDB user's password](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#change-a-mysql-or-mariadb-users-password)

While logged in to MySQL:

1. Use `FLUSH PRIVILEGES` before making changes:

   ```
   FLUSH PRIVILEGES;
   ```

2. Set a new password for the user:

   ```
   ALTER USER 'exampleUser'@'localhost' IDENTIFIED BY 'newPassword';
   ```

   If using MariaDB, use the `SET PASSWORD` command:

   ```
   SET PASSWORD FOR 'exampleUser' = PASSWORD('newPassword');
   ```

## [Remove a MySQL user](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#remove-a-mysql-user)

While logged in to MySQL:

```
DROP USER 'exampleUser'@'localhost';
```

If using MariaDB:

```
DROP USER exampleUser;
```

## [Add a new MySQL user](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#add-a-new-mysql-user)

Add a new user and grant them access to a specific database. If you are using a CMS and are concerned about access, update SSH login information. You do not need to create a new user, but it might help to update the database password. See the [Change WordPress Database Password in MySQL](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#change-the-wordpress-database-password-in-mysql) section for more information.

While logged in to MySQL:

```
CREATE USER 'exampleUser'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON databaseName.* TO 'exampleUser';
```

## [Change the WordPress database password in MySQL](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#change-the-wordpress-database-password-in-mysql)

 > Error: 
  This section changes the WordPress database password itself; not any WordPress user. This may affect your WordPress installation.

If you are only trying to change a WordPress user's login information, see the [WordPress Users](https://techdocs.akamai.com/cloud-computing/docs/grant-a-developer-access#add-or-remove-wordpress-users) section. It is rare that anyone should need to modify the database password except in the case of a WordPress migration. Otherwise, it is not likely that you need to follow this section.

1. Use the previous sections to log in to MySQL and find the WordPress database name and user. Replace `wordpress` and `wpuser` in this example with the appropriate names, and `newPassword` with a new secure password:

   ```
   ALTER USER 'wpuser'@'localhost' IDENTIFIED BY 'newPassword';
   FLUSH PRIVILEGES;
   quit
   ```

   If using MariaDB, use the `SET PASSWORD` command:

   ```
   SET PASSWORD FOR 'wpuser' = PASSWORD('newPassword');
   ```

2. Edit your site's `wp-config.php` to reflect the changes:

```php /var/www/html/example.com/public_html/wp-config.php
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'wpuser');

/** MySQL database password */
define('DB_PASSWORD', 'newPassword');

/** MySQL hostname */
define('DB_HOST', 'localhost');
```