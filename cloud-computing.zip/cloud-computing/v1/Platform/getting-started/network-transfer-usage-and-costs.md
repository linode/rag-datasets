# [Network transfer usage and costs](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#network-transfer-usage-and-costs)

# [Overview](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#overview)

**Network transfer** is the exchange of data between two computers over the public internet or a private network. Other providers and publications may also refer to this as data transfer, ingress/egress, and bandwidth.

This traffic is broken down into inbound (ingress) and outbound (egress) network transfer. _Inbound network transfer_ is data sent _to_ your service, such as a file upload. _Outbound network transfer_ is data sent _from_ your service, such as a web page and its images, stylesheets, and JavaScript files.

# [Transfer allowance](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#transfer-allowance)

The following services consume network transfer and, in most cases, include a set amount of outbound network transfer allowance per month. The amount of transfer is displayed along with the pricing and plan details for each service. See the [pricing page](https://www.linode.com/pricing) or Cloud Manager for exact amounts.

- **Linodes:** Consume network transfer, and include 0-20 TB of transfer allowance per month, depending on plan type and size. Transfer is not included for NVIDIA RTX 4000 GPU Linodes, Accelerated Linodes, and Linodes in [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions).

- **NodeBalancers:** Consume network transfer but do not include a monthly transfer allowance.

- **Object Storage:** Consumes network transfer and adds 1 TB of transfer allowance per month to your global network transfer pool.

- **Managed Databases:** Does not consume network transfer or include a monthly transfer allowance for customers using IPv6. To learn more, see [Access control](https://techdocs.akamai.com/cloud-computing/docs/aiven-manage-database#access-control) .

Most core data centers have their transfer allowance and usage tracked in a **global network transfer pool**. Some newer data centers may have their network transfer usage tracked separately in a _specific network transfer pool for that region_. Your global and region-specific pools can be viewed and [monitored](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#monitoring-network-transfer-usage) from your account's **Monthly Network Transfer Pool**. Network transfer isn't pooled in [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions).

When a service is deployed on an account, that service’s prorated transfer allowance is added to its corresponding network transfer pool. Whenever a service consumes network transfer, it is counted towards that pool (not the individual transfer allowance for the service). In most cases, this is the global pool. However, if the service is deployed in a region that has its own specific transfer pool, the network allowances and usage is tracked in that pool (not the global pool).

 > Note: 
  If a service is not active for the entire month, the amount of network transfer allowance is prorated based on the number of hours the service is active.

# [Usage costs](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#usage-costs)

Costs associated with network transfer can be unexpected or confusing in many cloud hosting environments. We keeps these costs simple and transparent so that you can easily anticipate your monthly charges.

**Free unmetered network transfer:**

- All inbound network transfer

- Outbound network transfer sent from Linodes and NodeBalancers to any service within the same data center, provided the traffic occurs over an IPv6 address, a private VLAN network, or on the private IPv4 address of those services. Public IPv4 addresses, due to the way traffic is routed, is not included in this.

**Metered network transfer:**

- Outbound transfer sent from Linodes and NodeBalancers to destinations outside of the origin data center (over both IPv6 and IPv4) and within the same data center if a public IPv4 address is used.

- Outbound transfer from Object Storage (over both public IPv6 and public IPv4), even to other services within the same data center.

All metered network transfer consumed by a service is counted toward either the global network transfer pool or its data center-specific pool (if that region tracks network transfer separately from the global pool). Any transfer usage that exceeds the monthly allotment starts at $0.005/GB (or $5/TB) depending on the service’s region (see the table below). If no transfer is included, all transfer is billed at the following rates. Transfer usage is charged at the end of the billing period.

| Data Center                                       | Network Transfer cost per GB |
| :------------------------------------------------ | ---------------------------- |
| All data core centers (except those listed below) | $0.005/GB                    |
| Jakarta, Indonesia                                | $0.015/GB                    |
| São Paulo, Brazil                                 | $ 0.007/GB                   |
| All distributed data centers                      | $0.01/GB                     |

 > Note: 
  The combined monthly network transfer pools are typically enough to cover _most_ common use cases for our services. You are only billed for additional network transfer if your usage exceeds the global or data center-specific pools during a billing period, or if you have deployed to a distributed compute region.
  If traffic for an individual service exceeds the network transfer amount specified by its plan, but the total transfer used between the rest of your services is still less than your monthly global or region-specific pools, then you are _not_ charged additional fees.

# [Monitoring network transfer usage](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#monitoring-network-transfer-usage)

We recommend that you monitor your network transfer usage throughout the month to ensure that your services aren't consuming more network transfer than expected. You can check your network usage for your current billing cycle via Cloud Manager or the Linode CLI.

## [Cloud manager](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#cloud-manager)

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Under the list of Linodes, NodeBalancers, or Object Storage Buckets, a short notice is displayed with the percentage of monthly network transfer pool that has been used.

   ![A screenshot of the Monthly Network Transfer Pool notice.](https://techdocs.akamai.com/linode/platform/img/accounts-network-transfer-notice-v1.jpg)

3. Click _Monthly Network Transfer Pool_ to display a modal pop-up with more details, including: your active pools, the amount of transfer used, the size of your pools, and when the network transfer usage will reset.

   ![A screenshot of the Monthly Network Transfer Pool pop-up.](https://techdocs.akamai.com/linode/platform/img/accounts-monthly-network-transfer-pool-v1.jpg)

   > > Note: 
   > 
   > Unless you have services deployed in a region that tracks data center-specific network transfer separately, you will only see the global network transfer pool displayed.

     

4. Lastly, you can view more details regarding a Linode's network transfer usage (including historical charts) directly on the Linode's page in Cloud Manager. To do so, click **Linodes** on the left navigation menu, select your Linode from the list, and navigate to the **Network** tab.

   

   The **Monthly Network Transfer** section includes usage details for the current billing period. The **Network Transfer History** section shows a chart with usage details over the selected period.

## [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#linode-cli)

To view your network utilization (in GB) for the current month, issue the following command:

```
linode-cli account transfer
```

 > Note: 
  You need to generate a Personal Access Token and install the Linode CLI before being able to use the CLI. See the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli) guide for more information.

## [Email alerts](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#email-alerts)

An email notification is automatically sent to [your account's email address](https://techdocs.akamai.com/cloud-computing/docs/change-your-email-address) when you have used 80%, 90%, and 100% of your transfer pool size.

# [More information](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs#more-information)

Read the [Billing and Payments](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works) guide for an overview of billing.