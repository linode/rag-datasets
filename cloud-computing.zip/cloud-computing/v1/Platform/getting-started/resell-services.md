# [Resell services](https://techdocs.akamai.com/cloud-computing/docs/resell-services#resell-services)

Partnerships and reselling of our services to third-party customers is welcomed and encouraged. Anyone can resell services. Discounted pricing is offered to resellers. If you are interested in becoming a reseller and learning more about discounted pricing, please contact our team through the [Partner form](https://www.linode.com/partners/apply/) or by emailing [partners@linode.com.](mailto:partners@linode.com.) This guide provides more information about our partner program and outlines the process of becoming a reseller.

# [What is a reseller](https://techdocs.akamai.com/cloud-computing/docs/resell-services#what-is-a-reseller)

A reseller is any person or entity that charges a third party for Akamai Cloud services, acting as a kind of middleman. Resellers are free to charge clients for full or partial access to Akamai Cloud services, either through the use of the [Linode API](https://techdocs.akamai.com/cloud-computing/docs/resell-services#linode-api), or by giving a client access to services provisioned on their behalf.

There are a variety of reasons one might want to resell our services. One of the most common reasons developers and engineers become resellers is because they use Akamai Cloud services to test, develop, and/or host their client's websites and apps, and in doing so need to bill those clients for charges accrued by the services that power this business. Specific examples of this pattern include:

- An agency that creates custom WordPress installations for their customers on Akamai Cloud.

- An app developer that uses Akamai Cloud to host their customer's database.

- A business which operates a fully-fledged hosting platform based on Akamai Cloud services, using tools like the [Linode API](https://techdocs.akamai.com/cloud-computing/docs/resell-services#linode-api). One such example is Cloudnet Sweden, a platform-as-a-service (PaaS) that uses Akamai Cloud as a cloud host for their managed platform. Read our [case study on Cloudnet Sweden](https://www.linode.com/content/cloudnet/) for an in-depth look at why they chose to partner with us.

# [Referral program](https://techdocs.akamai.com/cloud-computing/docs/resell-services#referral-program)

As an alternative to reselling our services, you can participate in our referral program. See the [Referral Program](https://www.linode.com/referral-program/) page on our website or the [Referral Program](https://techdocs.akamai.com/cloud-computing/docs/referral-program) section within our billing guide for more details.

Advertising your referral code to others is not the same as reselling our services. When someone else uses your referral code, they create an entirely separate account with their own billing.

# [Things resellers should keep in mind](https://techdocs.akamai.com/cloud-computing/docs/resell-services#things-resellers-should-keep-in-mind)

There are a few stipulations that resellers should keep in mind:

- All resellers, and the customers of resellers, are bound to our [Terms of Service](https://www.linode.com/tos) (ToS). If for any reason a customer of a reseller breaks our ToS, it is the reseller who will be held accountable. If you are planning on becoming a reseller it is a good idea to carefully craft a ToS of your own that is in accordance with the ToS.

- All resellers, and the customers of resellers, are bound to our [Acceptable Use Policy](https://www.linode.com/aup) (AUP). If for any reason a customer of a reseller breaks the AUP, it is the reseller who will be held accountable.

- Payments are to be made directly to Akamai by the reseller. If a customer of a reseller fails to pay the reseller for their services, the reseller is still responsible for their monthly payment to Akamai.

- Support can help with issues related to the physical operation of your services, but issues related to your software configuration are outside of the [scope of Support](https://techdocs.akamai.com/cloud-computing/docs/help-and-support#scope-of-support). There are a number of [resources](https://techdocs.akamai.com/cloud-computing/docs/help-and-support#types-of-questions-and-issues) to help with configuration questions. Support is only available to people with access to a [Cloud Manager user](https://techdocs.akamai.com/cloud-computing/docs/resell-services#limited-cloud-manager-users). If your customers do not have their own Akamai Cloud users, they will not be able to contact Support.

# [How to resell service](https://techdocs.akamai.com/cloud-computing/docs/resell-services#how-to-resell-service)

## [Linode API](https://techdocs.akamai.com/cloud-computing/docs/resell-services#linode-api)

The best way to resell our services is through the use of the Linode API. The Linode API provides robust, programmatic access to the full suite of services. Using the API, a reseller could set up a custom user interface to only allow the select features they want available for their customers. For example, it's possible to create a UI that only enables 4GB Linodes and that automatically provisions those Linodes with a StackScript. 

Here are a few assets to help you with the API:

- [API workflow](https://techdocs.akamai.com/linode-api/reference/api-workflow). A basic usage example of the API.
- [API summary](https://techdocs.akamai.com/linode-api/reference/api-summary). A full linked list of all of the operations available with the API.
- [Developer portal](https://developers.linode.com/libraries-tools/). Additional Linode API libraries and tools.

## [Limited Cloud Manager users](https://techdocs.akamai.com/cloud-computing/docs/resell-services#limited-cloud-manager-users)

If a reseller wants to be able to give reseller customers access to parts of Cloud Manager without developing a new user interface, they can create a limited Manager _user_ in Cloud Manager. A user is a set of credentials that can access your account, and your account can have multiple users. A user can be restricted to have a limited set of permissions, such as only being able to access certain Linodes and not having access to your billing information. To create a limited user in Cloud Manager, review the [Users and Permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-users-on-your-account#add-a-user) section of the Accounts and Passwords guide.

 > Note: 
  Cloud Manager users are not related to the Linux users you may separately configure on Linodes. If you need to revoke a customer's account access, you should remove access to both their Cloud Manager users and their Linux users. Read the [Linux Users and Groups](https://linode.com/docs/guides/linux-users-and-groups/) guide for more information on this subject.

## [Limited Linux user accounts](https://techdocs.akamai.com/cloud-computing/docs/resell-services#limited-linux-user-accounts)

A reseller might provide a customer with limited access to a Linode by creating an account for them at the operating system level. This provides the customer with access to their server, without access to the features of the Linode API or Cloud Manager. For a hosting reseller that offers access to a pre-defined Linux environment, this is often a good solution. Read the [Linux Users and Groups](https://linode.com/docs/guides/linux-users-and-groups/) guide for more information on this subject. You may also want to limit users' access to the filesystem with [SFTP jails](https://linode.com/docs/guides/limiting-access-with-sftp-jails-on-debian-and-ubuntu/).

# [Frequently asked questions](https://techdocs.akamai.com/cloud-computing/docs/resell-services#frequently-asked-questions)

## [Can I show logos on my site?](https://techdocs.akamai.com/cloud-computing/docs/resell-services#can-i-show-logos-on-my-site)

Yes. Please use the official [Akamai media resources](https://www.akamai.com/newsroom/media-resources).

## [What payment methods are available?](https://techdocs.akamai.com/cloud-computing/docs/resell-services#what-payment-methods-are-available)

Automatic payments can be made with a credit card. All accounts are required to have a credit card on file. Manual PayPal payments can also be made, so you can add credit to your account with PayPal. For more information on billing, review the [Payment Methods](https://techdocs.akamai.com/cloud-computing/docs/manage-payment-methods) guide.

## [Is there a white-label interface?](https://techdocs.akamai.com/cloud-computing/docs/resell-services#is-there-a-white-label-interface)

We do not offer a white-label interface, but you could create one via the [Linode API](https://techdocs.akamai.com/linode-api/reference/api).

## [Can I model my terms of service on Akamai's ToS?](https://techdocs.akamai.com/cloud-computing/docs/resell-services#can-i-model-my-terms-of-service-on-akamais-tos)

Yes, you can refer to our [ToS](https://www.linode.com/tos) and [AUP](https://www.linode.com/aup) when authoring your own policies. In addition, your business and your customers need to comply with these policies.