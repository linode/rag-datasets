# [Welcome to Akamai Cloud](https://techdocs.akamai.com/cloud-computing/docs/welcome#welcome-to-akamai-cloud)

Build, deploy, and scale your modern applications faster and easier on Akamai Cloud. Choose from a variety of user-friendly and reliable cloud solutions to help you grow your business. 

# [Benefits](https://techdocs.akamai.com/cloud-computing/docs/welcome#benefits)

Akamai Cloud offers these benefits:

- **Accessibility.** Build web, mobile, database, and machine learning applications using our intuitive browser-based [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager) interface. Use the [Linode API](https://techdocs.akamai.com/linode-api/reference/api) to programmatically manage the full range of  products and services. The [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/cli) also lets you manage your account from the command line. 
- **Scalability.** Scale up or down in seconds across comprehensive solutions, ranging from standard VMs to dedicated CPUs and enterprise-grade graphical processors.
- **Pricing.** Only pay for what you use. [Billing](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works)  is clear, consistent, and transparent across every global data center and advanced cloud solution. 
- **Tools.** Choose from a wide variety of robust developer tools to manage your infrastructure.
- **One-click apps and stacks.** Manage your infrastructure or quickly deploy a Linode using pre-installed and ready-to-use software applications. Visit [Marketplace](https://www.linode.com/docs/marketplace-docs) in Cloud Manager for a list of available apps, dev environments, and services. 

# [Get started with cloud computing](https://techdocs.akamai.com/cloud-computing/docs/welcome#get-started-with-cloud-computing)

Let's get started by creating an account and your first Linode. 

 > Tip: 
  To learn more, review the [Cloud computing](https://techdocs.akamai.com/platform-basics/docs/cloud-compute)  section in the [Get to know Akamai](https://techdocs.akamai.com/platform-basics/docs/welcome) guide. You can also follow the steps in the [Build on the cloud](https://techdocs.akamai.com/get-started-cloud-computing/docs/get-started) tutorial and set up your own highly available Linodes to deliver a basic site.

## [Create an account](https://techdocs.akamai.com/cloud-computing/docs/welcome#create-an-account)

To sign up to start using Akamai Cloud services, open a web browser and navigate to [login.linode.com/signup](https://login.linode.com/signup). For further instructions and information about Akamai Cloud, visit the [Get started](https://techdocs.akamai.com/cloud-computing/docs/getting-started) guide.

 > Tip: 
  To protect your account against unauthorized access, you can implement several security controls, such as 2FA, security questions, and phone verification. Visit [Security Controls for User Accounts](https://techdocs.akamai.com/cloud-computing/docs/security-controls-for-user-accounts) for more information.

Once you have your account, you can begin using [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager) to manage your account, view your bills, and add services. It's also where you can build, scale, and monitor all of your services.

For a Cloud Manager overview, watch this five-minute introductory video.

[block:html]
{
  "html": "\n

"
}
[/block]

## [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/welcome#create-a-linode)

Follow these steps to create a Linode. A Linode is a Linux-based virtual private server that lets you deploy applications and services.

1. **Choose a data center.** Before you start, review the information about [data centers](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center). The geographic location of your Linode can make a big impact on the connection speeds to your server. 
2. **Create a Linode.** You can use a Linode for nearly any purpose. They come in several different types, including Dedicated CPU, Shared CPU, Premium, High Memory, and GPU. Follow the detailed steps in the guide to [create your first Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance).
3. **Check the configuration settings.** The configuration settings help you make sure that your Linode is ready for use. You can update your system, set the time zone, configure a custom hostname, add a limited user, harden SSH to prevent unauthorized access, and configure a firewall. These steps are optional but are important to [secure your Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance).

# [Set up services](https://techdocs.akamai.com/cloud-computing/docs/welcome#set-up-services)

In addition to Linodes, you can set up other services to get the most out of cloud computing. 

## [Compute](https://techdocs.akamai.com/cloud-computing/docs/welcome#compute)

[block:html]
{
  "html": "\n \n\t\t\n\t\t\t\n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/lke.png\\")\n\t\t\t\n\t\t\t| \n **Linode Kubernetes Engine (LKE).** Deploy a production-ready managed Kubernetes cluster to control and scale your application's infrastructure.\n\t\t\t\n\t\t  
 ---|---  
 \n\t\n
"
}
[/block]

## [Storage](https://techdocs.akamai.com/cloud-computing/docs/welcome#storage)

Akamai Cloud offers dependable, easily accessible storage and management solutions.

[block:html]
{
  "html": "\n \n\t\t\n\t\t\t\n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/block-storage.png\\")\n\t\t\t\n\t\t\t| \n **Block Storage.** Add storage to a Linode using a scalable, high-speed, fault-tolerant, and portable (detachable) storage volume.\n\t\t\t\n\t\t  
 ---|---  
 \n \n \n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/object-storage.png\\")\n\t\t\t\n\t\t\t| \n **Object Storage.** Store data independently of a Linode using this Amazon S3-compatible object storage service.\n\t\t\t\n\t\t  
 \n \n \n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/backups.png\\")\n\t\t\t\n\t\t\t| \n **Backups.** Safeguard your data with fully managed automatic daily, weekly, and biweekly backups of your Linodes.\n\t\t\t\n\t\t  
 \n\t\t\n\t\t\t\n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/images.svg\\")\n\t\t\t\n\t\t\t| \n **Images.** Create pre-configured disk images or upload image files that you can rapidly deploy to new or existing Linodes.\n\t\t\t\n\t\t  
 \n\t\n
"
}
[/block]

## [Cloud networking](https://techdocs.akamai.com/cloud-computing/docs/welcome#cloud-networking)

These robust networking tools allow you to secure your network, balance traffic, and control your infrastructure.

[block:html]
{
  "html": "\n\t\n\t\t\n \n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/node-balancer.png\\")\n\t\t\t\n\t\t\t| \n **NodeBalancers.** Enable high availability and horizontal scaling on your Linodes with a managed cloud-based load balancing service.\n\t\t\t\n\t\t  
 ---|---  
 \n\t\t\n\t\t\t\n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/cloud-firewall.png\\")\n\t\t\t\n\t\t\t| \n **Cloud Firewalls.** Use this free cloud-based firewall service to secure any Linode and NodeBalancer.\n\t\t\t\n\t\t  
 \n\t\t\n \n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/dns-manager.png\\")\n\t\t\t\n\t\t\t| \n **DNS Manager.** Use this free comprehensive domain and DNS management service to add your registered domain names and manage DNS records.\n\t\t\t\n\t\t  
 \n\t\t\n\t\t\t\n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/VLAN.png\\")\n\t\t\t\n\t\t\t| \n **VLANs.** Secure traffic between Linodes using a private L2 network.\n\t\t\t\n\t\t  
 \n\t\t\n\t\t\t\n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/vpc.png\\")\n\t\t\t\n\t\t\t| \n **VPC.** Isolate your network traffic from other customers and the internet using a virtual private cloud.\n\t\t\t\n\t\t  
 \n\t\n
"
}
[/block]

## [Databases](https://techdocs.akamai.com/cloud-computing/docs/welcome#databases)

Add a fully managed cloud database service with high availability.

[block:html]
{
  "html": "\n \n\t\t\n\t\t\t\n\t\t\t\t![](\\"https://techdocs.akamai.com/linode/img/DBaaS.png\\")\n\t\t\t\n\t\t\t| \n **Managed Databases.** Support production database workloads using a reliable, performant, highly available, and fully managed database cluster.\n\t\t\t\n\t\t  
 ---|---  
 \n\t\n
"
}
[/block]