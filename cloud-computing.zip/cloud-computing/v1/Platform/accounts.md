# [Accounts](https://techdocs.akamai.com/cloud-computing/docs/accounts#accounts)

Your account is your gateway to deploying and using Akamai Cloud products and services. If you're new to Akamai Cloud, see the [Getting Started](https://techdocs.akamai.com/cloud-computing/docs/getting-started) guide to learn how to sign up for an account and deploy your first service.

# [Multiple users](https://techdocs.akamai.com/cloud-computing/docs/accounts#multiple-users)

Every account can have multiple users, each with their own permissions. This enables each person on your team (from account managers to developers) to use our services with their own set of credentials and levels of access. See [Manage Users](https://techdocs.akamai.com/cloud-computing/docs/manage-users-on-your-account) and [Set User Permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-user-account-permissions).

# [Enhanced security](https://techdocs.akamai.com/cloud-computing/docs/accounts#enhanced-security)

Protect your account with added security by using [two-factor authentication](https://techdocs.akamai.com/cloud-computing/docs/manage-2fa) or logging in with a [third-party provider](https://techdocs.akamai.com/cloud-computing/docs/enable-third-party-authentication). Each account is also further protected by user-defined [security questions](https://techdocs.akamai.com/cloud-computing/docs/security-controls-for-user-accounts#security-questions) and [phone verification](https://techdocs.akamai.com/cloud-computing/docs/security-controls-for-user-accounts#phone-verification).