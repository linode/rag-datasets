# [Manage Block Storage volumes with the Linode API](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api#manage-block-storage-volumes-with-the-linode-api)

The Linode API lets you create, delete, attach, detach, clone, and resize Block Storage volumes.

# [Before you begin](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api#before-you-begin)

You need a Personal Access Token for the Linode API to complete the steps in this guide. See [Manage personal access tokens](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens#create-an-api-token) for more information.

Store the token as a temporary shell variable to simplify repeated requests. Replace `
` in this example with your token:

```
export TOKEN=

```

# [Create a Block Storage volume](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api#create-a-block-storage-volume)

Create a new Block Storage volume by making a POST request to the `/volumes` endpoint. You can also automatically attach the new volume to an existing Linode by passing the Linode's ID when creating the volume.

1. List the Linodes on your account:

   ```
   curl -H "Authorization: Bearer $token" \
       https://api.linode.com/v4/linode/instances
   ```

   Choose a Linode from the returned list and copy its `id` and `region` values.

2. Create a volume in the same region as the target Linode. Use the ID of the target Linode and adjust the size (in GB), region, set encryption to `enabled` or `disabled`, and label to the desired values:

   ```
   curl -H "Content-Type: application/json" \
       -H "Authorization: Bearer $token" \
       -X POST -d '{
         "label": "my-volume",
         "region": "us-east",
         "size": 100,
         "linode_id": 1234567,
         "encryption": enabled

       }' \
       https://api.linode.com/v4/volumes
   ```

   > > Note: 
   > 
   > - The volume and Linode must be in the same region.
   > - The label can be up to 32 characters long and can contain uppercase and lowercase letters, numbers, hyphens, and underscores.

3. Examine the response JSON object and copy the values in the `id` and `filesystem_path` fields:

   ```json
   {
     "linode_id":1234567,
     "label":"my-volume",
     "size":100,
     "updated":"2018-05-07T14:59:48",
     "created":"2018-05-07T14:59:48",
     "encryption": "enabled",
     "id":6830,
     "status":"creating",
     "region":"us-east",
     "filesystem_path":"/dev/disk/by-id/scsi-0Linode_Volume_my-volume"
   }
   ```

4. Query the volume using the `/volumes/$volume_id` endpoint to make sure it was successfully created:

   ```
   curl -H "Authorization: Bearer $token" \
       https://api.linode.com/v4/volumes/$volume_id
   ```

   If the `status` field in the response is `active`, your volume is ready to use.

## [Mount the volume](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api#mount-the-volume)

The API can't directly mount the new volume after it is attached. SSH into the Linode and mount it manually:

1. Create a filesystem on the volume:

   ```
   mkfs.ext4 $volume_path
   ```

2. Create a mountpoint:

   ```
   mkdir /mnt/my-volume
   ```

3. Mount the volume:

   ```
   mount $volume_path /mnt/my-volume
   ```

4. To automatically mount the volume every time your Linode boots, add the following line to your `/etc/fstab` file:

   ```text /etc/fstab
   $volume_path /mnt/my-volume defaults 0 2
   ```

# [Attach and detach the volume](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api#attach-and-detach-the-volume)

If you did not specify a Linode when creating the volume, or would like to attach it to a different Linode, use the `/attach` and `/detach` endpoints:

1. Detach the volume. Replace `$volume_id` with the volume ID from the previous section:

   ```
   curl -H "Authorization: Bearer $token" \
       -X POST \
       https://api.linode.com/v4/volumes/$volume_id/detach
   ```

2. Attach the volume to the new target Linode:

   ```
   curl -H "Authorization: Bearer $token" \
       -H "Content-Type: application/json" \
       -X POST -d \
       '{ "linode_id": $linode-id }' \
       https://api.linode.com/v4/volumes/$volume_id/attach
   ```

   > > Note: 
   > 
   > If a Linode is not running and has more than one configuration profile, include a `config_id` parameter in the POST request to specify which profile to use. If you do not specify a profile, the first profile will be used by default.

# [Clone a volume](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api#clone-a-volume)

To copy all of the data in a Block Storage volume to a new volume:

```
curl -H "Authorization: Bearer $token" \
    -X POST -d '{
      "label": "new-volume"
    }' \
    https://api.linode.com/v4/volumes/$volume_id/clone
```

# [Delete a volume](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api#delete-a-volume)

Remove a volume from your account with a DELETE request. If the volume is attached to a Linode, you will have to detach it before it can be deleted:

```
curl -H "Authorization: Bearer $token" \
    -X DELETE \
    https://api.linode.com/v4/volumes/$volume_id
```

# [Resize a volume](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api#resize-a-volume)

If you need additional space, you can increase the size of a volume through the API. It is not possible to reduce the size of a volume.

Pass the desired size (in gigabytes) using the `size` parameter:

```
curl -H "Content-Type: application/json" \
    -H "Authorization: Bearer $token" \
    -X POST -d '{
        "size": 200
    }' \
    https://api.linode.com/v4/volumes/$volume_id/resize
```

 > Note: 
  After resizing the volume, you also need to resize the file system to accommodate the additional space. For instructions, see the last few steps on the [Resize a volume](https://techdocs.akamai.com/cloud-computing/docs/resize-a-volume) guide.