# [Configure and mount a volume](https://techdocs.akamai.com/cloud-computing/docs/configure-and-mount-a-volume#configure-and-mount-a-volume)

Once a Block Storage volume has been attached to a Linode, you need to perform a few additional steps before you can start using it. These steps include creating a file system (if you're configuring a new volume) and mounting the volume to your Linode's system. To make configuration easier, all the necessary commands can be viewed directly in Cloud Manager.

1.  Log in to [Cloud Manager](https://cloud.linode.com/linodes) and click on the **Volumes** link in the sidebar.

1.  Locate the desired volume within the list and click the **Show Config** link, which may appear within the **more options ellipsis** dropdown menu.

1.  The **Volume Configuration** panel appears and contains the commands needed to fully configure the volume with your Linode.

1.  Login to your Linode using [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

1.  Enter each command that's shown in the **Volume Configuration** panel, modifying them if needed. These configuration steps are also listed below:

    1.  **Create a file system.** If your volume *has not* been used before, create an ext4 file system on the volume.

        > > Error:
        > Skip this step if you wish to retain any data stored on an existing volume. Creating a new file system will overwrite any existing data and result in data loss. You can view existing file systems on an unmounted volume with the following command:
        >
        >             blkid FILE_SYSTEM_PATH
        >
        >         If you do not receive output, there is currently no file system on this volume.

        You can create an ext4 file system by running the following command, where `FILE_SYSTEM_PATH` is your volume's file system path:

            mkfs.ext4 FILE_SYSTEM_PATH

    1.  **Create a mount point.** This is the directory on your Linux system where the Block Storage files will be located.

            mkdir /mnt/BlockStorage1

    1.  **Mount the volume manually.** Mount the Block Storage volume to the directory you just created. After this is completed, you can access your files from that directory.

            mount FILE_SYSTEM_PATH /mnt/BlockStorage1

    1.  **Mount the volume automatically.** If you want to mount the new volume automatically every time your Linode boots, add the following line to your **/etc/fstab** file:

            FILE_SYSTEM_PATH /mnt/BlockStorage1 ext4 defaults 0 2

        > > Note:
        > If you plan on detaching the volume regularly or moving it between other Linodes, you may want to consider adding the flags `noatime` and `nofail` to the **/etc/fstab** entry.
        >
        >         * `noatime` - This will save space and time by preventing writes made to the file system for data being read on the volume.
        >         *  `nofail`  - If the volume is not attached, this will allow your server to boot/reboot normally without hanging at dependency failures if the volume is not attached.
        >
        >         Example:
        >
        >             FILE_SYSTEM_PATH /mnt/BlockStorage1 ext4 defaults,noatime,nofail 0 2