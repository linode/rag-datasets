# [Get started with Block Storage](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-block-storage#get-started-with-block-storage)

Block Storage volumes are persistent storage devices that can be attached to a Linode and used to store any type of data. They are especially useful for storing website files, databases, media, backups, and _much_ more. To get started with Block Storage, create a volume using the guide below.

- [View, create, and delete volumes](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes)

Once a Block Storage volume has been created, it can be attached to any Linode in the same region. Since volumes are external device, they are portable and can be attached and detached to Linodes as needed. Once attached, the device is assigned to an available block device (such as `/dev/sdc`) on a Linode's Configuration Profile and has its own path in your Linode's file system. When attaching and detaching a volume, additional internal configuration is needed to create a file system (if one hasn't already been created), mount or unmount the volume, and automatically mount the volume at system boot.

- [Attach and detach existing volumes](https://techdocs.akamai.com/cloud-computing/docs/attach-and-detach-a-volume)
- [Configure a volume on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-and-mount-a-volume)

When a volume is attached to a Linode, you can [log in to that Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode) and access the volume's data through its mount point. For instance, if the volume was mounted in `/mnt/volume/`, you can navigate to that directly to view any files stored on that volume. You can also use that directory when integrating your volume with any software or tooling you might employ.