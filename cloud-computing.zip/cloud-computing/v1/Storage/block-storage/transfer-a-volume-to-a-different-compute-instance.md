# [Transfer a volume to a different Linode](https://techdocs.akamai.com/cloud-computing/docs/transfer-a-volume-to-a-different-compute-instance#transfer-a-volume-to-a-different-linode)

Follow these steps to move a Block Storage volume to a different Linode _within the same data center_.

 > Note: 
  Volumes can only be attached to Linodes located in the same data center. To migrate data to a different data center, see the [Transfer Block Storage data between data centers](https://techdocs.akamai.com/cloud-computing/docs/transfer-block-storage-data-between-data-centers) guide.

1. Detach the volume from the original Linode. See [Attach and detach volumes > Detach a volume](https://techdocs.akamai.com/cloud-computing/docs/attach-and-detach-a-volume#detach-a-volume) for instructions.

2. Attach the volume to the desired Linode within the same data center as the volume. See [Attach and detach volumes > Attach a volume](https://techdocs.akamai.com/cloud-computing/docs/attach-and-detach-a-volume#attach-a-volume) for instructions.