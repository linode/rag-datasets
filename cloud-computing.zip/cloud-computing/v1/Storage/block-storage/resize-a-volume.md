# [Resize a volume](https://techdocs.akamai.com/cloud-computing/docs/resize-a-volume#resize-a-volume)

At any time after the Block Storage volume has been created, it can be increased to a larger size.

 > Warning: Volume size cannot be decreased
  At this time, the size of volumes are only able to be increased (not decreased). To decrease the size of your volume, you will need to create a new volume at your preferred size, attach it to a Linode, copy over your data, and remove the original volume.

1. Log in to [Cloud Manager](https://cloud.linode.com/linodes).

2. If the volume is attached to a Linode, power off that Linode.

3. Click on the **Volumes** link in the sidebar.

4. Locate the desired volume within the list, click the **more options ellipsis** dropdown menu, and select **Resize**.

5. Enter the new volume size. The minimum size is the current size of the volume and maximum is 10,240 GB. Then click **Submit**.

6. Click **Resize Volume** to start the resize. Once the resize has been completed, you will receive a notification in Cloud Manager.

7. After the volume is resized, power back on your Linode.

8. Once your Linode has fully booted up, you need to run the following commands to resize the file system within your volume.

   1. Login to your Linode using [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

   2. Unmount the volume, making sure to use the unique path for your own volume:

      ```
      umount /dev/disk/by-id/scsi-0Linode_Volume_BlockStorage1
      ```

   3. Assuming you have an ext2, ext3, or ext4 partition, run a file system check:

      ```
      e2fsck -f /dev/disk/by-id/scsi-0Linode_Volume_BlockStorage1
      ```

   4. Then resize it to fill the new volume size:

      ```
      resize2fs /dev/disk/by-id/scsi-0Linode_Volume_BlockStorage1
      ```

   5. Mount your volume back onto the filesystem:

      ```
      mount /dev/disk/by-id/scsi-0Linode_Volume_BlockStorage1 /mnt/BlockStorage1
      ```