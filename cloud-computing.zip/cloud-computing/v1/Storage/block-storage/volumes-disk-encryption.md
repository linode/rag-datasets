# [Volume Encryption](https://techdocs.akamai.com/cloud-computing/docs/volumes-disk-encryption#volume-encryption)

Full disk encryption ensures that the data stored on a block volume drive is secure. It protects against unauthorized access by keeping the data encrypted if the volume drive is removed from the data center, decommissioned, or disposed of.

The platform automatically manages the encryption and decryption process for you. An encrypted volume can be used in the same way that a non-encrypted volume is used today. 

You can enable or disable disk encryption only when creating new block volumes. After a volume is created, the encryption setting cannot be changed. By default, volume disk encryption is disabled. 

 > Note: Migrating your data to an encrypted volume
  If you want to migrate data from an unencrypted volume to an encrypted volume, you'll need to create a new encrypted volume and then transfer your data from the unencrypted volume to the new one.

  

 > Note: Local disk encryption and block volume encryption
  It's possible that the local disks for a Linode are encrypted but the block storage volumes attached to them are not. You can also have encrypted volumes attached to unencrypted Linodes.

## [How encryption works on Block Storage Volumes](https://techdocs.akamai.com/cloud-computing/docs/volumes-disk-encryption#how-encryption-works-on-block-storage-volumes)

| Operation                                                                                                                                                       | Volume Encryption Behavior                                                                                                                                                                                                                                                                           |   |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | - |
| [**Create volume:**](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance) Adds a volume which can be attached to Linodes.                                                       | Volume encryption is disabled by default.  After a volume is created, you can't change this setting.                                                                                                                                                                                                 |   |
| [**Clone a volume:**](manage-block-storage-volumes-with-the-api#clone-a-volume) Copies all of the data in a Block Storage volume to a new volume using the API. | <li>If a volume is cloned from an encrypted volume, the cloned volume is also encrypted.</li> <li>If a volume is cloned from an unencrypted volume, the cloned volume is also unencrypted.</li><li>When the status of a volume is `Key Rotating`, the option to **Clone** a volume is disabled.</li> |   |
| [**Resize a volume:**](https://techdocs.akamai.com/cloud-computing/docs/resize-a-volume) Increases the size of a volume through the API. It is not possible to reduce the size of a volume.                  | <li>If an encrypted volume is resized, it remains encrypted. </li> <li>If an unencrypted volume is resized, it remains unencrypted.</li><li>When the status of a volume is `Key Rotating`, the option to **Resize** a volume is disabled.</li>                                                       |   |
| [**Transfer Block Storage data to a different data center**](https://techdocs.akamai.com/cloud-computing/docs/transfer-block-storage-data-between-data-centers)                                              | During the Block Storage data transfer, decrypted data from the source volume is copied over to the destination volume. The destination volume can have encryption enabled or disabled.                                                                                                              |   |
| [**Transfer Block Storage data to another Linode within the same data center**](https://techdocs.akamai.com/cloud-computing/docs/transfer-a-volume-to-a-different-compute-instance)                          | Detaching an encrypted volume from one Linode and attaching it to another within the same data center is supported.                                                                                                                                                                            |   |

  

## [Availability](https://techdocs.akamai.com/cloud-computing/docs/volumes-disk-encryption#availability)

Volume encryption is currently not available in all regions. Select another region if you want encrypted volumes.

## [Considerations](https://techdocs.akamai.com/cloud-computing/docs/volumes-disk-encryption#considerations)

- After a volume is created, its encryption setting cannot be changed. 
- Using Volume disk encryption with other encryption methods on the same data can reduce Input/Output Operations Per Second (IOPS) and is generally not supported. Using only one encryption method is recommended. 
- Encryption in general, increases CPU and can decrease realized throughput and volume IOPS. For performance-sensitive workloads, you can consider keeping volume disk encryption disabled.

## [How to check if a volume is encrypted](https://techdocs.akamai.com/cloud-computing/docs/volumes-disk-encryption#how-to-check-if-a-volume-is-encrypted)

Log into [Cloud Manager](https://cloud.linode.com/linodes) and click the **Volumes** link in the sidebar.

## [How to check if an attached volume is encrypted](https://techdocs.akamai.com/cloud-computing/docs/volumes-disk-encryption#how-to-check-if-an-attached-volume-is-encrypted)

1. Log into [Cloud Manager](http://cloud.linode.com), click **Linodes** in the left menu.
2. Click on a Linode from the list to view more details.
3. Navigate to and select the **Storage** tab.
