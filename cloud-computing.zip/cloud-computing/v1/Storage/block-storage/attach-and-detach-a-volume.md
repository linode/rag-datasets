# [Attach and detach a volume](https://techdocs.akamai.com/cloud-computing/docs/attach-and-detach-a-volume#attach-and-detach-a-volume)

Each volume can to be attached to a single Linode within the same data center, which enables that Linode to read and write data to that volume. Volumes can also be detached, and its data cannot be accessed until it is again attached to any Linode within the same data center.

# [Attach a volume](https://techdocs.akamai.com/cloud-computing/docs/attach-and-detach-a-volume#attach-a-volume)

Learn how to attach an existing Block Storage volume to a Linode using these steps:

1. Log in to [Cloud Manager](https://cloud.linode.com/linodes) and click on the **Volumes** link in the sidebar.

2. Locate the desired volume within the list, click the **more options ellipsis** dropdown menu, and select **Attach**.

3. Complete the **Attach Volume** form that appears.

   - **Linode:** Use the dropdown menu to select the Linode you'd like to use. The volume will be attached to this Linode.
   - **Config:** If the Linode has multiple Configuration Profiles, select which one the Block Storage volume should be assigned to. This field will not be displayed if the Linode has only a single profile.

   > > Note: 
   > 
   > The Linode must be located within the same data center as the Block Storage volume.

   > > Note: 
   > 
   > If your Linode was deployed before August 24th, 2021 and hasn't been rebooted since your data center was upgraded to NVMe Block Storage, you may need to reboot the Linode for it to properly work with a Block Storage volume.

4. Click the **Save** button to attach the volume.

5. To start using the volume on the Linode, additional internal configuration is required. This includes creating the file system (if the volume hasn't been used before), mounting the volume, and configuring your Linode to automatically mount the volume at boot. To learn more about these configuration steps, see [Configure and mount a volume](https://techdocs.akamai.com/cloud-computing/docs/configure-and-mount-a-volume).

   > > Error: 
   > 
   > Do not create a new file system if you wish to retain any existing data on the volume. Creating a new file system will overwrite any existing data and result in data loss.

# [Detach a volume](https://techdocs.akamai.com/cloud-computing/docs/attach-and-detach-a-volume#detach-a-volume)

Follow these steps to safely detach a Block Storage volume from a Linode. A volume should be detached before it is reattached to a different Linode.

1. Log in to [Cloud Manager](https://cloud.linode.com/linodes) and click on the **Linodes** link in the sidebar.

2. Select the Linode that the volume is currently attached to.

3. It's recommended to power off the Linode. To do this, click **Power Off** on the top right of the Linode details page.

4. If a volume is currently mounted, detaching it while the Linode is powered on could cause data loss or an unexpected reboot. You can unmount the volume for safe live-detaching by logging in to the Linode over [SSH or Lish](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-instance) and running the `umount` command, such as in the example below.

   ```
   umount /dev/disk/by-id/scsi-0Linode_Volume_example-volume-1
   ```

   Replace the device path with the one for your own volume (which can be viewed from the _Show Config_ link). To avoid additional issues with your Linode, remove the detached volume's line from your `/etc/fstab/` configuration.

   ```
   FILE_SYSTEM_PATH /mnt/example-volume-1 ext4 defaults 0 2
   ```

5. Navigate to the **Storage** tab.

6. Locate the volume you wish to detach within the _Volumes_ list, click the **more options ellipsis** dropdown menu, and select **Detach**.

7. A confirmation screen appears and explains that the volume will be detached from the Linode. Click **Detach** to confirm.

Detached volumes still exist on your account and, as such, you are still billed for the volume as normal. It can be viewed and deleted within the **Volumes** listing page in Cloud Manager. See [View, add, and delete volumes](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes).