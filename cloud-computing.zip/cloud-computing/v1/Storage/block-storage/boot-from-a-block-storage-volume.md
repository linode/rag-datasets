# [Boot from a Block Storage volume](https://techdocs.akamai.com/cloud-computing/docs/boot-from-a-block-storage-volume#boot-from-a-block-storage-volume)

The Block Storage service lets you attach additional storage volumes to your Linodes. In addition to storing files and media, you can also use a volume as a boot disk. This can provide a low-cost way to maintain an image that can be quickly attached to a Linode and booted up when needed.

This guide outlines the steps needed to boot your Linode from a Block Storage volume. These steps include creating a new volume, copying the primary disk to that new volume, and configuring the Linode to boot from that volume. The process may be reversed in order to restore the primary disk from the volume.

 > Warning: 
  If you hot-detach a Block Storage volume that is configured as your root device it will not crash. It will, however, become unresponsive and will no longer send any notifications or warnings on Akamai Cloud.

# [Create the volume](https://techdocs.akamai.com/cloud-computing/docs/boot-from-a-block-storage-volume#create-the-volume)

Create a Block Storage volume and attach it to the desired target Linode. Verify that the volume is the same size as (or larger than) the primary disk and is in the same data center as the Linode. Review the [View, create, and delete volumes](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes) for instructions on creating a new volume.

# [Copy the primary disk onto the volume](https://techdocs.akamai.com/cloud-computing/docs/boot-from-a-block-storage-volume#copy-the-primary-disk-onto-the-volume)

1. Boot the Linode into Rescue Mode and assign the volume to `/dev/sdc` (shown below). The primary disk should remain assigned to `/dev/sda`. If your device assignments are different, you may need to adjust the commands or steps in this guide accordingly. Review the [Rescue and rebuild guide](https://techdocs.akamai.com/cloud-computing/docs/rescue-and-rebuild#boot-into-rescue-mode) for more information on booting into Rescue Mode.

   

2. Connect to the Linode via [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

3. Run `fdisk -l` to confirm the Linode's primary disk and Block Storage volume are available as `dev/sda` and `dev/sdc`, respectively.

4. Run the following `pv` command to copy the contents of the primary disk to the Block Storage volume. Respectively, the options `-pte` output a progress meter, the elapsed time, and the estimated time remaining.

   ```
   pv -pte < /dev/sda > /dev/sdc
   ```

# [Set the Block Storage volume as the primary disk and reboot](https://techdocs.akamai.com/cloud-computing/docs/boot-from-a-block-storage-volume#set-the-block-storage-volume-as-the-primary-disk-and-reboot)

1. Power off the Linode.

2. Edit the Linode's **Configuration Profile**. Under the **Block Device Assignments** section, assign the `/dev/sda` device to your Block Storage volume (shown below). Confirm that the root device is set to `/dev/sda` (this is the default setting). If your volume was previously assigned to any other device, such as `/dev/sdc`, set the device to `None`. Save these changes. Review the [Manage configuration profiles on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance) guide for more information on editing configuration profiles.

   

3. Power on the Linode.

The Linode should boot normally from the Block Storage volume. Keep in mind that Block Storage may not be as fast as the Linode's local storage and, as such, performance may be different.