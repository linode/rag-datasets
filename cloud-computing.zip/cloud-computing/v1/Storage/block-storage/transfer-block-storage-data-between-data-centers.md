# [Transfer Block Storage data between data centers](https://techdocs.akamai.com/cloud-computing/docs/transfer-block-storage-data-between-data-centers#transfer-block-storage-data-between-data-centers)

Block Storage volumes cannot be directly migrated to a different data center. These steps will outline how to transfer a volume's data to a different data center via the [SCP](https://linode.com/docs/guides/download-files-from-a-compute-instance/#download-files-with-scp) tool.

 > Note:
 Consult our [Network Transfer Usage and Costs](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs) guide for information on charges related to outbound traffic when transferring data over the public internet.

1. [Attach and mount](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes) your existing volume to a Linode, if you have not already.

1. [Create, attach, and mount](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes) a volume to a Linode within the new data center you wish to use.

1. Log in to your new receiving Linode using [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

1.  [Use the Secure Copy Protocol (SCP)](https://linode.com/docs/guides/download-files-from-a-compute-instance/#download-files-with-scp) to download your volume's data to the receiving Linode.

        scp [source-user]@[source-ip]:[source-path] [destination-path]

    Replace the above values with your own. In the example below, the user is `root`, the IP of the original Linode is `192.0.2.1`, the path to the volume's data on the source machine is `/mnt/source-volume/`, and the path to the new volume on the new Linode in the other data center is `/mnt/destination-volume/`.

        scp root@192.0.2.1:/mnt/source-volume/ /mnt/destination-volume/

    > > Note:
    > You will need a volume or device that has enough storage capacity to receive the entirety of your source data.

1. Once the transfer is complete and you have confirmed the original data is now located on the new volume in your desired data center, the original volume can be deleted to avoid further charges for that volume.