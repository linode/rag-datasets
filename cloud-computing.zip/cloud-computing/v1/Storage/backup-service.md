# [Backups](https://techdocs.akamai.com/cloud-computing/docs/backup-service#backups)

Safeguard your data with the Backups service by enabling automatic backups of the disks on your Linodes. Up to four backups are stored as part of this service, including automated daily, weekly, and biweekly backups in addition to a manual backup snapshot. Each backup is a full file-based snapshot of your disks taken during your preferred scheduled time slot while the Linode is still running. This means that the Backups service is not disruptive and provides you with several complete recovery options.

# [Fully managed](https://techdocs.akamai.com/cloud-computing/docs/backup-service#fully-managed)

Backups is a managed service that automatically backs up your disks at regular intervals. Use full-system backups to guard against accidental deletions or misconfigurations.

# [Convenient & configurable](https://techdocs.akamai.com/cloud-computing/docs/backup-service#convenient-configurable)

Enable the Backups service with a single click. It activates instantly, and your first backups are automatically scheduled. There is no software to install or configure. You can choose when your backups are generated. Select a two-hour window that suits you.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/backup-service#availability)

Backups are available across [all core compute regions](https://www.linode.com/global-infrastructure/) , but are not available in distributed compute regions.

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/backup-service#plans-and-pricing)

The Backups service is available as a paid add-on for Linodes. Pricing starts at $2/month for a 1 GB Shared CPU Linode. Review the [Pricing page](https://www.linode.com/pricing/#row--storage) for additional rates based on other Linode plans.

On all plans, the Backups service can store up to four backups, three of which are automatically generated on the date and time range you specify:

- **Daily** _(Less than 24 hours old)_
- **Weekly** _(Less than 7 days old)_
- **Biweekly** _(Between 8 and 14 days old)_
- **Manual Snapshot** _(A user-initiated snapshot that stays the same until another snapshot is initiated)_

The Backups service does not keep automated backups older than 14 days, though there are no restrictions on the age of a manual snapshot.

# [Additional technical specifications](https://techdocs.akamai.com/cloud-computing/docs/backup-service#additional-technical-specifications)

- Compatible with all Linodes, provided their disks contain unencrypted ext3 or ext4 file systems
- File-based backup solution, meaning it operates at the file level and not the block level
- Backups are stored on separate dedicated hardware within the same data center
- Can be managed through [Cloud Manager](https://cloud.linode.com/), the [Linode CLI](https://www.linode.com/products/cli/), or programmatically through the [Linode API](https://www.linode.com/products/linode-api/)

# [Part of a multi-tiered backup strategy](https://techdocs.akamai.com/cloud-computing/docs/backup-service#part-of-a-multi-tiered-backup-strategy)

The Backups service is one part of a well rounded backup strategy. On-site backups provide a quick and convenient recovery option. While the backups are stored on different hardware, that hardware is located within the same data center as the Linode. It's also recommended to regularly backup your data off-site, such as on a local machine or using a third-party cloud-based service.

# [Limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/backup-service#limits-and-considerations)

- Disks are backed up, but not Linode-specific settings such as those stored within Configuration Profiles.

- Disks must be unencrypted and able to be mounted. The Backups service is not compatible with full disk encryption or changes that prevent us from mounting the disk as a file system, such as creating partitions. This is because our service operates at the file level, not at the block level. Also, the disk must be formatted and an EXT3 or EXT4 file system should be assigned to it.

- All disks will be restored as an ext4 file system and their UUIDs will be different than the original disks.

- A large number of files will prolong the backup process and may cause failures. Because the Backups Service is file-based, the number of files stored on disk impacts both the time it takes for backups and restores to complete, and your ability to successfully take and restore backups. Customers who need to permanently store a large number of files may want to archive bundles of smaller files into a single file, or consider other backup services.

  > > Note: 
  > 
  > The percentage of customers who may run into this limitation is low. If you are not sure if this limitation applies to you, please [contact Support](https://techdocs.akamai.com/cloud-computing/docs/help-and-support#contact-customer-support).

- Files that have been modified but have the same size and modify time are not be considered "changed" during a subsequent backup. ACLs and extended attributes are _not_ tracked.

- The Backups service uses a snapshot of your disks to take consistent backups while your Linode is running. This method is very reliable, but can fail to properly back up the data files for database services like MySQL. If the snapshot occurs during a transaction, the database's files may be backed up in an unclean state. We recommend scheduling routine dumps of your database to a file on the filesystem. The resulting file is then included in the daily backup, allowing you to restore the contents of the database if you need to restore from a backup.

- Volumes attached to a Linode are not backed up as part of the Backups service.

- If you delete a Linode, its backups are deleted as well.

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/backup-service#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of services on Akamai Cloud.

  - [List backups](https://techdocs.akamai.com/linode-api/reference/get-backups)

  - [Create snapshot](https://techdocs.akamai.com/linode-api/reference/post-snapshot)

  - [Cancel backups](https://techdocs.akamai.com/linode-api/reference/post-cancel-backups)

  - [Enable backups](https://techdocs.akamai.com/linode-api/reference/post-enable-backups)

  - [View backup](https://techdocs.akamai.com/linode-api/reference/get-backup)

  - [Restore backup](https://techdocs.akamai.com/linode-api/reference/post-restore-backup)
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line.