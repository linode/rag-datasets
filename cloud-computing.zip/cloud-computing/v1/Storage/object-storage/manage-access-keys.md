# [Manage access keys](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys#manage-access-keys)

To start integrating Object Storage with your own applications, you need to create an _access key_. The access key provides access to buckets (and objects stored within those buckets). You can create many access keys, allowing you to create a unique one for each application or user. When an application or user no longer requires access, you can revoke that access key without affecting any other application.

When an access key is generated, a corresponding _secret key_ is also created. This secret key is used in tandem with the access key to authenticate connections. The secret key should not be shared.

# [View access keys](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys#view-access-keys)

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Select the **Object Storage** link in the sidebar and navigate to the **Access Keys** tab.

This page displays a list of all the access keys added to your Object Storage account. It also shows the Amazon S3 endpoint hostname. The Amazon S3 endpoint hostname is different for each region and is displayed when the you create an access key. 

From here, you can create a new access key. You can also click the ellipsis to:

- Edit the access key labels and the regions list.
- View the permissions.
- Revoke access (which deletes the access key).

# [Create an access key](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys#create-an-access-key)

To use Object Storage with any compatible client or command-line tool, you'll need to generate an Access Key. This can be done directly in Cloud Manager.

1. Navigate to the **Access Keys** page in Cloud Manager (see [View access keys](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys#view-access-keys)).

2. Click the **Create Access Key** button, which displays the **Create Access Key** panel.

3. Enter a label for the access key. This label is how you reference the access key in Cloud Manager and any Amazon S3-compatible client.

4. Select at least one Region. You can select multiple regions for your access key.

5. Toggle the **Limited Access** switch if you wish to only provide access to certain buckets. This lets you limit the permissions for the new access key on a per-bucket level. See [Access key permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys#permissions) for more details.

   

6. Click the **Create Access Key** button to create the access key. A dialog box appears that displays the new access key and its secret key. While the access key is always visible within Cloud Manager, its corresponding secrete key is only visible once and cannot be retrieved again after this window is closed. Store this secret key somewhere secure, such as a password manager.

   

You now have the credentials needed to connect to Object Storage.

# [Revoke access key](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys#revoke-access-key)

Revoking an access key removes it from your account and no longer provides access to applications that may have used it. You may wish to do this when decommissioning an application, ending a project with a third party developer, or any other situation where an access key is no longer needed.

1. Navigate to the **Access Keys** page in Cloud Manager (see [View access keys](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys#view-access-keys)).

2. Locate the access key you wish to remove and select **Revoke** from the ellipsis button.

   

3. A confirmation dialog appears. Click the **Revoke** button to immediately revoke the access key.

# [Permissions](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys#permissions)

By default, an Access Key is unrestricted and has full access to all Buckets on an account. When creating an Access Key, you can enable **Limited Access** and set more granular permissions for each Bucket. These permissions include **None**, **Read**, and **Read/Write**:

 > Note: 
  Regardless of permissions, all access keys can create new buckets and list all buckets. However, after creating a bucket, depending on what you select here, a limited access key may not be able to access those buckets, add items, remove items, and other actions.

- **None**: Restricts all access to the specified Bucket. This Access Key will still be able to view the Bucket in the list of all Buckets, but will otherwise be unable to access any objects stored within it.

- **Read** (`read_only`): Access keys with **Read** permissions are able to list and retrieve most information about the specified Bucket and objects stored in that Bucket. Technically, **read** permissions provide access to the following Amazon S3 actions (which are used by all Amazon S3-compatible clients and tools):

  > _GetBucketAcl, GetBucketCORS, GetBucketLocation, GetBucketLogging, GetBucketNotification, GetBucketPolicy, GetBucketTagging, GetBucketVersioning, GetBucketWebsite, GetLifecycleConfiguration, GetObjectAcl, GetObject, GetObjectTorrent, GetReplicationConfiguration, GetObjectVersionAcl, GetObjectVersion, GetObjectVersionTorrent, ListBucketMultipartUploads, ListBucket, ListBucketVersions, ListMultipartUploadParts_

- **Read/Write** (`read_write`): Access keys with **Read/Write** permissions can list, retrieve, add, delete, and modify most information and objects stored within the specified Bucket. Technically, **read/write** permissions provide access to all of the same Amazon S3 actions as **read** permissions, as well as the following:

  > _AbortMultipartUpload, DeleteBucketWebsite, DeleteObject, DeleteObjectVersion, DeleteReplicationConfiguration, PutBucketCORS, PutBucketLogging, PutBucketNotification, PutBucketTagging, PutBucketVersioning, PutBucketWebsite, PutLifecycleConfiguration, PutObject, PutObjectAcl, PutObjectVersionAcl, PutReplicationConfiguration, RestoreObject_

A full list of Amazon S3 actions is available on [Amazon's S3 API Reference](https://docs.aws.amazon.com/AmazonS3/latest/API/API_Operations_Amazon_Simple_Storage_Service.html) documentation.