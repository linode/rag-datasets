# [Product support and limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#product-support-and-limits)

# [Supported endpoint types by region](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#supported-endpoint-types-by-region)

Review the table below to see which regions support each of the available [endpoint types](https://techdocs.akamai.com/cloud-computing/docs/object-storage#endpoint-types).

 > Tip: 
  Some regions support more than one endpoint. You should select the highest standard endpoint available when creating a new bucket.  **E3** endpoints offer the highest performance and capacity, followed by **E2**, then **E1**. 
  Legacy **E0** endpoints include the four original Object Storage regions in Atlanta, Frankfurt, Newark, and Singapore. These endpoints have lower limits than all other endpoint types. There are no plans to increase limits for **E0** endpoints.

| Location | Country | Region | S3 hostname | E0 | E1 | E2 | E3 |
|---|---|---|---|---|---|---|---|
| North America |  |  |  |  |  |  |  |
| Atlanta, GA | United States | us-southeast | us-southeast-1.linodeobjects.com | ✓ |  |  |  |
| Chicago, IL | United States | us-ord | us-ord-1.linodeobjects.com |  | ✓ |  |  |
| Chicago, IL | United States | us-ord | us-ord-10.linodeobjects.com |  |  |  | LA\* |
| Los Angeles, CA | United States | us-lax | us-lax-1.linodeobjects.com |  | ✓ |  |  |
| Los Angeles, CA | United States | us-lax | us-lax-4.linodeobjects.com |  |  |  | LA\* |
| Miami, FL | United States | us-mia | us-mia-1.linodeobjects.com |  | ✓ |  |  |
| Newark, NJ | United States | us-east | us-east-1.linodeobjects.com | ✓ |  |  |  |
| Seattle, WA | United States | us-sea | us-sea-1.linodeobjects.com or |  | ✓ |  |  |
| Seattle, WA | United States | us-sea | us-sea-9.linodeobjects.com |  |  |  | LA\* |
| Washington, DC | United States | us-iad | us-iad-1.linodeobjects.com, us-iad-10.linodeobjects.com |  | ✓ |  |  |
| Asia |  |  |  |  |  |  |  |
| Jakarta | Indonesia | id-cgk | id-cgk-1.linodeobjects.com |  | ✓ |  |  |
| Chennai | India | in-maa | in-maa-1.linodeobjects.com |  | ✓ |  |  |
| Mumbai 2 | India | in-bom-2 | in-bom-1.linodeobjects.com |  |  |  | LA\* |
| Osaka | Japan | jp-osa | jp-osa-1.linodeobjects.com |  | ✓ |  |  |
| Tokyo 3 | Japan | jp-tyo-3 | jp-tyo-1.linodeobjects.com |  |  | ✓ |  |
| Singapore | Singapore | ap-south | ap-south-1.linodeobjects.com | ✓ |  |  |  |
| Singapore 2 | Singapore | sg-sin-2 | sg-sin-1.linodeobjects.com |  |  |  | ✓ |
| Europe |  |  |  |  |  |  |  |
| Frankfurt | Germany | eu-central | eu-central-1.linodeobjects.com | ✓ |  |  |  |
| Frankfurt 2 | Germany | de-fra-2 | de-fra-1.linodeobjects.com |  |  |  | LA\* |
| Madrid | Spain | es-mad | es-mad-1.linodeobjects.com |  | ✓ |  |  |
| Paris | France | fr-par | fr-par-1.linodeobjects.com |  | ✓ |  |  |
| London 2 | Great Britain | gb-lon | gb-lon-1.linodeobjects.com |  |  |  | ✓ |
| Milan | Italy | it-mil | it-mil-1.linodeobjects.com |  | ✓ |  |  |
| Amsterdam | Netherlands | nl-ams | nl-ams-1.linodeobjects.com |  | ✓ |  |  |
| Stockholm | Sweden | se-sto | se-sto-1.linodeobjects.com |  | ✓ |  |  |
| Oceania |  |  |  |  |  |  |  |
| Melbourne | Australia | au-mel | au-mel-1.linodeobjects.com |  |  | ✓ |  |
| South America |  |  |  |  |  |  |  |
| São Paulo | Brazil | br-gru | br-gru-1.linodeobjects.com |  | ✓ |  |  |

\*This endpoint is in Limited Availability status, if you would like to request access please open a support ticket.

## [Supported features by endpoint type](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#supported-features-by-endpoint-type)

Feature support is consistent across endpoints, with the exception of the following three items.

|                                                                                                                                           | E0 (Legacy) | E1  | E2 | E3 |
| :---------------------------------------------------------------------------------------------------------------------------------------- | :---------- | :-- | :- | :- |
| [Object level Access Control Lists](https://techdocs.akamai.com/cloud-computing/docs/define-access-and-permissions-using-acls-access-control-lists#object-level-acls-in-cloud-manager) | Yes         | Yes | No | No |
| [Custom domain support](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate)                                                         | Yes         | Yes | No | No |
| [In product static website support](https://www.linode.com/docs/guides/host-static-site-object-storage/) \*                               | Yes         | Yes | No | No |

\*For static website support you should use the CDN vs. supporting out of Object Storage directly.

# [Product limits and quotas](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#product-limits-and-quotas)

## [Object Storage limits by endpoint type](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#object-storage-limits-by-endpoint-type)

| Limit                                                                | E0 (Legacy)             | E1                      | E2                      | E3         |
| :------------------------------------------------------------------- | :---------------------- | :---------------------- | :---------------------- | :--------- |
| Performance limits                                                   |                         |                         |                         |            |
| Default number of Requests Per Second (RPS), per bucket              | 750                     | 750                     | 2,000                   | 2,000      |
| Maximum number of Requests Per Second (RPS), per bucket              | 750                     | \<=2,000                | \<=5,000                | 20,000     |
| Maximum Lifecycle Policy Deletes Per Second, per bucket (see Note 1) | 75                      | 75                      | 100                     | 300        |
| Quotas                                                               |                         |                         |                         |            |
| Default capacity per account, per endpoint                           | 5 TB                    | 100 TB                  | 100 TB                  | 500 TB     |
| Default number of objects per account, per endpoint                  | 50 M                    | 100 M                   | 100 M                   | 500 M      |
| Maximum number of buckets per account, per endpoint                  | 1,000                   | 1,000                   | 1,000                   | 1,000      |
| Connection limits                                                    |                         |                         |                         |            |
| Connections per bucket                                               | \<per bucket rate limit | \<per bucket rate limit | \<per bucket rate limit | 2,000      |
| Connections per account, per endpoint                                | 750                     | 750                     | 2,000                   | 2,000      |
| Bucket Limits                                                        |                         |                         |                         |            |
| Maximum capacity per bucket                                          | 1 TB                    | 1 PB                    | 1 PB                    | 5 PB       |
| Maximum number of objects per bucket                                 | 50 million              | 1 billion               | 1 billion               | 10 billion |
| Access keys                                                          |                         |                         |                         |            |
| Maximum number of buckets per limited access key                     | 25                      | 25                      | 25                      | 25         |
| Maximum number of access keys per account                            | 100                     | 100                     | 100                     | 100        |

Note 1: [Lifecycle Policy deletes](https://techdocs.akamai.com/cloud-computing/docs/lifecycle-policies) execute over a 24 hour period.  The Lifecycle delete rate per second, per bucket, is the maximum rate that can be expected over a 24 hour period.

## [Multi-part upload limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#multi-part-upload-limits)

The maximum size of a single upload is _5 GB_. You can use multi-part uploads to upload an object that exceeds this limit. Both [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage) and [Cyberduck](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage) will do this for you automatically as part of the upload process.

|                                                                                  |                                                                                           |
| :------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------- |
| Maximum Object Size                                                              | 5 TiB                                                                                     |
| Maximum number of parts per upload                                               | 10,000                                                                                    |
| Part numbers                                                                     | 1 to 10,000 (inclusive)                                                                   |
| Part size                                                                        | 5 MiB to 5 GiB. There is no minimum size limit on the last part of your multipart upload. |
| Maximum number of parts returned for a list parts request                        | 1000                                                                                      |
| Maximum number of multipart uploads returned in a list multipart uploads request | 1000                                                                                      |

## [Quotas](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#quotas)

A quota is a default value for your account. You can submit a request to support to increase your quotas. [Product limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits) cannot be increased.

You can view your current quotas and usage in [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/quotas), the [CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli), and the [API](https://techdocs.akamai.com/linode-api/reference/get-object-storage-quotas).

# [Per bucket rate limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#per-bucket-rate-limits)

Bucket rate limits specify the maximum Requests Per Second (RPS) for an endpoint. The rate limits for E0 and E1 endpoints are calculated differently than the E2 and E3 endpoints. 

- For E0 and E1 endpoints all operations count towards one rate limit for the bucket. 
- For E2 and E3 endpoints there are separate rate limits for each operation.

[block:html]
{
  "html": "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n Operation\n\n|  E0/E1 Default Rate Limits\n\n|  E2/E3 Default Rate Limits\n\n|  E2 Maximum Rate Limits\n\n|  E3 Maximum Rate Limits\n\n  
 ---|---|---|---|---  
 \n\n\n\n\n\n\n\n**GET, HEAD operations for object** \n\n| 750 RPS  
\n   
\n This limit is a maximum rate for all operations combined, per bucket. In addition, there is a maximum of 100 RPS for all delete operations as a subset of the total rate limit for the bucket.\n\n| 2,000 RPS\n\n| 5,000 RPS\n\n| 20,000 RPS\n\n  
 \n\n\n\n  
 \n\n\n\n  
 \n\n\n\n**PUT operations for objects including mult-part uploads** \n\n| 500 RPS \n\n| 1,000 RPS \n\n| 2,000 RPS \n\n  
 \n\n\n\n**LIST operations for objects** \n\n| 100 RPS\n\n| 200 RPS\n\n| 400 RPS\n\n  
 \n\n\n\n\n\n**DELETE** \n\n| 200 RPS\n\n| 200 RPS\n\n| 400 RPS\n\n  
 \n\n\n\n\n\n**All other operations including ACL and POLICY** \n\n| 400 RPS\n\n| 800 RPS\n\n| 1,000 RPS\n\n  
 \n\n\n\n\n\n
"
}
[/block]

\*Contact support for any per bucket rate limit increase requests.

## [Optimize to avoid rate limiting](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#optimize-to-avoid-rate-limiting)

The rate limit for the number of RPS applies to a bucket and is evaluated against each bucket once per second. If the duration of any request is greater than one second, any open requests will count against the rate limit in the next one second window.

For example, assume there are 750 requests for a single bucket with a duration of two seconds each. All of the requests that do not complete within the first second will count against the rate limit in the next second. With a rate limit of 750 RPS for the bucket, no additional requests can be processed within the two second window until the first 750 requests complete. Any requests that are rate limited will receive a 503 response.

To help avoid rate limiting you can structure your data across multiple buckets, each of which will have its own rate limit.

## [Rate limiting headers](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#rate-limiting-headers)

These headers apply directly to the [per bucket rate limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#per-bucket-rate-limits). The Object Storage **E2** and **E3** endpoints support the following rate limit headers as defined in the [IETF draft specification](https://datatracker.ietf.org/doc/html/draft-ietf-httpapi-ratelimit-headers).

`x-ratelimit-limit` - Indicates the number of requests allowed in the current time window.

`x-ratelimit-remaining` - Indicates the number of requests remaining in the current time window.

`x-ratelimit-reset` - Indicates the time, as a relative number of seconds, until the current time window resets.

### [Examples](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#examples)

- `x-ratelimit-limit: 2000, 2000;w=1`  
  This indicates a maximum of 2000 requests per second (RPS). The w=1 suggests a 1-second window.
- `x-ratelimit-remaining: 1926`  
  After making some requests within the current 1-second window, there are still 1926 requests left before hitting the limit.
- `x-ratelimit-reset: 1`  
  The current rate limit window will reset in 1 second. After this second passes, the counter will return to the full capacity (2000 requests).