# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/object-storage-pricing#pricing)

There are three components to Object Storage pricing:

- Content stored
- Network transfer
- Request pricing

## [Content stored](https://techdocs.akamai.com/cloud-computing/docs/object-storage-pricing#content-stored)

Object Storage costs a flat rate of $5 a month, and includes 250 gigabytes of storage. This flat rate is prorated, so if you use Object Storage for a fraction of the month you are charged a fraction of the cost. For example, if you have Object Storage enabled for half of the month and use up to 250 gigabytes of storage you are billed $2.50 at the end of the month. The default cost of storage per gigabyte over the first 250 gigabytes is $0.02, and this usage is also prorated based on usage time.

Storage overages for Object Storage vary by data center due to regional infrastructure costs. The below table includes overage costs for different data centers where Object Storage is available:

| Data Center                                  | Storage overage per GB above 250 GB |
| :------------------------------------------- | :---------------------------------- |
| All data centers (except those listed below) | $0.02/GB                            |
| Jakarta, Indonesia                           | $0.024/GB                           |
| São Paulo, Brazil                            | $0.028/GB                           |

Once you enable Object Storage you will be billed at the flat rate regardless of whether or not there are active buckets on your account. You must [Cancel Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cancel-object-storage) to stop billing for this service.

Object Storage does not have a minimum billable object size. All objects that are stored in Object Storage, regardless of size, are billable.

## [Network transfer](https://techdocs.akamai.com/cloud-computing/docs/object-storage-pricing#network-transfer)

You can find details on network transfer pricing in the [Network transfer usage and costs](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs) guide.  
Network transfer overages for Object Storage vary by data center due to regional infrastructure costs. The below table includes overage costs for different data centers where Object Storage is available:

| Data Center                                  | Network Transfer overage cost |
| :------------------------------------------- | :---------------------------- |
| All data centers (except those listed below) | $0.005/GB                     |
| Jakarta, Indonesia                           | $0.015/GB                     |
| São Paulo, Brazil                            | $0.007/GB                     |

 > Note: 
  If creating a bucket in our Jakarta or São Paulo data centers, note that no additional transfer is added to their region-specific transfer pools

## [Request pricing](https://techdocs.akamai.com/cloud-computing/docs/object-storage-pricing#request-pricing)

With the introduction of the high-performance E2 and E3 endpoints, we will be introducing charges for requests to the Object Storage service.  To allow our customers time to optimize usage of object storage prior to the introduction of this new pricing, charges will appear on Object Storage bills no earlier than October 1, 2026.

Requests charges are organized by Class A and Class B requests. Class A operations include requests to write content (PUT) and high overhead operations such as LIST.  Class B operations include read requests (GET) and operations with lower overhead.  

Both Class A and Class B include a base quota of free operations per month.

| Operations | Price | Free Requests/ Month |
|---|---|---|
| Class A - write and list request (PUT\*, COPY\*, POST\*, LIST\*) | $0.00500 / 1000 requests | 1,000,000 |
| Class B - read requests (GET\*) | $0.00040 / 1000 requests | 12,500,000 |

### [Free Operations](https://techdocs.akamai.com/cloud-computing/docs/object-storage-pricing#free-operations)

Delete operations are always free.
