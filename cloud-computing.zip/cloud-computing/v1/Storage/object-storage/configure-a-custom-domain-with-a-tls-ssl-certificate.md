# [Configure a custom domain with a TLS/SSL certificate](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate#configure-a-custom-domain-with-a-tlsssl-certificate)

Akamai's Object Storage service supports both shared and custom domain names. By default, files can be accessed through secured (HTTPS) URLs within the shared domain _\*.linodeobjects.com_. If you prefer, you can use a custom domain, such as a subdomain of _\*.example.com_. This guide walks you through the configuration of a custom domain and adding a TLS certificate to secure that custom domain. When configuring Akamai Cloud services, this guide uses Cloud Manager, though the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli) and the [Linode API](https://techdocs.akamai.com/linode-api/reference/api-summary) can be used instead.

 > Note: Support for E0 and E1
  This configuration is only available for buckets created using an E0 or E1 endpoint type. If your bucket was created using an E2 or E3 endpoint type you can't configure it as a custom domain with a TLS/SSL certificate.

# [Before you begin](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate#before-you-begin)

**Obtain a domain name:** Before starting this guide, consider what domain name you'd like to use with your Object Storage bucket. If you do not already own the domain, purchase it from a trusted registrar.

 > Note: 
  When configuring Object Storage with a custom domain, you must use a fully qualified domain name (FQDN), such as _assets.example.com_ or any subdomain of _\*.your-domain.tld_. Apex (root) domains, such as _example.tld_, are not supported at this time.

# [Create a bucket](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate#create-a-bucket)

If you have not already done so, [create an E0 or E1 bucket](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-buckets). This configuration is not supported for E2 and E3 endpoint types.
 Since the intention is to use this bucket with a custom domain, the bucket must be labeled as your fully qualified domain name, such as `assets.example.com`. If your files already exist in a bucket that doesn't have this label, create a new bucket with this label and copy or move your files into it. For more information, see [Moving objects between buckets in Akamai's Object Storage](https://linode.com/docs/guides/how-to-move-objects-between-buckets/).

# [Configure DNS](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate#configure-dns)

To connect your custom domain, you must create a CNAME DNS record within the name server for the domain you intend to use. This can be done through your DNS provider, such as one operated by your domain registrar or a service like Akamai's DNS Manager. The CNAME record should be created using the following values:

- **Hostname/Name:** This is the custom domain you wish to use. Each DNS provider may require slightly different formatting. In many cases, enter just the _subdomain_ value. For example, if you plan to use _assets.example.com_, enter `assets`.

- **Alias To/Target:** This is the full URL on the shared domain (excluding the `https://` part of the URL) for your Object Storage bucket. See [Access Buckets and Files through URLs](https://techdocs.akamai.com/cloud-computing/docs/access-buckets-and-files-through-urls#bucket-url) for details on obtaining the bucket's URL. The URL can either be for the default file host functionality of Object Storage or the URL used to host a static website.

  - File URL: `[bucket-label].[cluster-id].linodeobjects.com`
  - Website URL: `[bucket-label].website-[cluster-id].linodeobjects.com`

For more information on DNS records and CNAME records, see our [Introduction to DNS Records](https://linode.com/docs/guides/dns-overview/#cname) guide.

# [Obtain a TLS/SSL certificate](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate#obtain-a-tlsssl-certificate)

Once your DNS has been configured, create (or purchase) a TLS/SSL certificate through a trusted certificate authority. For this guide, the free [certbot](https://certbot.eff.org/) tool will be used, which creates free certificates through the Let's Encrypt CA. You can skip this section if you have already obtained a certificate.

1. Install certbot on whichever system you wish to use to obtain the certificate. You can use your local machine, a Linode on Akamai Cloud, or any other compatible virtual machine. Here are links to the instructions on certbot's website:

   - [macOS](https://certbot.eff.org/instructions?ws=other&os=osx)
   - [Windows](https://certbot.eff.org/instructions?ws=other&os=windows)
   - Any compatible Linux system listed on the [certbot instructions](https://certbot.eff.org/instructions) page within the **System** dropdown.

2. Run the following certbot command to generate a certificate manually:

   ```
   sudo certbot certonly --manual
   ```

3. When prompted, enter the custom domain that you intend to use and have already configured (such as `assets.example.com`)

4. You are then requested to create a specific file with specific contents and make it accessible on your custom domain within a certain directory. If you've followed the previous steps in this guide, your custom domain now points to your bucket. This means you can create this file directly within your Object Storage account. To do this, you can use [Cyberduck](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage), the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/using-the-linode-cli-with-object-storage), [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage), [s4cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage), or any other tool or application that integrates with Object Storage and as the ability to create folders and files.

5. Once the file has been created and is accessible, press enter within the certbot command line to continue. If certbot is able to successfully access that file, it generates the certificate along with its private key and saves them to your system:

   ```
   {{
}}
   ```

   Successfully received certificate.  
   Certificate is saved at: /etc/letsencrypt/live/assets.example.com/fullchain.pem  
   Key is saved at:         /etc/letsencrypt/live/assets.example.com/privkey.pem  
   This certificate expires on 2022-05-11.  
   These files will be updated when the certificate renews.  
   {{
}}

You can view the saved certificate using whichever plaintext file viewer or editor you have on your system. For instance, on a Linux system you can use `sudo cat [file-location]` to output the file or `sudo nano [file-location]` to open the file.

# [Upload your SSL certificate](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate#upload-your-ssl-certificate)

To upload your new SSL certificate to an Object Storage Bucket:

1. Log in to [Cloud Manager](https://cloud.linode.com/) and select **Object Storage** from the left menu.

2. Open the bucket you wish to use and navigate to the **SSL/TLS** tab. This opens the _SSL/TLS Certificate_ page.

   

3. In the **Certificate** field, enter the contents of the certificate file you just created or obtained.

4. In the **Private Key** field, enter the contents of the corresponding private key file.

5. Click the **Upload Certificate** button to submit the certificate and attach it to your bucket.

# [Upload your files or static website](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate#upload-your-files-or-static-website)

Before you can test your custom domain, you need to have files hosted on your Object Storage bucket. Upload your files or your static website. After they are uploaded, set the permissions so the files can be read by the public. If the permissions are not set, you will not be able to view the files through any URL (either shared or custom).

If you currently don't have any files, you can create a test file called `index.html`, edit it to include the following text, upload it to your bucket's main directory, and make sure the permissions are set so it can be read by the public.

```

    

        # 
Hello world...

    

```

# [Access your secured custom domain](https://techdocs.akamai.com/cloud-computing/docs/configure-a-custom-domain-with-a-tls-ssl-certificate#access-your-secured-custom-domain)

You can now access your files or static website using your secured custom domain. Open a web browser and enter your custom domain. If you are using Object Storage just to store and access files, include the file path of the file you wish to access. If you are using Object Storage to host a website, you do not need to enter any additional file path assuming you have uploaded an `index.html` file (or have set a different file as the default).