# [Clients and tooling](https://techdocs.akamai.com/cloud-computing/docs/clients-and-tooling#clients-and-tooling)

# [Clients and tools](https://techdocs.akamai.com/cloud-computing/docs/clients-and-tooling#clients-and-tools)

Guides for using Object Storage with various clients and command-line tools:

- [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/using-the-linode-cli-with-object-storage): An easy to use command-line tool for use with Akamai Cloud's own services.
- [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage): One of the most common command-line tools for interacting with Amazon S3-compatible object storage solutions, including Object Storage.
- [s4cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage): A faster alternative to the s3cmd command-line tool.
- [Cyberduck](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage): A cross-platform graphical interface for interacting with various cloud storage services.

# [AWS tooling](https://techdocs.akamai.com/cloud-computing/docs/clients-and-tooling#aws-tooling)

Guides for using Object Storage with various AWS SDKs:

- [AWS CLI](https://techdocs.akamai.com/cloud-computing/docs/using-the-aws-cli-with-object-storage)
- [AWS SDK for Python (boto3)](https://techdocs.akamai.com/cloud-computing/docs/using-the-aws-sdk-for-python-boto3-with-object-storage)
- [AWS SDK for PHP](https://techdocs.akamai.com/cloud-computing/docs/using-the-aws-sdk-for-php-with-object-storage)

 > Note: 
  We currently recommend that you use versions of the AWS CLI or SDK released prior to January 15, 2025. For example:
  - AWS CLI v2.22.35
 - AWS SDK for Python (boto3) v1.35.99
  For more information, go to the [Supported versions](https://techdocs.akamai.com/cloud-computing/docs/aws-cli-sdks-support-details#supported-versions) section on the AWS CLI and SDKs support details page.