# [Get started with Object Storage](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-object-storage#get-started-with-object-storage)

# [Enable Object Storage](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-object-storage#enable-object-storage)

Object Storage is not enabled for a Akamai Cloud account by default. All that is required to enable Object Storage is to create a bucket or an Object Storage access key. To cancel Object Storage, see the [Cancel Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cancel-object-storage) guide.

 > Note: 
  Billing for Object Storage starts when it is enabled on your account, **regardless of how it is enabled**. For example, if you enable the service by creating an access key, but you have not yet created a bucket, the $5 monthly flat rate (prorated) for Object Storage is charged for your account. [Cancel Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cancel-object-storage) to stop further billing.

# [Generate an access key](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-object-storage#generate-an-access-key)

1. Log into the [Cloud Manager](https://cloud.linode.com).

   > > Note: 
   > 
   > Object Storage is not available in the Linode Classic Manager.

2. Click on the **Object Storage** link in the sidebar, click the **Access Keys** tab, and then click the **Create an Access Key** link.

3. A prompt appears asking you to confirm that you'd like to enable Object Storage. Click **Enable Object Storage**.

4. The **Create an Access Key** menu appears.

5. Enter a label for the key pair. This label is how you reference your key pair in the Cloud Manager. Then, click **Submit**.

6. Select at least one region. You can select multiple regions for your access key.

7. A window appears that contains your access key and your secret key. Write these down somewhere secure. The access key is visible in the Cloud Manager, but **you are not able to retrieve your secret key again once you close the window.**

8. You now have the credentials needed to connect to Object Storage.

# [Create a bucket](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-object-storage#create-a-bucket)

Cloud Manager provides a web interface for creating buckets. To create a bucket:

1. If you have not already, log in to the [Cloud Manager](https://cloud.linode.com).

2. Click on the **Object Storage** link in the sidebar, and then click on **Create Bucket**.

   > > Note: 
   > 
   > If you have not created an access key or a bucket before, you are prompted to enable Object Storage.

3. The **Create a Bucket** menu appears.

4. Add a label for your bucket. See the [Bucket name](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-buckets#create-a-bucket) section for rules on naming your bucket.

5. Choose a cluster location for the bucket to reside in.

   > > Note: 
   > 
   > A _cluster_ is defined as all buckets hosted by a unique URL; for example: `us-east-1.linodeobjects.com`, `ap-south-1.linodeobjects.com`, or `eu-central-1.linodeobjects.com`.

6. Click **Submit**. You are now ready to upload objects to your bucket.

# [Upload an object to a bucket](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-object-storage#upload-an-object-to-a-bucket)

1. If you have not already, log in to the [Cloud Manager](https://cloud.linode.com).

2. Click on the **Object Storage** link in the sidebar. A list of all your buckets appears. Click on the bucket you'd like to begin uploading objects to.

3. Your bucket's **Objects Listing Page** appears. In the example, the _my-example-bucket_ does not yet contain any objects. You can use the **Upload Files Pane** to drag and drop a file from your computer to your Object Storage bucket.

   > > Note: 
   > 
   > You can drag and drop multiple files to the **Upload Files Pane** at one time.

   You can also click on the **Browse Files** button to bring up your computer's file browser and select a file to upload to your bucket.

4. When the upload has completed, your object is visible on the **Objects Listing Page**.

   > > Note: 
   > 
   > Individual object uploads are limited to a size of 5GB each, though larger object uploads can be facilitated with multipart uploads. [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage) and [Cyberduck](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage) do this for you automatically if a file exceeds this limit as part of the uploading process.

   > > Note: 
   > 
   > You can add an `_AbortIncompleteMultipartUpload_` lifecycle policy to the buckets to automatically abort unfinished multipart uploads after a certain amount of time. For more information about adding the `_AbortIncompleteMultipartUpload_` lifecycle policy, see [Additional Actions](https://techdocs.akamai.com/cloud-computing/docs/lifecycle-policies#additional-actions).

# [Control permissions with ACLs and bucket policies](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-object-storage#control-permissions-with-acls-and-bucket-policies)

Object Storage allows users to share access to objects and buckets with other Object Storage users. There are two mechanisms for setting up sharing: _Access Control Lists (ACLs)_, and _bucket policies_. These mechanisms perform similar functions: both can be used to restrict and grant access to Object Storage resources. ACLs can also restrict or grant access to _individual objects_, but they don't offer as many fine-grained access modes as bucket policies.

- [ACLs (Access Control Lists)](https://techdocs.akamai.com/cloud-computing/docs/define-access-and-permissions-using-acls-access-control-lists)

- [Bucket policies](https://techdocs.akamai.com/cloud-computing/docs/define-access-and-permissions-using-bucket-policies)

If you can organize objects with similar permission needs into their own buckets, then it's strongly suggested that you use bucket policies. However, if you cannot organize your objects in this fashion, ACLs are still a good option.

ACLs offer permissions with less fine-grained control than the permissions available through bucket policies. If you are looking for more granular permissions beyond read and write access, choose bucket policies over ACLs.

Additionally, bucket policies are created by applying a written bucket policy file to the bucket. This file cannot exceed 20KB in size. If you have a policy with a lengthy list of policy rules, you may want to look into ACLs instead.

 > Note: 
  ACLs and bucket policies can be used at the same time. When this happens, any rule that limits access to an Object Storage resource overrides a rule that grants access. For instance, if an ACL allows a user access to a bucket, but a bucket policy denies that user access, the user can not access that bucket.

# [Object Storage tools](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-object-storage#object-storage-tools)

There are a number of tools that are available to help manage Object Storage. This guide explains how to install and use the following options:

- [Cloud Manager](https://cloud.linode.com) can be used to create buckets, and upload and delete objects, as well as create access keys for use with the Amazon S3-compatible clients.

- The [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/using-the-linode-cli-with-object-storage) has an Object Storage plugin and can be used to create and remove buckets, add and remove objects, and convert a bucket into a static site from the command line.

- [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage) is a powerful command line utility that can be used with any Amazon S3-compatible object storage service, including Akamai Cloud's. s3cmd can be used to create and remove buckets, add and remove objects, convert a bucket into a static site from the command line, plus other functions like syncing entire directories up to a bucket.

- [Cyberduck](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage) is a graphical utility available for Windows and macOS and is a great option if you prefer a GUI tool.