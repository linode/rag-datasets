# [AWS CLI and SDKs support details](https://techdocs.akamai.com/cloud-computing/docs/aws-cli-sdks-support-details#aws-cli-and-sdks-support-details)

## [Supported versions](https://techdocs.akamai.com/cloud-computing/docs/aws-cli-sdks-support-details#supported-versions)

If you are using a version of the AWS CLI or SDKs released on or after January 15, 2025 you might experience issues uploading to Akamai Cloud Object Storage Amazon S3 endpoints. `PutObject` and `UploadPart` requests fail with `SignatureDoesNotMatch`, `MissingContentLength`, and `NotImplemented` error codes.

The affected CLI and SDKs now require [Data Integrity Protections for Amazon S3](https://docs.aws.amazon.com/sdkref/latest/guide/feature-dataintegrity.html), which is not supported with Object Storage. Affected versions may include:

- AWS CLI v2.23.0 and later
- AWS SDK for Python (boto3) v1.36.0 and later

Our current recommendation is to downgrade the CLI or SDK to the latest version released prior to January 15, 2025. For example:

- AWS CLI v2.22.35
- AWS SDK for Python (boto3) v1.35.99

An alternative workaround is to configure the `request_checksum_calculation` parameter to **WHEN_REQUIRED** using one of the methods described in the [Data Integrity Protections for Amazon S3](https://docs.aws.amazon.com/sdkref/latest/guide/feature-dataintegrity.html) document. This workaround may not work in all cases. For example, when using AWS CLI v2.23.5, this method works when uploading with `aws s3api put-object` but not with `aws s3 cp`, as described in [aws s3 cp does not honor request_checksum_calculation = WHEN_REQUIRED](https://github.com/boto/s3transfer/issues/327).

We are continuing to investigate this issue to better support the latest releases of the AWS SDKs.