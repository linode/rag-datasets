# [Use s4cmd with Object Storage](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#use-s4cmd-with-object-storage)

The [s4cmd](https://github.com/bloomreach/s4cmd) software is a command-line tool that can access Amazon S3-compatible storage services, such as Object Storage. It uses the [Amazon S3 client](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html) in Amazon's boto3 library. Compared to the popular s3cmd tool, s4cmd is typically much faster but it has less options and is less configurable. For many use cases, the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/using-the-linode-cli-with-object-storage) or [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage) is recommended.

# [Install s4cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#install-s4cmd)

To install S3cmd on both Mac and Linux systems, Python’s package manager [pip](https://linode.com/docs/guides/how-to-manage-packages-and-virtual-environments-on-linux/) can be used.

```
sudo pip install s4cmd
```

Some Linux distributions are also able to install s4cmd from their own package managers, but those versions may not be as up to date. See [Download S3cmd](https://s3tools.org/download) for more information.

Additional methods of installing s4cmd can be found within the s4cmd Readme file under [Installation and setup](https://github.com/bloomreach/s4cmd#installation-and-setup).

# [Configure credentials](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#configure-credentials)

To access Object Storage buckets and objects, s4cmd needs to know the Access Key and Secret Key to use. By default, s4cmd looks for these credentials in the `~/.s3cfg` file, which is the configuration file that s3cmd uses. If you do not have s3cmd installed and configured, create this file and add the following contents.

```text ~/.s3cfg
[default]
access_key = YOUR_ACCESS_KEY
secret_key = YOUR_SECRET_KEY
```

Replace `YOUR_ACCESS_KEY` and `YOUR_SECRET_KEY` with the access key and secret key created on your Akamai Cloud account. If you haven't yet created these credentials, follow the [Manage access keys](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys) guide.

Additional methods of configuring your credentials can be found on the s4cmd Readme file under [Installation and Setup](https://github.com/bloomreach/s4cmd#installation-and-setup).

# [Specify the endpoint url](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#specify-the-endpoint-url)

Originally, s4cmd was used for Amazon S3. To allow this tool to be used by other Amazon S3-compatible solutions, the `--endpoint-url` command option was added. When running any s4cmd command, you will need to specify the full endpoint url of the Object Storage Cluster that your bucket resides in. For a full list of Clusters and their associated Amazon S3 endpoints, see the [Access buckets and files through URLs](https://techdocs.akamai.com/cloud-computing/docs/access-buckets-and-files-through-urls) guide).

As an example, the following command will list all buckets in the Newark data center:

```
s4cmd ls --endpoint-url https://us-east-1.linodeobjects.com
```

# [Interact with buckets](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#interact-with-buckets)

## [List buckets](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#list-buckets)

**Command:** `s4cmd ls`

**Example**: List all buckets on the account within the Newark data center:

```
s4cmd ls --endpoint-url https://us-east-1.linodeobjects.com
```

## [Create a bucket](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#create-a-bucket)

**Command:** `s4cmd mb s3://[bucket-label]`, replacing _[bucket-label]_ with the label you'd like to use for the new bucket.

**Example:** Create a bucket with the label of "example-bucket" in the Newark data center:

```
s4cmd mb s3://example-bucket --endpoint-url https://us-east-1.linodeobjects.com
```

## [Delete a bucket](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#delete-a-bucket)

There is currently no defined command for deleting a bucket through s4cmd.

# [Interact with objects](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#interact-with-objects)

## [List objects](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#list-objects)

**Command:** `s4cmd ls [path]`, where _[path]_ is the path of the directory you'd like to view within a bucket.

**Example:** List all objects within the bucket called "example-bucket", located in the Newark data center:

```
s4cmd ls s3://example-bucket/ --endpoint-url https://us-east-1.linodeobjects.com
```

## [Upload an object](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#upload-an-object)

**Command:** `s4cmd put [file] s3://[bucket-label]/[path]`, replacing _[file]_ with the name and path of the file you wish to upload, _[bucket-label]_ with the label for your bucket and _[path]_ with the optional directory within the bucket.

**Example:** Upload the file "file.txt" to the bucket called "example-bucket", located in the Newark data center:

```
s4cmd put file.txt s3://example-bucket/ --endpoint-url https://us-east-1.linodeobjects.com
```

 > Note: 
  Uploading or renaming objects using non-standard special characters and unusual ASCII/Unicode characters may cause issues. This includes the characters: `: " ' < > & + =`.

## [Download an object or directory](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#download-an-object-or-directory)

**Command:** `s4cmd get s3://[bucket-label]/[path]`, replacing _[bucket-label]_ with the label for your bucket and _[path]_ with the full path and optional filename of the file or directory you wish to download.

**Example:** Download the file "file.txt" from the bucket called "example-bucket", located in the Newark data center:

```
s4cmd get s3://example-bucket/file.txt --endpoint-url https://us-east-1.linodeobjects.com
```

## [Delete an object or directory](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#delete-an-object-or-directory)

**Command:** `s4cmd del s3://[bucket-label]/[path]`, replacing _[bucket-label]_ with the label for your bucket and _[path]_ with the full path and optional filename of the file or directory you wish to delete.

**Example:** Delete all the files within the "files" directory on the bucket called "example-bucket", located in the Newark data center:

```
s4cmd del s3://example-bucket/files/ --endpoint-url https://us-east-1.linodeobjects.com
```

# [Additional commands](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#additional-commands)

Additional commands and options for s4cmd can be found on the [s4cmd Readme](https://github.com/bloomreach/s4cmd) page or by running `s4cmd --help`.