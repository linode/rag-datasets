# [Use Cyberduck with Object Storage](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#use-cyberduck-with-object-storage)

Cyberduck is a desktop application that facilitates file transfer over FTP, SFTP, and a number of other protocols, including Amazon S3.

# [Install and configure Cyberduck](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#install-and-configure-cyberduck)

1. Navigate to Cyberduck's [Download](https://cyberduck.io/download/) webpage and download the latest version of Cyberduck for your operating system. After downloading, run the file to install the application.

   > > Note: 
   > 
   > If you already have Cyberduck installed, be sure to update to version 8.2.1 or newer. Some of the steps within this guide do not work properly on earlier versions.

2. Open Cyberduck and then select _Cyberduck_ > _Preferences_ from the menu bar.

3. Navigate to the **Profiles** tab to open the _Connection Profiles_ page.

   

4. Search for "Linode" or scroll down to see the connection profiles designed for the Object Storage service.

   

5. Select the checkbox next to connection profile for each data center you wish to use with Object Storage.

6. Close the _Preferences_ window and restart Cyberduck to install the selected connection profiles.

# [Open a connection](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#open-a-connection)

1. Open Cyberduck and then select _File_ > _Open Connection..._ from the menu bar. This displays the connection dialog.

2. At the top of the Open Connection dialog, click the dropdown menu and select the **Linode Object Storage** profile that corresponds with the data center you wish to use.

3. Enter your access key in the **Access Key** field and your secret key in the **Secret Key** field. If you do not yet have an access key, create one now by following the instructions within the [Manage Access Keys](https://techdocs.akamai.com/cloud-computing/docs/manage-access-keys) guide. If you intend to create new buckets, the access key must not be limited. Otherwise, the access key must have permissions to read or read/write on the bucket you intend to use.

   

4. Click **Connect** to open the connection.

# [View your buckets and files](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#view-your-buckets-and-files)

Once the connection is successful, a list appears of all the buckets that your access key has permissions to view within the selected data center. You can view the files stored within the buckets by clicking the chevron icon to the left of the bucket label or double clicking the bucket to open it.

 > Note: 
  To create additional buckets, use Cloud Manager, Linode CLI, s3cmd, or s4cmd. Cyberduck is not able to create new buckets.

# [Upload and manage files](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#upload-and-manage-files)

To upload a file, drag it into the Cyberduck window at the location where you'd like the file to be stored. For instance, if you see multiple buckets or folders, drag the file to whichever one you wish. This process also works for multiple files and even entire directories. Alternatively, you can click the **Action** button and select **Upload** from the menu.

If you wish to perform an action on a particular file, right click that file to open up a context menu with additional options. These options include:

- [Info](https://docs.cyberduck.io/cyberduck/info/): Get additional details about the file, folder, or bucket, change permissions, view and update metadata, edit the domain, set versioning, and much more.
- [Download](https://docs.cyberduck.io/cyberduck/download/): Download a copy of the file.
- [Edit](https://docs.cyberduck.io/cyberduck/edit/): Useful for editing plaintext files.
- Rename, Duplicate, and much more.

 > Note: 
  Uploading or renaming objects using non-standard special characters and unusual ASCII/Unicode characters may cause issues. This includes the characters: `: " ' < > & + =`.

# [Obtain the URL of a file](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#obtain-the-url-of-a-file)

In most cases, URLs are used to share and display files. While you can always manually determine the URL (see [Access buckets and files through URLs](https://techdocs.akamai.com/cloud-computing/docs/access-buckets-and-files-through-urls#file-urls)), you can get this information quickly using Cyberduck.

1. Right click on the file, select **Info**, and navigate to the _General_ tab.

2. Locate the **Web URL** field. The URL for the file is displayed here.

   

3. Click on the URL to open it in a web browser or right click it and select **Copy Link** to copy the URL.

# [Make files public](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#make-files-public)

It's common to make a file, folder, or even an entire bucket publicly accessible so they can be accessed through the file's URL without any additional authentication needed. To do this through Cyberduck, update the permissions on the file using the instructions below.

1. Right click on the file, select **Info**, and navigate to the _Permissions_ tab.

2. Click the ellipsis icon at the bottom left of the window and select **Everyone**.

   

3. A new entry for _Everyone_ appears in the Access Control List. Next to _Everyone_, under the _Permissions_ column heading, select **READ** from the drop down menu.

   

The object is now accessible through the internet. See [Obtain the URL of a file](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#obtain-the-url-of-a-file) to get the URL.

# [Host a website](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#host-a-website)

Object Storage can be used to host static website files, such as html, css, and client-side javascript. Once you've uploaded your files to a particular bucket, follow the instructions below to enable your website.

1. Locate your bucket within Cyberduck

2. Highlight all of the website files within your bucket, right click on them, and select **Info**. Follow the instructions within [Make files public](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#make-files-public) so that your files can be accessed by everyone with the URL.

3. Right click the bucket itself, select **Info**, and navigate to the **Distribution (CDN)** tab.

4. Check the box that reads **Enable Website Configuration (HTTP) Distribution**.

   

5. Make sure the root of your bucket contains an "index.html" file. If not, you can select a different file to act as the index by modifying the **Index File** field within the same window as the previous step.

6. The static site is accessed from a different URL than can be found in the [Obtain the URL of a file](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#obtain-the-url-of-a-file) section. Review the [Access buckets and files through URLs](https://techdocs.akamai.com/cloud-computing/docs/access-buckets-and-files-through-urls#website-urls) guide for information on obtaining the website URL.

For more information on hosting a static website with Object Storage, read the [Host a Static Site using Linode Object Storage](https://linode.com/docs/guides/host-static-site-object-storage/) guide.