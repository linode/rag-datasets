# [Create and manage buckets](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-buckets#create-and-manage-buckets)

Buckets are the primary containers within Object Storage. Each bucket stores your files (objects) and lets you access or share those files.

For information about Object Storage product limits, including supported endpoint types by region and bucket rate limits go to the [Product limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits) page in this guide.

# [View buckets](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-buckets#view-buckets)

Log in to [Cloud Manager](https://cloud.linode.com/) and select **Object Storage** from the left menu. If you currently have buckets on your account, they are listed on this page, along with their URL, region, endpoint type, date created, size, and the number of objects (files) they contain.

You can also view your bucket through the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/using-the-linode-cli-with-object-storage), [Cyberduck](https://techdocs.akamai.com/cloud-computing/docs/using-cyberduck-with-object-storage#view-your-buckets-and-files), [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage#list-buckets), and [s4cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#list-buckets).

# [Create a bucket](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-buckets#create-a-bucket)

One of the first steps to using Object Storage is to create a bucket. Here's how to create a bucket using Cloud Manager, though you can also use the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/using-the-linode-cli-with-object-storage#create-a-bucket-with-the-cli), [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage#create-a-bucket), and [s4cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#create-a-bucket).

1. Navigate to the **Object Storage** page in Cloud Manager (see [View buckets](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-buckets#view-buckets)).

2. Click the **Create Bucket** button to open the _Create Bucket_ panel. If you have not created an access key or a bucket on this account, you are prompted to enable Object Storage.

   > > Note: 
   > 
   > Billing for Object Storage starts as soon as it is enabled on the account. See [Object Storage Pricing](https://techdocs.akamai.com/cloud-computing/docs/object-storage-pricing) for more detail on the minimum flat-rate and per GB charge. See [Cancel Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cancel-object-storage) for instructions on cancelling this service.

3. Within the _Create Bucket_ form, add a **Label** for the new bucket. This label must be unique and should not be used by any other bucket (from any customer) in the selected data center. Keep the following formatting requirements in mind:

   - Must be between 3 and 63 characters in length.
   - Can only contain lower-case characters, numbers, periods, and dashes.
   - Must start with a lowercase letter or number.
   - Cannot contain underscores (\_), end with a dash (-) or period (.), have consecutive periods (.), or use dashes (-) adjacent to periods (.).
   - Cannot be formatted as IP addresses.
   - You cannot upload files to Object Storage that contain the following characters, `" ' < > & + =` when using Cloud Manager or the Linode CLI.

   > > Note: 
   > 
   > If you intend to use this bucket with a custom domain, the bucket must be labeled as your fully qualified domain name, such as `assets.example.com` or any subdomain of `*.your-domain.tld`.

4. Choose a **Region** for the bucket to reside. See the Availability section on the [Object Storage Overview](https://techdocs.akamai.com/cloud-computing/docs/object-storage#availability) page for a list of available regions.

5. Review the **Endpoint Type** information. 

Most regions only support one endpoint type. For these regions the endpoint type information is read only. There are, however, a few regions that support more than one endpoint type. You should select the highest option available to take advantage of the greater performance and capacity limits. 

To learn more, go to the [Endpoint types](https://techdocs.akamai.com/cloud-computing/docs/get-started-with-object-storage-new-feature-early-access#endpoint-types) section in this guide. You can also review the [Product limits](https://techdocs.akamai.com/cloud-computing/docs/get-started-with-object-storage-new-feature-early-access#product-limits) topic to review the performance, capacity, and rate limits available for each endpoint type.

6. Click **Submit** to create the bucket.

You are now ready to [upload files to the bucket](https://techdocs.akamai.com/cloud-computing/docs/upload-and-manage-files-objects).

# [Delete a bucket](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-buckets#delete-a-bucket)

Follow these steps to delete an Object Storage bucket from Cloud Manager. You can also use the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/using-the-linode-cli-with-object-storage), [s3cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage#delete-a-bucket), and [s4cmd](https://techdocs.akamai.com/cloud-computing/docs/using-s4cmd-with-object-storage#delete-a-bucket).

 > Note: 
  Only empty buckets are able to be deleted through Cloud Manager. To delete objects, see [Delete a File/Object](https://techdocs.akamai.com/cloud-computing/docs/upload-and-manage-files-objects#delete-a-file). Alternatively, you can use the following s3cmd command, which deletes a non-empty bucket. See [s3cmd > Delete a Bucket](https://techdocs.akamai.com/cloud-computing/docs/using-s3cmd-with-object-storage#delete-a-bucket) for more details.
  ```
 s3cmd rb -r -f s3://example-bucket/
 ```

1. Navigate to the **Object Storage** page in Cloud Manager (see [View buckets](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-buckets#view-buckets)).

2. Locate the bucket you wish to delete and click the corresponding **Delete** button.

   

3. A dialog box appears that prompts you to enter the bucket's name as a way to confirm that you'd like to delete the bucket. Type the bucket's name into the text entry field and click **Delete**.
