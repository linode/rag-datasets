# [Use Object Lock to protect data](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#use-object-lock-to-protect-data)

Object Lock lets you store objects using a write once, read many (WORM) model. WORM is useful when you want to store important data to protect against accidental deletion, or to meet compliance requirements.

# [Key Concepts](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#key-concepts)

## [GOVERNANCE mode](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#governance-mode)

Object versions cannot be overwritten or deleted unless the user has specially granted permissions. This mode allows for strong protection while still offering an authorized workflow to adjust retention settings or remove objects when needed.

## [COMPLIANCE mode](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#compliance-mode)

Object versions remain completely immutable and cannot be overwritten, deleted, or have their retention period shortened by any user—ensuring the highest level of data protection.

## [Retention Period](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#retention-period)

The amount of time an object is protected.

## [Summary of functionality](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#summary-of-functionality)

Object lock is supported on all [endpoint types](https://techdocs.akamai.com/cloud-computing/docs/object-storage#endpoint-types) (E0-E3).  The table below summarizes feature functionality by mode and access key type.

| Access key permissions | Object Lock type | Add object version | Add delete marker | Delete object version (during retention period) | Delete object version (retention period expired) |
|---|---|---|---|---|---|
| unlimited | disabled | ✓ | ✓ | ✓ | ✓ |
| unlimited | GOVERNANCE | ✓ | ✓ | ✓\* | ✓ |
| unlimited | COMPLIANCE | ✓ | ✓ | x | ✓ |
| limited: read_write | disabled | ✓ | ✓ | ✓ | ✓ |
| limited: read_write | GOVERNANCE | ✓ | ✓ | x | ✓ |
| limited: read_write | COMPLIANCE | ✓ | ✓ | x | ✓ |
| limited: read_only | any | x | x | x | x |

\*Requires `x-amz-bypass-governance-retention` request header.

- "add object version" means any of the following:
  - Using `PutObject` or a multipart upload to upload a new object.
  - Using `PutObject` or a multipart upload to upload a new current version for an existing object.
- "add delete marker" means
  - Using `DeleteObject` without versionId to add a delete marker for an existing object, thereby hiding it.
- "delete object version" means
  - Using `DeleteObject` with versionId to permanently delete a specific version of an existing object.

# [Object Lock usage details](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#object-lock-usage-details)

- Object Lock must be enabled at bucket creation time.
- When Object Lock is enabled versioning on a bucket is automatically enabled.
- Object Lock configuration can only be applied at the bucket level and will apply to every new object version within a bucket.
- If the Object Lock configuration changes, the new default retention rule applies only to new object versions created after the change, not to any pre-existing object versions.
- If compliance mode is enabled any object versions cannot be deleted or modified by any user, or Akamai, until (1) the retention period expires (2) the account is deleted.
- Management of Object Lock is currently only supported using the S3 API’s; there is currently no support for Object Lock in Cloud Manager.  All examples below use the Amazon AWS CLI to illustrate key management concepts.
- It is possible to create a delete-marker for an object (ex. by calling delete-object on a key without a specific version id).  This will remove the object from being returned in a response via the list-objects-v2 API call, however the individual object versions still remain and are subject to the governance and compliance lock policy.

# [Examples](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#examples)

## [Create a bucket with Object Lock enabled](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#create-a-bucket-with-object-lock-enabled)

The same Object Lock configuration is used for both governance and compliance buckets. The Object Lock configuration is provided next. 

```
aws s3api create-bucket \
  --bucket lock-bucket-governance \
  --object-lock-enabled-for-bucket \
  --endpoint=https://gb-lon-1.linodeobjects.com/

aws s3api create-bucket \
  --bucket lock-bucket-compliance \
  --object-lock-enabled-for-bucket \
  --endpoint=https://gb-lon-1.linodeobjects.com/
```

## [Apply governance mode with the retention period set to 1 day](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#apply-governance-mode-with-the-retention-period-set-to-1-day)

```
aws s3api put-object-lock-configuration \
  --endpoint=https://gb-lon-1.linodeobjects.com/ \
  --bucket lock-bucket-governance \
  --object-lock-configuration '{ "ObjectLockEnabled": "Enabled", "Rule": { "DefaultRetention": { "Mode": "GOVERNANCE", "Days": 1 }}}'
```

## [Apply compliance mode with the retention period set to 1 day](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#apply-compliance-mode-with-the-retention-period-set-to-1-day)

```
aws s3api put-object-lock-configuration \
  --endpoint=https://gb-lon-1.linodeobjects.com/ \
  --bucket lock-bucket-compliance \
  --object-lock-configuration '{ "ObjectLockEnabled": "Enabled", "Rule": { "DefaultRetention": { "Mode": "COMPLIANCE", "Days": 1 }}}'
```

## [Verify Bucket-level Object Lock Configuration](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#verify-bucket-level-object-lock-configuration)

```
aws s3api get-object-lock-configuration \
  --endpoint=https://gb-lon-1.linodeobjects.com/ \
  --bucket lock-bucket-governance

aws s3api get-object-lock-configuration \
  --endpoint=https://gb-lon-1.linodeobjects.com/ \
  --bucket lock-bucket-compliance
```

## [Verify Object-level Object Lock Configuration (object retention)](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#verify-object-level-object-lock-configuration-object-retention)

```
aws s3api list-object-versions \
    --endpoint=https://gb-lon-1.linodeobjects.com/ \
    --bucket=lock-bucket-governance \
    --prefix=governance-object.txt

aws s3api list-object-versions \
    --endpoint=https://gb-lon-1.linodeobjects.com/ \
    --bucket=lock-bucket-compliance \
    --prefix=compliance-object.txt
```

### [Use version id in](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#use-version-id-in)

```
aws s3api get-object-retention \
  --endpoint=https://gb-lon-1.linodeobjects.com/ \
  --bucket lock-bucket-governance \
  --key governance-object.txt \
  --version-id [version id]

aws s3api get-object-retention \
  --endpoint=https://gb-lon-1.linodeobjects.com/ \
  --bucket lock-bucket-compliance \
  --key compliance-object.txt \
  --version-id [version id]
```

## [Set a lifecycle policy to delete object versions automatically after their retention period expires](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#set-a-lifecycle-policy-to-delete-object-versions-automatically-after-their-retention-period-expires)

For more information see, [Removing expired object delete markers in a versioning-enabled bucket](https://docs.aws.amazon.com/AmazonS3/latest/userguide/lifecycle-configuration-examples.html#lifecycle-config-conceptual-ex7).

## [Examples that work in governance mode but not in compliance mode](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#examples-that-work-in-governance-mode-but-not-in-compliance-mode)

### [Delete an object version whose retention period has not yet expired](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#delete-an-object-version-whose-retention-period-has-not-yet-expired)

```
aws s3api delete-object \
  --endpoint=https://gb-lon-1.linodeobjects.com/ \
  --bucket lock-bucket-governance \
  --key governance-object.txt \
  --version-id [version id] \
  --bypass-governance-retention
```

### [Shorten the retention period for an existing object version](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#shorten-the-retention-period-for-an-existing-object-version)

```
aws s3api put-object-retention \
  --endpoint=https://gb-lon-1.linodeobjects.com/ \
  --bucket lock-bucket-governance \
  --key governance-object.txt \
  --version-id [version id] \
  --retention Mode=GOVERNANCE,RetainUntilDate=2026-01-01 \
  --bypass-governance-retention
```

<!--

 

# [Audit Logging - Configuration](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#audit-logging-configuration)

The following configuration audit log events are supported with Cloud Pulse in support of the use cases to:

1. Create a bucket and configure Object Lock.
2. Set a lifecycle policy to delete all object versions after X days.

| S3 API                          | Audit Trail |
| :------------------------------ | :---------- |
| CreateBucket                    | ✓           |
| DeleteBucket                    | ✓           |
| PutObjectLockConfiguration      | ✓           |
| PutBucketPolicy                 | ✓           |
| DeleteBucketPolicy              | ✓           |
| PutBucketLifecycleConfiguration | ✓           |
| DeleteBucketLifecycle           | ✓           |

# [Audit Logging - Data Access](https://techdocs.akamai.com/cloud-computing/docs/protect-data-with-object-lock#audit-logging-data-access)

Data access events are not currently supported.

\--!>