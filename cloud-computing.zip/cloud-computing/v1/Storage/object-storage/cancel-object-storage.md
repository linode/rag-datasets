# [Cancel Object Storage](https://techdocs.akamai.com/cloud-computing/docs/cancel-object-storage#cancel-object-storage)

The following steps outline how to cancel the Object Storage service from Cloud Manager.

 > Error: 
  Cancelling Object Storage deletes all objects and buckets from your account. Consider downloading any important files before continuing.

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Settings** (under **Administration**) in the sidebar menu.

2. Find the section labeled _Object Storage_ and click the **Cancel Object Storage** button.

   

3. A prompt appears asking you to confirm the cancellation. Click **Confirm cancellation** to proceed. Any remaining buckets and objects on your account are deleted and you will no longer be billed for Object Storage.