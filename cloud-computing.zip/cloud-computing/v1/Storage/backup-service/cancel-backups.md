# [Cancel backups](https://techdocs.akamai.com/cloud-computing/docs/cancel-backups#cancel-backups)

You can cancel the Backups service at any time, which prevents any new backups from being created using the service and deletes any previously generated backups that may have been stored.

 > Error: 
  Cancelling your Backups Service irretrievably deletes all of your Linode's backups, including its manual snapshot.
  To preserve this data, you need to back up your data independently from the Backups service before cancelling it. You may consult the suggestions in [Backing up your data](https://linode.com/docs/guides/backing-up-your-data/) for more information on how to do this.

1. From the **Linodes** page, select the Linode.

2. Click the **Backups** tab.

3. Click the **Cancel Backups** button at the bottom of the page.