# [Take a manual snapshot](https://techdocs.akamai.com/cloud-computing/docs/take-a-manual-snapshot#take-a-manual-snapshot)

As part of the Backups service, you can store a manual backup of your Linode through the _manual snapshot_ feature. This can be useful to save a restore point before a major system upgrade or before significant changes to software or configuration within your Linode.

 > Note: 
  The manual snapshot feature is part of the paid Backups service and, as such, the Backups service must be enabled. See [Enable backups](https://techdocs.akamai.com/cloud-computing/docs/enable-backups).

 > Error: 
  Only a _single_ manual snapshot can be stored for a Linode. Taking a new snapshot overwrites any previously saved manual snapshot.

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Linodes** link in the left navigation menu.

2. On the **Linodes** page, select the Linode from the list.

3. Navigate to the **Backups** tab.

4. Under **Manual Snapshot**, enter a label for this new snapshot and click **Take Snapshot**.

   

5. A pop-up box displays confirming that you intend to take a new manual snapshot and that any previous snapshot will be overwritten. Click **Take Snapshot** to proceed.

Creating the manual snapshot can take several minutes, depending on the size of your Linode and the amount of data you have stored on it. Other Cloud Manager jobs for this Linode will not run until the snapshot job completes.