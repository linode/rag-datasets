# [Backups FAQ](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#backups-faq)

# [Can I create more than one manual backup?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#can-i-create-more-than-one-manual-backup)

The Backups service allows for one manual snapshot in addition to the three automatically generated scheduled backups. There are no additional manual snapshot slots available. If you have an existing snapshot and you attempt to create a new one, the new snapshot will replace the old one.

If you require additional manual backups of your data, consider using [alternative methods of backing up your data](https://linode.com/docs/guides/backing-up-your-data/) or use our Images service to [capture an image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image) of your Linode's disk.

# [Can I use the Backups service to backup Block Storage volumes?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#can-i-use-the-backups-service-to-backup-block-storage-volumes)

No, the Backups service does not take backups of Block Storage volumes, even if a volume is attached to an instance.  If you wish to create a backup of your volume, consider cloning your volume or using [alternative methods of backing up your data](https://linode.com/docs/guides/backing-up-your-data/). Cloning a volume creates a new Block Storage volume of the same size and copies over all existing data. To clone your volume, navigate to the volumes page in Cloud Manager, open the ellipsis menu of the corresponding volume you wish to clone, and select the **Clone** link.

# [Where are backups physically stored?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#where-are-backups-physically-stored)

Backups created by the Backups service are stored on separate dedicated hardware located in the same data center as the associated instance. This means that existing backups are not affected by isolated incidents with the instance or the underlying hardware of that instance.

# [How do I download a backup to my local computer?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#how-do-i-download-a-backup-to-my-local-computer)

Existing backups are not able to be downloaded directly, though you can restore a backup to a n instance and download any files or disks you require.

- If you need a local backup of your instance as it exists in that moment, you do not need to restore from a backup. Instead, you can use tools like [rsync](https://linode.com/docs/guides/backing-up-your-data/#manual-backup-via-rsync), FTP, and SCP to download files directly from your instance. For more details, see [Download files from your Linode](https://linode.com/docs/guides/download-files-from-a-compute-instance/).

- If you wish to download files as they were on a previous backup, you can restore that backup to a Linode and then access that instance to download files. For instructions, see [Download a local copy of your backup](https://techdocs.akamai.com/cloud-computing/docs/download-backups-locally).

# [Is the Backups service compatible with an encrypted or partitioned disk?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#is-the-backups-service-compatible-with-an-encrypted-or-partitioned-disk)

No. Our Backups service must be able to mount your disk. This is not currently possible if your disk is encrypted or if it has multiple partitions. See [Limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/backup-service#limits-and-considerations) for more details about this and other requirements.

# [Why does it take such a long time to create a backup or restore from a backup?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#why-does-it-take-such-a-long-time-to-create-a-backup-or-restore-from-a-backup)

In many cases, slow backup operations (including creating a new backup and restoring from a backup) are due to a large number of files stored on your instance. The more files on your system, the longer it takes to perform backup operations and the greater the chance for a backup failure.

If your system generates a large number of files (such as log files), consider configuring your system to automatically archive (or delete) these files. Alternatively, you can also store these files on a disk that is _not_ subscribed to our Backups service or store them on a [Block Storage](https://www.linode.com/products/block-storage/) volume. If any of these solutions do not work for you, review the [Backing up your data](https://linode.com/docs/guides/backing-up-your-data/) guide for to learn about other backup tools and strategies.

# [What do I do if my backup restoration fails?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#what-do-i-do-if-my-backup-restoration-fails)

When restoring a backup to an instance , you may see a message that your backup restoration has failed. If you receive this message, we first recommend that you attempt to boot that instance . It's possible that only a small number of files failed to be properly restored (such as socket files and other temporary files). In this case, it's likely that your instance will still successfully boot and contain all of the data you required. If booting the instance does not work, review the [Troubleshooting backups](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-issues-with-the-backup-service) guide.

# [Why do I keep receiving "backup failure" tickets?](https://techdocs.akamai.com/cloud-computing/docs/faqs-for-the-backup-service#why-do-i-keep-receiving-backup-failure-tickets)

This ticket is to alert you when our Backups service isn't able to successfully backup one of your instances. These issues are often resolved automatically and, in many cases, no action is required on your end. If you have received more than one of these tickets in a short period of time, we recommend reviewing the [Troubleshooting backups](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-issues-with-the-backup-service) guide so that you can diagnose the issue yourself or replying to one of the tickets so that our Support team can investigate further.