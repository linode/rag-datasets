# [Schedule backups](https://techdocs.akamai.com/cloud-computing/docs/schedule-backups#schedule-backups)

The Backups service will generate automatic backups according to the schedule that you specify.

1. From the **Linodes** page, select the Linode.

2. Click the **Backups** tab.

3. Under **Settings**, select a time interval from the **Time of Day** dropdown menu. The Backups Service will prioritize _starting_ the automated daily backup between these hours.

4. Select a day from the **Day of Week** menu. On this day, the daily backup will also be saved to the weekly backup slot and the weekly backup will be promoted to the biweekly slot.

5. Click **Save Schedule** to make any changes.
