# [Enable backups](https://techdocs.akamai.com/cloud-computing/docs/enable-backups#enable-backups)

The Backups service can be individually enabled on an existing Linode and auto-enabled on all new Linodes.

# [Enable the Backups service on an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/enable-backups#enable-the-backups-service-on-an-existing-linode)

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. From the **Linodes** page, select the Linode you want to back up.

3. Click the **Backups** tab.

4. Click **Enable Backups**. 

   

5. A pop-up box is displayed confirming that you intend to enable backups for the specified monthly cost. Click **Enable Backups** to confirm.

The Backups service is now enabled for the selected Linode.

# [Auto enroll new Linodes in the Backups service](https://techdocs.akamai.com/cloud-computing/docs/enable-backups#auto-enroll-new-linodes-in-the-backups-service)

You can automatically enroll all new Linodes in the Backups service.

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Settings** (under **Administration**) in the sidebar menu.

2. In the **Backup Auto Enrollment** panel, click on the switch to enable backups on all new Linode.

   

 > Note: 
  Enabling this setting does not retroactively enroll any previously created Linodea in the Backups service.