# [Get started with the Backups service](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-backup-service#get-started-with-the-backups-service)

# [Enable the Backups service](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-backup-service#enable-the-backups-service)

The Backups service can be enabled on existing Linode by following the instructions below:

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. From the **Linodes** page, select the Linode you want to back up.

3. Click the **Backups** tab.

4. Click **Enable Backups**.

For further instructions, including details on enabling the Backups service for new Linodes, see [Enable backups](https://techdocs.akamai.com/cloud-computing/docs/enable-backups).

# [Manage backups](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-backup-service#manage-backups)

Once enabled, the Backups service will store up to four backups, three of which are automatically generated on the date and time range you specify:

- **Daily** _(Less than 24 hours old)_
- **Weekly** _(Less than 7 days old)_
- **Biweekly** _(Between 8 and 14 days old)_
- **Manual Snapshot** _(A user-initiated snapshot that stays the same until another snapshot is initiated)_

These backups can be managed in Cloud Manager under the **Backups** tab for your Linode.

This page also provides a few other options, detailed below:

- **Manual Snapshot:** Creates a new manual snapshot, overwriting any existing one. See [Take a manual snapshot](https://techdocs.akamai.com/cloud-computing/docs/take-a-manual-snapshot).

- **Settings:** Allows you to schedule when automatic backups are generated. See [Schedule backups](https://techdocs.akamai.com/cloud-computing/docs/schedule-backups).

- **Cancel Backups:** Removes the Backups service and deletes all existing backups. See [Cancel backups](https://techdocs.akamai.com/cloud-computing/docs/cancel-backups).

# [Restore from a backup](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-backup-service#restore-from-a-backup)

To restore from a backup, locate the backup within the **Backups** tab of the Linode and click the corresponding **ellipsis** menu. From here, there are a few options that can be selected:

- **Restore to existing Linode:** See [Restore a backup to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/restore-a-backup-to-an-existing-compute-instance).

- **Deploy new Linode:**  See [Restore a backup to a new Linode](https://techdocs.akamai.com/cloud-computing/docs/restore-a-backup-to-a-new-compute-instance).