# [Block Storage](https://techdocs.akamai.com/cloud-computing/docs/block-storage#block-storage)

The Block Storage service provides a method of adding additional storage drives to Linodes, enabling you to store more data without resizing your Linode to a larger plan. These storage drives, called _Volumes_, can be formatted with any Linux-compatible file system and attached and mounted to a Linode.

# [Scalable](https://techdocs.akamai.com/cloud-computing/docs/block-storage#scalable)

A Block Storage volume augments the raw storage capacity of a Cloud Instance, which can be useful if your storage needs are greater than your computing demands. Because a volume is scalable, it can adapt as your data grows in size.

# [Resilient and fault tolerant](https://techdocs.akamai.com/cloud-computing/docs/block-storage#resilient-and-fault-tolerant)

Block Storage volumes are configured to be durable and fault tolerant using erasure coding, ensuring that your data is protected from loss. Since volumes are managed independently of Linodes, your data persists even if you delete your attached instance.

# [Ultra-fast performance](https://techdocs.akamai.com/cloud-computing/docs/block-storage#ultra-fast-performance)

Block Storage is powered entirely by NVMe SSD storage devices. NVMe storage offers dramatically increased performance over standard SATA SSDs, HDDs, or hybrid storage solutions. Additionally, performance is automatically increased in 60 second bursts for even faster real-world speeds. See the table below for both sustained and burst performance limits on NVMe-only Block Storage:

| Performance Metric | IOPS   | Throughput |
| ------------------ | ------ | ---------- |
| **Sustained**      | 8,000  | 350 MB/s   |
| **Burst**          | 12,000 | 525 MB/s   |

Performance may vary based on the workload and Linode type. Plans with dedicated CPU resources (such as Dedicated CPU or High Memory Linodes) will not be impacted by resource contention, though a Shared Linode may be impacted.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/block-storage#availability)

Block Storage is available across [all core compute regions](https://www.linode.com/global-infrastructure/), but is not available in distributed compute regions. Additionally, the newer NVMe-backed Block Storage has been deployed to all data centers.

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/block-storage#plans-and-pricing)

Block Storage volumes start at $0.10/GB per month ($0.00015/GB per hour) and can range from 10 GB to 16 TB in size. [Pricing](https://www.linode.com/pricing/) for Block Storage may vary between data centers.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/block-storage#technical-specifications)

- Minimum size for a volume is 10 GB and the maximum size is 16 TB.
- Backed by high speed NVMe storage in all data centers.
- **Throughput**: Up to 350 MB/s sustained and 525 MB/s in 60 second bursts
- **IOPS**: Up to 8,000 sustained and 12,000 in 60 second bursts
- Built in redundancy maximizes availability and reduces possibility for data loss

# [Limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/block-storage#limits-and-considerations)

- A Linode can have multiple volumes attached to it, but a volume can only be attached to one Linode at a time. To attach a volume, both the volume and the Linode must be located in the same data center. Migrating a volume to a different data center is not directly available at this time. See [Transfer Block Storage data between data centers](https://techdocs.akamai.com/cloud-computing/docs/transfer-block-storage-data-between-data-centers) for a work-around.

- A combined total of 8 storage devices can be attached to a Linode at the same time, including local disks and Block Storage volumes. For example, if your Linode has two main disks, root and swap, you can attach no more than 6 additional volumes to this Linode.

- The maximum combined capacity limit of all volumes on an account across all regions is 100 TiB. If you plan on exceeding this amount, contact [Support](https://www.linode.com/support/) to request an increase. In your request, please provide the capacity limit you are requesting for each region you plan to use.

- You can attach Block Storage volumes to a Linode in Full Virtualization mode only after you Power Off the Linode. For further steps, see [Attach a volume](https://techdocs.akamai.com/cloud-computing/docs/attach-and-detach-a-volume).

- Our Backups Service does not cover Block Storage volumes. You must manage [your own backups](https://linode.com/docs/guides/backing-up-your-data/) if you wish to backup data stored on your volumes.

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/block-storage#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of services on Akamai Cloud.

  - [Block Storage Endpoint Collection](https://linode.com/docs/api/volumes/)

  - [Manage Block Storage volumes with the Linode API](https://techdocs.akamai.com/cloud-computing/docs/manage-block-storage-volumes-with-the-api).
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line. Learn how to use the Linode CLI to [create and manage Block Storage volumes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-block-storage-volumes).
- **Block Storage CSI Driver**: The Container Storage Interface (CSI) defines a standard that storage providers can use to expose block and file storage systems to container orchestration systems. [Block Storage CSI driver](https://github.com/linode/linode-blockstorage-csi-driver) follows this specification to allow container orchestration systems, like [Kubernetes](https://www.linode.com/products/kubernetes/), to use Block Storage volumes to persist data despite a Pod’s lifecycle.
- **Docker Volume Driver**: The [Docker volume driver](https://github.com/linode/docker-volume-linode) is a plugin that adds the ability to manage Block Storage volumes as Docker Volumes. Good use cases for volumes include:

  - Off-node storage, to avoid size constraints

  - Moving a container and the related volume between nodes in a Swarm
- **Terraform**: Terraform is an Infrastructure-as-code tool that includes management features for various types of Linode resources. Use Linode’s [official Terraform Provider](https://www.terraform.io/docs/providers/linode/r/volume.html) to create and manage Block Storage volumes. To learn more about Terraform see our documentation library’s [Terraform section](https://linode.com/docs/applications/configuration-management/terraform/).
- **Pulumi**: Pulumi is a development tool that lets you write computer programs which deploy cloud resources. With [Pulumi’s Akamai Cloud integration](https://github.com/pulumi/pulumi-linode), you can manage your cloud computing resources in several programming languages, like JavaScript, Go, Python, and TypeScript. Pulumi manages your resources in the same way as Linode API or Linode CLI. See [Pulumi’s documentation](https://www.pulumi.com/docs/intro/cloud-providers/linode/) to get started. [Getting Started with Pulumi](https://linode.com/docs/guides/deploy-in-code-with-pulumi/).