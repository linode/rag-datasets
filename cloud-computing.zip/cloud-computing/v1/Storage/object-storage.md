# [Object Storage](https://techdocs.akamai.com/cloud-computing/docs/object-storage#object-storage)

Object Storage is a globally-available, Amazon S3-compatible method for storing and accessing data. Object Storage differs from traditional hierarchical data storage, such as a traditional filesystem on a physical/virtual disk and [Block Storage volumes](https://techdocs.akamai.com/cloud-computing/docs/block-storage). Under Object Storage, files (also called _objects_) are stored in flat data structures (referred to as _buckets_) alongside their own rich metadata.

Due to the nature of Object Storage, it does not require the use of a Linode. Instead, Object Storage gives each object a unique URL with which you can access the data. An object can be publicly accessible, or you can set it to be private and only visible to you. This makes Object Storage great for sharing and storing unstructured data like images, documents, archives, streaming media assets, and file backups, and the amount of data you store can range from small collections of files up to massive libraries of information.

# [Features](https://techdocs.akamai.com/cloud-computing/docs/object-storage#features)

## [Amazon S3-compatible](https://techdocs.akamai.com/cloud-computing/docs/object-storage#amazon-s3-compatible)

Object Storage is a globally-available, Amazon S3-compatible storage solution, maintaining the same performance as your data grows.

## [No Linode required](https://techdocs.akamai.com/cloud-computing/docs/object-storage#no-linode-required)

Object storage does not require the use of a Linode. Instead, Object Storage gives each object a unique URL which you can use to access your data.

## [Host static sites](https://techdocs.akamai.com/cloud-computing/docs/object-storage#host-static-sites)

Using Object Storage to host your static site files means you do not have to worry about maintaining your site’s infrastructure. It is no longer necessary to perform typical server maintenance tasks, like software upgrades, web server configuration, and security upkeep. See [Deploy a Static Site using Hugo and Object Storage](https://linode.com/docs/guides/host-static-site-object-storage/).

# [Endpoint types](https://techdocs.akamai.com/cloud-computing/docs/object-storage#endpoint-types)

An endpoint type defines the performance and limits when working with content stored on that endpoint.  All endpoints have an assigned type of E0, E1, E2, or E3. 

In any region that has more than one endpoint type we recommend using the endpoint with the highest performance and scale.  For example, in Seattle, please choose the E3 endpoint over the E1 endpoint for all new content to gain the performance and scale benefits of the E3 endpoint.

The [Object Storage product limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits#supported-endpoint-types-by-region) topic in this guide provides the performance and limits and for each endpoint type.

| Endpoint type | Description |
|---|---|
| Standard endpoints |  |
| E3 | E3 endpoints offer the highest performance and highest capacity and scale. E3 endpoints should be used whenever possible. |
| E2 | E2 endpoints are offered in a subset of regions that do not yet have the scale and performance of E3 endpoints. |
| E1 | E1 endpoints offer higher limits than the Legacy E0 offering. |
| Legacy endpoint |  |
| E0 | E0 endpoints include the four original Object Storage regions in Atlanta, Frankfurt, Newark, and Singapore. These endpoints have lower limits than all other endpoint types. There are no plans to increase limits for E0 endpoints. All new content should be stored on the highest endpoint available in each region. For example, in Singapore and Frankfurt, please choose the E2 and E3 endpoints over the E0 endpoint to gain the performance and scale benefits of the newer high-performance endpoints. |

# [Product support and limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage#product-support-and-limits)

For detailed information about the limits associated with buckets and each endpoint type review the [ Product support and limits](https://techdocs.akamai.com/cloud-computing/docs/object-storage-product-limits) page.

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/object-storage#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of services on Akamai Cloud.
  - [Object Storage Endpoint Collection](https://linode.com/docs/api/object-storage)
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line. [Learn how to use the Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-object-storage).