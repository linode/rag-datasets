# [Incoming DNS zone transfers](https://techdocs.akamai.com/cloud-computing/docs/incoming-dns-zone-transfers#incoming-dns-zone-transfers)

DNS Manager supports importing DNS records from external DNS providers in one of two ways:

- [**Import a DNS zone**](https://techdocs.akamai.com/cloud-computing/docs/incoming-dns-zone-transfers#import-a-dns-zone): Initiate a one-time transfer from an external DNS service. _This lets you migrate to Akamai Cloud and manage your DNS records from DNS Manager._
- [**Operate as a _secondary_ read-only DNS service**](https://techdocs.akamai.com/cloud-computing/docs/incoming-dns-zone-transfers#operate-as-a-secondary-read-only-dns-service): Get notified of (or periodically check for) DNS changes from an external DNS service and automatically update the zone file with those changes. _This lets you manage your DNS records in an external DNS service but take advantage of Akamai's reliable and geographically distributed DNS platform._

# [Before you begin](https://techdocs.akamai.com/cloud-computing/docs/incoming-dns-zone-transfers#before-you-begin)

As part of DNS zone transfers, DNS Manager sends an AXFR query to whichever external name server you specify. That external name server must then send back an AXFR response, which includes a copy of the DNS zone file data.

**Before continuing, verify that your current external DNS provider offers the ability to perform outgoing DNS zone transfers through AXFR.** If they do, add the IP addresses for Akamai's AXFR servers to the ACL or allow-list of that DNS provider. These IP addresses vary depending on if you're importing a zone or operating as a secondary and are listed in their corresponding section below.

 > Note: 
  AXFR functionality is typically available on enterprise-level plans. If your DNS provider does not support AXFR, DNS zone transfers will not work. If you still wish to use Akamai's name servers, you can instead manually create the DNS zone and update it as needed. See [Create a domain](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain).

# [Import a DNS zone](https://techdocs.akamai.com/cloud-computing/docs/incoming-dns-zone-transfers#import-a-dns-zone)

This section walks you through the first option, importing a DNS zone. This method gathers all of the DNS records from an external DNS service, creates a new domain zone within the DNS Manager, and imports each record into new zone.

1. Within your external name server, allow AXFR transfers to the following IP addresses:

   ```
   96.126.114.97
   96.126.114.98
   2600:3c00::5e
   2600:3c00::5f
   ```

2. Log in to [Cloud Manager](https://cloud.linode.com/) and select **Domains** from the left navigation menu. Click the **Import a Zone** button.

3. In the **Domain** field, enter the domain name you wish to import.

4. Enter your DNS provider's name server into the **Remote Nameserver** field. This name server needs to allow AXFR queries from the IP addresses listed in a previous step.

5. Click the **Import** button. The DNS Manager connects to the remote name server and imports your existing DNS records. If there is an issue connecting to the name server, you may see an error stating that the request was refused. If this is the case, you may want to contact your external DNS provider and verify their domain transfer process.

6. Once the DNS records have been imported, update the authoritative name servers on your domain's registrar. Remove your current provider's name servers and add Akamai's own name servers (ns1.linode.com through ns5.linode.com).

# [Operate as a secondary read-only DNS service](https://techdocs.akamai.com/cloud-computing/docs/incoming-dns-zone-transfers#operate-as-a-secondary-read-only-dns-service)

Using Akamai's DNS Manager as a _secondary_ DNS service lets you manage your DNS records elsewhere but still take advantage of Akamai Cloud's reliable and distributed platform. Chose this option if your existing DNS provider:

- does not offer secondary name server,
- is not equipped to handle large amounts of DNS traffic,
- or does not implement any high availability features.

As part of this, a common reason for using Akamai's DNS Manager as a secondary DNS provider is if your primary name server is self-hosted. This is true for users of cPanel, Plesk, and other web-hosting panels. It is also true for power-users that prefer to run their own dedicated DNS software, such as BIND, and manually update their DNS zone files. In these cases, you may value the control or automation from your current solution, but you desire more reliability and availability.

1. Within your primary name server, allow AXFR transfer from the following IP addresses. You should also make sure your name server sends NOTIFY requests to these IP addresses, which serves to notify Akamai of any DNS changes so an AXFR zone transfer is triggered.

   ```
   104.237.137.10
   45.79.109.10
   74.207.225.10
   143.42.7.10 (was 207.192.70.10)
   109.74.194.10
   2600:3c00::a
   2600:3c01::a
   2600:3c02::a
   2600:3c03::a
   2a01:7e00::a
   ```

   > > Error: 
   > 
   > On May 6, 2025, the IP address `207.192.70.10` was retired and replaced with `143.42.7.10`. Please update your firewall rules and DNS server configurations to add the new IP address (`143.42.7.10`).

2. Log in to [Cloud Manager](https://cloud.linode.com/) and select **Domains** from the left navigation menu. Click the **Create Domain** button.

3. Select **Secondary** as the zone type. This changes some of the form options below it.

4. Enter the domain name you wish to use into the **Domain** field.

5. Add the IP Address of your external DNS provider's name server. If they have more than one name server, click **Add an IP** to add each additional one if desired.

6. Click the **Create Domain** button to create the domain zone and start the transfer.

7. Once the DNS zone transfer is finished, update the authoritative name servers on your domain's registrar to use some or all of Akamai's name servers (ns1.linode.com through ns5.linode.com). If desired, add them alongside your current DNS provider's name servers (so Akamai operates as one of many name servers) or you can delete their name servers (so Akamai Cloud is the only authoritative name server).

Akamai Cloud checks for DNS changes when the refresh time elapses for the domain _or_ when it receives a NOTIFY request from one of the designated external name servers.