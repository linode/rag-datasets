# [Create a domain](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#create-a-domain)

This guide walks you through how to createLinode a domain through Cloud Manager. Adding a domain only takes a few steps. Here's an outline on how to create a domain using Cloud Manager.

1. [Open the Create Domain form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#open-the-create-domain-form-in-cloud-manager)
2. [Select the zone type](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#select-the-zone-type)
3. [Enter the domain and SOA contact](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#enter-the-domain-and-soa-contact)
4. [Pre-populate DNS records](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#pre-populate-dns-records)
5. [Create the Domain](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#create-the-domain)
6. [Finish the setup](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#finish-the-setup)

After you’ve figured out how to create domains, you’ll never need to call IT support for help again. Let’s look at each step in more detail.

# [Open the Create Domain form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#open-the-create-domain-form-in-cloud-manager)

Figuring out how to create a domain starts with getting into the system. Log in to [Cloud Manager](https://cloud.linode.com/) and choose **Domains** from the left navigation menu. Click the **Create Domain** button. This opens the [Domain Create](https://cloud.linode.com/domains/create) form.

# [Select the zone type](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#select-the-zone-type)

Select _Primary_ to use Akamai Cloud as the main DNS provider, allowing you to add and edit DNS records directly on Akamai Cloud. Alternatively, select _Secondary_ if you want Akamai Cloud to serve as a secondary DNS provider and obtain DNS records from a third-party service.

- **Primary:** _This is the most common option._ Akamai's DNS Manager serves as the primary DNS provider. This enables you to manage all of your DNS records for the domain directly through Akamai Cloud. This option supports _outgoing_ AXFR zone transfers so that other services can serve as secondary DNS providers. See [Outgoing DNS zone transfers](https://techdocs.akamai.com/cloud-computing/docs/outgoing-dns-zone-transfers).
- **Secondary**: Akamai's DNS Manager serves as the secondary DNS provider. All DNS records are managed through a third party DNS provider and are imported to Akamai Cloud through AXFR zone transfers. See [Incoming DNS zone transfers > Operate as a secondary read-only DNS service](https://techdocs.akamai.com/cloud-computing/docs/incoming-dns-zone-transfers#operate-as-a-secondary-read-only-dns-service).

# [Enter the domain and SOA contact](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#enter-the-domain-and-soa-contact)

Enter the domain name you wish to use into the **Domain** field. This is typically the bare domain (such as _example.com_) but could also include a subdomain (such as _web.example.com_). Make sure the domain name has been registered (purchased) from your preferred registrar.

Within the **SOA Email Address** field, enter the email address for the domain administrator. Ideally the SOA email should not be on the domain it's administering, as it should be accessible if there are any issues with the domain or the infrastructure hosting the domain.

# [Pre-populate DNS records](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#pre-populate-dns-records)

The **Insert Default Records** dropdown field lets you pre-populate DNS records with the IP addresses corresponding to one of your Linodes or NodeBalancers. If you already know the Linode or NodeBalancer you'd like to use with your domain, this adds the basic DNS records (A, AAAA, and MX) for that service automatically.

- **Do not insert default records for me.** No DNS records are automatically created.
- **Insert default records from one of my Lindoes.** Select one of your Linodes and DNS records are automatically created using the IPv4 and IPv6 addresses for that instance.
- **Insert default records from one of my NodeBalancers.** Select one of your NodeBalancers and DNS records are automatically created using the IPv4 and IPv6 addresses for that service.

# [Create the domain](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#create-the-domain)

Once you've made your selections, click the **Create Domain** button to add your domain to DNS Manager. The domain zone is created within seconds and is automatically set to an _Active_ status. And that's how to create a domain in Cloud Manager. But, you are not done yet.

# [Finish the setup](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#finish-the-setup)

After adding a new domain, there are a few additional steps required to complete the process:

- **Add DNS Records.** After the domain has been created, you can immediately start adding and editing DNS records for it. If you are migrating to Akamai Cloud from an existing DNS provider, make sure you have added all of the necessary DNS records to your domain _before_ adding Akamai's name servers to your domain (on your registrar). See [Manage DNS Records](https://techdocs.akamai.com/cloud-computing/docs/manage-dns-records).

- **Add Akamai's Name Servers.** To use Akamai's DNS Manager as the authoritative name servers for your domain, you need to change the name servers on your registrar. Note that the process for this varies for each registrar.

  - [Namecheap](https://www.namecheap.com/support/knowledgebase/article.aspx/767/10/how-to-change-dns-for-a-domain/): Look for the _Custom DNS_ option.
  - [GoDaddy](https://www.godaddy.com/help/change-nameservers-for-my-domains-664): Select _Enter my own name servers (advanced)_.
  - [Hover](https://help.hover.com/hc/en-us/articles/217282477--Changing-your-domain-nameservers): Find the _Edit_ option for your name servers.

  And that’s it. Now you know how to add a domain in Cloud Manager!