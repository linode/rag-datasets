# [DNS record types](https://techdocs.akamai.com/cloud-computing/docs/dns-record-types#dns-record-types)

- [A and AAAA records](https://techdocs.akamai.com/cloud-computing/docs/a-and-aaaa-records)

- [CNAME records](https://techdocs.akamai.com/cloud-computing/docs/cname-records)

- [MX records](https://techdocs.akamai.com/cloud-computing/docs/mx-records)

- [TXT records](https://techdocs.akamai.com/cloud-computing/docs/txt-records)

- [NS records](https://techdocs.akamai.com/cloud-computing/docs/ns-records)

- [SOA record](https://techdocs.akamai.com/cloud-computing/docs/soa-record)

- [SRV records](https://techdocs.akamai.com/cloud-computing/docs/srv-records)

- [CAA records](https://techdocs.akamai.com/cloud-computing/docs/caa-records)