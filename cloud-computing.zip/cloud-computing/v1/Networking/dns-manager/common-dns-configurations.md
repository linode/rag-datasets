# [Common DNS configurations](https://techdocs.akamai.com/cloud-computing/docs/common-dns-configurations#common-dns-configurations)

# [Set up a domain](https://techdocs.akamai.com/cloud-computing/docs/common-dns-configurations#set-up-a-domain)

The most common DNS configuration is a single domain name on a single Linode. For this, you'll need to add _SOA_ and _NS records_ for all of your name servers, and _A/AAAA_ records for your domain names. Use the screenshot below as a guide.

 > Note: 
  The Domains section of Cloud Manager can automatically add all of these records when you create a domain. For instructions, see the _Add a Domain_ section of the [DNS Manager](https://techdocs.akamai.com/cloud-computing/docs/dns-manager) guide.

# [Configure subdomains](https://techdocs.akamai.com/cloud-computing/docs/common-dns-configurations#configure-subdomains)

1. To configure a subdomain (e.g. `staging.example-site-demo.com`), create an A record with the subdomain's hostname. Click **Add an A/AAAA Record**:

   

2. Add the subdomain under the **Hostname** field. Assign the IP address of the server you want to host the subdomain:

   

3. Click on the **Save** button to create the record.

   > > Note: Multi-level Subdomains
   > 
   > The Cloud Manager does not support adding a subdomain of a subdomain in the same domain zone. For example, if you have `example.com` as a domain with an A record for `staging.example.com`, you cannot create `test.staging.example.com` within that same domain zone. Instead, create a separate domain zone for the subdomain `staging.example.com`. Then, add an A record for `test.staging.example.com` to that new zone.
   > 
   > ```
   > See the [subdomains](https://techdocs.akamai.com/cloud-computing/docs/manage-dns-records#second-level-subdomains) section of the [DNS manager](https://techdocs.akamai.com/cloud-computing/docs/dns-manager) guide for more information.
   > ```

# [Host multiple domains on a single server](https://techdocs.akamai.com/cloud-computing/docs/common-dns-configurations#host-multiple-domains-on-a-single-server)

To host multiple domain names on a single server, create a separate domain entry for each domain name as shown below. When creating the new domain entry, we recommend that you allow the Domains section of Cloud Manager to automatically [insert basic records](https://techdocs.akamai.com/cloud-computing/docs/create-a-domain#pre-populate-dns-records). At a minimum, you'll need an A record for each domain name pointing to the server's IP address.

# [Use one domain on multiple servers](https://techdocs.akamai.com/cloud-computing/docs/common-dns-configurations#use-one-domain-on-multiple-servers)

If you have more than one server, but only one domain name, you can point A records with server-specific hostnames to all servers that need domain names. One machine will be the "front end" for the domain, by virtue of the first-level domain's A record pointing to it, but the domain can serve as a proxy for services provided by other machines, if needed. For example, if you wanted to create a development environment on another server, you could create an A record for `staging.example.com` and point it at another Linode's IP address.

# [Route email to third-party mail services](https://techdocs.akamai.com/cloud-computing/docs/common-dns-configurations#route-email-to-third-party-mail-services)

To route email to a third-party email service, create MX records that associate your mail server (for example, `mail.example-site-demo.com`) with a _hostname_ provided by the third-party service. For more detailed instructions, see the website of your third-party email service.

# [Use wildcard DNS records](https://techdocs.akamai.com/cloud-computing/docs/common-dns-configurations#use-wildcard-dns-records)

A _wildcard_ DNS record matches requests for non-existent domain names. For example, if you create an A record for `*.example.com`, and a user visits `nonexistantname.example.com`, that user will be redirected to `example.com`. An example wildcard DNS record is shown below.
