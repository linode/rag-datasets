# [A and AAAA records](https://techdocs.akamai.com/cloud-computing/docs/a-and-aaaa-records#a-and-aaaa-records)

# [A and AAAA overview](https://techdocs.akamai.com/cloud-computing/docs/a-and-aaaa-records#a-and-aaaa-overview)

An **A** (_Address_) record matches a domain name to an IPv4 address, specifically the address of the machine hosting the desired resource for the domain. **AAAA** (also called _quad A_) records are the same as _A_ records, but store the IPv6 address of the machine instead of the IPv4 address. See [Overview of DNS and DNS Records > A and AAAA](https://linode.com/docs/guides/dns-overview/#a-and-aaaa).

# [Properties](https://techdocs.akamai.com/cloud-computing/docs/a-and-aaaa-records#properties)

- **Hostname:** The root domain or the subdomain that you wish to use.

  - For the root domain (such as _example.com_), enter the `@` character or leave the field blank.
  - For a subdomain (such as _host.example.com_), enter a string that's 1-63 characters in length and contains only letters, numbers, and underscores. Hyphens can also be used, but the string cannot start with one.

- **IP Address:** The IPv4 or IPv6 address of the target server, such as a Linode. The DNS Manager automatically creates either an A record or AAAA record depending on the type of IP address. See the [Find Your Linode's IP Address](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance) guide for help locating an IP address on your Linode Linode.

- **TTL** (_Time To Live_): The length of time that DNS resolvers should store the DNS record _before_ revalidating it with Akamai Cloud's name servers. Setting the TTL to **5 minutes** is recommended for many use cases. If **Default** is selected, the TTL is set to **24 hours**.

# [Examples](https://techdocs.akamai.com/cloud-computing/docs/a-and-aaaa-records#examples)

- **Hosting a website using the domain _example.com_.** Set the **Hostname** to `@` and the **IP Address** to the IPv4 address of the server hosting the website. If you wish to support IPv6 users (such as devices connected over many cellular networks), also create an AAAA record with the same hostname but using the IPv6 address of the server.

  > > Note: 
  > 
  > While you can also create an A record for a subdomain, like _[www.example.com](http://www.example.com)_, it's more common to use CNAME records if the subdomain points to the same server. This limits the amount of places you might need to enter your IP address and reduces the overall number of DNS records you need to maintain.

- **Configuring the FQDN (fully qualified domain name) for a server.** Machines are often addressed by their FQDN, not their IP addresses. To set up an FQDN, create an A (and/or AAAA) record using the hostname of the machine (such as `web01` for _web01.example.com_.) and map it to its primary IPv4 or IPv6 address.