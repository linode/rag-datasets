# [SRV records](https://techdocs.akamai.com/cloud-computing/docs/srv-records#srv-records)

# [SRV overview](https://techdocs.akamai.com/cloud-computing/docs/srv-records#srv-overview)

An **SRV** (_service_) record provides the target hostname and port for a given service. This lets you direct traffic for specific services to a server other than what is specified in corresponding DNS records. SRV records are required for some protocols, such as XMPP and SIP.

# [Properties](https://techdocs.akamai.com/cloud-computing/docs/srv-records#properties)

- **Service:** The name of the service, such as _sip_ or _xmpp_. The DNS Manager automatically includes a leading underscore character (`_`) and trailing period (`.`).

- **Protocol:** The name of the protocol you wish to use. Select from one of the supported protocols: _tcp_, _udp_, _xmpp_, _tls_, and _smtp_. The DNS Manager automatically formats this to conform to the SRV record standards.

- **Domain:** The name of the domain that will receive the original traffic for this service. This is generated automatically by DNS Manager and is based on the root domain (the domain name specified when you created the _Domain_ entry). If you wish to enable an SRV on a subdomain, you must create a separate zone (_Domain_ entry) for that subdomain

- **Priority**: A number representing the priority of the target host, with lower numbers having higher priority. This value matters when you have more than one SRV record for the same service, allowing you to have one or more fallback hosts.

- **Weight**: A number representing the weight given to the target host. When multiple hosts have the _same_ priority, clients should load balance them according to their weight. Hosts with larger weights are sent a larger portion of the traffic.

- **Port**: The port used by the service on the target host.

- **Target**: The target domain name where traffic should be redirected. This could be the root domain, a subdomain, or a separate domain entirely. Enter the `@` character to use the root domain. The target domain name must have a valid A or AAAA record to specify the IP address of the target host.

- **TTL** (_Time To Live_): The length of time that DNS resolvers should store the DNS record _before_ revalidating it with Akamai Cloud's name servers. Setting the TTL to **5 minutes** is recommended for many use cases. If **Default** is selected, the TTL is set to **24 hours**.