# [NS records](https://techdocs.akamai.com/cloud-computing/docs/ns-records#ns-records)

# [NS overview](https://techdocs.akamai.com/cloud-computing/docs/ns-records#ns-overview)

**NS** (_Name Server_) records specify the name servers used for a domain or subdomain. Name servers for the root domain (like _example.com_) are set directly on the domain's registrar, as well as through NS records. By default, five NS records are automatically created for you on DNS Manager, one for each of Akamai's name servers (ns1.linode.com through ns5.linode.com). These can not be modified. Additional NS records can be created if you wish use a subdomain with a different DNS provider or manage it as a separate _Domain_ (zone file) in DNS Manager.

The order of NS records does not matter. A random NS record for a domain will be provided when the domain is queried. If one name server fails to respond, another one will be queried.

# [Properties](https://techdocs.akamai.com/cloud-computing/docs/ns-records#properties)

- **Name Server:** The name server you wish to use. This could be name server corresponding with a third-party DNS service. If you wish to still use Akamai's DNS Manager but manage the subdomain as a separate _Domain_ (zone file), enter Akamai's name servers.

- **Subdomain:** The subdomain that you wish to manage as a separate _Domain_ (zone file) or through another DNS provider.

  - Enter a string that's 1-63 characters in length and contains only letters, numbers, and underscores. Hyphens can also be used, but the string cannot start with one.

- **TTL** (_Time To Live_): The length of time that DNS resolvers should store the DNS record _before_ revalidating it with Akamai's name servers. Setting the TTL to **5 minutes** is recommended for many use cases. If **Default** is selected, the TTL is set to **24 hours**.