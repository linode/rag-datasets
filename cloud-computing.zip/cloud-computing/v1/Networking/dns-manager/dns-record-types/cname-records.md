# [CNAME records](https://techdocs.akamai.com/cloud-computing/docs/cname-records#cname-records)

# [CNAME overview](https://techdocs.akamai.com/cloud-computing/docs/cname-records#cname-overview)

A **CNAME** (_Canonical Name_) record maps one subdomain to another subdomain, a root domain, or even a different domain entirely. Essentially, it creates an _alias_ to the specified _target_ domain. CNAME records are very common and prevent administrators from repeating IP addresses or other information across multiple DNS records.

To provide an example, consider that _docs.example.com_ is hosted on the same server as _example.com_. Also consider that an [A record](https://techdocs.akamai.com/cloud-computing/docs/a-and-aaaa-records) already exists for _example.com_, which specifies the IP address of the server. Instead of creating another A record, you can create a CNAME record for _docs.example.com_ and set it as an alias to _example.com_. When a DNS lookup occurs on _docs.example.com_, the DNS resolver sees that it is a CNAME record and performs another DNS lookup on the target domain. As the second query is for an A record, the IP address of the server is returned, which allows the user to access the website on that server.

In most cases, the target domain should resolve to another type of DNS record, like an A record. However, you can configure CNAME looping, which occurs when a CNAME points to another CNAME. In this case, the last record in the chain must be another type of record.

# [Properties](https://techdocs.akamai.com/cloud-computing/docs/cname-records#properties)

- **Hostname:** The subdomain that you wish to use.

  - Enter a string that's 1-63 characters in length and contains only letters, numbers, and underscores. Hyphens can also be used, but the string cannot start with one.

  > > Note: 
  > 
  > Using the root domain as the hostname for a CNAME record is called _CNAME flattening_ and is not supported on Akamai's DNS Manager.

- **Alias to:** The full domain name of the canonical domain, where traffic should be redirected. You can also use the `@` character to use the root domain.

- **TTL** (_Time To Live_): The length of time that DNS resolvers should store the DNS record _before_ revalidating it with Akamai's name servers. Setting the TTL to **5 minutes** is recommended for many use cases. If **Default** is selected, the TTL is set to **24 hours**.