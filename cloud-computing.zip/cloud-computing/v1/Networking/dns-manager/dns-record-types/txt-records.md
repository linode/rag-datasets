# [TXT records](https://techdocs.akamai.com/cloud-computing/docs/txt-records#txt-records)

# [TXT record overview](https://techdocs.akamai.com/cloud-computing/docs/txt-records#txt-record-overview)

**TXT** (_text_) records stores text and can be used to provide information about the domain. It is the most flexible DNS record type and can serve many different purposes, including email security (SPF, DKIM, DMARC) or prove ownership of a domain to an outside service.

# [Properties](https://techdocs.akamai.com/cloud-computing/docs/txt-records#properties)

- **Hostname:** The root domain or the subdomain that you wish to use.

  - For the root domain (such as _example.com_), leave the field blank.
  - For a subdomain (such as _text.example.com_), enter a string that's 1-63 characters in length and contains only letters, numbers, and underscores. Hyphens can also be used, but the string cannot start with one.

- **Value:** The text you wish to include.

  - TXT records are composed of 1 or more strings. Each string can have a maximum of 255 characters and are encapsulated by quotation marks. DNS Manager automatically splits the contents of the _Value_ field into strings (including adding quotation marks). You do not need to manage this yourself.

- **TTL** (_Time To Live_): The length of time that DNS resolvers should store the DNS record _before_ revalidating it with Akamai Cloud's name servers. Setting the TTL to **5 minutes** is recommended for many use cases. If **Default** is selected, the TTL is set to **24 hours**.