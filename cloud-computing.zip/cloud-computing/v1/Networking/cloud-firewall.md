# [Linode Cloud Firewalls](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#linode-cloud-firewalls)

Linode Cloud Firewalls is a robust cloud-based firewall solution available at no additional charge. Through this service, you can create, configure, and add stateful network-based firewalls to Linodes using Configuration Profile Interfaces, Linode Interfaces (BETA), and NodeBalancers.

# [Enhanced security](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#enhanced-security)

Cloud Firewalls sit between a service (Linode, Linode Interface (BETA), or NodeBalancer) and the Internet and can be configured to filter out unwanted network traffic before it even reaches your server. Defend your apps and services from malicious attackers by creating rules to only allow traffic from trusted sources. Firewall rules can filter traffic at the network layer, providing fine-grained control over who can access your servers.

For Linodes using Linode network interfaces, firewalls are assigned at the VPC and public network interface level. For Linodes using Configuration Profile Interfaces, firewalls are assigned at the Linode level, and the same firewall rules apply to all non-VLAN interfaces in the profile.

## [Firewall templates (BETA)](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#firewall-templates-beta)

Firewall templates are available for both VPC and public Linode interfaces (BETA). Each template includes pre-configured protection rules to help you get started.

For improved security, narrow the allowed IPv4 and IPv6 ranges used in the templates.

### [VPC template rules](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#vpc-template-rules)

This default firewall rule set is a starting point for VPC Linode Interfaces. It allows SSH access, essential networking control traffic, and inbound traffic from the VPC address space.

### [Public template rules](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#public-template-rules)

This default firewall rule set is a starting point for Public Linode Interfaces. It allows SSH access and essential networking control traffic.

# [Simple interface](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#simple-interface)

Control inbound and outbound traffic using the [Linode API](https://techdocs.akamai.com/linode-api/reference/api-summary), [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli) or [Cloud Manager](https://www.linode.com/products/cloud-manager/). Each interface can be integrated into your workflow for seamless control over firewall rules. The Cloud Firewalls service makes security more accessible and enables you to secure your network traffic without needing to learn complicated software or access the command line.

# [Scalable security in seconds](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#scalable-security-in-seconds)

Stay protected as your network grows. Effortlessly apply the same ruleset across multiple Linodes and NodeBalancers. This saves time as you no longer need to manually configure internal software on each server.

# [Pricing and availability](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#pricing-and-availability)

Cloud Firewalls are available at no charge across [all regions](https://www.linode.com/global-infrastructure/).

# [Limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#limits-and-considerations)

- Cloud Firewalls are compatible with Linodes, Linode Interfaces (BETA), and NodeBalancers. They are not currently directly supported on other Akamai Cloud services, such as Object Storage.
- A Cloud Firewall can be attached to multiple services (Linodes, Linode Interfaces (BETA), and NodeBalancers), but a service can only be attached to one Cloud Firewall at a time.
- Cloud Firewall inbound and outbound rules are applied to Linodes, and Linode Interfaces (BETA), but only inbound rules are applied to NodeBalancers.
- When used in conjunction with NodeBalancers, a Cloud Firewalls inbound rules only apply to the NodeBalancer's public IP, not the IPs of the back-end nodes. This means you may also want to add individual back-end nodes to a Cloud Firewalls to protect any additional exposed IP addresses.
- Cloud Firewall rules are applied to traffic over the public and private network but are not applied to traffic over a private [VLAN](https://techdocs.akamai.com/cloud-computing/docs/vlan).
- A maximum of **25 rules** can be added to each Cloud Firewall (both Inbound and Outbound rules combined).
- A maximum of **255 IP addresses (and ranges)** can be added to each Cloud Firewall rule.
- All **IP addresses** and **IP Ranges** must be correctly formatted to save changes.
- A maximum of **15 ports (and port ranges)** can be defined on each Cloud Firewall rule.

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of services on Akamai Cloud.
  - [List firewalls](https://techdocs.akamai.com/linode-api/reference/get-firewalls)
  - [Create a firewall](https://techdocs.akamai.com/linode-api/reference/post-firewalls)
  - [Delete a firewall](https://techdocs.akamai.com/linode-api/reference/delete-firewall)
  - [Get a firewall](https://techdocs.akamai.com/linode-api/reference/get-firewall)
  - [Update a firewall](https://techdocs.akamai.com/linode-api/reference/put-firewall)
  - [List firewall devices](https://techdocs.akamai.com/linode-api/reference/get-firewall-devices)
  - [Delete a firewall device](https://techdocs.akamai.com/linode-api/reference/delete-firewall-device)
  - [Get a firewall device](https://techdocs.akamai.com/linode-api/reference/get-firewall-device)
  - [List firewall rules](https://techdocs.akamai.com/linode-api/reference/get-firewall-rules)
  - [Update firewall rules](https://techdocs.akamai.com/linode-api/reference/put-firewall-rules)
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line. [Learn how to use the Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli).