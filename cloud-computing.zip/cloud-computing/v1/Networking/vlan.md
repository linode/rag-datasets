# [VLANs](https://techdocs.akamai.com/cloud-computing/docs/vlan#vlans)

**VLANs** are private _virtual local area networks_ that are available at no additional cost to users in select data centers. They operate on [layer 2](https://en.wikipedia.org/wiki/OSI_model#Layer_2:_Data_Link_Layer) of the OSI networking model and are entirely isolated from other networks. VLANs are a key part of enabling private and secure communication between Linodes on the Linode platform. They function like a virtual network switch, which effectively means all Linodes connected to the same VLAN can communicate with each other like they were directly connected to the same physical Ethernet network. Devices outside the network cannot see any traffic within the private network.

# [Features](https://techdocs.akamai.com/cloud-computing/docs/vlan#features)

## [Private communication between Linodes](https://techdocs.akamai.com/cloud-computing/docs/vlan#private-communication-between-linodes)

A VLAN creates a truly private network and communication is isolated to just the Linodes belonging to the same VLAN. No other Linodes on other VLANs or within the same data center can see this private traffic. This goes beyond the [Private IP](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#types-of-ip-addresses) feature, which can be accessed by any resource in the same data center.

## [Simple configuration](https://techdocs.akamai.com/cloud-computing/docs/vlan#simple-configuration)

Use Cloud Manager to create a VLAN and assign Linodes. Create up to 10 VLANs per data center and assign each Linode to up to 3 VLANs.

## [Reduce network transfer costs](https://techdocs.akamai.com/cloud-computing/docs/vlan#reduce-network-transfer-costs)

Private network transfer is free. Any communication between Linodes over a VLAN does not count against the account's monthly [network transfer allowance](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs).

## [Part of a flexible custom VPC solution](https://techdocs.akamai.com/cloud-computing/docs/vlan#part-of-a-flexible-custom-vpc-solution)

Since VLANs operate on layer 2 of the OSI networking stack, you can use them as part of a custom VPC solution, which typically operates on layer 3. VLAN users can implement their own firewall policies, routing, and security systems to build out their VPC.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/vlan#availability)

VLANs are available in all data centers.

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/vlan#pricing)

VLANs are free to use. Communication across your private network does not count against your [monthly network transfer usage](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs).

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/vlan#technical-specifications)

- Fully isolated private networking for Cloud-based resources
- Operates on [Layer 2](https://en.wikipedia.org/wiki/OSI_model#Layer_2:_Data_link_layer) of the OSI model (the data link layer) and, as such, can be more flexible than Layer 3 based VPC (Virtual Private Cloud) solutions
- Supports all logical Ethernet features, such as L2 broadcast and L2 multicast
- Supports any [Layer 3](https://en.wikipedia.org/wiki/OSI_model#Layer_3:_Network_layer) protocol, including IP (Internet Protocol)
- User assignable IPv4 addresses
- Each account can maintain up to 10 VLANs per region
- Each Linode can belong to up to 3 VLANs
- Network transfer over a VLAN does not count towards your account's [network transfer allowance](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs)

# [Additional limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/vlan#additional-limits-and-considerations)

- **VLANs are region-specific.**  Once created, a VLAN can only be attached to other Linodes within the same data center.

- **VLANs cannot be manually renamed by the user.** If a VLAN's label must be changed, a new VLAN can be created and all required Linodes can be attached to that new VLAN.

- **VLANs can be manually deleted using the API.** You can manually [delete a VLAN](https://techdocs.akamai.com/linode-api/reference/delete-vlan). Alternatively, if a VLAN is no longer needed, simply detach it from all Linodes. After this, it will automatically be deleted within a short timeframe.

- **Network Helper is required for automatic configuration.** If [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) has been disabled, the Linode will not _automatically_ be able to communicate over the VLAN’s private network. In this case, advanced users can manually adjust their Linode's internal network configuration files with the appropriate settings for their VLAN. See [Manually configuring a VLAN on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manually-configuring-a-vlan-on-a-compute-instance) for instructions.

- **The Public Internet must always use the eth0 network interface.** While VLANs themselves can function without issue on the `eth0` interface, public internet traffic will not be routed properly if assigned to other interfaces.

- **Rate limit on unique source MAC addresses.** For security and performance, a rate limit of 300 unique source MAC addresses per 5-minute period is applied to VLAN interfaces.

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/vlan#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of services on Akamai Cloud.
  - [Creating a private network with VLANS using the Linode API](https://techdocs.akamai.com/cloud-computing/docs/create-a-private-network-with-vlans-using-the-api): This guide shows you how to create a VLAN and attach Linodes to it using the Linode APIv4.
  - **VLANs Endpoint Collection:** Use [VLANs List](https://linode.com/docs/api/networking/#vlans-list) and the [Configuration Profiles View](https://linode.com/docs/api/linode-instances/#configuration-profile-view) (as part of the `interfaces array`) to view VLANs. Create and manage VLANs through the [Configuration Profile Create](https://linode.com/docs/api/linode-instances/#configuration-profile-create) and [Configuration Profile Update](https://linode.com/docs/api/linode-instances/#configuration-profile-update) endpoints.
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line. Learn how to use the Linode CLI to [create and manage your Linode resources](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli).