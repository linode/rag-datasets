# [NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#nodebalancers)

**NodeBalancers** are managed _load balancers as a service (LBaaS)_, making load balancing accessible and easy to configure on Akamai Cloud. They intelligently distribute incoming requests to multiple backend Linodes, so that there's no single point of failure. This enables high availability, horizontal scaling, and A/B testing on any application hosted with Akamai Cloud.

# [High availability](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#high-availability)

In a typical single machine configuration, issues with the machine may cause the application to stop working as expected or become inaccessible. High availability solutions remove this single point of failure through combining multiple machines (redundancy), monitoring systems, and automatic failover - all of which are implemented by NodeBalancers.

# [Horizontal scaling](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#horizontal-scaling)

There are two main ways to scale an application to increase the performance and capacity within your applications. _Vertical scaling_ increases or decreases the resources on the existing machines. This is achieved by [resizing](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance) your Linodes. _Horizontal scaling_ adds or removes machines that are identically configured to serve your application or perform a certain task. This is commonly accomplished through a load balancing solution, like NodeBalancers. Horizontal scaling can be much more flexible and lets you scale as needed without taking down your site while upgrading or downgrading.

# [Additional features](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#additional-features)

- **Backend Linodes.**  You can use either VPC or non-VPC Linodes as backend nodes.
- **Firewall Security:** [Cloud Firewalls](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall) provides enhanced security by allowing you to control who can access your NodeBalancer. The optional Cloud Firewall sits between your NodeBalancer and the internet to filter out unwanted network traffic before it reaches your NodeBalancer. When used in conjunction with NodeBalancers, a Cloud Firewall's inbound rules only apply to the NodeBalancer’s public IP, not the IPs of the backend nodes. This means you may also want to add individual backend nodes to a Cloud Firewall to protect any additional exposed IP addresses.
- **Managed:** NodeBalancers take the infrastructure management out of load balancing. They are designed to be maintenance free after initial configuration.
- **Sticky Sessions:** NodeBalancers can route subsequent requests to the same back end, so all application sessions work correctly.
- **Health Checks:** Traffic is only routed to healthy back ends. Passive health checks happen on every request. You can configure active health checks based on your application or service.
- **SSL termination:** NodeBalancers can terminate SSL traffic on your behalf and expose the requester’s IP through the back end. This is done using configurable rulesets that give you the power to fine-tune admissible traffic.
- **Throttling:** Prevent potential abuse (and preserve resources on your backends) by setting a client connection throttle on the NodeBalancer.
- **Multi-Port:** NodeBalancers support balancing traffic to multiple network ports. Several services can be load balanced with a single NodeBalancer.

# [Recommended workloads](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#recommended-workloads)

- Enterprise applications
- High traffic and e-commerce websites
- Applications that require extreme reliability and uptime
- Applications that need to dynamically scale without any downtime
- A/B testing
- Expose workloads in a VPC to the internet
- Balance traffic between private workloads within a VPC
- Time-sensitive transmission, such as live streaming and broadcasts

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#availability)

NodeBalancers are available across [all regions](https://www.linode.com/global-infrastructure/). 

For NodeBalancers with backend nodes in a VPC, the VPC subnet must be in the same region as the NodeBalancer, see [VPC Availability](https://techdocs.akamai.com/cloud-computing/docs/vpc#availability) for VPC regions.

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#pricing)

Each NodeBalancer on an account starts at $10/mo ($0.015/hr). [Price](https://www.linode.com/pricing/) may vary by region.

For premium pricing, [contact sales](https://www.linode.com/company/contact/).

Cloud Firewalls is available at no additional charge to customers.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#technical-specifications)

- Managed cloud-based load balancing service
- Dynamically routes traffic over any ports to configurable backend Linodes
  - A single configuration on a premium NodeBalancer can support up to 2,000 backend nodes, while a non-premium NodeBalancer configuration can support 1,000. There may be exceptions to this limit for pre-existing NodeBalancer configurations.
- Highly available with built-in redundancy
- Automatically assigned premium NodeBalancers for [LKE-E](https://techdocs.akamai.com/cloud-computing/docs/lke-enterprise) clusters
- Up to 10,000 concurrent connections for non-premium NodeBalancers and up to 100,000 for premium
- Supports UDP (layer 4) load balancing (configured using APIs)
- Supports TCP-based (layer 4) load balancing
- Supports HTTP and HTTPS (layer 7) load balancing through the HTTP/1.1 protocol (HTTP/2 is not yet available)
- Supports both SSL termination (using the HTTPS protocol mode) and SSL pass-through (using the TCP or UDP protocol mode)
- Equipped with both public IPv4 and IPv6 addresses
- Supports inbound Cloud Firewalls rules such as IPv4 and IPv6 access control lists (ACLs) to _Accept_ or _Drop_ ingress traffic.
- Fully customizable health checks to ensure traffic lands on a functioning back end
- Maximum 10 Gbps inbound network bandwidth per NodeBalancer
- Free inbound network transfer
- Outbound network transfer usage is counted towards the account-wide [monthly network transfer pool](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs)
- Provisioning and management through [Cloud Manager](https://cloud.linode.com/), [Linode CLI](https://www.linode.com/products/cli/), or programmatically through the [Linode API](https://www.linode.com/products/linode-api/)

# [Limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#limits-and-considerations)

- **Maximum number of concurrent connections:** NodeBalancers each support up to 10,000 concurrent connections. If your application needs to support more than that, [contact support](https://www.linode.com/support/) to determine additional options or consider using multiple NodeBalancers behind a DNS load balancing solution such as [Round-Robin DNS](https://linode.com/docs/guides/setting-up-round-robin-dns/).

- **Connections per second:** There are no defined rate limits for the number of connections over a given time period, though certain modes are more performant. A port configured in **TCP** mode allows for the most number of connections. A port configured in **HTTPS** mode is the most resource intensive and accommodates fewer connections.

- **IP addresses:** A public IPv4 address and IPv6 address are configured on each NodeBalancer. Additional addresses are not available.

- **Private network:** Communication with backend Linodes occurs over a data center's private network. As such, backend Linodes must be located within the same data center as the NodeBalancer.

- **HTTP support:** HTTP/1.1 (HTTP/2 support is not yet available).

- **Network transfer:** _Outbound transfer_ usage is counted towards the account-wide [monthly network transfer pool](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs). This pool is the combined total of the network transfer allowance of each Linode on the account. Both _Incoming transfer_ and transfer over the private network are provided at no cost.

- **TLS termination:** When using a NodeBalancer with an application that requires HTTPS, you can either terminate the TLS connection on the NodeBalancer (**HTTPS** mode) or on the backend Linodes (**TCP** mode). When terminating TLS connections directly on the NodeBalancer, there are a few key considerations:

  - **TLS protocols:** TLS v1.2 and v1.3 are supported in **HTTPS** mode.
  - While operating in **HTTPS** mode, internal traffic sent to the backend Linodes will be unencrypted.

    For applications that require a very high connection rate or otherwise need to overcome the above considerations present in **HTTPS** mode, consider operating in **TCP** mode and terminating TLS on the backend Linodes.

- **Cloud Firewalls support:** When a Cloud Firewall is assigned to a NodeBalancer, the firewall only looks at incoming requests, this means that only inbound Cloud Firewall  rules apply and outbound rules are not applicable.

  > > Note: 
  > 
  > A Linode can be accessed from other interfaces (not just the NodeBalancer). To filter traffic from other interfaces, backend Linodes require their own firewalls.

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of services on Akamai Cloud.
  - [Configure NodeBalancers with the Linode API](https://techdocs.akamai.com/cloud-computing/docs/configure-nodebalancers-with-the-api)
  - [NodeBalancers API Endpoint Collection](https://linode.com/docs/api/nodebalancers)
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line. Learn how to use the Linode CLI to [create and manage NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-nodebalancers).
- **Terraform**: Terraform is an Infrastructure-as-code tool that includes management features for various types of Akamai Cloud resources. Use Akamai's [official Terraform Provider](https://registry.terraform.io/providers/linode/linode/latest/docs) to [Create a NodeBalancer with Terraform](https://linode.com/docs/guides/create-a-nodebalancer-with-terraform/). To learn more about Terraform see our documentation library’s [Terraform section](https://linode.com/docs/applications/configuration-management/terraform/).
- **Pulumi**: Pulumi is a development tool that lets you write computer programs which deploy cloud resources. With [Pulumi’s Akamai Cloud integration](https://github.com/pulumi/pulumi-linode), you can manage your cloud computing resources in several programming languages, like JavaScript, Go, Python, and TypeScript. Pulumi manages your resources in the same way as Linode API or Linode CLI. See [Pulumi’s documentation](https://www.pulumi.com/docs/intro/cloud-providers/linode/) to get started. [Getting Started with Pulumi](https://linode.com/docs/guides/deploy-in-code-with-pulumi/).
  - [Create and Configure a NodeBalancer with Pulumi](https://linode.com/docs/guides/deploy-in-code-with-pulumi/#create-and-configure-a-nodebalancer)