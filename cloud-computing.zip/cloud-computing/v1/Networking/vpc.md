# [VPC](https://techdocs.akamai.com/cloud-computing/docs/vpc#vpc)

 > Note: VPC Availability
  VPCs are now publicly available to all customers in select data centers. For a list of supported regions, review the [Availability](https://techdocs.akamai.com/cloud-computing/docs/vpc#availability) section. You can also use the [List Regions](https://techdocs.akamai.com/linode-api/reference/get-regions) API to get a list of all services available in each region.

# [Protect sensitive data](https://techdocs.akamai.com/cloud-computing/docs/vpc#protect-sensitive-data)

Networking packets sent over a VPC are walled off from the public internet — as well as from other services within the same data center that don't belong to the same VPC. When assigning a Linode to a VPC, you can opt for it to be fully private or configure it with public internet access through either a 1:1 NAT on the VPC or a public internet interface.

# [Segment traffic into separate subnets](https://techdocs.akamai.com/cloud-computing/docs/vpc#segment-traffic-into-separate-subnets)

Instead of assigning a single IPv4 range for the entire VPC, Akamai's VPC design allows users to configure multiple RFC1918 ranges through the use of subnets. This has the benefit of segmenting services into distinct networks and can be useful when migrating or combining existing networking environments so that there are no changes to routing or static IPs. These subnets can isolate various functionality of an application (such as separating public front-end services from private back-end services) or separate out a production environment from staging or development.

Routing between subnets on a VPC is configured automatically. By default, all Linodes on a VPC can communicate with any other Linode on that VPC, regardless of which subnet the other Linode is assigned to use.

# [Compatible with Cloud Firewalls](https://techdocs.akamai.com/cloud-computing/docs/vpc#compatible-with-cloud-firewalls)

If a Linode is assigned to a Cloud Firewall, firewall rules that limit access and filter traffic will be applied to the public interface as well as the VPC interface defined in the configuration profile. This means that private traffic between Linodes within a VPC will be filtered by the Cloud Firewall.

For Linodes using Linode interfaces (BETA), firewall rules are applied directly to the VPC interface, controlling access and filtering traffic at that level.

# [NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/vpc#nodebalancers)

You can configure backend Linodes in a VPC to serve NodeBalancer traffic. Communication between the NodeBalancer and backend nodes takes place over the VPC network.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/vpc#availability)

VPCs are available in the following core regions: Amsterdam (Netherlands), Chennai (India), Chicago IL (USA), Frankfurt 2 (Germany), Jakarta (Indonesia), London 2 (United Kingdom), Los Angeles CA (USA), Madrid (Spain), Melbourne (Australia), Miami FL (USA), Milan (Italy),  Mumbai (India), Paris (France), Osaka (Japan), São Paulo (Brazil), Seattle WA (USA), Singapore 2, Stockholm (Sweden), Tokyo 3 (Japan), and Washington DC (USA). 

VPCs are also available in all [distributed regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions).

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/vpc#pricing)

VPCs are provided at no additional cost. Additionally, communication across your private VPC network does not count against your [monthly network transfer usage](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs).

# [Difference between private network options (VPCs, VLANs, and private IPs)](https://techdocs.akamai.com/cloud-computing/docs/vpc#difference-between-private-network-options-vpcs-vlans-and-private-ips)

Both [VLANs](https://techdocs.akamai.com/cloud-computing/docs/vlan) and [Private IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#types-of-ip-addresses) are private networking services offered on Akamai Cloud. VLANs operate on layer 2 of the OSI model whereas VPCs and Private IPs operate on layer 3. While this allows VLANs to use any layer 3 protocol, it also means that there are limitations to routing and other layer 3 features. Since VPC is on layer 3 and uses the IP (Internet Protocol), IP addressing and IP routing features are built-in.

- **Latency:** All 3 services offer extremely low latency.

- **Cost:** There is no charge for VPCs, VLANs, and private IP addresses. The only costs are related to the associated Linode service and any outbound traffic over the public IP addresses.

- **Network Isolation:** Both VPC and VLANs offer true network isolation from other tenants within the same data center. Private IP addresses are accessible by default from any other Linode in the same region, provided that Linode also has a private IP address. This is because they all use the same `192.168.128.0/17` range.

- **Multiple Subnets:** Each VPC can have multiple subnets. Each VLAN can only be configured with IP addresses from one specified range.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/vpc#technical-specifications)

- A single VPC can support a maximum of 500 Linodes within it.

- Users can create up to 10 VPCs per data center (by default).

- Each VPC can have up to 10 subnets.

- Linodes can join a VPC by specifying the VPC as a network interface. Other services, such as NodeBalancers, LKE clusters, and Managed Databases cannot join a VPC at this time.

- VPCs can only be deployed to a single data center. As such, Linodes within different data centers cannot belong to the same VPC.

- A VPC interface can be private or have public internet access through a 1:1 NAT.

# [Additional limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/vpc#additional-limits-and-considerations)

- VPCs peering is not supported (within the same data center or different data centers).

- While VPC traffic is isolated from other cloud tenants, it is not encrypted.

- IPv6 addresses are not available on a VPC interface.

- VPC IP addresses cannot use [IP sharing](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuring-ip-sharing) or [IP transfer](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#transferring-ip-addresses) features.

- To facilitate routing between different subnets on the same VPC, configure the VPC network interface as the primary interface.

- Network traffic across a private VPC network does not count against your [monthly network transfer usage](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs). The network transfer allowance for Linodes configured on VPCs still counts towards the _global network transfer pool_ on your account.