# [Attach a VLAN to a Linode](https://techdocs.akamai.com/cloud-computing/docs/attach-a-vlan-to-a-compute-instance#attach-a-vlan-to-a-linode)

Within Cloud Manager, VLANs are created and managed only by attaching them to Linodes. They are not managed independently. You can attach a VLAN when creating a new Linode or when editing an existing Linode.

- [Attaching a VLAN When Creating a Linode](https://techdocs.akamai.com/cloud-computing/docs/attach-a-vlan-to-a-compute-instance#attaching-a-vlan-when-creating-a-compute-instance)
- [Attaching a VLAN to an Existing Linode](https://techdocs.akamai.com/cloud-computing/docs/attach-a-vlan-to-a-compute-instance#attaching-a-vlan-to-an-existing-compute-instance)

This guide covers implementing both of these methods using Cloud Manager. While VLANs can also be created and administered through the API and CLI, that's beyond the scope of this guide.

# [Attaching a VLAN when creating a Linode](https://techdocs.akamai.com/cloud-computing/docs/attach-a-vlan-to-a-compute-instance#attaching-a-vlan-when-creating-a-linode)

1. On the top left of [Cloud Manager](https://cloud.linode.com/dashboard), click **Create** and select **Linode**.

   

2. Fill out all desired configuration options in the form that appears, until reaching the **Attach a VLAN** section. See the [Creating a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance) guide for more information.

   > > Note: 
   > 
   > VLANs are not available in all regions. If the Attach a VLAN section isn't visible, see the Availability section on the [VLANs Overview](https://techdocs.akamai.com/cloud-computing/docs/vlan) page.

3. Within the **Attach a VLAN** section, enter the _Label_ of the VLAN or select from a list of the VLANs that currently exist on the account. If the VLAN does not yet exist, it is automatically created when creating the Linode.

   

4. Optionally enter the IPv4 address you wish to assign to the VLAN's network interface on this machine. The IP address should be unique to avoid conflicts in the case other machines share the same address. If this field left blank, the Linode will not be able to communicate with other Linodes on that VLAN until one of the following is true:

   - An IPAM address is added to the `eth1` interface within the Linode's [Configuration Profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance)
   - An IP address is manually assigned to the network interface within the Linode's internal configuration files.

   See the [Assigning an IPAM Address](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vlans#assigning-an-ipam-address) section on the Get Started guide for more information about IPAM and examples of valid IPAM addresses.

5. Complete the create form with any additional add-ons and settings you'd like to use. Then click the **Create Linode** button.

By default, the public IP address (and, if added, the private IP address) of the Linode is configured on the _eth0_ network interface. The VLAN, if one was attached, is configured on the _eth1_ network interface. These network interfaces can be removed or modified by editing the [Configuration Profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#edit-a-configuration-profile).

# [Attaching a VLAN to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/attach-a-vlan-to-a-compute-instance#attaching-a-vlan-to-an-existing-linode)

1. Within [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar and select a Linode.

2. Navigate to the **Configurations** tab for that Linode.

3. Click the **Edit** button next to the configuration profile you'd like to modify.

   

4. An **Edit Configuration** screen will appear. Scroll down to the **Network Interfaces** section.

5. Click the dropdown menu under the desired network interface and select **VLAN**. Typically `eth1` or `eth2` would be used when adding the first or second VLAN to a Linode, respectively, since the Linode's `eth0` network interface is typically configured to access the public internet.

   

   A secondary menu will appear next to the selected interface for entering the VLAN's label and the IP address to use.

6. Enter the _Label_ of the VLAN or select an existing VLAN from the drop down menu. If a custom label is entered and the VLAN does not yet exist, it is automatically created when saving the configuration profile.

7. Optionally enter an IP (IPAM) Address. If this field is left blank, the Linode will not be able to communicate with other Linodes on that VLAN until an IP address is manually assigned to the network interface within the Linode's internal configuration files.

   See the [Assigning an IPAM Address](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vlans#assigning-an-ipam-address) section of the Get Started guide for more information about IPAM and examples of valid IPAM addresses.

8. Click on the **Save Changes** button towards the bottom of this form to save the changes.

9. Once the configuration profile has been updated, select the **Boot** or **Reboot** button next to the edited configuration profile on the following page. This will reboot using the edited configuration profile and apply the new VLAN configuration to the Linode.

   

# [Testing connectivity](https://techdocs.akamai.com/cloud-computing/docs/attach-a-vlan-to-a-compute-instance#testing-connectivity)

Once a VLAN has been attached to more than one Linode, verify that you can communicate between those Linodes over the VLAN's private network.

1. If the Linode has a public network configured, connect to it via SSH. See [Setting Up and Securing a Linode > Connect to the Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode).

   ```
   ssh username@192.0.2.1
   ```

   If the Linode does not have a public network configured, connect to it via Lish by following the steps in the [Using the Lish Console](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) guide.

2. Ping another Linode within the VLAN's private network using the IPAM address assigned to it.

   ```
   ping 10.0.0.1
   ```

   The output should display ICMP packets successfully transmitted and received from this Linode to the secondary Linode in the private network.

   ```text Output
   PING 10.0.0.1 (10.0.0.1) 56(84) bytes of data.
   64 bytes from 10.0.0.1: icmp_seq=1 ttl=64 time=0.733 ms
   64 bytes from 10.0.0.1: icmp_seq=2 ttl=64 time=0.294 ms
   ^C
   --- 10.0.0.1 ping statistics ---
   2 packets transmitted, 2 received, 0% packet loss, time 18ms
   rtt min/avg/max/mdev = 0.294/0.513/0.733/0.220 ms
   ```