# [Getting started with VLANs](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vlans#getting-started-with-vlans)

VLANs (Virtual Local Area Networks) are a completely free solution available to Linodes and are used for enabling private networking in the cloud. Here are a few key features of VLANs:

- **Privacy and Security.** Linodes on the same account and in the same region can be added to the same VLAN, allowing for private and secure communications between those Linodes. The public internet can also be disabled on a Linode to provide even more security.

  > > Note: 
  > 
  > VLANs are separate from [Private IP Addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#types-of-ip-addresses). Private IPs are accessible to all Linodes in that same data center and can only be further restricted by firewall rules or additional internal configuration.

- **Performance.** A VLAN is configured as a Layer 2 networking device and provides low latency for latency-sensitive applications.

- **No additional charges.** VLANs are available at no cost and network transfer over a VLAN does not count towards monthly transfer quotas.

# [Configuring VLANs](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vlans#configuring-vlans)

VLANs are relatively simple to manage and do not require much configuration beyond attaching (or detaching) a VLAN to a Linode. VLANs can be configured when creating new Linodes or by modifying the network interfaces on the [Configuration Profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance) of an existing Linode.

- [Attach a VLAN to a Linode](https://techdocs.akamai.com/cloud-computing/docs/attach-a-vlan-to-a-compute-instance)

- [Remove a Linode from a VLAN](https://techdocs.akamai.com/cloud-computing/docs/detach-a-vlan-from-a-compute-instance)

## [Configuring the network interface](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vlans#configuring-the-network-interface)

VLANs are managed within the Configuration Profile of a Linode. Each Linode has 3 configurable network interfaces, which are referred to as _eth0_, _eth1_, and _eth2_. The purpose of a network interface is to provide access to either the public internet or a VLAN:

- **Public Internet:** Configuring a network interface for the **Public Internet** enables the public (and private) IP address(es) for that Linode. If no network interface is configured as **Public Internet**, the Linode will not be able to access the internet or other Linodes within the data center's main private network.

- **VLAN:** Configuring a network interface for a VLAN enables the Linode to communicate over a specified VLAN.

- **None:** Selecting **None** will deactivate that network interface.

 > Error: 
  The Public Internet must always be set to use the network interface `eth0`.

## [Selecting a VLAN](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vlans#selecting-a-vlan)

When configuring a network interface, a VLAN can be selected by entering its **Label**. VLANs that already exist on an account can be quickly selected through a drop down list. If the label doesn't correspond with an existing VLAN, a new VLAN is created.

## [Assigning an IPAM address](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vlans#assigning-an-ipam-address)

IPAM (IP Address Management) is the system that allows users to assign and manage IP addresses for each VLAN configured on a Linode. When attaching a VLAN, an **IPAM Address** can be specified in address/netmask format. This should be a unique IPv4 address that doesn't already exist within the VLAN or on the public internet. It is common to use a /24 network within the 10.0.0.0/8 range (10.0.0.0 – 10.255.255.255). For example, if a user wishes to use the subnet 10.0.0.0/24 on a VLAN, they can assign any unique address in the range 10.0.0.0 - 10.0.0.255. Here are valid IPAM addresses for two Linodes connected to that VLAN:

- Linode 1: `10.0.0.1/24`
- Linode 2: `10.0.0.2/24`

Just like public and private IP addresses, IP addresses for a VLAN are automatically configured on a Linode through [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking). If Network Helper is disabled or if no IPAM address is provided, the Linode will not automatically be able to communicate over the VLAN. In some cases, advanced users may disable Network Helper or refrain from providing an IPAM address. When doing so, the Linode's internal network configuration files must be manually adjusted with the desired settings. See [Manually configuring a VLAN on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manually-configuring-a-vlan-on-a-compute-instance) for instructions.

 > Note: 
  The Linode must be rebooted for any changes within its network interfaces to take effect. This reboot allows Network Helper to run so it can automatically adjust the necessary network configuration files.