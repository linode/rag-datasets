# [Detach a VLAN from a Linode](https://techdocs.akamai.com/cloud-computing/docs/detach-a-vlan-from-a-compute-instance#detach-a-vlan-from-a-linode)

If you no longer wish to include a particular Linode within a VLAN's private network, the VLAN can be detached by editing that Linode's [Configuration Profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#edit-a-configuration-profile).

1. Within [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar and select a Linode.

2. Navigate to the **Configurations** tab for that Linode.

3. Click the **Edit** button next to the configuration profile you'd like to modify.

   

4. An **Edit Configuration** screen will appear. Scroll down to the **Network Interfaces** section.

5. Click the dropdown menu under the network interface for that VLAN and select **None**. This detaches the VLAN.

6. Click on the **Save Changes** button to confirm the changes to the configuration profile.

7. Reboot the Linode to save your changes and completely detach the VLAN.

   > > Note: 
   > 
   > If a VLAN is not attached to a Akamai Cloud service, it will automatically be deleted.