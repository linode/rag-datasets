# [Delete a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/delete-a-cloud-firewall#delete-a-cloud-firewall)

1. Log into your [Cloud Manager](https://cloud.linode.com/) and select **Firewalls** from the navigation menu. This takes you to the **Firewalls** listing page.

2. Click on the more options menu (**...**),  button next to the corresponding firewall you would like to delete, and select **Delete**. You are prompted to confirm deletion of the firewall. Click **Delete** to proceed.

The firewall is deleted and any Linode, Linode interface (BETA) or NodeBalancer that the firewall was applied to no longer has their network traffic filtered by the firewall.