# [Apply firewall rules to a Linode, Linode Interface (BETA), or NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/apply-firewall-rules-to-a-service#apply-firewall-rules-to-a-linode-linode-interface-beta-or-nodebalancer)

Each Cloud Firewall can be applied to multiple Linodes, Linode interfaces (BETA) and NodeBalancers.

- For Linodes using Configuration Profile network interfaces, firewalls are assigned at the Linode level, and the same firewall rules apply to all non-VLAN interfaces in the profile.
- For Linodes using Linode network interfaces, individual firewalls can be assigned at the interface level to all non-VLAN interfaces.

Use the steps below to view and modify the services utilizing a Cloud Firewall.

1. Log into your [Cloud Manager](https://cloud.linode.com/) and select **Firewalls** from the navigation menu.

2. From the **Firewalls** listing page, click on the Cloud Firewall that you would like to use. This takes you to the **Rules** page for that firewall.

3. Click either the **Linodes** or **NodeBalancers** tab to see a list of the respective services currently using the firewall.

# [Add Linodes, Linode interfaces (BETA) and NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/apply-firewall-rules-to-a-service#add-linodes-linode-interfaces-beta-and-nodebalancers)

To add a Linode or Linode interface(BETA) to this firewall, select the **Linodes** tab. To add a NodeBalancer to this firewall, select the **NodeBalancers** tab. 

Click the **Add Linodes/NodeBalancers to Firewall** button. In the form that appears, select the Linode or NodeBalancer from the dropdown menu. If the Linode has Linode interfaces without an assigned firewall, an additional dropdown appears, allowing you to choose an interface.

Click **Add**. Once added, all rules configured on the firewall are applied to the selected service. Note that only inbound rules are applied to NodeBalancers.

 > Note: 
  You can apply the Cloud Firewall to more than one Linode service at a time. Repeat this process to add additional Linodes, Linode interfaces (BETA) or NodeBalancers.

 > Error: 
  If [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) has been disabled on your Linode and the internal networking configuration uses DHCP for IPv4 address assignment, some additional firewall rules are necessary. You must edit the Cloud Firewall to allow DHCP traffic through port 67 and 68. If needed, a full list of IP addresses for our DHCP servers can be found in our [DHCP IP Address Reference Guide](https://techdocs.akamai.com/cloud-computing/docs/dhcp-ip-address-reference).

# [Remove Linodes, Linode interfaces (BETA) and NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/apply-firewall-rules-to-a-service#remove-linodes-linode-interfaces-beta-and-nodebalancers)

To remove a Linode, Linode Interface or NodeBalancer from a firewall, click the **Remove** link. Once removed, the Cloud Firewall rules will no longer apply to that resource, which may leave it more vulnerable to malicious traffic or attacks.