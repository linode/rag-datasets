# [Update Cloud Firewall status](https://techdocs.akamai.com/cloud-computing/docs/update-cloud-firewall-status#update-cloud-firewall-status)

When you [add a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall), the firewall is enabled by default. Enabled means that the firewall is active. If it is applied to an Akamai Cloud resource, it filters network traffic according to the firewall's rules. Disabling a firewall deactivates the firewall and it no longer filters any traffic for the resources it has been applied to.

1. Log into your [Cloud Manager](https://cloud.linode.com/) and select **Firewalls** from the navigation menu. This takes you to the **Firewalls** listing page.

2. Click on the **Enable/Disable** button corresponding to the firewall whose status you would like to update:

   

   The **Status** column on the **Firewalls** listing page updates to display the Firewall's current status.

   