# [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall#create-a-cloud-firewall)

1. Log in to [Cloud Manager](https://cloud.linode.com/) and select **Firewalls** from the navigation menu.

2. From the **Firewalls** listing page, click on the **Create Firewall** link.

3. The **Create Firewall** drawer appears with the configuration options needed to add a Firewall. 

4. Select the option to create a **Custom Firewall **or create a firewall **From a Template**.  Templates are available for VPC and public Linode interfaces (BETA) and come with some pre-configured rules.

5. Configure your Firewall with the required fields:

   Error parsing table data: name 'null' is not defined

     

6. Click on the **Create Firewall** button to finish creating your Cloud Firewall. Firewalls can be further customized, see [Manage Cloud Firewall rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules).

 > Note: NodeBalancer Firewalls
  If you add a Cloud Firewall to a NodeBalancer, the inbound rules only apply to NodeBalancer’s public IP address and not the IPs of the back-end nodes (Linodes) assigned to the NodeBalancer. This means that the IPs of the back-end nodes may still be exposed to the public internet. As a best practice, you can protect the IPs of the individual Linodes by:
  - Adding the individual instances to the same Cloud Firewall as the NodeBalancer
 - Adding the individual instances to a new Cloud Firewall
 - Manually configuring internal firewall rules on the instances
  See [Comparing Cloud Firewalls to Linux firewall software](https://techdocs.akamai.com/cloud-computing/docs/comparing-cloud-firewalls-to-linux-firewall-software) to help determine which solution is best for your use case.