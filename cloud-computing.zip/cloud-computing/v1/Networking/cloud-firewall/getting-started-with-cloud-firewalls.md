# [Getting started with Cloud Firewalls](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-cloud-firewalls#getting-started-with-cloud-firewalls)

Cloud Firewalls is a free service that can be used to create, configure, and add stateful network-based firewalls to resources on Akamai Cloud. A Cloud Firewall is independent of the service it is attached to and can be applied to multiple services. Cloud Firewalls are compatible with Linodes using Configuration Profile Interfaces, Linode Interfaces (BETA), and NodeBalancers.

# [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-cloud-firewalls#create-a-cloud-firewall)

There are two main options to consider when deciding how to protect your Linodes, Linode interfaces, and NodeBalancers: installing firewall software on your system or using Linode Cloud Firewalls service. While both are robust solutions, a major benefit to using Cloud Firewalls is the ease of configuration. Cloud Firewalls can be created and managed through Cloud Manager, Linode CLI, or Linode API.

- [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall)

- [Comparing Cloud Firewalls to Linux firewall software](https://techdocs.akamai.com/cloud-computing/docs/comparing-cloud-firewalls-to-linux-firewall-software)

 > Note: 
  NodeBalancers do not support the installation of firewall software. If you wish to configure inbound firewall rules for your NodeBalancer, we recommend using the Cloud Firewalls service.

# [Manage firewall rules](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-cloud-firewalls#manage-firewall-rules)

Cloud Firewalls analyzes traffic against a set of user-defined rules. The firewall can be configured to implicitly \_accept_ or \_drop_ all _inbound_ or _outbound_ traffic. Individual rules can be added to further accept or drop specific traffic, such as over certain ports or to/from a certain IP address.

The default behavior for inbound traffic is set to Drop, which blocks all unsolicited inbound traffic unless explicitly allowed by other rules.

The default behavior for outbound traffic is set to Accept, which allows all outbound traffic unless explicitly denied by other rules.

Firewall templates (BETA) are available for both VPC and public Linode interfaces (BETA). Each template includes pre-configured protection rules to help you get started.

- [Manage Cloud Firewall rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules)

 > Note: 
  Outbound firewall rules are not applied to NodeBalancers.

# [Apply to Linodes](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-cloud-firewalls#apply-to-linodes)

To start using Cloud Firewalls to protect your services, you can apply it to Linodes, Linode interfaces (BETA) and NodeBalancers. Each Cloud Firewall can be applied to multiple services, but a service can only belong to a single Cloud Firewall.

- [Apply Cloud Firewalls to a service](https://techdocs.akamai.com/cloud-computing/docs/apply-firewall-rules-to-a-service)

# [Troubleshooting](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-cloud-firewalls#troubleshooting)

- [Troubleshooting firewalls](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances): Information on troubleshooting any firewall service.