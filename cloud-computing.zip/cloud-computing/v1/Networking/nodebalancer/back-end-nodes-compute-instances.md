# [Backend nodes](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances#backend-nodes)

Load balancers distribute traffic across a pool of servers. For NodeBalancers, these servers can be VPC or non‑VPC Linodes configured as backend nodes. Each backend Linodes must be in the same data center as the NodeBalancer and have a private IPv4 address or a VPC IPv4 address. See [Managing IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#adding-an-ip-address) for instructions on adding a private IP address to an existing non-VPC Linode.

 > Note: 
  While only a single backend node is required, _at least_ two backends need to be configured to make use of load balancing functionality.

# [Add, edit, and remove backend nodes](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances#add-edit-and-remove-backend-nodes)

Backend nodes can be defined through a NodeBalancer's [Configurations](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers), which contain all the settings and parameters for a particular _inbound_ port.

A single configuration on a premium NodeBalancer can support up to 2,000 backend nodes, while a non-premium NodeBalancer configuration can support 1,000. There may be exceptions to this limit for pre-existing NodeBalancer configurations.

1. Log in to [Cloud Manager](http://cloud.linode.com), click **NodeBalancers** in the left menu, and select the NodeBalancer you wish to edit. See [Manage NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers).

2. Navigate to the **Configurations** tab. This displays a list of all ports that have been configured.

3. Open the port configuration you wish to edit or create a new one by clicking the **Add Another Configuration** button.

4. Scroll down to the _Backend Nodes_ section to see a list of backends that have already been added.

   - Adjust any of the existing fields to edit the backend.
   - Click the **Add a Node** button to add a new backend.
   - Click the **Remove** link to remove the backend.

5. Click the **Save** button to save the configuration.

 > Note: 
  Removing a backend from the NodeBalancer configuration does not delete the associated Linode. It only removes that instance from operating as a backend for this particular NodeBalancer.

# [Backend configuration options](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances#backend-configuration-options)

Each backend node contains the following configuration parameters.

- **Label**: Sets a label to identify the backend. While any label can be used, it's common to use the label of the associated Linode.
- **IP Address**: Select the private IPv4 address or the VPC – IPv4 address of the Linode you wish to use as the backend. The VPC – IPv4 address option is available for NodeBalancers configured with a VPC. This field has a dropdown list of all Linodes within the same region as the NodeBalancer that have a private IPv4 or VPC – IPv4 address assigned.
- **Port**: Identifies the port that the NodeBalancer should use when sending traffic to the backend. This should be the port that the application is listening on within this backend Linode.
- **Weight**: Sets the priority of the backend. Backends with a higher weight are allocated more connections than backends with a lower weight.
- **Mode**: Determines if the backend accepts or rejects traffic and in what circumstances. See [Mode](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances#mode).

# [Mode](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances#mode)

By default, all backends are allocated traffic according to the configuration settings of the NodeBalancer, provided the backends have a status of _up_. To change this behavior, use the **Mode** setting to modify how a backend accepts or rejects traffic. UDP configurations do not use **Mode**. 

- **Accept**: Accept incoming connections
- **Reject**: Reject new incoming connections and discontinue health checks on this backend. Existing connections remain active, but session stickiness is not respected. Useful for taking the backend out of rotation to perform maintenance or decommission it.
- **Drain**: Only accept connections from clients whose session stickiness points to this backend. Use _in advance_ of taking a backend out of rotation for maintenance or decommissioning to gradually drain connections.
- **Backup**: Only accept connections if all other backends are down. Useful if you use front-end caching servers, such as Varnish, and want to direct traffic to the origin servers if the caching servers are down.

 > Note: 
  Changes made to the Mode field are applied within 60 seconds.

# [Understand the status of a backend node](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances#understand-the-status-of-a-backend-node)

Each backend node has a status of _up_ or _down_.

- **Up**: The backend is healthy and should be kept in rotation, provided that the [Mode](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances#mode) is allowing traffic.
- **Down**: The backend is _unhealthy_ and taken out of rotation. This means that a health check has failed or the **Mode** has been set to _Reject_.

 > Note: Backend node status: DOWN
  If the backend node status is DOWN, you may need to take one or more of the following actions:
  1. **Install web server software**. To allow the NodeBalancer to connect to the backend node on the designated port, you'll need to install a web server. SSH into the Linode and install the web server software. For example, installing NGINX will automatically set it up to listen on port 80:
  ```
 apt update && apt upgrade && apt install nginx
 ```
  2. **Enable Network Helper**. If you've configured a static IP address, enable [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking). 
 3. **Update configuration files**. Alternatively, if Network Helper is turned off, and you are using a static IP address for the Linode, ensure that the configuration files are updated with the correct IP address, refer to the section covering how to [update the configuration files](https://www.linode.com/docs/guides/linux-system-administration-basics/#configure-the-etchosts-file).

# [Configure Linodes](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances#configure-linodes)

When adding a Linode as a _Backend Node_ to a NodeBalancer, you must also ensure that it has been properly configured for your application. As part of this, review the following:

- Install all required software on the Linode.

- Verify that any required data has been properly replicated on each Linode. There are many different methods of ensuring data is properly replicated between multiple servers, including [rsync](https://linux.die.net/man/1/rsync), [Gluster](https://www.gluster.org/), [Galera](https://galeracluster.com/), or CI/CD tooling.

- Verify that each instance accepts traffic over the port specified in the backend's configuration and is not blocking addresses from the NodeBalancer's private IP address range: `192.168.255.0/24`.