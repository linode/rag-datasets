# [Getting started with NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-nodebalancers#getting-started-with-nodebalancers)

Nearly every production application can benefit from a load balancing solution like Akamai's NodeBalancers. This guide covers how to get started with NodeBalancers, including how to architect your application, configure the NodeBalancer, and update the DNS.

# [Prepare the application](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-nodebalancers#prepare-the-application)

To start using a NodeBalancer and benefiting from load balancing, your application should be stored on at least two Linodes. 

You can use either VPC or non-VPC Linodes as backend nodes. Each NodeBalancer configuration can have an associated VPC, which must be set when the NodeBalancer is created. For VPC backends, the NodeBalancer routes traffic to backend nodes through the VPC’s subnets. The subnet must be located in the same data center as the NodeBalancer.

 > Note: 
  Once the NodeBalancer is created, its VPC cannot be changed.

Each instance of your application should be able to fully serve the needs of your users, including being able to respond to web requests, access all necessary files, and query any databases. When determining your application's infrastructure, consider the following components:

- **Application deployment:** _How will you deploy your application's code and software infrastructure to each Linode?_ Consider using automated git deployments or more advanced CI/CD tooling.

- **File storage and synchronization:** _Should the application's files be stored alongside the application's code or should you consider implementing a distributed storage solution on separate instances?_ For simple applications, consider file synchronization/backup tools like [rsync](https://linux.die.net/man/1/rsync) or [csync2](https://linux.die.net/man/1/csync2). For a more robust solution, consider a distributed file system like [GlusterFS](https://www.gluster.org/).

- **Database replication:** _How will you maintain consistency between multiple databases?_ Consider the suggested architecture and available tooling for the database software you intend to use. [Managed Databases](https://techdocs.akamai.com/cloud-computing/docs/aiven-database-clusters), when deployed with high availability enabled, are a great fully-managed solution. Alternatively, [Galera](https://galeracluster.com/) is a self-hosted option that can be used with MySQL.

In some simple applications, the servers that store your application's code can also store its files and databases. For more complex applications, you may want to consider designating separate application servers, file servers, and database servers. The application servers (where the web server software and application code resides) operate as the backends to the NodeBalancer. The file servers and database servers can be built on cloud-based solutions (like Managed Databases) or self-hosted software on Linodes.

For advice on load balancing and high availability, review the following resources:

- [Introduction to load balancing](https://techdocs.akamai.com/cloud-computing/docs/introduction-to-load-balancing)
- [Introduction to High Availability](https://linode.com/docs/guides/introduction-to-high-availability/)
- [Host a Website with High Availability](https://linode.com/docs/guides/host-a-website-with-high-availability/)

# [Create the NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-nodebalancers#create-the-nodebalancer)

If you are using a Linode Cloud Firewall with this NodeBalancer, have the name of the firewall available. To see a listing of available firewalls, log in to [Cloud Manager](https://cloud.linode.com) and select **Firewalls** from the navigation menu. If the firewall doesn't exist yet, [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall) and [add firewall rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules).

If you are using backend Linodes in a VPC with this NodeBalancer, have the name of the VPC and subnet information available. To see a listing of available VPCs, log in to [Cloud Manager](https://cloud.linode.com) and select **VPC** from the navigation menu. If the VPC doesn't exist yet, [Create a VPC](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc).

Once your application has been deployed on multiple Linodes, you are ready to create the NodeBalancer. Simple instructions have been provided below. For complete instructions, see the [Create a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer) guide.

1. Log in to [Cloud Manager](https://cloud.linode.com), select **NodeBalancers** from the left menu, and click the **Create NodeBalancer** button. This displays the _NodeBalancers Create_ form.

2. Enter a **Label** for the NodeBalancer, as well as any **Tags** that may help you organize this new NodeBalancer with other services on your account.

3. Select a **Region** for this NodeBalancer. The NodeBalancer needs to be located in the same data center as your application'sLinodes. 

4. If you are using a firewall, select a firewall from the **Assign Firewall** list. Only one firewall can be selected, however you can attach the same Cloud Firewall to multiple NodeBalancers, Linode Interfaces or Linodes.

   You can also create a new firewall by clicking the **Create Firewall** button. This displays the _Create Firewall_ drawer. 

   Select the option to create a **Custom Firewall **or create a firewall **From a Template**.  Templates are available for VPC and public Linode interfaces and come with some pre-configured rules.

   Configure your Firewall with the required fields:

Error parsing table data: name 'null' is not defined

Click on the **Create Firewall** button to finish creating the Cloud Firewall and to return to the _NodeBalancers Create_ form.

 > Note: 
  By default, a new Cloud Firewall accepts all inbound and outbound connections. Only inbound firewall rules apply to NodeBalancers, see [Cloud Firewall inbound rules for NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#cloud-firewall-inbound-rules-for-nodebalancer). Custom rules can be added as needed in the Firewall application. See [Add rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules).

5. NodeBalancers can route to VPC or non‑VPC backend nodes. If none of the backends are (or will be) in a VPC, skip this step.
   - **VPC**. Select the VPC that contains the backend nodes (Linodes) that this NodeBalancer will route requests to. 
   - **Subnet.** Choose the subnet that the NodeBalancer will use to source IP addresses for routing requests to Linodes in the VPC.
   - **Auto-assign IPs for this NodeBalancer**.  When enabled, the system automatically allocates a `/30` IPv4 range from the selected subnet for this NodeBalancer’s backend nodes. This helps you reserve address space for other NodeBalancers in the same VPC. When disabled, you can manually enter the IPv4 range the NodeBalancer will use to communicate with backend nodes.
6. Create a NodeBalancer configuration. Each configuration defines the inbound port, the protocol, the load balancing algorithm, health checks, and the backend nodes that serve traffic for the specified port. You can add additional configurations using the **Add another Configuration** button.

 > Warning: UDP configurations
  Currently, you can create NodeBalancer configurations using the `TCP`, `HTTP`, or `HTTPS` protocols in Cloud Manager. However, configurations using `UDP` can only be created via the [API](https://techdocs.akamai.com/linode-api/reference/post-node-balancer).
  You can configure UDP on the same NodeBalancer that also uses TCP, HTTP, or HTTPS, but only when managing it through the API. If UDP is configured and you make changes to the TCP, HTTP or HTTPS settings in Cloud Manager, the existing UDP configuration will be overwritten. This is because Cloud Manager doesn't currently support UDP.

 > Note: 
  The following recommended parameters can be used for deploying a website. For other applications or to learn more about these settings, see the [Configuration options](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers) guide.

- **Port:** For load balancing a website, configure two ports: port 80 and port 443. Each of these ports can be configured separately. See [Configuration options > Port](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#port).

- **Protocol:** Most applications can benefit from using the _TCP_ protocol. This option is more flexible, supports HTTP/2, and maintains encrypted connections to the backend Linodes. If you intend to manage and terminate the TLS certificate on the NodeBalancer, use _HTTP_ for port 80 and _HTTPS_ for port 443. See [Configuration options > Protocol](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#protocol).

- **Algorithm:** This controls how new connections are allocated across backend nodes. Selecting _Round Robin_ can be helpful when testing (in conjunction with no session stickiness). Otherwise, _Least Connections_ can help evenly distribute the load for production applications. See [Configuration options > Algorithm](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#algorithm).

- **Session Stickiness:** This controls how subsequent requests from the same client are routed when selecting a backend node. For testing, consider selecting _None_. Otherwise, _Table_ can be used for any protocol and _HTTP Cookie_ can be used for _HTTP_ and _HTTPS_. See [Configuration options > Session stickiness](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#session-stickiness).

- **Health Checks:** NodeBalancers have both _active_ and _passive_ health checks available. These health checks help take unresponsive or problematic backend Linodes out of the rotation so that no connections are routed to them. These settings can be left at the default for most applications. Review [Configuration options > Health Checks](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#health-checks) for additional information.

- **Backend nodes:** Each Linode for your application should be added as a _backend node_ to the NodeBalancer. Backend nodes can be VPC and non-VPC Linodes. Within the Backend Nodes area of the creation form, add each Linode you intend on using with this NodeBalancer, making sure to select the correct private IPv4 address for non-VPC backends or the IPv4 address for the VPC backend. These Linodes need to be located in the same data center as your NodeBalancer. Set a **Label** for each instance, select the corresponding **IP address** from the dropdown menu, and enter the **Port** that the application is using on that instance. See [Backend nodes (Linodes)](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances).

   For most web applications that have the _inbound_ ports 80 and 443 configured using the _TCP_ protocol, you can set the backend nodes to use the same ports. If you are using the _HTTPS_ protocol, TLS termination happens on the NodeBalancer and your Linodes should only need to listen on port 80 (unencrypted). If that's the case, backend nodes for both _inbound_ ports can be configured to use port 80.

6. Review the summary and click the **Create NodeBalancer** button to provision your new NodeBalancer.
7. [Check Backend Node Status](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#view-nodebalancers).
   > > Note: Backend node status: DOWN
   > 
   > If the backend node status is DOWN, you may need to take one or more of the following actions:
   > 
   > 1. **Install web server software**. To allow the NodeBalancer to connect to the backend node on the designated port, you'll need to install a web server. SSH into the Linode and install the web server software. For example, installing NGINX will automatically set it up to listen on port 80:
   > 
   > ```
   > apt update && apt upgrade && apt install nginx
   > ```
   > 
   > 2. **Enable Network Helper**. If you've configured a static IP address, enable [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking).
   > 3. **Update configuration files**. Alternatively, if Network Helper is turned off, and you are using a static IP address for the Linode, ensure that the configuration files are updated with the correct IP address, refer to the section covering how to [update the configuration files](https://www.linode.com/docs/guides/linux-system-administration-basics/#configure-the-etchosts-file).
   > 
   > After completing these steps, recheck the backend node status to ensure it is operational (UP).

# [Update the DNS](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-nodebalancers#update-the-dns)

After deploying your NodeBalancer and putting your application behind the NodeBalancer, the application can now be accessed using the NodeBalancer's public IPv4 and IPv6 addresses. Since most public-facing applications use domain names, you need to update any associated DNS records. The _A_ record should use the NodeBalancer's IPv4 address and the _AAAA_ record (if you're using one) should use the NodeBalancer's IPv6 address. See [Manage NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#review-and-edit-a-nodebalancer) to view your NodeBalancer's IP addresses. For help changing the DNS records, consult your DNS provider's documentation. If you are using Akamai's DNS Manager, see [Edit DNS Records](https://techdocs.akamai.com/cloud-computing/docs/manage-dns-records). Keep in mind that DNS changes can take up to 24 hours to fully propagate, though that typically happens much faster.