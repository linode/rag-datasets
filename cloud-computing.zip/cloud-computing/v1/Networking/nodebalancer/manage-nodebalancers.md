# [Manage NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#manage-nodebalancers)

# [View NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#view-nodebalancers)

Log in to [Cloud Manager](https://cloud.linode.com) and select NodeBalancers from the left menu. If any NodeBalancers exist on your account, they are listed on this page.

Each NodeBalancer in the matrix is displayed alongside the following details:

- **Backend Status:** The number of backend machines that are available and accepting connections (_up_) or have been removed from the rotation and are not accepting connections (_down_).
- **Transferred:** The amount of network transfer consumed by the inbound traffic to the NodeBalancer.
- **Ports:** A list of the ports that have been configured on the NodeBalancer.
- **IP Address:** The NodeBalancer's IPv4 address.
- **Region:** The data center where the NodeBalancer is located.
- **VPC:** The name of the VPC configured for this NodeBalancer or None. The NodeBalancer can serve traffic to the  backend Linodes within the VPC.

# [Create a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#create-a-nodebalancer)

To create a NodeBalancer, follow the instructions within the [Create a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer) guide.

# [Review and edit a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#review-and-edit-a-nodebalancer)

Navigate to the **NodeBalancer** page in Cloud Manager and select the NodeBalancer you wish to edit. See [View NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#view-nodebalancers).

This displays the details and settings for the selected NodeBalancer.

From here, the following pages are available:

- **Summary:** If this is a premium-tier NodeBalancer and it is linked to an LKE-Enterprise cluster, it will be indicated in the NodeBalancer Details. You can also view the assigned Cloud Firewall (if any), IP addresses, ports, backend statuses, and if a VPC has been assigned to this NodeBalancer. Graphs showing the number of connections and network traffic are also provided.
- **Configurations:** This lists each port configured for the NodeBalancer, with the ability to edit the settings for the existing port or add a new port. See [configuration options](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers) for more information on each of these settings.
- **Settings:** Displays additional settings for the NodeBalancer, including the label, firewall and connection throttle setting.

# [Delete a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#delete-a-nodebalancer)

1. Navigate to the **NodeBalancer** page in Cloud Manager and select the NodeBalancer you wish to edit.

2. Navigate to the **Settings** tab, scroll to the _Delete NodeBalancer_ section, and click **Delete**.

   

3. A confirmation dialog appears. To confirm deletion, type the name of the NodeBalancer in the field and click **Delete** to proceed with removing the service from your account.

 > Note: 
  When you delete a NodeBalancer that has a firewall, the NodeBalancer is also deleted in Cloud Firewalls. Firewalls are not deleted when you delete a NodeBalancer.

# [Unassign, change or add firewalls](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#unassign-change-or-add-firewalls)

After the NodeBalancer is created, you can add a firewall, select a different firewall or unassign the current firewall using the following information;

## [Unassign the firewall](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#unassign-the-firewall)

1. Navigate to the **NodeBalancer** page in Cloud Manager and select the NodeBalancer that has the firewall you wish to unassign.

2. Navigate to the **Settings** tab. In the _Firewall_ section, click **Unassign**.

   

3. A confirmation dialog appears. Click **Unassign Firewall** to proceed with unassigning the firewall from the NodeBalancer.

 > Note: 
  You can also remove/unassign firewalls from a NodeBalancer using Cloud Firewalls.

## [Add a firewall to an existing NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#add-a-firewall-to-an-existing-nodebalancer)

1. Navigate to the **NodeBalancer** page in Cloud Manager and select the NodeBalancer that you would like to assign a firewall to.

2. Navigate to the **Settings** tab. In the _Firewall_ section, click **Add Firewall**.

   

3. The **Add Firewall** drawer opens. Select a Firewall to assign to your NodeBalancer, click **Add Firewall. **

## [Create a new firewall for the NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#create-a-new-firewall-for-the-nodebalancer)

To create a new Cloud firewall for an existing NodeBalancer, follow the instructions in [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall) and [Add rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules).

## [Change the NodeBalancer's firewall](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#change-the-nodebalancers-firewall)

1. [Unassign the firewall](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#unassign-the-firewall).

2. [Add a firewall to an existing NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers#add-a-firewall-to-an-existing-nodebalancer) .