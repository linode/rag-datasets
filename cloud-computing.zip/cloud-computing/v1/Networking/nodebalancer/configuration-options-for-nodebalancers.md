# [Configuration options for NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#configuration-options-for-nodebalancers)

NodeBalancers, and load balancers in general, operate by taking inbound traffic over certain ports and distributing that traffic to pre-defined backend instances. For NodeBalancers, the settings that accommodate this behavior are all stored within _Configurations_. Each configuration specifies the inbound port, the protocol, the load balancing algorithm, health checks, and the backend nodes. This guide covers how to add or edit these configurations as well as the options that are available.

 > Warning: UDP configurations
  Currently, you can create NodeBalancer configurations using the `TCP`, `HTTP`, or `HTTPS` protocols in Cloud Manager. However, configurations using `UDP` can only be created via the [API](https://techdocs.akamai.com/linode-api/reference/post-node-balancer-config).
  You can configure UDP on the same NodeBalancer that also uses TCP, HTTP, or HTTPS, but only when managing it through the API. If UDP is configured and you make changes to the TCP, HTTP or HTTPS settings in Cloud Manager, the existing UDP configuration will be overwritten. This is because Cloud Manager doesn't currently support UDP.

# [Add or edit configurations](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#add-or-edit-configurations)

Each configuration is assigned a single inbound port. Follow the instructions below to add or edit a configuration. If your application requires multiple inbound ports, create one configuration for _each_ port you wish to use. This provides a great amount of flexibility, allowing each port to have its own distinct configuration settings and backend nodes.

1. Log in to [Cloud Manager](http://cloud.linode.com), click **NodeBalancers** in the left menu, and select the NodeBalancer you wish to edit. See [Manage NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/manage-nodebalancers).

2. Navigate to the **Configurations** tab. This displays a list of all ports that have been configured.

3. Open the port configuration you wish to edit or create a new one by clicking the **Add Another Configuration** button.

# [Configuration options](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#configuration-options)

## [Port](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#port)

This is the _inbound_ port that the NodeBalancer is listening on. This can be any port from 1 through 65534, though it should be set to whichever port the client software will connect to. For instance, web browsers use port 80 for HTTP traffic and port 443 for HTTPS traffic, though a client can change the port by specifying it as part of the URL.

## [Protocol](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#protocol)

The protocol can be set to either TCP, HTTP, or HTTPS using Cloud Manager and configurations using UDP can only be created with the  [API](https://techdocs.akamai.com/linode-api/reference/post-node-balancer-config). While a brief description of each is provided below, review [Available Protocols](https://techdocs.akamai.com/cloud-computing/docs/available-protocols) for more complete information.

- **TCP**: Supports most application-layer protocols, including HTTP and HTTPS. This should be selected when you want to enable layer 4 load balancing, use TLS/SSL pass-through, use HTTP/2.0 or higher, balance non-HTTP services, or make use of [Proxy Protocol](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#proxy-protocol). Since the NodeBalancer serves as a pass-through for these TCP packets, any encrypted traffic is preserved and must be decrypted on the backend nodes.

- **UDP:**Standard Layer 4 (transport) protocol commonly used in media, entertainment, and gaming applications because it is connectionless and enables faster data transmission compared to other protocols like TCP. UDP forwards data without inspecting higher-level protocols (e.g., QUIC) that may run on top of it.

- **HTTP\:** Unencrypted web traffic using HTTP/1.1. This terminates the HTTP request on the NodeBalancer, allowing the NodeBalancer to create a new HTTP request to the backend machines. This can be used when serving most standard web applications, especially if you intend on configuring the NodeBalancer to use HTTPS mode with TLS/SSL termination.

- **HTTPS\:** Encrypted web traffic using HTTP/1.1. Since this terminates the request on the NodeBalancer, it also terminates the TLS/SSL connection to decrypt the traffic. Use this if you wish to configure TLS/SSL certificates on the NodeBalancer and not on individual backend nodes.

  > > Warning: 
  > 
  > When the **HTTPS** protocol setting is used, all traffic is decrypted at the NodeBalancer. Communication between the NodeBalancer and the backend nodes is then sent unencrypted over the private data center network using the HTTP protocol.

    

## [Proxy protocol](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#proxy-protocol)

When selecting _TCP_ as the protocol, **Proxy Protocol** can be enabled to send client information to backend nodes. Backend nodes must also have Proxy Protocol enabled on supported applications to receive this information. There are two available versions of Proxy Protocol, **v1** and **v2**:

- **v1**: Proxy Protocol v1 adds a human readable string to all requests.
- **v2**: Proxy Protocol v2 adds a more efficient binary data header to all requests.

For more information, see the [Using Proxy Protocol with NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/using-proxy-protocol-with-nodebalancers) guide.

## [Algorithm](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#algorithm)

The _algorithm_ controls how _new connections_ are allocated across the backend nodes.

- **Round Robin**: Allocates connections in a weighted circular order across the back ends.

- **Least Connections**: Tracks each back end's connection count and allocates new connections to the one with the least connections.

- **Source IP**: Modulates the client's IP to allocate them to the same back end on subsequent requests. This works as long as the set of backend nodes doesn't change, however the **Session Stickiness** setting (below) does affect this behavior. Not applicable for UDP.

- **Ring Hash.** Requires the configuration protocol to be set to UDP. Each backend node is mapped into a circle by hashing its address. Each request is then routed clockwise around the ring to the nearest backend.

## [Session stickiness](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#session-stickiness)

This controls how subsequent requests from the same client are routed when selecting a backend node. It allows a NodeBalancer to maintain a client session to the same back end.

- **None**: No session information is saved and requests are routed in only accordance with the _algorithm_ (see [Algorithm](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#algorithm) above).

- **Session.** _Requires the configuration protocol to be set to UDP._ All packets with the same session identifiers are routed to the same backend server. Two packets are considered part of the same session if they share the same source and destination IP addresses or ports, and are received within a short time window.

- **Source IP.** _Requires the configuration protocol to be set to UDP_.  The NodeBalancer uses the client's source IP address to route all packets from the same client to the same backend server.

- **Table. **_Requires the configuration protocol to be set to TCP, HTTP, or HTTPS._ This preserves the initial back end selected for an IP address by the chosen algorithm. Subsequent requests by the same client are routed to that back end, when possible. This map is stored within the NodeBalancer and expires after 30 minutes from when it was added. If a backend node goes offline, entries in the table for that back end are removed. When a client sends a new request, it is then rerouted to another backend node (in accordance with the chosen algorithm) and a new entry is created in the table.

- **HTTP Cookie**: _Requires the configuration protocol be set to HTTP or HTTPS._ The NodeBalancer stores a cookie (named `NB_SRVID`) on the client that identifies the back end where the client is initially routed to. Subsequent requests by the same client are routed to that back end, when possible. If a backend node goes offline, the request is rerouted to another backend node (in accordance with the chosen algorithm) and the cookie is rewritten with the new backend identifier.

  > > Note: 
  > 
  > The client must have cookies enabled. If the client has disabled cookies or deletes cookies, session persistence is not preserved and each new request is routed in accordance with the chosen algorithm.

If session persistence is required or desired for the application, it is recommended to use both the _Source IP_ algorithm in combination with either _Table_ or _HTTP Cookie_ session stickiness.

## [TLS/SSL certificate and private key](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#tlsssl-certificate-and-private-key)

When the _HTTPS_ protocol is selected, the **Certificate** and **Private Key** fields appear and must be properly configured.

- **Certificate**: The TLS/SSL certificate (and certificate chain) that has been obtained for the application.

- **Private Key**: The passphraseless private key that is associated with the certificate file.

A certificate can be obtained for your domain by using [certbot](https://certbot.eff.org/) or by purchasing one through a trusted certificate authority. See [TLS/SSL Termination](https://techdocs.akamai.com/cloud-computing/docs/tls-ssl-termination-on-nodebalancers) for more details on obtaining a certificate and configuring both the NodeBalancer and backend nodes.

 > Note: 
  If you wish to use TLS/SSL pass-through and terminate the HTTPS connection on the backend nodes, select the **TCP** protocol instead of **HTTPS**.

# [Health checks](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#health-checks)

NodeBalancers perform both passive and active health checks against the backend nodes. Back ends that are not responsive are marked as _down_ and taken out of rotation.

## [Active health checks](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#active-health-checks)

_Active_ health checks proactively query the backend nodes by performing TCP connections or making HTTP requests. To enable an active health check, choose from one of the following types:

- **TCP Connection**: Requires a successful TCP handshake with a backend node.
- **HTTP Valid Status**: Performs an HTTP request on the provided path and requires a 2xx or 3xx response from the backend node.
- **HTTP Body Regex**: Performs an HTTP request on the provided path and requires the provided PCRE regular expression matches against the request's result body. UDP doesn't support regular expressions. Instead, it uses a simple text match (e.g., checking if a substring is present in the response). If there is a match, the backend node is considered healthy. For UDP-based HTTP health checks, if the response includes an HTTP status code in the 200–299 range, the back end is healthy. When the response code is 300-599 , the UDP healthy check retries the health check.

Additionally, configure the following settings to adjust the frequency and number of attempts:

- **Check Interval**: Seconds between active health check probes.
- **Check Timeout**: Seconds to wait before considering the probe a failure. 1-30.
- **Check Attempts**: Number of failed probes before taking a node out of rotation. 1-30.
- **Health Check Port.** For UDP configurations, you can specify a health check port for the backend node, which may differ from the UDP port used to serve traffic. UDP NodeBalancers use TCP and HTTP active health checks to verify that backend nodes are able to receive traffic.

## [Passive health checks](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#passive-health-checks)

The **passive checks** setting controls if passive health checks are enabled. You can enable passive checks on configurations using TCP, HTTP or HTTPS protocols. When enabled, the NodeBalancer monitors all requests sent to backend nodes. If the request times out, returns a 5xx response code (excluding 501 and 505), or otherwise fails to connect, the back end is marked as _down_ and taken out of rotation.

Passive checks are not available for UDP. 

# [Backend nodes (Linodes)](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#backend-nodes-linodes)

Load balancers work by distributing traffic to a pool of servers. For NodeBalancers, these servers are VPC or non-VPC Linodes configured as _backend nodes_. For information on configuring backend nodes, see the [Configure Backend Nodes (Linodes)](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances) guide.