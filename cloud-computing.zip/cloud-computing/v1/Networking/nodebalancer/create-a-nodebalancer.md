# [Create a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#create-a-nodebalancer)

This guide walks you through creating a NodeBalancer through Cloud Manager.

1. [Open the Create NodeBalancer Form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#open-the-create-nodebalancer-form-in-cloud-manager)
2. [Set the label and add tags](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#set-the-label)
3. [Select a region](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#select-a-region)
4. [Assign a Cloud Firewall (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#assign-a-cloud-firewall-optional)
5. [Add a VPC (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#add-a-vpc-optional)
6. [Add and configure ports](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#add-and-configure-ports)

 > Warning: UDP configurations
  Currently, you can create NodeBalancer configurations using the `TCP`, `HTTP`, or `HTTPS` protocols in Cloud Manager. However, configurations using `UDP` can only be created via the [API](https://techdocs.akamai.com/linode-api/reference/post-node-balancer).
  You can configure UDP on the same NodeBalancer that also uses TCP, HTTP, or HTTPS, but only when managing it through the API. If UDP is configured and you make changes to the TCP, HTTP or HTTPS settings in Cloud Manager, the existing UDP configuration will be overwritten. This is because Cloud Manager doesn't currently support UDP.

7. [Set up health checks for each port](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#set-up-health-checks-for-each-port)
8. [Add backend nodes to each port](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#add-back-end-nodes-to-each-port)
9. [Deploy the NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#deploy-the-nodebalancer)

# [Open the Create NodeBalancer form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#open-the-create-nodebalancer-form-in-cloud-manager)

Log in to [Cloud Manager](https://cloud.linode.com/) and select **NodeBalancers** from the left navigation menu. Click the **Create NodeBalancer** button. This opens the _[NodeBalancer Create](https://cloud.linode.com/nodebalancers/create)_ form.

# [Set the label and add tags](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#set-the-label-and-add-tags)

Within the **Label** field, enter the label you wish to use to identify it from other NodeBalancers on your account. A good label should provide some indication as to what the NodeBalancer will be used for. The label must be alphanumeric, between 3 and 32 characters, and unique from other NodeBalancer labels on your account.

To help you identify and manage your NodeBalancer more effectively, you can **Add Tags** to specify its purpose, environment (e.g. staging, production, testing), or any other relevant detail.

# [Select a region](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#select-a-region)

Select the **Region** where the NodeBalancer will reside. Regions correspond with individual data centers, each located in a different geographical area. Select the region where you've deployed the Linodes you intend on using with this NodeBalancer. If you haven't yet deployed Linodes or chosen a region, select the region closest to you and/or your customers. This helps reduce latency and can make a significant impact in connection speeds and quality.

- [Global Infrastructure](https://www.linode.com/global-infrastructure/)
- [Speed Tests for Data Centers](https://www.linode.com/speed-test/)
- [How to choose a data center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center)

# [Assign a Cloud Firewall (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#assign-a-cloud-firewall-optional)

A NodeBalancer can only be attached to one Cloud Firewall at a time. You can attach the same Cloud Firewall to multiple NodeBalancers, Linodes and Linode interfaces.

Select the Cloud Firewall from the **Assign Firewall** pull down to use with the NodeBalancer.

If the firewall doesn't exist yet, you can create the firewall using either the Firewall application, or the NodeBalancer application. Rules for the firewall, can only be added in the Firewalls application.

To create a firewall and add rules using the Firewall application, see [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall) and [Add rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules).

To create a firewall using the NodeBalancer  application, in the _NodeBalancer Create_ form, click the **Create Firewall**. This displays the _Create Firewall_ drawer.  

Select the option to create a **Custom Firewall **or create a firewall **From a Template**.  Templates are available for VPC and public Linode interfaces and come with some pre-configured rules.

Configure your Firewall with the required fields:

Error parsing table data: name 'null' is not defined

Click on the **Create Firewall** button to finish creating the Cloud Firewall and to returned to the _NodeBalancers Create_ form.

 > Note: 
  By default, a new Cloud Firewall accepts all inbound and outbound connections. Only inbound firewall rules apply to NodeBalancers. Custom rules can be added in the Firewall application as needed. See [Add rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules).

## [Cloud Firewall inbound rules for NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#cloud-firewall-inbound-rules-for-nodebalancer)

- Inbound rules limit incoming network connections to the NodeBalancer based on the port(s) and sources you configure.
- The NodeBalancer accepts traffic and routes traffic on an internal network to backend targets. For this reason, only inbound firewall rules apply to NodeBalancer.
- Inbound firewall rules such as IPv4 and IPv6 access control lists (ACLs) can be configured to _Accept_ or _Drop_ ingress traffic to the NodeBalancer.
- NodeBalancers can accept TCP connections on all ports. When you add an inbound rule for a NodeBalancer in Cloud Firewalls, select TCP or UDP as the transport layer protocol. ICMP, and IPENCAP are not currently supported on NodeBalancers.
- The firewall is in front of the NodeBalancer and the assigned backend nodes. When both the NodeBalancer and its backend nodes have firewalls, the NodeBalancers inbound firewall rules are applied to incoming requests first, before the requests reach the backend nodes.
- A backend node server (Linode) can have multiple IP addresses. The NodeBalancer firewall only controls inbound traffic to the backend nodes IPs that are assigned to the NodeBalancer. A Linode can be accessed from any interface (not just the NodeBalancer). To filter traffic from other interfaces, backend Linodes require their own firewalls.

# [Add a VPC (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#add-a-vpc-optional)

NodeBalancers can route to VPC or non‑VPC backend nodes. If none of the backends are (or will be) in a VPC, skip this step.

To load balance traffic to applications in a VPC, select a VPC and a subnet. This allows the NodeBalancer to communicate with backend nodes within the VPC. The subnet must be in the same data center as the NodeBalancer.

 > Note: 
  Once the NodeBalancer is created, its VPC cannot be changed.

- **VPC**. Select the VPC that contains the backend nodes (Linodes) that this NodeBalancer will route requests to. 
- **Subnet.** Choose the subnet that the NodeBalancer will use to source IP addresses for routing requests to Linodes in the VPC.
- **Auto-assign IPs for this NodeBalancer**.  When enabled, the system automatically allocates a `/30` IPv4 range from the selected subnet for this NodeBalancer’s backend nodes. This helps you reserve address space for other NodeBalancers in the same VPC. When disabled, you can manually enter the IPv4 range the NodeBalancer will use to communicate with backend nodes.

# [Add and configure ports](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#add-and-configure-ports)

To start load balancing traffic, you need to define which ports the NodeBalancer should listen to and how the incoming traffic should be routed to the backend nodes. By default, a single port configuration is visible in this area. Additional ports can be added by clicking the **Add Another Configuration** button. See [Configuration options](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers) for more details regarding each of these settings.

- **Port:** Enter the _inbound_ port the NodeBalancer should listen to. This can be any port from 1 through 65534 and should align with the port the client connects to. See [Configuration options > Port](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#port).
- **Protocol:** Select _TCP_, _HTTP_, or _HTTPS_. For many applications, using _TCP_ offers the most flexibility and allows for TLS pass through. Using _HTTP_ and _HTTPS_ offers some additional NodeBalancer options and allows for TLS termination. See [Configuration options > Protocol](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#protocol). Configurations using `UDP` can only be created via the [API](https://techdocs.akamai.com/linode-api/reference/post-node-balancer).
- **Proxy Protocol:** _Only visible when the TCP  protocol is selected._ Used for sending the client IP address to the backend nodes. See [Configuration options > Proxy protocol](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#proxy-protocol).
- **Algorithm:** Controls how new connections are allocated across backend nodes. See [Configuration options > Algorithm](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#algorithm).
- **Session Stickiness:** Controls how subsequent requests from the same client are routed when selecting a backend node. See [Configuration options > Session stickiness](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#session-stickiness).
- **SSL Certificate and Private Key (required when protocol is HTTPS):** 
  - **Certificate:** The TLS/SSL certificate (and certificate chain) that has been obtained for the application.
  - **Private Key:** The passphraseless private key that is associated with the certificate file.

 > Note: 
  For most web applications, it's common to configure two ports: port _80_ and port _443_.

# [Set up health checks for each port](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#set-up-health-checks-for-each-port)

Each port can optionally be configured with health checks. These health checks either proactively query the backend nodes (_active_) or monitor the existing traffic to backend nodes (_passive_). If a health check determines that the back ends aren't responsive or are encountering another issue, they can be marked as _down_ and taken out of rotation.

- **Active Health Checks:** Active health checks proactively query the backend nodes by performing TCP connections or making HTTP requests. See [Configuration Options > Active Health Checks](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#active-health-checks).

- **Passive Checks:** Passive health checks monitor requests sent to the backend nodes and look for any issues. See [Configuration Options > Passive Health Checks](https://techdocs.akamai.com/cloud-computing/docs/configuration-options-for-nodebalancers#passive-health-checks).

# [Add backend nodes to each port](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#add-backend-nodes-to-each-port)

Load balancers work by distributing traffic to a pool of servers. For NodeBalancers, these servers are VPC and non-VPC Linodes configured as _backend nodes_. Within the **Backend Nodes** area of the creation form, add each Linode you intend on using with this NodeBalancer, making sure to select the correct private IPv4 address for non-VPC backends or the IPv4 address for the VPC backend. For information on configuring backend nodes, see the [Backend nodes (Linodes)](https://techdocs.akamai.com/cloud-computing/docs/back-end-nodes-compute-instances) guide.

# [Deploy the NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#deploy-the-nodebalancer)

Once you've adjusted the settings to fit your needs, review the _NodeBalancer Summary_ section and click the **Create NodeBalancer** button. The NodeBalancer should be provisioned within a few minutes.