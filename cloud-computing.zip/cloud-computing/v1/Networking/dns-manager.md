# [DNS Manager](https://techdocs.akamai.com/cloud-computing/docs/dns-manager#dns-manager)

The _Domains_ section of [Cloud Manager](https://cloud.linode.com/domains) is a comprehensive DNS management interface, referred to as DNS Manager. Within the DNS Manager, you can add your registered domain names and manage DNS records for each of them.

# [High availability](https://techdocs.akamai.com/cloud-computing/docs/dns-manager#high-availability)

The Akamai Cloud DNS service is anycasted to over 250 locations (_PoPs_) around the world. This provides distributed denial-of-service (DDoS) attack mitigation, load balancing, and increased geographic distribution for our [name servers](https://linode.com/docs/guides/dns-overview/#name-servers). If one name server suffers an outage, the service will automatically failover to a redundant name server. These factors make our service reliable, fast, and a great choice for your DNS needs.

# [Flexible configuration](https://techdocs.akamai.com/cloud-computing/docs/dns-manager#flexible-configuration)

In addition to supporting a wide range of DNS record types, DNS Manager offers even more flexibility through AXFR transfers and zone types (_primary_ and _secondary_). These two features work together so you can create a DNS configuration that works for your own application. Using Akamai's DNS Manager as the _primary_ domain manager is the most common option and lets you manage DNS records directly on Akamai Cloud. Operating as a _secondary_ DNS provider, you can mange your DNS records within other services or tools (like cPanel) but still host them on Akamai Cloud, taking advantage of the reliability and high availability of our platform.

# [Pricing and availability](https://techdocs.akamai.com/cloud-computing/docs/dns-manager#pricing-and-availability)

The DNS Manager is available at no charge across [all regions](https://www.linode.com/global-infrastructure/).

 > Warning: DNS Manager Linode requirement
  To use DNS Manager to serve your domains, you must have at least one active Linode on your account. If your account does not have any Linodes (because they have all been removed), DNS records will not be served.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/dns-manager#technical-specifications)

- High-availability managed DNS provider
- Anycast DNS with over 250 PoPs (_point of presence_)
- Each domain supports up to 12,000 DNS records
- DDoS mitigation
- Supports outgoing and incoming DNS zone transfers
- Can be configured as a read-only secondary DNS
- IPv6 support
- Manage domains through an intuitive web-based control panel ([Cloud Manager](https://cloud.linode.com/)), the [Linode CLI](https://www.linode.com/products/cli/), or programmatically through the [Linode API](https://www.linode.com/products/linode-api/)

# [Limits and considerations](https://techdocs.akamai.com/cloud-computing/docs/dns-manager#limits-and-considerations)

- _DNSSEC_ is not supported and should be disabled on your domain's registrar.

- _CNAME flattening_ is not supported. This means that you are not able to use the root (apex) domain as the hostname for a CNAME record.