# [Getting started with VPC](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vpc#getting-started-with-vpc)

# [Determine your application's networking architecture](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vpc#determine-your-applications-networking-architecture)

Consider your application's requirements and determine how your application should communicate both internally and over the public internet. As part of this, review the range of options available for private and public network connectivity on Akamai Cloud: VPCs, VLANs, private IPv4 addresses, and public IPv4/IPv6 addresses. When choosing VPC for private networking (the most common product), determine if segmenting the VPC into multiple subnets is needed. Consider the number of IP addresses you need now (and might need in the future) per subnet and decide on an acceptable CIDR block as outlined with [Valid IPv4 Ranges for Subnets](https://techdocs.akamai.com/cloud-computing/docs/manage-vpc-subnets#valid-ipv4-ranges-for-a-subnet).

# [Create a VPC](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vpc#create-a-vpc)

Once you've determined that a VPC is needed, you can create it directly in Cloud Manager using the Create VPC form or by deploying a new Linode and entering a new VPC. During this process, you'll need to define the following parameters:

- **Region:** The data center where the VPC is deployed. Since VPCs are region-specific, only Linodes within that region can join the VPC.
- **Label:** A string to identify the VPC. This should be unique to your account.
- **Subnet Label:** A string to identify the subnet, which should be unique compared to other subnets on the same VPC.
- **Subnet CIDR range:** The range of IP addresses that can be used by Linodes assigned to this subnet.

While at least 1 subnet must be created, you can create up to 10 subnets per VPC.

Review the [Create a VPC](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc) guide for complete instructions.

# [Assign Linodes](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vpc#assign-linodes)

You can assign existing Linodes to a VPC or, more commonly, deploy a new Linode to the VPC. For further instructions, review the [Assign a Linode to a VPC](https://techdocs.akamai.com/cloud-computing/docs/assign-a-compute-instance-to-a-vpc) page.

- **New Linode:** When creating a Linode, there is an option to add it to an existing VPC. The VPC must already be created in the same data center as selected for the Linode. When assigning a new Linode to a VPC, you must also select the subnet that the Linode should belong to. By default, an IPv4 address from the subnet's CIDR range will be assigned to the Linode, though you can opt to manually enter an IP address. Additionally, public IPv4 connectivity won't be configured by default, though an option is present to configure 1:1 NAT on the VPC interface.

- **Existing Linode:** If you need to add an existing Linode to a VPC, you can do so from the VPC page or by directly editing that Linode's configuration profile.

# [Assign a Managed Database cluster (Beta)](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-vpc#assign-a-managed-database-cluster-beta)

To enhance security and performance of your managed database cluster, you can now assign an existing VPC to a database cluster. With a VPC assigned, the database resources operate within completely isolated network boundaries and database traffic uses private addresses which eliminates external exposure.

- [New database cluster](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-database-clusters#create-a-new-database-cluster): When creating a new database cluster, you can select a VPC you want to assign to the cluster. The VPC needs to be in the same region as the cluster.
- [Existing database cluster](https://techdocs.akamai.com/cloud-computing/docs/create-and-manage-database-clusters#manage-networking): You can update the networking settings of your cluster to assign a VPC to it.