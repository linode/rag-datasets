# [Configure a forward proxy to enable internet access within a VPC](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#configure-a-forward-proxy-to-enable-internet-access-within-a-vpc)

Placing sensitive computing resources inside of a [_Virtual Private Cloud_ (VPC)](https://en.wikipedia.org/wiki/Virtual_private_cloud) helps limit exposure and protect those systems. However, this also means it is impossible for these servers to directly access the internet without additional infrastructure. This limitation can be resolved through the use of a forward proxy, which acts as a gateway between the VPC and the public internet. This guide explains how to use a forward proxy to enable public internet access for devices within a VPC. It also demonstrates how to secure the VPC using Akamai Cloud Firewalls and how to provide applications with proxy access.

# [Methods of enabling internet access for VPC resources](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#methods-of-enabling-internet-access-for-vpc-resources)

A server within a VPC cannot access other networks, or the internet, without additional configuration. To use the public internet, a server must either enable _Network Address Translation_ (NAT) or send traffic to a forward proxy.

## [NAT](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#nat)

A _One-to-one NAT_ (1:1 NAT), also known as a _Basic NAT_, grants full internet access to the device. It connects two IP networks with different addressing schemes at the network layer. A 1:1 NAT maps an internal address and port to an external address and port. This technique allows the device to present a public IP address to the wider network while using a VPC-based address inside the private network.

NAT modifies the source and destination addresses in the IP header to correspond to the next address space. When sending a packet from the VPC to a different network, it swaps out the internal address for the public address. It reverses this process when traffic moves in the opposite direction. There are many variations of NAT, but the 1:1 type is the simplest and most common. It recalculates the IP address and any associated checksums, while leaving the rest of the packet intact. For more detailed information about 1:1 NAT, see the [NAT page on Wikipedia](https://en.wikipedia.org/wiki/Network_address_translation).

## [Forward proxy](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#forward-proxy)

A proxy is a general term for any intermediate device or application lying between a client and the target server. A forward proxy is a boundary point between the internet and a private network. It is used to retrieve resources for clients from the wider network. In addition to validating client requests, it processes packets and routes them towards their destinations. A forward proxy often changes the source or destination address, but it can also modify other fields. It keeps track of the active requests, responses, destinations, and sources, allowing it to match responses to the original client.

A proxy greatly enhances security by hiding some or all of the original addressing information. To the destination server, the request appears to come from the forward proxy. All details about the originating VPC remain hidden. Proxies can also be configured with traffic management policies. These policies can drop or filter unwanted packets, and limit the rate of incoming and outgoing packets. Some forward proxies also inspect packets to implement data protection and threat prevention. A forward proxy is typically used with a cloud or server-based firewall for extra security.

In contrast to NAT, a forward proxy works at the application layer. The proxy information is configured as part of the web server configuration, similar to a website. While NAT is self-contained, a forward proxy is part of a networking solution. A device on the VPC first transmits an outbound packet to a forward proxy. The proxy analyzes the packet and redirects it towards its ultimate destination. A common architecture is to use a 1:1 NAT and a forward proxy together. The forward proxy uses NAT to bridge multiple address spaces.

# [Configuration steps](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#configuration-steps)

Here are the basic steps needed to configure a forward proxy on a Linode and then utilize that forward proxy on other Linodes within a VPC.

1. **[Deploy _at least two_ Linodes](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#deploy-linodes)** to the same data center. Connect all systems to the same VPC. Designate one system that will act as the forward proxy and connect it to the public internet or a different private network.

2. **[Configure a firewall](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#configure-a-firewall-for-the-forward-proxy-instance)** that will protect the forward proxy Linode. This guide uses our free Cloud Firewalls service.

3. **[Install and configure Apache](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#install-apache-and-configure-it-as-a-forward-proxy)** on the Linode you've designated to act as the forward proxy.

4. **[Test connectivity through the forward proxy](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#test-connectivity-through-the-forward-proxy)** on one of the other Linodes within the same VPC.

Continue reading for detailed instructions on each of these steps.

# [Deploy Linodes](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#deploy-linodes)

To get started, use Akamai Cloud to deploy multiple Linodes within a VPC.

1. Deploy two or more Linodes to the same region and the same VPC. This guide uses Ubuntu 22.04 as the distribution image, but the instructions are generally applicable to other Linux distributions (with some modifications). See [Creating a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance) for additional instructions on how to deploy Linodes.

   - **Forward Proxy Instance**: On the Linode designated as the _forward proxy_, configure this instance with a 1:1 NAT by selecting the **Assign a public IPv4 address for this Linode** option. This enables your Linode to connect to the internet. Additional NAT-specific configuration is not required. In later steps, we'll need to know the IP address configured for the VPC interface. You can find this information later or manually set the VPC IPv4 address when creating the Linode. To do this, uncheck the _Auto-assign a VPC IPv4 address_ option and manually enter a valid IPv4 address from the defined subnet range. For example, if the subnet range is `10.0.2.0/24`, you can use `10.0.2.2` as IPv4 address. The last segment of the IPv4 address cannot be `1` or `255` as they are reserved.

   - **Other Instance(s)**: On each Linode _other than the forward proxy_, do not check the **Assign a public IPv4 address for this Linode** option. When this remains deselected, the Linode are created without public internet access.

   When creating these Linodes, _do not_ enable the **Private IP** option under **Add-ons**. This is for an unrelated feature.

2. For the VPC interface to be automatically configured within the internal system of each Linode, [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) needs to be enabled. This is the default setting for Linodes on new accounts so, in most cases, you can proceed without issues. If Network Helper is disabled, enable it on each Linode and reboot each Linode.

3. Log in to each Linode using [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) and test the connectivity to ensure the VPC has been configured properly.

   - Ping the private VPC IPv4 address of another Linode. Each Linode on the VPC should be able to ping the IP addresses of all other Linodes within that same VPC.

   - Ping an IP address or website of a system on the public internet. This ping should only be successful for the Linode configured with 1:1 NAT (the forward proxy instance).

# [Configure a firewall for the forward proxy instance instance or network Linode interface](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#configure-a-firewall-for-the-forward-proxy-instance-instance-or-network-linode-interface)

After configuring the VPC and forward proxy instance, add a cloud firewall to protect the network. It is important to configure a firewall to restrict inbound access to the proxy, while leaving outbound traffic unrestricted. An insecure and open proxy can expose the network inside the VPC to security threats and misuse.

1. Create the Cloud Firewalls in the same data center as your VPC. When doing so, assign the Cloud Firewalls to the newly created forward proxy instance  or to the forward proxy's network Linode interface (BETA).

2. Set the default **inbound policy** to _Drop_, leaving the default **outbound policy** as _Accept_.

3. Add the following three _inbound_ rules. No _outbound_ rules should be configured.

   - **Allow proxy traffic** from other Linodes within the VPC:

     - **Label**: Set this to `VPC`.
     - **Protocol**: Use `TCP`.
     - **Ports**: Choose `Custom`, then set the **Custom Port Range** to `8080`.
     - **Sources**: Select `IP / Netmask`. List all subnets within the VPC under **IP / Netmask**.
     - **Action**: Set to `Accept`.
     - Click **Add Rule** to save the configuration.

   - **Allow ICMP (ping) traffic** within the VPC:

     - **Label**: Choose `VPC-ICMP`.
     - **Protocol**: Use `ICMP`.
     - **Ports**: Leave this field blank.
     - **Sources**: Select `IP/Netmask` and enter all VPC subnets using the **IP / Netmask** field.
     - **Action**: Set to `Accept`.
     - Click the **Add Rule** button.

   - **Allow SSH connections** from other Linodes in the VPC as well as any administrative systems:

     - **Label**: Set this to `ssh`.
     - **Protocol**: Use `TCP`.
     - **Ports**: Use `SSH (22)`.
     - **Sources**: select `IP/Netmask`, entering all VPC subnets in the **IP / Netmask** field. Also include the IP addresses of any administrative servers used to connect to the forward proxy. Ensure these addresses are as specific as possible, for example, `Admin_Addr/32`.
     - **Action**: Set to `Accept`.
     - Click the **Add Rule** button.

4. Save the changes to apply the new firewall rules.

Test the new firewall restrictions. It should be possible to initiate an SSH connection to the forward proxy from one of the designated administrative addresses. However, all attempts from other addresses should be silently blocked.

# [Install Apache and configure it as a forward proxy](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#install-apache-and-configure-it-as-a-forward-proxy)

The next step is to configure a Linode to act as the forward proxy. Ideally, this proxy server should have only one role, which is to act as a forward proxy. Other than the web server and proxy information, it should have minimal additional configuration. In most cases, other applications should not be installed. This reduces the possible attack surface of the proxy.

This guide uses Apache as the forward proxy, though other HTTP proxy software can also be used.

1. Log in to the Linode you've designated as the forward proxy using [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) or [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/).

2. Install the Apache software package, making sure to download the latest package lists first.

   ```
   sudo apt update -y && sudo apt install apache2 -y
   ```

3. Enable the Apache modules that provide the forward proxy functionality.

   ```
   sudo a2enmod proxy proxy_http proxy_connect
   ```

4. Create and edit an Apache configuration file to store the forward proxy settings. This should be located wherever Apache configuration files are stored within your system (such as the `/etc/apache2/sites-available` directory).

   ```
   sudo nano /etc/apache2/sites-available/fwd-proxy.conf
   ```

5. Paste in the following example configuration, customizing these directives:

   - Replace {{\< placeholder "10.0.2.2" >}} in the _Listen_ directive with the internal VPC address of the forward proxy, using the format `IP_ADDRESS:8080` (such as `10.0.2.2:8080`). Do not use the public IP address.
   - Replace {{\< placeholder "10.0.2.0/24" >}} in the _Require_ directive (within the _Proxy_ group) with the VPC subnet range. Use the format `NETWORK_ADDR/MASK`. For example, to permit proxy service for the `10.0.2.0/24` subnet, include the line `Require ip 10.0.2.0/24`. Multiple subnets can be added using a space as the delimiter.

   ```aconf /etc/apache2/sites-available/fwd-proxy.conf
   Listen {{< placeholder "10.0.2.2" >}}:8080
   

       ServerAdmin webmaster@localhost
       DocumentRoot /var/www/html
       ErrorLog ${APACHE_LOG_DIR}/fwd-proxy-error.log
       CustomLog ${APACHE_LOG_DIR}/fwd-proxy-access.log combined
       ProxyRequests On
       ProxyVia On
       

           Require ip {{< placeholder "10.0.2.0/24" >}}
       

   

   ```

6. Set the owner of the file to `root:root` and set the correct file permissions:

   ```
   sudo chown root:root /etc/apache2/sites-available/fwd-proxy.conf
   sudo chmod 0644 /etc/apache2/sites-available/fwd-proxy.conf
   ```

7. Enable the Apache configuration file that was created in a previous step.

   ```
   sudo a2ensite fwd-proxy
   ```

8. Restart the Apache server to activate the new configuration:

   ```
   sudo systemctl restart apache2
   ```

# [Test connectivity through the forward proxy](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#test-connectivity-through-the-forward-proxy)

All servers in the VPC can now utilize the forward proxy to access the internet. This is configured per application and the instructions depend on that particular application.

## [Package management](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#package-management)

A common use case is to enable internet access for package management (such as through the apt tool). This allows administrators to install updates on the Linodes inside the VPC. Follow the steps below to enable `apt` connectivity on the VPC nodes and use `curl`.

1. Log in to one of the servers in the VPC. To access the node, use the LISH console. Alternatively, log in to the forward proxy from one of the designated administrative addresses, then establish a new SSH connection to the target instance.

2. Add the following line to the `apt` proxy configuration, replacing {{\< placeholder "10.0.2.2" >}} with the internal VPC IP address of the forward proxy:

   ```
   echo 'Acquire::http::proxy "http://{{< placeholder "10.0.2.2" >}}:8080";' > /etc/apt/apt.conf.d/proxy.conf
   ```

3. Attempt to update the local packages using `apt update`:

   ```
   sudo apt update
   ```

   The command should now function correctly, using the proxy as a forwarding agent.

## [cURL](https://techdocs.akamai.com/cloud-computing/docs/forward-proxy-for-vpc#curl)

To transmit `curl` requests, append the `--proxy` parameter to the request, again replacing {{\< placeholder "10.0.2.2" >}} with the internal VPC IP address of the forward proxy:

```
curl --proxy {{< placeholder "10.0.2.2" >}}:8080 http://example.com
```