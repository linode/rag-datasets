# [Create a VPC](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#create-a-vpc)

This guide provides step-by-step instructions for creating a VPC.

1. [Get started](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#get-started)
2. [Set the basic parameters](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#set-the-basic-parameters)
3. [Define subnets](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#define-subnets)
4. [Deploy the VPC](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#deploy-the-vpc)
5. [Next steps](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#next-steps)

# [Get started](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#get-started)

Log in to [Cloud Manager](https://cloud.linode.com/), click the **Create** dropdown menu on the top bar, and select _VPC_. This opens the **Create VPC** form.

# [Set the basic parameters](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#set-the-basic-parameters)

Select the region and enter a label and description for the VPC.

- **Region:** Select the data center where the VPC should be deployed. Since VPCs do not span multiple data centers, only services within the selected data center can join the VPC. For a list of regions that support VPCs, review [VPCs > Availability](https://techdocs.akamai.com/cloud-computing/docs/vpc#availability).

- **Label:** Enter an alphanumeric string (containing only letters, numbers, and hyphens) to identify the VPC. A good label should provide some indication as to the purpose or intended use of the VPC.

- **Description:** Adding tags gives you the ability to categorize your resources however you wish. If you're a web development agency, you could add a tag for each client you have. You could also add tags for which services are for development, staging, or production.

# [Define subnets](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#define-subnets)

Subnets partition out the VPC into smaller networks, allowing groups of related systems to be separated from other functions of your applications or workloads. At least one subnet is required, though up to 10 can be created for each VPC.

- **Subnet Label:** Enter an alphanumeric string (containing only letters, numbers, and hyphens) to identify the subnet. It should be unique among other subnets in the same VPC and should provide an indication as to its intended usage.

- **Subnet IP Address Range:** VPC subnet ranges must be in the RFC1918 IPv4 address space designated for private networks. That said, it cannot overlap with the `192.168.128.0/17` range set aside for [Private IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#types-of-ip-addresses) on Linodes.

You can add, edit, and remove subnets from the VPC after it has been created.

For each additional subnet you wish to create, press the **Add Another Subnet** button within the **Subnets** section. This adds another set of subnet fields to the form.

# [Deploy the VPC](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#deploy-the-vpc)

Once all fields have been entered, you can click the **Create VPC** button in Cloud Manager or run the Linode CLI or Linode API command. If you are using Cloud Manager, you are taken to the VPC's details page where you can view and edit the VPC and its subnets.

# [Next steps](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc#next-steps)

Once the VPC has been created, the next step is to start adding services to it or assign it to a NodeBalancer. Currently, only Linodes can be added to the VPC. 

- **Add an Existing Linode to the VPC:** Review the [Assign existing Linode to a VPC subnet](https://techdocs.akamai.com/cloud-computing/docs/assign-a-compute-instance-to-a-vpc) guide.
- **Add a new Linode to the VPC:** To add a new Linode, follow the [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance) workflow and complete the VPC section.
- **Assign a VPC to a NodeBalancer.** To allow the NodeBalancer to serve request to backend nodes in a VPC, follow [Create a NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/create-a-nodebalancer#cloud-firewall-inbound-rules-for-nodebalancer). The VPC must be in the same data center as the NodeBalancer.