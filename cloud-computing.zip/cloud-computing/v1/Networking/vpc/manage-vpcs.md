# [Manage VPCs](https://techdocs.akamai.com/cloud-computing/docs/manage-vpcs#manage-vpcs)

# [View VPCs](https://techdocs.akamai.com/cloud-computing/docs/manage-vpcs#view-vpcs)

Log in to [Cloud Manager](https://cloud.linode.com/) and select **VPC** in the sidebar. If any VPCs exist on your account, they are listed on this page.

Each VPC is listed along with the region it is located within, its ID, the number of subnets, and the number of resources, (Linodes and NodeBalancers) that are assigned.

# [Review and edit a VPC](https://techdocs.akamai.com/cloud-computing/docs/manage-vpcs#review-and-edit-a-vpc)

Navigate to the **VPCs** page in Cloud Manager and locate the VPC you wish to edit. See [View VPCs](https://techdocs.akamai.com/cloud-computing/docs/manage-vpcs#view-vpcs). Click the name of the VPC to be taken to its details page.

This displays the summary of the VPC along with a list of subnets within the VPC. Click on the subnets to get information on the Linodes in the VPC or to see if the VPC subnet is assigned to a NodeBalancer. To edit the VPC label or description, click the **Edit** button within the _Summary_ section. The data center assignment cannot be changed. Once a VPC has been created, you cannot move it to a different data center.

# [Create a VPC](https://techdocs.akamai.com/cloud-computing/docs/manage-vpcs#create-a-vpc)

To add a new VPC on your account, follow the [Create a VPC](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc) instructions.

# [Delete a VPC](https://techdocs.akamai.com/cloud-computing/docs/manage-vpcs#delete-a-vpc)

A VPC can be deleted using the **Delete** button next to the VPC you wish to delete on the main **VPC** page. It can also be deleted when viewing that VPCs details page by clicking the **Delete** button within the _Summary_ section.

Only a VPC without any Linodes or NodeBalancers (Resources) assigned can be deleted. Review the [Remove Linodes from a VPC](<>) workflow if any Linodes are currently assigned.