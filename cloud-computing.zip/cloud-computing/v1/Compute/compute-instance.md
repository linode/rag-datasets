# [Linodes](https://techdocs.akamai.com/cloud-computing/docs/compute-instance#linodes)

Linodes (also referred to as Compute Instances) are virtual machines that run on Akamai's secure and reliable global infrastructure. To support a variety of workloads, Linode plans are organized under several basic plan types, each with their own set of resources, unique value propositions, and technical specifications (see [Plan Types](https://techdocs.akamai.com/cloud-computing/docs/compute-instance-plan-types)). Each Linode can run a variety of [supported Linux distributions](https://techdocs.akamai.com/cloud-computing/docs/choose-a-distribution), including the latest versions of Ubuntu, CentOS Stream, Debian, and more.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/compute-instance#availability)

Linodes are available across [all regions](https://www.linode.com/global-infrastructure/).

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/compute-instance#plans-and-pricing)

See [Plans](https://techdocs.akamai.com/cloud-computing/docs/compute-instance-plan-types) for the list of available plan types. Note that pricing and plan availability may vary between regions. See our [Pricing](https://www.linode.com/pricing/) page for a full list of pricing options.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/compute-instance#technical-specifications)

Linodes deployed to core compute regions meet the following specifications:

- Shared or Dedicated vCPU cores (dependent on the chosen plan)
- 100% SSD (Solid State Disk) storage
- 40 Gbps inbound network bandwidth
- Free inbound network transfer (ingress)
- Metered outbound network transfer (egress) that includes 1 TB - 20 TB of prorated\* network transfer allowance
- Dedicated IPv4 and IPv6 addresses (additional addresses available on request)
- Deploy using the many available [Linux Distributions](https://www.linode.com/distributions/), [Marketplace Apps](https://www.linode.com/marketplace/), or Community [StackScripts](https://www.linode.com/products/stackscripts/)
- Direct console access through [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish)
- Provisioning and management through [Cloud Manager](https://cloud.linode.com/), [Linode CLI](https://www.linode.com/products/cli/), or programmatically through the [Linode API](https://www.linode.com/products/linode-api/)
- [Multi-queue NIC](https://techdocs.akamai.com/cloud-computing/docs/multi-queue-nics) support on plans with 2 or more vCPU cores.

\*_If a service is not active for the entire month, the amount of network transfer allowance is prorated based on the number of hours the service is active._

Shared CPU plans, Marketplace Apps, or Stackscripts are not supported when Linodes are deployed to [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions).

# [Services included at no extra cost](https://techdocs.akamai.com/cloud-computing/docs/compute-instance#services-included-at-no-extra-cost)

The following services are bundled with all Linodes deployed to core compute regions:

- Domain management through our [DNS Manager](https://www.linode.com/products/dns-manager/)
- DNS query resolution with [DNS resolvers](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers) 
- Seamless firewall management with [Cloud Firewalls](https://www.linode.com/products/cloud-firewall/)
- Isolated, private networking with [VPCs and VLANs](https://www.linode.com/products/private-networking/)
- Physical placement of your Linodes in a data center with [Placement Groups](https://techdocs.akamai.com/cloud-computing/docs/work-with-placement-groups)
- Metrics and monitoring through [Cloud Manager](https://www.linode.com/products/monitoring/) and [Longview](https://techdocs.akamai.com/cloud-computing/docs/longview) (free plan)
- Reusable deployment scripts through [StackScripts](https://www.linode.com/products/stackscripts/)

For the list of services supported Linodes in distributed compute regions, see [Features and services (distributed compute regions)](https://techdocs.akamai.com/cloud-computing/docs/supported-services-distributed).

# [Complementary paid services](https://techdocs.akamai.com/cloud-computing/docs/compute-instance#complementary-paid-services)

To help build and manage your applications, consider complementing your Linode with the following compatible services:

- Automated daily and weekly backups with our [Backups service](https://www.linode.com/products/backups/)
- Add additional storage drives with [Block Storage](https://www.linode.com/products/block-storage/)
- Create and store reusable images with [Custom Images](https://www.linode.com/products/images/)
- Advanced metrics and monitoring through [Longview Pro](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-longview)
- Automated service deployments with [LKE (Linode Kubernetes Engine)](https://www.linode.com/products/kubernetes/)
- Incident response (and more) with [Managed Services](https://www.linode.com/products/managed/)
- Enable load balancing and horizontal scaling with [NodeBalancers](https://www.linode.com/products/nodebalancers/)
- Add scalable storage to your application with [Object Storage](https://www.linode.com/products/object-storage/)

Support for these services varies by region. For the list of supported services in each core region, see [Choose a data center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center). For the list of supported services in distributed compute regions, see [Features and services](https://techdocs.akamai.com/cloud-computing/docs/supported-services-distributed).

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/compute-instance#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of services on Akamai Cloud.
  - [Linode Instances Endpoint Collection](https://linode.com/docs/api/linode-instances)
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your  Akamai Cloud account and resources from the command line. Learn how to use the Linode CLI to [create and manage Linodes](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-compute-instances).
- **Terraform**: Terraform is an Infrastructure-as-code tool that includes management features for various types of Akamai Cloud resources. Use Akamai's [official Terraform Provider](https://registry.terraform.io/providers/linode/linode/latest/docs) to [provision Linode environments](https://linode.com/docs/guides/how-to-build-your-infrastructure-using-terraform-and-linode/). To learn more about Terraform see our documentation library’s [Terraform section](https://linode.com/docs/applications/configuration-management/terraform/).
- **Pulumi**: Pulumi is a development tool that lets you write computer programs which deploy cloud resources. With [Pulumi’s Akamai Cloud integration](https://github.com/pulumi/pulumi-linode), you can manage your cloud computing resources in several programming languages, like JavaScript, Go, Python, and TypeScript. Pulumi manages your resources in the same way as Linode API or Linode CLI. See [Pulumi’s documentation](https://www.pulumi.com/docs/intro/cloud-providers/linode/) to get started. [Getting Started with Pulumi](https://linode.com/docs/guides/deploy-in-code-with-pulumi/).