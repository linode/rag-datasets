# [Add user data when deploying Linodes](https://techdocs.akamai.com/cloud-computing/docs/add-user-data-when-deploying-a-compute-instance#add-user-data-when-deploying-linodes)

The Metadata service is always active, so there's no need to enable it. User data can be provided to the Metadata service, which is then consumed by cloud-init when your Linode boots up for the first time.

- **Cloud Manager:**

  1. Navigate to the **Linodes** page in [Cloud Manager](http://cloud.linode.com) and click the **Create Linode** button. This opens the **Create Linode** form.

  2. Fill out the form with your desired settings. Be sure to select one of the supported distribution images and data centers.

  3. Expand the _Add User Data_ section and enter your user data into the **User Data** field.

     

     If you are unfamiliar with cloud-init, see [Using cloud-config files to configure a server](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server) for help creating a cloud-config file.

  4. Once you are ready, click the **Create Linode** button to deploy the Linode.

- **Linode CLI:**

  ```
  linode-cli linodes create \
    --label new-instance-with-metadata \
    --region us-iad \
    --type g6-standard-2 \
    --image linode/ubuntu22.04 \
    --root_pass [your-root-password] \
    --metadata.user_data [your-user-data]
  ```

  Replace _[your-root-password]_ with a strong root password and _[your-user-data]_ with the cloud-config data or script you wish to use. When using the CLI, user data must be a Base64-encoded string. Review the [Base64 Encoded](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#base64-encoded) section below to generate the string.

- **Linode API:**

  Run the API curl request below, making sure to properly paste in or reference your [API token](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens).

  ```
  curl -H "Content-Type: application/json" \
      -H "Authorization: Bearer $TOKEN" \
      -X POST -d '{
        "label": "new-instance-with-metadata",
        "region": "us-iad",
        "type": "g6-standard-2",
        "image": "linode/ubuntu22.04",
        "root_pass": "[your-root-password]",
        "metadata": {
            "user_data": "[your-user-data]"
        }
      }' \
      https://api.linode.com/v4/linode/instances
  ```

  Replace _[your-root-password]_ with a strong root password and _[your-user-data]_ with the cloud-config data or script you wish to use. When using the API, user data must be a Base64-encoded string. Review the [Base64 Encoded](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#base64-encoded) section below to generate the string.

When your Linode boots up using a compatible distribution, cloud-init runs. If it detects that this is the first time running on this Linode, it connects to the Metadata API and captures the instance data for that Linode, including any user data that you added. It then uses that metadata to provision the software on the Linode, including setting the hostname to the Linode's label and executing the user data script.

 > Note: 
  User data can be added when creating a new Linode, rebuilding a Linode, cloning a Linode, and restoring from a backup.

## [User data formats](https://techdocs.akamai.com/cloud-computing/docs/add-user-data-when-deploying-a-compute-instance#user-data-formats)

User data can be provided in many different formats, with the most common being [cloud-config](https://cloudinit.readthedocs.io/en/latest/explanation/format.html#cloud-config-data).

- **Cloud-config script:** cloud-config is the default syntax for cloud-init and can be used on any Linux distribution. It contains a list of directives formatted using YAML. Review the [Using cloud-config files to configure a server](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server) guide for more details.

  ```
  #cloud-config
  package_update: true
  package_upgrade: true
  packages:
  - nginx
  - mysql-server
  ```

- **Executable script:** Cloud-init also accepts other scripts that can be executed by the target distribution. This includes bash and python. Since many commands (including those to create users and install packages) differ between distributions, providing these scripts may limit which distributions you can target.

  ```
  #!/bin/bash
  apt-get update -y && apt-get upgrade -y
  apt-get install nginx mysql-server -y
  ```

- **Other formats:** Review the [User data formats](https://cloudinit.readthedocs.io/en/latest/explanation/format.html#user-data-formats) guide within the official documentation to learn more about other types of formats supported by cloud-init.

### [Base64 encoded](https://techdocs.akamai.com/cloud-computing/docs/add-user-data-when-deploying-a-compute-instance#base64-encoded)

When submitting user data through the Linode CLI or API, you first need to encode it into [Base64](https://en.wikipedia.org/wiki/Base64) (without any line breaks/wraps). To do that, run the command below that corresponds with your local operating system. Replace _[file]_ with the name (and path, if needed) of your cloud-config or script file.

- **macOS:**

  ```
  base64 --break=0 --input=[file]
  ```

- **Linux:**
  ```
  base64 --wrap=0 [file]
  ```