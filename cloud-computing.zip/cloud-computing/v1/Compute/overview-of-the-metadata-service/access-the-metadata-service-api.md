# [Access the Metadata service API](https://techdocs.akamai.com/cloud-computing/docs/access-the-metadata-service-api#access-the-metadata-service-api)

In addition to being consumed by cloud-init, the Metadata service can also be accessed through an API. The API is available on industry standard link-local IP addresses (`169.254.169.254` and `fd00:a9fe:a9fe::1`) and returns only instance data and user data for that Linode. For more details on using the API, see [Use the Metadata service API](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api).

1. Log in to a Linode that has been deployed in a supported data center using a supported distribution image.

2. Generate your API token by running the command below:

   ```
   curl -X PUT -H "Metadata-Token-Expiry-Seconds: 3600" http://169.254.169.254/v1/token
   ```

   Instead of receiving the token as an output string, you can save it directly to the `$TOKEN` environmental variable:

   ```
   export TOKEN=$(curl -X PUT -H "Metadata-Token-Expiry-Seconds: 3600" http://169.254.169.254/v1/token)
   ```

3. Query one of the following API endpoints to receive data from the API. If you did not save the API token to the `$TOKEN` variable, replace `$TOKEN` in the commands below with your token.

   - **/v1/instance**: Output information about your Linode, including plan resources.

     ```
     curl -H "Metadata-Token: $TOKEN" http://169.254.169.254/v1/instance
     ```

   - **/v1/network**: Output information about your Linode's IP addresses.

     ```
     curl -H "Metadata-Token: $TOKEN" http://169.254.169.254/v1/network
     ```

   - **/v1/user-data**: Output your user data.

     ```
     curl -H "Metadata-Token: $TOKEN" http://169.254.169.254/v1/user-data | base64 --decode
     ```