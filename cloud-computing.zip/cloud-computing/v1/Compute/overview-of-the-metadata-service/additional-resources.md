# [Additional resources](https://techdocs.akamai.com/cloud-computing/docs/additional-resources#additional-resources)

For further information about using cloud-init with Metadata service, see the following guides:

[Use Akamai's Metadata Service with Cloud-Init on Any Distribution](https://www.linode.com/docs/guides/using-metadata-cloud-init-on-any-distribution/)  
[Use Cloud-Init to Manage Users on New Servers](https://www.linode.com/docs/guides/manage-users-with-cloud-init/)  
[Use Cloud-Init to Automatically Configure and Secure Your Servers](https://www.linode.com/docs/guides/configure-and-secure-servers-with-cloud-init/)  
[Use Cloud-Init to Install and Update Software on New Servers](https://www.linode.com/docs/guides/install-and-update-software-with-cloud-init/)  
[Use Cloud-Init to Run Commands and Bash Scripts on First Boot](https://www.linode.com/docs/guides/run-shell-commands-with-cloud-init/)  
[Use Cloud-Init to Write to a File](https://www.linode.com/docs/guides/write-files-with-cloud-init/)