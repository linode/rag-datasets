# [Use cloud-config files to configure a server](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server#use-cloud-config-files-to-configure-a-server)

[Cloud-config](https://cloudinit.readthedocs.io/en/latest/explanation/format.html#cloud-config-data) files are supported by our [Metadata service](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service) and are used by cloud-init to automate server configuration. This guide covers creating cloud-config files, common modules, and examples to help get you started.

# [Syntax](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server#syntax)

Cloud-config data is written using the YAML syntax, a commonly used data serialization format that's more user-friendly and human-readable than alternatives (like JSON). YAML consists of key-value pairs. Each key is entered on its own line and a colon (`:`) is used to separate the key from its value. The scope of the key is defined by its indentation. To learn more about YAML, review the [latest YAML specification](https://yaml.org/spec/1.2.2/#chapter-2-language-overview).

# [Cloud-config modules](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server#cloud-config-modules)

A cloud-config file must contain `#cloud-config` as the first line. Following that, you can use the keys provided by any of the cloud-init modules. Review the remaining sections of this guide for a list of common modules and how to configure them. For a full list of modules/keys, see the [cloud-init module reference](https://cloudinit.readthedocs.io/en/latest/reference/modules.html).

# [Create a new user and restrict root access](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server#create-a-new-user-and-restrict-root-access)

One of the most common security tasks for every new system deployment is configuring user accounts. This includes creating a limited user account for the system administrator, adding them to the _sudo_ group, and enabling the user to log in over SSH using a public key instead of a password.

- `users` _(list)_: Configure user accounts ([Reference](https://cloudinit.readthedocs.io/en/latest/reference/modules.html#users-and-groups) \| [Example](https://cloudinit.readthedocs.io/en/latest/reference/examples.html#including-users-and-groups))
  - `name` _(string)_: The name of the user.
  - `passwd` _(string)_: The hash of the password you want to configure for this user.
  - `groups` _(string)_: The name of the group the user should belong to.
  - `sudo`: Define a sudo rule string or set to `False` to deny sudo usage.
  - `lock_passwd` _(boolean)_: If true (the default setting), prevents logging in with a password for that user.
  - `ssh_authorized_keys` _(list)_: A list containing the public keys that should be configured for this user.

```yaml
#Cloud-config
users:
- name: example-user
  groups: sudo
  sudo: ALL=(ALL) NOPASSWD:ALL
  shell: /bin/bash
  ssh_authorized_keys:
  - [insert-public-key]
```

# [Update system](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server#update-system)

Updating the system is another common task that's performed after a system is deployed.

- `package_update` _(boolean)_: Updates the apt database ([cloud-init Docs](https://cloudinit.readthedocs.io/en/latest/reference/examples.html#update-apt-database-on-first-boot))
- `package_upgrade` _(boolean)_: Upgrades the software on your system (by running the yum or apt upgrade command). See the [cloud-init documentation](https://cloudinit.readthedocs.io/en/latest/reference/examples.html#run-apt-or-yum-upgrade).

```yaml
#Cloud-config
package_update: true
package_upgrade: true
```

# [Install a software package](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server#install-a-software-package)

Almost all workloads running on a Linode require additional software to be installed. You can automatically install software packages by adding them to your cloud-config file.

- `packages` _(list)_: Installs the specified list of packages. See the [cloud-init documentation](https://cloudinit.readthedocs.io/en/latest/reference/examples.html#install-arbitrary-packages).

```yaml
#Cloud-config
packages:
- nginx
- mysql-server
- php
```

# [Run a command](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server#run-a-command)

- `runcmd` _(list)_: Runs the specified commands during the first boot. See the [cloud-init documentation](https://cloudinit.readthedocs.io/en/latest/reference/examples.html#run-commands-on-first-boot).

```yaml
#Cloud-config
runcmd:
- mkdir ~/new-folder/
```

# [Write to a file](https://techdocs.akamai.com/cloud-computing/docs/using-cloud-config-files-to-configure-a-server#write-to-a-file)

- `write_files` (_list_): see the [cloud-init documentation](https://cloudinit.readthedocs.io/en/latest/reference/examples.html#writing-out-arbitrary-files).
  - `content`: The entire content to include in the file.
  - `path`: The path for the file. If a file already exists at this location, it is overwritten.
  - `permissions`: Defines the file permissions in octal format (ex: `0644`).

```yaml
#Cloud-config
write_files:
- content: |
    

    # 
Hello world!

    
This is the content of my web page.

    

  path: /var/www/html/index.html
```