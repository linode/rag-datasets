# [Use the Metadata service API](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#use-the-metadata-service-api)

The [Metadata service](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service) offers an API for use in automated deployment configurations. Compatible versions of cloud-init can leverage the Metadata service to automatically configure new Linodes at deployment. However, the Metadata service's API can also be accessed directly. Doing so provides access to both instance and user data.

In this reference guide, learn more about the available API endpoints for the Metadata service and how to use them. Follow along to find out how to access the API from your Linode and what to expect from each endpoint.

# [API endpoints](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#api-endpoints)

To access the Metadata API, you need to be on a Linode. If you have not done so already, follow along with our guide on [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance) before moving forward.

Once you have an Linode deployed, the Metadata API is accessible via link-local addresses, specifically:

- **IPv4**: `169.254.169.254`
- **IPv6**: `fd00:a9fe:a9fe::1`

The Metadata API provides the following endpoints:

- [token](metadata-service-api#authentication-tokens-v1token) 
- [instance](metadata-service-api#instance-data-v1instance) 
- [maintenance/events](#maintenance-events-v1maintenanceevents) (beta)
- [network](metadata-service-api#network-data-v1network)
- [ssh-keys](metadata-service-api#ssh-keys-v1ssh-keys)
- [user-data](metadata-service-api#user-data-v1user-data)

The following sections cover each of these endpoints individually, explaining their usage and providing examples of the expected output. Using the `Accept` header, output can generally be in either the default `text/plain` format or the `application/json` format.

To demonstrate, this guide provides example output in the plain-text format and shows the response structure in JSON format, where applicable.

## [Authentication tokens (/v1/token)](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#authentication-tokens-v1token)

Use of the Metadata API always starts with the `token` endpoint. Use this endpoint to authenticate a new session and receive a Metadata token for accessing subsequent Metadata endpoints from your instance.

While all other Metadata endpoints use `GET`, requests to this endpoint use the `PUT` method:

```
curl -X PUT -H "Metadata-Token-Expiry-Seconds: 3600" http://169.254.169.254/v1/token
```

These requests provide a `Metadata-Token-Expiry-Seconds` header, which indicate the token's expiry time in seconds:

```text Output
e80eb80986f17fcd3df8fcb6ea944774cae47b26ed6d68df63a15b294b7a6e3f
```

When using the JSON format, the endpoint's response is an array containing the token string:

```text Output
[ "token" ]
```

From here on, this guide assumes you have already acquired a Metadata token. For convenience, subsequent examples use `$TOKEN` in place of the actual token string. Follow along by storing the token in an [environment variable](https://linode.com/docs/guides/how-to-set-linux-environment-variables/), as shown here:

```
export TOKEN=$(curl -X PUT -H "Metadata-Token-Expiry-Seconds: 3600" http://169.254.169.254/v1/token)
```

## [Instance data (/v1/instance)](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#instance-data-v1instance)

: Instance data includes information related to the deployment and the Linode itself

To receive information about the Linode, use the `instance` endpoint:

```
curl -H "Metadata-Token: $TOKEN" http://169.254.169.254/v1/instance
```

The output includes information on the identity of the Linode, its specifications, and its backup scheduling:

```text Output
account_euuid: D0C1C361-AAF4-4404-B05904FDB58C42A2
backups.enabled: false
host_uuid: 123abc456def789ghi
id: 532754976
image.id: linode/ubuntu24.04
image.label: Ubuntu 24.04 LTS
label: example-linode-instance
region: us-iad
specs.disk: 51200
specs.gpus: 0
specs.memory: 2048
specs.transfer: 2000
specs.vcpus: 1
type: g6-standard-1
```

The endpoint's response is structured as shown below using the JSON format:

```text Output
{
  “id”: int,
  “host_uuid”: str,
  “label”: str,
  “region”: str,
  “type”: str,
  “tags”: array of str,
  “specs”: {
    “vcpus”: int,
    “memory”: int,
    “disk”: int,
    “transfer”: int,
    “gpus”: int
  },
  “backups”: {
    “enabled”: bool,
    “status”: str[pending/running/complete] or null
  },
  “account_euuid”: str
  “image”: {
    “id”: str,
    “label”: str
  }  
}
```

The overall object provides identifying information about the Linode, such as `ID`, `label`, and `tags`. A nested `specs` object details the Linode specifications, while a nested `backups` object provides the status of backups for the instance.

## [Maintenance events (v1/maintenance/events)](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#maintenance-events-v1maintenanceevents)

 > Warning: 
  This endpoint is currently in beta and may not be available in all regions.

The `v1/maintenance/events` endpoint outputs details related to upcoming scheduled maintenance events for the Linode. These details include a description of the maintenance, the time the maintenance is scheduled to occur, and the [maintenance policy](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy) that will be used.

```
curl -H "Metadata-Token: $TOKEN" http://169.254.169.254/v1/maintenance/events
```

```Text Output (Text)
beta: true
data.applied_maintenance_policy: linode/migrate
data.description: We are upgrading the operating system of your current host.
data.event_status: in_progress
data.maintenance_id: 171
data.not_before: 2025-08-16T14:26:27
data.schedule_type: scheduled
data.selected_maintenance_policy: linode/migrate
data.source: platform
page: 1
pages: 1
results: 1
```
```Text Output (JSON)
{
  "data": [
    {
      "maintenance_id": 171,
      "applied_maintenance_policy": "linode/migrate",
      "selected_maintenance_policy": "linode/migrate",
      "schedule_type": "scheduled",
      "description": "We are upgrading the operating system of your current host.",
      "source": "platform",
      "not_before": "2025-08-16T14:26:27",
      "event_status": "in_progress"
    }
  ],
  "page": 1,
  "pages": 1,
  "results": 1,
  "beta": true
}
```

- `maintenance_id` (_int_): Unique identifier for the maintenance event.
- `applied_maintenance_policy` (_str_): Actual policy applied during this event.
- `selected_maintenance_policy` (_str_): Maintenance policy selected on the Linode.
- `description` (_str_): Brief summary of the event.
- `source` (_str_): Origin of the event.
- `not_before` (_str_): The earliest scheduled start time for the event.
- `event_status`(_str_): The current state of this event.
- `schedule_type` (_str_): Differentiates if the event is based on scheduled or emergency maintenance.

## [Network data (/v1/network)](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#network-data-v1network)

To retrieve information about how the Linode's networking is configured, use the `network` endpoint:

```
curl -H "Metadata-Token: $TOKEN" http://169.254.169.254/v1/network
```

Refer to this endpoint when you need to identify the Linode's IP addresses, configured network interfaces, and those interfaces' IPAM addresses:

```text Output
ipv4.public: 192.0.2.0/24
ipv6.link_local: fe80::db8:1b3d:e5b7/128
ipv6.slaac: 2600:3c05::db8:1b3d:e5b7/128
```

The endpoint's response follows the JSON structuring shown below:

```text Output structure
{
  “interfaces”: [
    {
      “purpose”: str[public/vlan],
      “label”: str,
      ipam_address”: str[optional]
    },
  ],
  “ipv4”: {
    “public”: array of str,
    “private”: array of str,
    “shared”: array of str,
    “vpc”: array of str
  },
  “ipv6”: {
    “slaac”: str,
    “ranges”: array of str,
    “link-local”: str
    “shared_ranges”: array of str
  }
}

```

The `interfaces` array shows what interfaces, if any, the Linode has. However, a default "eth0 - Public Internet" interface alone does not result in any output here. The `ipv4` and `ipv6` objects list the various addresses configured for the instance.

## [SSH keys (/v1/ssh-keys)](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#ssh-keys-v1ssh-keys)

Use the `ssh-keys` endpoint to acquire a list of all SSH keys and associated users configured for the Linode:

```
curl -H "Metadata-Token: $TOKEN" http://169.254.169.254/v1/ssh-keys
```

The output lists each user by username, along with an array of associated keys:

```text Output
users.example-user: EXAMPLE_SSH_PUBLIC_KEY
users.root: ROOT_SSH_PUBLIC_KEY
```

The endpoint's output uses the structure shown below for JSON requests:

```text Output
{
  “users”: {
    “root”: array of str,
    “username”: array of str
  }
}
```

A `root` array lists keys for the root user. Other users each have their own array of keys, with the username acting as a label.

## [User data (/v1/user-data)](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#user-data-v1user-data)

The `user-data` endpoint returns the user data submitted during the Linode's deployment. Typically, this user data consists of a cloud-config script to be used by cloud-init for automating deployment. However, when accessing the Metadata service directly, you may utilize the user data for other purposes. If no user data was submitted, nothing will be returned.

Submitted user data is required to be encoded using `base64`, so you need to decode the returned string to view the expected user data:

```
curl -H "Metadata-Token: $TOKEN" http://169.254.169.254/v1/user-data | base64 --decode
```

The output from this endpoint is simply the user data contents. There is no further formatting. For this reason, the endpoint only accepts the `text/plain` format, not `application/json` format.

Below is example cloud-config user data for a basic Linode. This is just an example and the specific content varies depending on the user data submitted when initializing the Linode.

```text Output
#Cloud-config

# [Configure a limited user](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#configure-a-limited-user)
users:
  - default
  - name: example-user
    groups:
      - sudo
    sudo:
      - ALL=(ALL) NOPASSWD:ALL
    shell: /bin/bash
    ssh_authorized_keys:
      - "SSH_PUBLIC_KEY"

# [Perform system updates](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#perform-system-updates)
package_update: true
package_upgrade: true

# [Configure server details](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#configure-server-details)
timezone: 'US/Central'
hostname: examplehost

# [Harden SSH access](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#harden-ssh-access)
runcmd:
  - sed -i '/PermitRootLogin/d' /etc/ssh/sshd_config
  - echo "PermitRootLogin no" >> /etc/ssh/sshd_config
  - systemctl restart sshd
```