# [Networking interfaces](https://techdocs.akamai.com/cloud-computing/docs/networking-interface#networking-interfaces)

You can create public, VLAN and VPC network interfaces using either configuration profile interfaces or Linode interfaces (Beta).

# [Linode interfaces (New) (BETA)](https://techdocs.akamai.com/cloud-computing/docs/networking-interface#linode-interfaces-new-beta)

**Linode interfaces** offer an alternative to the existing configuration profile interfaces for Linode networking. They are directly associated with a given Linode and allow you to assign firewalls directly to VPC and Public Internet.

# [Configuration profile interfaces (Legacy)](https://techdocs.akamai.com/cloud-computing/docs/networking-interface#configuration-profile-interfaces-legacy)

A **configuration profile** functions as a boot loader for a Linode. It controls general boot settings, including the disk the Linode will boot from, the disks that will be mounted, the kernel that will be used, and the network interfaces on the Linode.

# [Linode interfaces and configuration profile interfaces differences](https://techdocs.akamai.com/cloud-computing/docs/networking-interface#linode-interfaces-and-configuration-profile-interfaces-differences)

Configuration profile interfaces or Linode interfaces differ in the following ways:

- **Network settings**. Linode interfaces are directly integrated into the Linode’s networking settings. In constrast, configuration profile interfaces are part of the configuration profile.
- **Management**. You can create, delete, or update Linode interface addresses only when the Linode is powered off. This ensures a clear and reliable association between the Linode and its network interfaces. You can modify configuration profile interfaces while the Linode is running, but changes only take effect after a reboot.
- **Cloud Firewalls**. A firewall is automatically assigned or you can assign a Cloud Firewall directly to each VPC or public Linode interface. Firewall templates are available for Linode interfaces and come with pre-configured protection rules. For configuration profile interfaces, Cloud Firewalls are applied at the Linode level, and the same firewall rules apply to all non-VLAN interfaces in the profile.
- **Private IPv4 addresses**. Configuration profile interfaces support private IPv4 addresses. Linode interfaces do not support private IPs.
- **Primary interface.** For Linode interfaces, you can set different primary interfaces for IPv4 and IPv6 addresses. If there are multiple eligible interfaces, you can choose the primary one. For configuration profile interfaces, you can't set different interfaces for IPv4 and IPv6 addresses. If there are multiple eligible interfaces, the primary interface is chosen automatically. 
- **MAC address.** You can identify Linode interfaces using their MAC address. MAC addresses aren't available for configuration profile interfaces.  

# [Choosing configuration profile interfaces or Linode interfaces](https://techdocs.akamai.com/cloud-computing/docs/networking-interface#choosing-configuration-profile-interfaces-or-linode-interfaces)

You can select to use configuration profile interfaces or Linode interfaces:

- For all new Linodes on your account. See [Select network interfaces for new Linodes](https://techdocs.akamai.com/cloud-computing/docs/select-network-interfaces-for-new-linodes) for more information.
- When creating a Linode. See [Set up networking](https://techdocs.akamai.com/cloud-computing/docs/create-a-linode-with-networking-interfaces#set-up-networking) for more information.

# [Upgrading to Linode interfaces (BETA)](https://techdocs.akamai.com/cloud-computing/docs/networking-interface#upgrading-to-linode-interfaces-beta)

You can upgrade a Linode that uses configuration profile interfaces to use Linode interfaces. This upgrade is irreversible—once completed, configuration profile interfaces can no longer be used on that Linode. For more information, see [Upgrade Configuration profile interfaces to Linode interfaces](https://techdocs.akamai.com/cloud-computing/docs/upgrading-config-profile-interfaces-to-linode-interfaces).

 > Warning: 
  Linode interfaces do not support private IPs. Linodes that require private IPs shouldn't be upgraded.