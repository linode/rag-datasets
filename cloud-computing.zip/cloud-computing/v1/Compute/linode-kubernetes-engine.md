# [Linode Kubernetes Engine](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#linode-kubernetes-engine)

Linode Kubernetes Engine (LKE) is Akamai’s managed container orchestration engine built on top of Kubernetes. Through LKE, you can quickly deploy and manage your containerized applications without needing to build and maintain your own Kubernetes cluster. This enables you to utilize Kubernetes without the specialized knowledge, added complexity, and additional overhead typically associated with manual deployments.

Akamai’s managed Kubernetes service is now offered in two tiers: LKE and LKE Enterprise. Each of these tiers accommodates different use cases and deployment sizes. Review the sections below for an overview of each tier and a comparison of their feature sets, resource limits, and capabilities.

- **LKE Enterprise**: Designed to be a more robust, scalable, and enterprise-grade Kubernetes management solution for larger deployments. The control plane is highly available and offers dedicated resources.
- **LKE**: Designed for smaller deployments and offers a standard array of cluster management features. All LKE clusters are equipped with a fully-managed control plane at no additional cost. Only pay for the add-on features, worker nodes, and any other resources that your application uses (such as NodeBalancers and Block Storage volumes).

# [LKE Enterprise](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#lke-enterprise)

[LKE Enterprise](https://techdocs.akamai.com/cloud-computing/docs/lke-enterprise) offers a robust set of enterprise-grade capabilities. It is more scalable than LKE and can support a larger number of worker nodes and pods. The control plane is always highly available and offers dedicated resources, reducing possibility of resource contention and increasing the overall performance. Unlike LKE, the control plane that is deployed as part of LKE Enterprise is a paid service (in addition to any paid resources deployed within the cluster). Communication between pods in the cluster is isolated from other traffic.

- **Dedicated HA control plane**: The control plane is equipped with dedicated compute resources and is now HA-enabled.
- **Increased scalability**: LKE Enterprise clusters can support up to 500 nodes and 5000 pods.
- **Enhanced security**:  Control plane ACLs are enabled by default and Cloud Firewalls are automatically configured on worker nodes.
- **Isolated high-performance pod-to-pod networking**: All traffic between pods occurs over the worker node’s VPC interface and is isolated from other traffic within the region.
- **High-performance ingress service networking**
- **Enterprise-grade load balancing**: When load balancing resources are configured in an LKE Enterprise cluster, they are deployed as Premium NodeBalancers, a more advanced version of our NodeBalancing solution. For more details, see the [instructions on configuring Premium NodeBalancers with LKE Enterprise](https://techdocs.akamai.com/cloud-computing/docs/lke-enterprise#configure-nodebalancers) .
- **More performant CNI**: Instead of Calico (which is offered in LKE non-enterprise clusters), LKE Enterprise uses Cilium as its CNI (container network interface). Cilium is more performant and provides more powerful observability features.

# [LKE](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#lke)

LKE (non-enterprise) was designed to make Kubernetes more approachable to developers and small businesses. As such, its feature set is geared towards smaller deployments and focuses on ease of use and simplicity. Container orchestration is handled by the fully-managed control plane. This control plane utilizes shared resources and is not highly available by default (though an HA control plane is available as a paid add-on). LKE itself is a free service, though users still pay for add-ons and resources deployed as part of their LKE clusters, including worker nodes (Linodes), load balancers (NodeBalancers), and persistent storage volumes (Block Storage).

- **Free fully-managed control plane**: The control plane on a Kubernetes cluster is responsible for managing the cluster's worker nodes, resources, and Pods. Basic control plane infrastructure is provided at no cost. An optional high availability control plane is offered as a paid upgrade.
- **Kubernetes Dashboard**: All LKE non-enterprise installations include access to a Kubernetes Dashboard installation.

# [Features common to both tiers](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#features-common-to-both-tiers)

- **Automatic monitoring, backup, and recovery**: A snapshot of your cluster's metadata is backed up continuously and your cluster is automatically restored in the event of a failure. In addition, all of the control plane components are monitored and, if a failure is detected, they will automatically recover.
- **Third-party integration**: Harness the strong open source ecosystem of Kubernetes tooling. LKE supports integration with popular K8s-related tools, such as Rancher, Helm, Operators, and more.

# [Compare LKE and LKE Enterprise](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#compare-lke-and-lke-enterprise)

|                                      | LKE Enterprise                       | LKE                                                                                        |
| :----------------------------------- | :----------------------------------- | :----------------------------------------------------------------------------------------- |
| Maximum # of worker nodes            | 500                                  | 250                                                                                        |
| Maximum # of pods                    | 5000                                 | 1000                                                                                       |
| Control plane resources              | Dedicated                            | Shared                                                                                     |
| High availability (HA) control plane | Yes                                  | Optional add-on                                                                            |
| VPC isolated networking              | Yes                                  | No                                                                                         |
| Node pool autoscaling                | Yes                                  | Yes                                                                                        |
| Node pool data encryption            | Yes                                  | Yes                                                                                        |
| Automated Kubernetes version updates | Yes                                  | Yes                                                                                        |
| Container Network Interface (CNI)    | Cilium                               | Calico                                                                                     |
| Load balancing solution              | NodeBalancers, Premium NodeBalancers | NodeBalancers                                                                              |
| GPU support                          | Coming soon                          | Yes                                                                                        |
| Kubernetes Dashboard pre-installed   | No                                   | Yes                                                                                        |
| Akamai App Platform                  | Coming soon                          | Yes                                                                                        |
| Pricing                              | Paid service (see Pricing)           | No additional cost beyond worker node resources, add-ons, and additional deployed services |
| Availability                         | Limited availability                 | All core compute regions                                                                   |

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#availability)

LKE is available across [most core compute regions](https://www.linode.com/global-infrastructure/), but is not yet available in distributed compute regions. LKE Enterprise has been released with limited availability and is only available in select regions.

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#pricing)

For LKE clusters, the basic control plane infrastructure is provided at no additional cost. An upgrade to a [high availability control plane](https://techdocs.akamai.com/cloud-computing/docs/high-availability-ha-control-plane-on-lke) is priced starting at $60/month per cluster, depending on region. All other resources consumed by the cluster are billed at the normal rate, including Linodes, NodeBalancers, and Block Storage volumes. LKE Enterprise clusters are available to approved customers at $300/month in addition to any resources consumed by the cluster. Review the [Pricing](https://www.linode.com/pricing/#kubernetes) page for more information on those costs.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#technical-specifications)

- **Equipped with a fully-managed control plane**. While the control plane is fully-managed, the user is responsible for managing their deployment configuration and applications.
- **Kubernetes version availability:** When deploying your cluster, you can select from multiple Kubernetes versions. These are periodically updated with the latest features and security updates. We also regularly make new Kubernetes versions available and remove older versions when they are no longer supported.
- **Linode plans supported:** Dedicated CPU, Shared CPU, High Memory, and Premium CPU (excluding the 512 GB size for both Dedicated CPU and Premium CPU). GPU plans are supported on non-enterprise LKE only at this time. See the [Pricing](https://www.linode.com/pricing/) page for the compute resources included in each plan.
- 40 Gbps inbound network bandwidth
- Free inbound network transfer
- Provisioning and management through [Cloud Manager](https://cloud.linode.com/), [Linode CLI](https://www.linode.com/products/cli/), or programmatically through the [Linode API](https://www.linode.com/products/linode-api/)

# [Developer resources](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine#developer-resources)

- **[Linode API](https://techdocs.akamai.com/linode-api/reference/api)** provides the ability to programmatically manage the full range of Akamai cloud computing products and services.
  - [Linode Kubernetes Engine Endpoint Collection](https://techdocs.akamai.com/linode-api/reference/post-lke-cluster)
- **[Linode CLI](https://github.com/linode/linode-cli)** is a wrapper around the Linode API that lets you manage your account and resources from the command line. Learn how to use the Linode CLI to [create and manage LKE clusters](https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-lke).
- **Terraform**: Terraform is an Infrastructure-as-code tool that includes management features for various types of Akamai Cloud resources. Use Akamai's [official Terraform Provider](https://www.terraform.io/docs/providers/linode/r/volume.html) to [provision Linode Kubernetes Engine Clusters](https://linode.com/docs/guides/deploy-lke-cluster-using-terraform/).