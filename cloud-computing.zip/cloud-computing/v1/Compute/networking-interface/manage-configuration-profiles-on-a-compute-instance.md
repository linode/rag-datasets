# [Manage configuration profiles on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#manage-configuration-profiles-on-a-linode)

A **configuration profile** functions as a boot loader for a Linode. It controls general boot settings, including the disk the Linode will boot from, the disks that will be mounted, the kernel that will be used, and the network interfaces on the Linode. Multiple configuration profiles can be created, each one booting from different disks with different settings. This can allow you to try out new Linux distributions without paying for additional Linodes (see [Deploy an image to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-an-existing-compute-instance)) or to create custom software testing environments.

# [View configuration profiles](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#view-configuration-profiles)

The configuration profiles for a Linode can be viewed and managed from [Cloud Manager](https://cloud.linode.com).

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.

2. Navigate to the **Configurations** tab to view the configuration profiles on a Linode.

   

From here, a [configuration profile can be created](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#create-a-configuration-profile) using the **Add Configuration** button. To take action on an certain configuration, locate it within the **Configurations** table and select from the list of actions, some or all of which may appear within the **ellipsis** menu:

- **Boot:** Boots the Linode using the settings defined within the selected configuration profile. See [Boot from a configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#boot-from-a-configuration-profile).
- **Edit:** Modify the settings within a configuration profile. See [Edit a configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#edit-a-configuration-profile).
- **Clone:** Clones the configuration profile and the attached disks to any Linode on the same account. See [Clone a configuration profile and the attached disks](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#clone-a-configuration-profile-and-the-attached-disks).
- **Delete:** Deletes the configuration profile. See [Delete a configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#delete-a-configuration-profile).

# [Settings](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#settings)

When adding or editing a configuration profile on a Linode, the following settings are available:

- **Virtual Machine:** VM mode determines whether devices inside your virtual machine are _paravirtualized_ or _fully virtualized_. Here are the drivers used for various devices in each mode:

  | Device  | Paravirtualization | Full virtualization |
  | ------- | ------------------ | ------------------- |
  | Block   | VirtIO SCSI        | IDE                 |
  | Network | VirtIO Net         | e1000               |
  | Serial  | ttyS0              | ttyS0               |

  Since paravirtualization offers more performant networking and disk IO, it is the recommended mode. All of the Linux distributions we provide support paravirtualization. When installing an operating system not offered by us, full virtualization may be required if that OS does not include virtualization-aware drivers.

- **Boot Settings:**
  - **Kernel:** Select the version of the Linux kernel that will be used. The options include Grub 2 (for upstream or custom-compiled kernels), a specific Linode-supplied kernel, or Direct Disk. For most distributions, its recommended to set this option to _Grub 2_. See [Manage the kernel on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manage-the-kernel-on-a-compute-instance).
  - **Run Level:** Adjust the [run level](https://en.wikipedia.org/wiki/Runlevel) of the OS to allow for advanced diagnostics. Recommended setting: _Run Default Level_.
  - **Memory Limit:** Limits the amount of memory that the Linode can use. Recommended setting: _Do not set any limits on memory usage_.

- 
**Block Device Assignment:**
 Assigns the Linode's disks to the disk devices in Linux, making them accessible once the Linode has booted up. Up to 8 disks can be assigned (`/dev/sda` through `/dev/sdg`), though it's common to only use the first two devices: `/dev/sda` as the main disk and `/dev/sdb` as the swap disk. The **Root Device** is used to select the primary disk device (commonly `/dev/sda`), though another predefined device or custom device path can be used.

  > > Note: 
  > 
  > In some distribution images, block devices are assigned using [UUIDs](https://en.wikipedia.org/wiki/Universally_unique_identifier) in the `/etc/fstab` file to support proper disk mounting. In order to see the UUID assigned to each block device, you can use the `lsblk` command:
  > 
  > ````
  > ```
  > lsblk -f
  > ```
  > This displays block devices for your booted configuration and their current mount points:
  > 
  > ```text Output
  > NAME FSTYPE FSVER LABEL       UUID                                 FSAVAIL FSUSE% MOUNTPOINTS
  > sda  ext4   1.0   linode-root cfa3834a-c6ec-0c85-1b68-6345a69f3759   14.3G    20% /
  > sdb  swap   1                 208b24eb-47fe-4e6b-907a-d70d24af0cf0                [SWAP]
  > sdc  ext4   1.0   linode-root 72a6eb6d-941c-bf66-c5e7-636242a1efbe
  > ```
  > ````

- **Network Interfaces:** Configures network interfaces for the Public Internet, a [VPC](https://techdocs.akamai.com/cloud-computing/docs/vpc), or a [VLAN](https://techdocs.akamai.com/cloud-computing/docs/vlan). There are a total of 3 available network interfaces, which correspond to the devices assigned within the Linux system: `eth0`, `eth1`, and `eth2`. If no VLANs or VPCs are in use, the recommended setting is _Public Internet_ for `eth0` and _None_ for all other interfaces. When assigning an Linode to a VPC, it's recommended to use `eth0` for the VPC interface. If public internet is required along with a VPC, configure the VPC interface as a 1:1 NAT with internet access (the _Assign a public IPv4 address for this Linode_ option under the VPC interface) instead of designating a separate network interface as _Public Internet_. For more details on assigning a Linode to a VPC or VLAN, review the appropriate documentation:

  - [Assign a Linode to a VPC](https://techdocs.akamai.com/cloud-computing/docs/assign-a-compute-instance-to-a-vpc)
  - [Attach a VLAN to a Linode](https://techdocs.akamai.com/cloud-computing/docs/attach-a-vlan-to-a-compute-instance)

- **Filesystem / Boot Helpers:** Various helper tasks that run when the Linode is booted up. Recommended setting for all helpers: _Enabled_.
  - **Enable distro helper:** Helps maintain correct inittab/upstart console device.
  - **Disable `updatedb`:** Disables `updatedb` cron job to avoid disk thrashing.
  - **Enable modules.dep helper:** Creates a module dependency file for the kernel you run.
  - **Auto-mount devtmpfs:** Controls if `pv_ops` kernels auto-mount devtmpfs at boot.
  - **Auto-configure networking:** Automatically configures static networking. See the [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) documentation.

# [Create a configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#create-a-configuration-profile)

Making a new configuration profile lets you create a new and separate boot configuration for your system. You can specify boot settings and disks to mount. Here's how to create a new configuration profile:

1. Within [Cloud Manager](https://cloud.linode.com), view the Configuration Profiles for your desired Linode. See [View configuration profiles](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#view-configuration-profiles).

2. Select the **Add a Configuration** link. The **Add Configuration** form appears:

3. Enter the _Label_ for the new configuration, as well as an optional _Comment_.

4. Complete the remainder of the form, referencing the [Settings](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#settings) section above for additional details and recommended values. For most basic configurations, it's recommended to adjust the following settings:
   - **Kernel:** Select _Grub 2_.
   - **Block Device Assignments:** Set `/dev/sda` to the disk you want to use as the primary disk (and boot disk) and set `/dev/sdb` to the swap disk.

5. Click **Add Configuration** to create the new configuration profile.

# [Edit a configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#edit-a-configuration-profile)

You can edit existing configuration profiles to change boot settings, set other disks to mount, and more. Here's how to edit a configuration profile:

1. Within [Cloud Manager](https://cloud.linode.com), view the Configuration Profiles for your desired Linode. See [View configuration profiles](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#view-configuration-profiles).

2. Within the **Configurations** table, locate the configuration profile you wish to modify and click the corresponding **Edit** button, which may also appear within the **ellipsis** menu. This displays the **Edit Configuration** form.

3. Adjust any settings as needed, referencing the [Settings](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#settings) section above for additional details and recommended values.

4. Once finished, click **Save Changes**.

The changes to the configuration profile have been saved. You may need to reboot your Linode to activate the changes.

# [Boot from a configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#boot-from-a-configuration-profile)

You can create and store many different configuration profiles in Cloud Manager, but you can only boot your Linode from one configuration profile at a time. Here's how to select a configuration profile and boot your Linode from it:

1. Within [Cloud Manager](https://cloud.linode.com), view the Configuration Profiles for your desired Linode. See [View configuration profiles](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#view-configuration-profiles).

2. Within the **Configurations** table, locate the configuration profile you wish to modify and click the corresponding **Boot** button, which may also appear within the **ellipsis** menu.

3. A confirmation dialog window will appear. Click **Boot** to confirm.

4. The Linode will boot (or reboot) using the selected configuration profile. The progress of the boot can be viewed from the Linode's status.

You have successfully selected and booted your Linode from a configuration profile.

# [Determine which configuration profile was used](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#determine-which-configuration-profile-was-used)

When a Linode is powered on or rebooted, it uses the settings stored within a configuration profile. You can determine which configuration profile was used by looking at the event history. Events are visible within the **Activity Feed** tab for a particular Linode or within the main [Events](https://cloud.linode.com/events) page for the account.

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.

2. Navigate to the **Activity Feed** tab to view all events for the Linode.

3. Locate the particular boot or reboot event and review the text. The configuration profile used during that boot will be mentioned here.

   

   Sometimes the boot or reboot event doesn't list a configuration profile, such as when the [Lassie Shutdown Watchdog](https://techdocs.akamai.com/cloud-computing/docs/recover-from-unexpected-shutdowns-with-lassie) initiates the event. In this case, look at the most recent reboot or boot event which does include the configuration profile that was used.

# [Clone a configuration profile and the attached disks](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#clone-a-configuration-profile-and-the-attached-disks)

A configuration profile, along with any attached disks, can be duplicated to any _other_ Linode on the account. See [Clone to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/clone-a-compute-instance#clone-to-an-existing-compute-instance) for instructions.

# [Delete a configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#delete-a-configuration-profile)

You can remove a configuration profile from Cloud Manager at any time. Here's how:

1. Within [Cloud Manager](https://cloud.linode.com), view the Configuration Profiles for your desired Linode. See [View configuration profiles](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#view-configuration-profiles).

2. Within the **Configurations** table, locate the configuration profile you wish to modify and click the corresponding **Delete** button, which may also appear within the **ellipsis** menu.

3. A confirmation dialog window will appear. Click **Delete** to confirm.

4. The Linode will boot (or reboot) using the selected configuration profile. The progress of the boot can be viewed from the Linode's status.