# [Upgrade Configuration profile interfaces to Linode interfaces (BETA)](https://techdocs.akamai.com/cloud-computing/docs/upgrading-config-profile-interfaces-to-linode-interfaces#upgrade-configuration-profile-interfaces-to-linode-interfaces-beta)

Use this procedure to automatically upgrade all configuration profile interfaces belonging to a specific Linode to Linode interfaces.

After the upgrade:

- New Linode interfaces are created to match the existing configuration profile interfaces.
- The Linode will only use Linode interfaces and cannot revert to configuration profile interfaces.
- Private IPv4 addresses are not supported on public Linode interfaces—services relying on a private IPv4 will no longer function.
- All firewalls are removed from the Linode. Any previously attached firewalls are reassigned to the new public and VPC interfaces. Default firewalls are not applied if none were originally attached.
- Public interfaces retain the Linode’s existing MAC address and SLAAC IPv6 address.
- Configuration profile interfaces are removed from the **Configurations** tab. The new Linode interfaces will appear in the **Network** tab.

 > Error: This action is irreversible
  You can upgrade a Linode that uses a legacy configuration profile interface to use a Linode interface. However, this action is irreversible—once upgraded, configuration profile interfaces can no longer be used. Additionally, Linode interfaces do not support private IPv4 addresses. As a result, Linodes using Linode interfaces cannot be used with products that require private IPs.

1. Log in to [Cloud Manager](https://cloud.linode.com).
2. Click the **Linodes** link in the sidebar and select a Linode from the list.
3. Power off the Linode.
4. Click the **Upgrade** button.

![A screenshot of the Linode's summary page showing the Upgrade button.](https://techdocs.akamai.com/linode/compute/img/linodes-upgrade-interfaces-button-v1.png)

5. Click **Upgrade Dry Run** to verify and resolve potential conflicts before the upgrade.  
   ![The Upgrade Dry Run button](https://techdocs.akamai.com/linode/compute/img/linodes-upgrade-dry-run-v1.png)

- If there are any issues, follow the on-screen instructions to fix them.
- If there aren't any issues, move on to the next step.

5. Click **Upgrade Interfaces**.  
   ![The Upgrade Interfaces button](https://techdocs.akamai.com/linode/compute/img/linodes-upgrade-interfaces-submit-v1.png)

6. After the upgrade, click **Close**.  
   ![The Close button](https://techdocs.akamai.com/linode/compute/img/linodes-upgrade-successful-close-v1.png)
 
7. Power on the Linode.