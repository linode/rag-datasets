# [Manage Linode interfaces (BETA)](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#manage-linode-interfaces-beta)

Linode interfaces offer an alternative to the existing configuration profile interfaces for Linode networking. They are directly associated with a given Linode. 

Interfaces are active as soon as an interface is created for a Linode, or you have opted-in for using them by default on your account. For more information, see [Set up networking](https://techdocs.akamai.com/cloud-computing/docs/create-a-linode-with-network-interfaces#set-up-networking) and [Select network interfaces for new Linodes ](https://techdocs.akamai.com/cloud-computing/docs/select-network-interfaces-for-new-linodes).

This section covers how to manage VPC, public and VLAN Linode interfaces. For information on Configuration Profile Interfaces, see [Manage configuration profiles on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance).

## [View Linode interfaces](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#view-linode-interfaces)

The Linode interfaces for a Linode can be viewed and managed from [Cloud Manager](https://cloud.linode.com).

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.

2. Navigate to the **Network** tab to view the Linode interfaces on a Linode.

   

From here, you can view and edit **Interface Settings** or use the **Add Network Interface** button.

Click on the **ellipsis (...) menu** of a network interface to view, edit, or delete it: 

- **Details**. View details about the network interface.
- **Edit**. Modify the network interface's settings. See [Edit public or VPC network interfaces](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces-new#edit-public-or-vpc-network-interfaces).
- **Delete**. Delete the network interface. See [Delete Linode interfaces](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces-new#delete-linode-interfaces).

## [Create a public, VPC, or VLAN network interface](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#create-a-public-vpc-or-vlan-network-interface)

A Linode can have up to three interfaces:

- Only one public interface is allowed on a Linode.
- Multiple VLAN interfaces are allowed, provided that they belong to distinct VLANs.
- One VPC interface is allowed.

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.
2. Power off the Linode.
3. Click the **Network** tab.
4. Click the **Add Network Interface** button.

5. Select the interface type you want to add and fill in the form. For more information, see [Set up networking](https://techdocs.akamai.com/cloud-computing/docs/create-a-linode-with-networking-interfaces#set-up-networking). 
6. Click **Add Network Interface**. 
7. Power on the Linode for the changes to take effect. 

## [Edit the Linode's default route and Network Helper settings](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#edit-the-linodes-default-route-and-network-helper-settings)

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.

2. Click the **Network** tab.

3. Click the **Interface Settings** link.

4. Modify the settings.

- **Default Route Selection**. The default route is the route your Linode uses when traffic doesn’t have a specific route to a destination.  
  If the [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#edit-the-s-default-route-and-network-helper-settings) is enabled, power off the Linode. For **Default IPv4 Route**, select the VPC or Public Interface. For **Default IPv6 Route**, select the Public Interface. The default route may change automatically when modifying interfaces.
- **Network Helper**. Automatically configures the network settings on your Linode when it boots. Its main purpose is to ensure that the instance can connect to the network (public, VPC, or VLAN) without requiring manual configuration of things like IP addresses, gateways, or DNS.  
  To enable or disable Network Helper, power off the Linode and move the **Enable Network Helper** slider.

5. Click **Save**. 

## [Edit public or VPC network interfaces](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#edit-public-or-vpc-network-interfaces)

 > Warning: You can't edit VLAN interfaces
  If you want to make changes to a VLAN interface, delete it and create it from scratch.

### [Edit Public Interface](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#edit-public-interface)

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.
2. If the [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#edit-the-s-default-route-and-network-helper-settings) is enabled, power off the Linode. Otherwise, move to the next step.
3. Click the **Network** tab.
4. Within the **Network Interfaces** table, locate the Public Interface, navigate to the **ellipsis menu** and click **Edit**. This displays the **Edit Public Interface** form.
5. Adjust any settings as needed. If you wish to revert your changes, click **Reset**.

- **IPv4 address**. You can add/remove IPv4 addresses and make them primary.
  - **Add IPv4 address**.  Adding additional IPv4 addresses require justification. Contact [Support](https://cloud.linode.com/support/tickets). After you get the approval, click **Add IPv4 Address**. The IP is allocated automatically after you save your changes. 
  - **Set the primary IP address**. The primary IPv4 address is defined as the IPv4 address assigned to your system that is in the first position when sorted numerically. If there are more IPv4 addresses, you can make one of them primary by clicking **Make Primary**. 
  - **Remove IPv4 address**. You can delete the IPv4 address by clicking **Remove**.
- **IPv6 ranges**. IPv6 addresses are allocated as ranges, which you can choose to distribute and further route yourself. 
  - **Add IPv6 /56 and /64 ranges**. The ranges are allocated automatically after you save your changes.
  - **Remove IPv6 range**. You can delete an IPv6 range by clicking **Remove**.
- **Firewall**. Secure your Linode by assigning a Cloud Firewall to the Public interface. To assign a firewall, click on the dropdown menu and select it from the list. To unassign a firewall, click **x** next to the firewall's name.

6. Click **Save**. 
7. Power on the Linode for the changes to take effect.

### [Edit VPC interface](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#edit-vpc-interface)

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.
2. Click the **Network** tab.
3. If the [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#edit-the-s-default-route-and-network-helper-settings) is enabled, power off the Linode. Otherwise, move to the next step.
4. Within the **Network Interfaces** table, locate the VPC interface you wish to modify, navigate to the **ellipsis (...) menu** and click **Edit**. This displays the **Edit Network Interface** form.
5. Adjust any settings as needed. If you wish to revert your changes, click **Reset**.

- **IPv4 address**. If you want the IPv4 address to be assigned automatically, check the **Auto-assign a VPC IPv4 Address** option. If you want to manually assign an IP address, uncheck this option and enter your custom IPv4 address in the **VPC IPv4 Address** field.
  - **Assign or unassign a public IPv4 address**. If you wish to enable public internet access on this new Linode, check the **Assign a public IPv4 address for this Linode** option. You can also uncheck it, but you will not be able to access the internet from this Linode.
- **IPv4 ranges**. You can assign additional IPv4 ranges that can be used to reach this Linode and/or the services running on it. For example, you may wish to assign additional IPv4 ranges to directly expose Docker containers to the VPC. Click **Add IPv4 Range** and enter the value in the field that will appear. If you wish to remove the address, click the **x** icon.
- **Firewall**. Secure your Linode by assigning a Cloud Firewall to the VPC interface. To assign a firewall, click on the dropdown menu and select it from the list. To unassign a firewall, click **x** next to the firewall's name.

6. Click **Save**.
7. Power on the Linode for the changes to take effect.

## [Delete Linode interfaces](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#delete-linode-interfaces)

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.
2. Power off the Linode.
3. Click the **Network** tab. 
4. Within the **Network Interfaces** table, locate the network interface you wish to modify, navigate to the **ellipsis (...) menu** and click **Delete**.
5. Power on the Linode for the changes to take effect.