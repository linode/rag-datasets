# [Configure SSH access for Linode Managed](https://techdocs.akamai.com/cloud-computing/docs/configure-ssh-access-for-linode-managed#configure-ssh-access-for-linode-managed)

To troubleshoot an issue with a failed monitor check, our support team needs access to your system. Access can be provided by using the unique public key generated for your account. You can upload this key to any system user and then configure the SSH access settings for each Linode so our support team is aware of how they should log in. To start using your public key, follow these steps _for each Linode_ on your account.

1. View your account's public key.
2. Install the public key on your preferred system user.
3. Edit the SSH access settings for the Linode.

 > Note: 
  If you don't want to use this public key, you can also configure credentials in the form of usernames and passwords.

# [View your public key](https://techdocs.akamai.com/cloud-computing/docs/configure-ssh-access-for-linode-managed#view-your-public-key)

Akamai generates a unique public/private key pair for your account when you enable Linode Managed. You can access the public key on your account so that you can add it to each Linode. Our support team uses the private key to access your system whenever an issue requires investigation. 

To locate your public key:

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Managed** from the sidebar.

2. Select the **SSH Access** tab. Your public key is displayed at the top of this tab.

   

3. Hover over the public key box to view the full public key and click **Copy to clipboard** button.

# [Add the public key to your Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-ssh-access-for-linode-managed#add-the-public-key-to-your-linode)

Installing the public SSH key for the `root` user is the easiest way to add the Linode's public key to your server. 

 > Note: 
  If your server's SSH configuration doesn't allow [root login](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#ssh-daemon-options), you can skip to the next section to add the public key to another user's account.

1. Log in to your Linode through [LISH](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) or [SSH](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode).

2. Edit the SSH authorized keys file for whichever user account you want the Support Team to use when logging in.

   - **Root user**. Issue this command:

     ```
     sudo nano /root/.ssh/authorized_keys
     ```

     > > Note: 
     > 
     > If you followed the instructions in the [Securing Your Server](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance) guide to disable root login via SSH, you need to re-enable that feature. Follow the relevant instructions within the [Set Up and Secure](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#ssh-daemon-options) guide to edit the `sshd_config` file and re-enable root login via SSH.

   - **Limited user** (To edit the home directory as needed). Run this command:

     ```
     sudo nano /home/example_user/.ssh/authorized_keys
     ```

     > > Note: 
     > 
     > In general, [sudo privileges](https://linode.com/docs/guides/linux-users-and-groups/#understanding-the-sudo-linux-group-and-user) are needed to run many of the troubleshooting commands our Support Team might use. Whenever possible, you should grant the limited user sudo privileges. The [Adding a New User](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#add-a-limited-user-account) guide shows how to add your user to the `sudo` group (or `wheel` or `admin` group, depending on your distribution).
     > 
     > After adding the limited user account to the sudo group, you need to either provide the user's password to the Support Team (see [Add Credentials](https://techdocs.akamai.com/cloud-computing/docs/configure-ssh-access-for-managed-services#adding-service-credentials)) or enable passwordless sudo by following the instructions below.
     > 
     > 1. Edit the `sudoers` file. The following command opens the file using the [Nano](https://en.wikipedia.org/wiki/GNU_nano) text editor.
     > 
     >    ```
     >    nano sudoers
     >    ```
     > 
     > 2. Navigate to the _User privilege specification_ section of the file using arrow keys. 
     > 3. Add the following line, replacing `example_user` with your user name:
     > 
     >    ```
     >    example_user ALL=(ALL) NOPASSWD: ALL
     >    ```
     > 
     > 4. Make sure that this user is not in any other groups listed in /etc/sudoers, as this may override the passwordless sudo setting.
     > 
     > 5. Press **CTRL+X** and then **Y** to save the changes.

3. If the `.ssh` directory doesn't exist for your user or the root user, you can create it with the following command, replacing _[directory]_ with `/home/example_user/.ssh/` or `/root/.ssh/`, adjusting the path as needed for your user.

   ```
   mkdir [directory]
   ```

4. Paste your public key to a new line in the file.

5. Save the changes to the file and exit your text editor. In the `nano` editor, type `Ctrl` > `X` > `Y`.

Once you've added the public key to your preferred user, you may need to allow access from our infrastructure (see [Configure Firewall Rules to allow access](https://techdocs.akamai.com/cloud-computing/docs/configure-firewall-rules-to-allow-access-from-linode-infrastructure) for more information.) If you wish to confirm that everything is properly configured, [open a support ticket](https://techdocs.akamai.com/cloud-computing/docs/help-and-support#contact-customer-support) to have the Support team confirm that they have access. Repeat this process on every Linode you want to monitor.

# [Edit SSH access settings for each Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-ssh-access-for-linode-managed#edit-ssh-access-settings-for-each-linode)

After adding your public key to each Linode you want to monitor, make sure to edit the SSH access settings for those Linodes (and any other iLinode on your account). These settings are used to confirm that SSH access has been enabled and, if so, on which user and port. The following settings can be specified:

- **SSH Access**. Specifies if SSH access is enabled for the Linode (default: _Enabled_).

- **User**. The user account that the Support team should use (default: _root_).

- **IP**. The IP address that the Support team should use (default: _Any_). This is only needed if your Linode has multiple IP addresses and only certain ones allow SSH connections.

- **Port**. The SSH port on the system (default: _22_). Only change this if your system is using a non-standard port for SSH connections.

 > Note: 
  Modifying these SSH access settings for a Linode **does not change** anything internally on your system. These settings are only used to communicate access details to the Support team.

Follow the steps below to edit the SSH access settings for each Linode.

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Managed** from the sidebar.

2. Select the **SSH Access** tab and scroll down to view a list of Linodes on your account.

3. Locate the Linode you want to modify and click **Edit**.

   

4. Update the SSH access details with the appropriate values for your system. Once you're done, click the **Save Changes** button.