# [Get started with Linode Managed](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-managed-service#get-started-with-linode-managed)

[Linode Managed](https://www.linode.com/products/managed/) is a 24/7 incident response service coupled with Longview Pro, our Backups service, cPanel, and additional dashboard metrics. This robust system sends out monitoring checks to ensure that your monitored services remain online and available at all times. Linode Managed can monitor any service or software stack reachable over TCP or HTTP.

# [Enable managed services](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-managed-service#enable-managed-services)

 > Warning: 
  This is an account-wide setting. Enabling Linode Managed creates additional charges _for each_ Linode on your account. If you only want to enable this for some Linodes, you need to create a separate account without Linode Managed and transfer any services you don't want administered to that account. See [Transfer services to a different account](https://techdocs.akamai.com/cloud-computing/docs/transfer-services-to-a-different-account).

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Administration** link in the sidebar.

2. Select the **Settings** tab and click the **Add Linode Managed** button at the bottom of this page.

3. A confirmation dialog appears that outlines the total cost of the service for your account. Click the **Add Linode Managed** button in this confirmation dialog to enable Linode Managed.

# [Initial setup](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-managed-service#initial-setup)

Now you need to configure which services or resources you'd like to monitor on your Linodes, allow the Support team to log in to the Linodes and access these services, and then let the Support team know who to contact in case of a failure.

1. **Provide access to the Support team**. In order to investigate any issues with your Linodes, our Support team requires access to those Linodes. Because of this requirement, you should install your unique Managed Services public key on any Linode you intend for us to monitor. You may also need to add any credentials that are specific to the applications or services you are running. For example, if you run a WordPress site that communicates with a MySQL database, you should provide the MySQL username and password if you would like us to troubleshoot it in the event of outage for your site. See the following guides:

   - [Configure SSH Access](https://techdocs.akamai.com/cloud-computing/docs/configure-ssh-access-for-managed-services)
   - [Manage Credentials](https://techdocs.akamai.com/cloud-computing/docs/configure-credentials-for-managed-services)
   - [Configure Firewall Rules to allow access](https://techdocs.akamai.com/cloud-computing/docs/configure-firewall-rules-to-allow-access-from-linode-infrastructure)

2. **Configure contacts**. If a service monitor fails a check, all associated contacts are notified. Contacts may also be contacted by the Support team if additional information is needed when troubleshooting. See [Manage Contacts](https://techdocs.akamai.com/cloud-computing/docs/manage-contacts-for-managed-services).

3. **Create service monitors**. Next, configure the actual monitors that are responsible for watching a particular website or service and checking for issues. You can even add checks to make sure specific strings of text appear on your monitored website or in the response body of your service. See [Create and Manage Service Monitors](https://techdocs.akamai.com/cloud-computing/docs/create-and-edit-service-monitors-for-managed-services).

# [Install cPanel (optional)](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-managed-service#install-cpanel-optional)

Each Linode on a Linode Managed account is eligible to receive a [cPanel](https://cpanel.net/) license at no additional charge.

1. **Installing cPanel**. The easiest method to quickly get cPanel up and running is to deploy a new Linode using its Marketplace app. Review the [How to Deploy cPanel with Marketplace Apps](https://www.linode.com/docs/marketplace-docs/guides/cpanel/) guide for additional instructions. If the cPanel Marketplace App doesn't support your desired Linux distribution, you can also follow the instructions in the [Install cPanel on CentOS](https://linode.com/docs/guides/install-cpanel-on-centos/) guide or the [Installation Guide](https://docs.cpanel.net/installation-guide/) on cPanel's documentation site. Currently, both Akamai and cPanel support these distribution images: CentOS 7, AlmaLinux 8, Rocky Linux 8, and Ubuntu 20.04 LTS. See [What operating systems are supported by cPanel](https://support.cpanel.net/hc/en-us/articles/1500001216582-What-operating-systems-are-supported-by-cPanel-) for a full list.

2. **Obtaining a License**. Contact the Support team to obtain a cPanel license for your Linode. If you don't subscribe to Linode Managed, you need to get your license directly from cPanel. cPanel is typically licensed by the number of accounts within the cPanel installation, each account typically corresponding to a single website or group of similar websites. The license we provide will automatically scale based on the number of cPanel accounts you've configured.