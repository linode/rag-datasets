# [Configure credentials for Linode Managed](https://techdocs.akamai.com/cloud-computing/docs/configure-credentials-for-linode-managed#configure-credentials-for-linode-managed)

Many of the applications running on your servers can only be accessed with the appropriate username and password combination. To provide Akamai with access to those applications, you should upload _credentials_ for them to the Cloud Manager. Once uploaded, you can also link credentials to specific Linode Managed to communicate which ones Support should use when troubleshooting the service.

 > Note: 
  All credentials are securely stored in our encrypted database.

# [View credentials](https://techdocs.akamai.com/cloud-computing/docs/configure-credentials-for-linode-managed#view-credentials)

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Managed** link in the sidebar.

2. Navigate to the **Credentials** tab. A list of all your current credentials is displayed. From here, you can add new credentials or edit existing credentials.

   

   Alongside each credential is a _Last Decrypted_ field. This displays the timestamp for when the credential was last decrypted by our Support team.

# [Add a credential](https://techdocs.akamai.com/cloud-computing/docs/configure-credentials-for-linode-managed#add-a-credential)

1. Navigate to the **Credentials** tab for Linode Managed in Cloud Manager. See [View Credentials](https://techdocs.akamai.com/cloud-computing/docs/configure-credentials-for-managed-services#view-credentials).

2. Click the **Add Credentials** button.

3. In the form that appears, enter the details for your credential. The following fields are available:

   - **Label** (required): A descriptive name for the credential that explains to the Support Team how the credential should be used. For example, if you are entering the MySQL `root` password, you might label it as `MySQL Root`.

   - **Username:** The username to supply when authenticating with the application.

   - **Password** (required): The password or passphrase to supply when authenticating with the application.

4. Once the form is complete, click the **Add Credential** button.

# [Edit a credential](https://techdocs.akamai.com/cloud-computing/docs/configure-credentials-for-linode-managed#edit-a-credential)

1. Navigate to the **Credentials** tab for Linode Managed in Cloud Manager. See [View Credentials](https://techdocs.akamai.com/cloud-computing/docs/configure-credentials-for-managed-services#view-credentials).

2. Locate the credential you wish to edit and click the corresponding **Edit** button.

3. To update the label, enter the new label and click the **Update Label** button.

4. To modify the credentials, enter the new username or password and click the **Update Credentials** button.