# [Configure firewall rules to allow access for Linode Managed](https://techdocs.akamai.com/cloud-computing/docs/configure-firewall-rules-to-allow-access-from-linode-infrastructure#configure-firewall-rules-to-allow-access-for-linode-managed)

As a Linode Managed customer, you may need to add or modify your firewall rules to allow access from our infrastructure. By following this process and [configuring SSH access for Linode Managed](https://techdocs.akamai.com/cloud-computing/docs/configure-ssh-access-for-managed-services), you let our Support team log in to your system and troubleshoot issues. Our infrastructure can also perform the checks configured on your monitors. The exact procedure varies based on the firewall software you're using. 

Check out these guides for help configuring firewalls:

- **Cloud Firewalls**. [Manage Cloud Firewalls Rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules)
- **UFW**. [How to Configure a Firewall with UFW](https://linode.com/docs/guides/configure-firewall-with-ufw/)
- **FirewallD**. [Introduction to FirewallD on CentOS](https://linode.com/docs/guides/introduction-to-firewalld-on-centos/)
- **iptables**. [Controlling Network Traffic with iptables - A Tutorial](https://linode.com/docs/guides/control-network-traffic-with-iptables/)

## [Incident response infrastructure](https://techdocs.akamai.com/cloud-computing/docs/configure-firewall-rules-to-allow-access-from-linode-infrastructure#incident-response-infrastructure)

Allow the following hostnames and IP addresses so that our incident response team can access your server.

```
blackbox1-dallas.linode.com 50.116.31.27
blackbox1-newark.linode.com 66.175.214.213
```

# [Monitor infrastructure](https://techdocs.akamai.com/cloud-computing/docs/configure-firewall-rules-to-allow-access-from-linode-infrastructure#monitor-infrastructure)

Allow the following hostnames and IP addresses so that our infrastructure can perform the checks configured on your monitors:

Compute region | Command |  **Atlanta**  |  ``` monitor1-atlanta.linode.com 2600:3c02::f03c:91ff:feae:8540 66.228.57.137 monitor2-atlanta.linode.com 2600:3c02::f03c:91ff:feae:69d5 50.116.38.168 ```   
 ---|---  
 **Dallas**  |  ``` monitor1-dallas.linode.com 2600:3c00::f03c:91ff:feae:8351 50.116.25.212 monitor2-dallas.linode.com 2600:3c00::f03c:91ff:feae:47d9 198.58.98.236 ```   
 **Frankfurt**  |  ``` monitor1-frankfurt.linode.com 2a01:7e01::f03c:91ff:fe26:e120 139.162.128.25 monitor2-frankfurt.linode.com 2a01:7e01::f03c:91ff:fe26:8a6a 139.162.128.26 ```   
 **Fremont**  |  ``` monitor1-fremont.linode.com 2600:3c01::f03c:91ff:feae:85e2 50.116.11.198 monitor2-fremont.linode.com 2600:3c01::f03c:91ff:feae:47d3 66.175.221.50 ```   
 **London**  |  ``` monitor1-london.linode.com 2a01:7e00::f03c:91ff:feae:6965 176.58.113.114 monitor2-london.linode.com 2a01:7e00::f03c:91ff:feae:6924 178.79.189.96 ```   
 **Mumbai**  |  ``` monitor1-mum1.linode.com 2400:8904::f03c:91ff:fe5d:25b5 172.105.41.4 monitor2-mum1.linode.com 2400:8904::f03c:91ff:fe5d:2595 172.105.42.4 ```   
 **Newark**  |  ``` monitor1-newark.linode.com 2600:3c03::f03c:91ff:feae:832c 198.74.56.5 monitor2-newark.linode.com 2600:3c03::f03c:91ff:feae:4766 198.74.59.104 ```   
 **Singapore**  |  ``` monitor1-singapore.linode.com 2400:8901::f03c:91ff:fe33:54f2 103.3.60.25 monitor2-singapore.linode.com 2400:8901::f03c:91ff:fe33:5401 103.3.60.26 ```   
 **Sydney**  |  ``` monitor1-syd1.linode.com 2400:8907::f03c:92ff:fe67:b794 172.105.176.9 monitor2-syd1.linode.com 2400:8907::f03c:92ff:fe67:b74f 172.105.162.10 ```   
 **Tokyo**  |  ``` monitor1-shg1.linode.com 2400:8902::f03c:91ff:fe2c:ff57 139.162.65.25 monitor2-shg1.linode.com 2400:8902::f03c:91ff:fe2c:6eda 139.162.65.26 ```   
 **Toronto**  |  ``` monitor1-tor1.linode.com 2600:3c04::f03c:91ff:fe82:1151 172.105.0.13 monitor2-tor1.linode.com 2600:3c04::f03c:91ff:fe82:de74 172.105.14.4 ``` 