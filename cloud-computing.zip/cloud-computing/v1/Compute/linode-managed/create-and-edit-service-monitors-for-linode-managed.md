# [Create and edit service monitors for Linode Managed](https://techdocs.akamai.com/cloud-computing/docs/create-and-edit-service-monitors-for-linode-managed#create-and-edit-service-monitors-for-linode-managed)

Linode Managed monitors the _services_ running on your Linodes. Setting up services is an essential step in the configuration process.

# [View service monitors](https://techdocs.akamai.com/cloud-computing/docs/create-and-edit-service-monitors-for-linode-managed#view-service-monitors)

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Managed** from the sidebar.

2. Select the **Monitors** tab. A list of your current monitors is displayed. From here, you can add new monitors or edit existing ones.

   

   Each monitor is listed along side its status and the resource it's checking.

# [Configuration options](https://techdocs.akamai.com/cloud-computing/docs/create-and-edit-service-monitors-for-linode-managed#configuration-options)

Each monitor can be configured with the following settings, which are available when creating a new service monitor or editing an existing monitor.

- **Monitor Label** (required). A label for the service that's being monitored. If an issue arises, a clear and descriptive label helps the Support team quickly identify the service that may need troubleshooting.

- **Contact Group:** Select a contact group, which contains one or more contacts on your team. This is the group that is notified of any failed checks. It is also the group that the Support team may contact if more information is needed when investigating an issue with the service. To add or modify contacts, see [Manage Contacts](https://techdocs.akamai.com/cloud-computing/docs/manage-contacts-for-managed-services).

- **Monitor Type** (required). Select **URL** to monitor a website or **TCP Connection** to monitor any other service running on your Linode.

- **Response Timeout** (required). The time (in seconds) for a monitor's requests to timeout if a response is not received.

- **URL** (required): If you selected **URL** for the **Monitor Type** field, enter a URL for a web page that you'd like to monitor. If you selected **TCP Connection**, enter the domain or IP address and, optionally, a port number (separated by a colon) in the **TCP** field.

- **Response Body Match**. A string that should appear in the HTTP or TCP response body. If not present, then an alert is generated for the service.

- **Instructions / Notes**. Any notes or additional information about this service. This information is used by the Support team to learn more about the service, it's configuration, and the way it should respond to failed checks.

- **Credentials**. Any credentials that may need to be used to troubleshoot the service. You can select and save more than one credential for a service. To add or modify credentials, see [Manage Credentials](https://techdocs.akamai.com/cloud-computing/docs/configure-credentials-for-managed-services).

# [Add a service monitor](https://techdocs.akamai.com/cloud-computing/docs/create-and-edit-service-monitors-for-linode-managed#add-a-service-monitor)

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Managed** from the sidebar.

2. Select the **Monitors** tab.

3. Click **Add Monitor**.

4. In the form that appears, enter your [desired settings](#configuration-options) . 

5. Once you're ready, click **Add Monitor**. The new service monitor is created.

# [Edit a service monitor](https://techdocs.akamai.com/cloud-computing/docs/create-and-edit-service-monitors-for-linode-managed#edit-a-service-monitor)

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Managed** from the sidebar.

2. Select the **Monitors** tab.

3. Locate the service monitor you want to modify and click **Edit**.

4. Modify relevant fields and click**Save Changes**.

# [Enable or disable a service monitor](https://techdocs.akamai.com/cloud-computing/docs/create-and-edit-service-monitors-for-linode-managed#enable-or-disable-a-service-monitor)

When you create a service monitor, it's automatically enabled. However, you may need to temporarily disable the monitor. For instance, when you're performing maintenance on the monitored resource or on the entire Linode, you likely don't want the service monitor checking because it alerts your team (and our Support team) when the check fails. Follow these steps to disable the monitor and then re-enable it once the maintenance is complete.

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Managed** from the sidebar.

2. Select the **Monitors** tab.

3. Locate the service monitor you want to modify and click **Enable** or **Disable** for it. (These options may be in the expandable **...**  menu.)

Once the change takes effect, the new status should appear under the **Status** column of the service monitor.

# [Remove a service monitor](https://techdocs.akamai.com/cloud-computing/docs/create-and-edit-service-monitors-for-linode-managed#remove-a-service-monitor)

If you decide to remove or stop using a monitored service on your Linode, you should also remove the service monitor from your account. If you do not, you will continue to receive notifications when the service fails to contact the specified resource.

1. Log in to [Cloud Manager](https://cloud.linode.com) and select **Managed** from the sidebar.
2. Select the **Monitors** tab.
3. Locate the service monitor you wish to modify and click the corresponding **Delete** button. This button may be within the expandable **more options ellipsis menu**.
4. A confirmation dialog appears. Follow the instructions and click the **Delete Monitor** button to remove the monitor from your account.