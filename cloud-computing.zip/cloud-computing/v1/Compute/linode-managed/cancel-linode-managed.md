# [Cancel Linode Managed](https://techdocs.akamai.com/cloud-computing/docs/cancel-linode-managed#cancel-linode-managed)

If you no longer need Linode Managed, you can cancel it by [contacting the Support team](https://www.linode.com/support/). This removes all service monitors and any other data, such as saved credentials and contacts, that is stored as part of Linode Managed. In addition to this, the following services are also affected:

- **Backups Service**. By default, the Backups service for each Linode remains active. This means that all of your backups are retained and that you will be billed for this service going forward. If desired, you can make a note in your request to cancel Linode Managed that you also wish to remove all backup services. Otherwise, you can remove backups for individual Linodes by following the [Cancel Backups](https://techdocs.akamai.com/cloud-computing/docs/cancel-backups) guide.

- **Longview Pro**. If any Longview Pro clients have been configured, the Longview Pro service remains on your account as a paid service. Your Longview clients will continue to work as expected. If desired, you can make a note in your request to cancel Linode Managed that you also wish to cancel Longview Pro. If you do so, your Longview clients will be migrated to the free plan (which supports up to 10 clients). See [Longview Pricing and Plans](https://techdocs.akamai.com/cloud-computing/docs/longview).

- **cPanel**. When the service is cancelled, any cPanel licenses acquired through Linode Managed are also revoked. If you still wish to use cPanel, you can purchase licenses directly through the [cPanel website](https://cpanel.net/pricing/).

 > Note: 
  There is not currently a self-service option for cancelling Linode Managed in Cloud Manager, Linode CLI, or Linode API. You will need to contact the Support team to do so.