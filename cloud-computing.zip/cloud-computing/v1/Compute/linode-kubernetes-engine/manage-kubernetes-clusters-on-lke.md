# [Manage Kubernetes clusters on LKE](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke#manage-kubernetes-clusters-on-lke)

# [View Kubernetes clusters](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke#view-kubernetes-clusters)

Log in to [Cloud Manager](https://cloud.linode.com) and select Kubernetes from the left menu. If any LKE clusters exist on your account, they are listed on this page.

Each Kubernetes cluster in the matrix is displayed alongside the following details:

- **Version:** The Kubernetes version that the cluster is using.
- **Created:** The day and time the cluster was created.
- **Region:** The data center where the cluster resides.
- **Total Memory:** The total combined memory of all worker nodes in the cluster.
- **Total CPUs:** The total combined number of CPU cores in all worker nodes in the cluster.

# [Create a cluster](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke#create-a-cluster)

To create a new Kubernetes cluster within LKE, follow the instructions within the [Create a Cluster](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster) guide.

# [Review and edit a cluster](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke#review-and-edit-a-cluster)

Navigate to the **Kubernetes** page in Cloud Manager and select the cluster you wish to edit. See [View Kubernetes Clusters](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke#view-kubernetes-clusters).

This displays the details page for the selected cluster. From here, you can view the summary section (which includes the Kubernetes version, region, cost, and combined computing resources) as well as the following details:

- **Kubernetes API Endpoint**
- **Kubeconfig:** Download, view, and reset the Kubeconfig configuration file. This file outlines the configuration of your cluster and lets you connect to it.

There are also links to view the Kubernetes dashboard, upgrade the cluster to high availability, delete the cluster, and more. From here, you can also add, remove, recycle, and resize node pools (see [Manage Node Pools](https://techdocs.akamai.com/cloud-computing/docs/manage-nodes-and-node-pools)).

# [Delete a cluster](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke#delete-a-cluster)

Follow the steps below to delete an LKE cluster through the Cloud Manager. Once a cluster is deleted, it cannot be restored or otherwise recovered.

1. Navigate to the **Kubernetes** page in Cloud Manager and select the cluster you wish to delete. See [View Kubernetes Clusters](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke#view-kubernetes-clusters).

2. Within the summary and details section, click the **Delete Cluster** button.

3. A confirmation dialog appears. Click **Delete Cluster** to proceed with removing the Kubernetes cluster from your account.

 > Warning: Deleting an LKE cluster may not delete all associated services
  When an LKE cluster is deleted, some additional services associated with that cluster remain active on your account. These services include NodeBalancers and Block Storage volumes. To avoid further charges, delete these services manually through the Cloud Manager, Linode CLI, or Linode API.