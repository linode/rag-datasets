# [Getting Started with the Akamai App Platform](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#getting-started-with-the-akamai-app-platform)

# [Create an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#create-an-lke-cluster)

1. Log in to the Cloud Manager.
2. Select **Kubernetes** from the left navigation menu and then click **Create Cluster**.
3. The **Create a Kubernetes Cluster** page appears. At the top of the page, you are required to select the following options
   1. In the **Cluster Label** field, provide a name for your cluster. The name must be unique between all of the clusters on your account. This name is how you identify your cluster in Cloud Manager’s dashboard.
   2. From the **Region** dropdown menu, select the region where you would like your cluster to reside.
   3. From the **Version** dropdown menu, select a Kubernetes version to deploy to your cluster.
4. In the **App Platform for LKE** section, select “Yes, enable App Platform for LKE”
   > > Note: 
   > 
   > The App Platform requires HA control plane to be enabled. When **App Platform for LKE** is enabled, HA control plane is automatically enabled.
5. In the **Add Node Pools** section, select the hardware resources for the Linode worker node(s) that make up your LKE cluster. To the right of each plan, select the plus + and minus - to add or remove a Linode to a node pool one at time.
   > > Note: 
   > 
   > The App Platform requires a node pool with at least 3 worker nodes with a total minimum of 16 GB memory and 12 CPUs. Linode plans that do not provide the minimal required resources can not be selected.
6. Select **Add** to include the node pool in your configuration. If you decide that you need more hardware resources after you deploy your cluster, you can make changes to your node pool(s) at any point.
7. Once a pool has been added to your configuration, it is listed in the **Cluster Summary** on the right-hand side of Cloud Manager detailing your cluster's hardware resources and monthly cost. Additional pools can be added before finalizing the cluster creation process by repeating the previous step for each additional pool.
8. When you are satisfied with the configuration of your cluster, click the **Create Cluster **button on the right hand side of the screen. Your cluster's detail page appears and your node pools are listed on this page. The LKE cluster is created and, once ready, the App Platform is installed. The installation of the App Platform takes between 10 and 15 minutes. When the installation is finished, the URL of the portal endpoint appears within the App Platform section. The progress of the installation is checked every 60 seconds. When the installation is still in progress, the URL of the portal endpoint is not displayed. Instead the message “Installation in progress” appears.
9. When the installation of both the LKE cluster and the App Platform is ready, click on the provided URL of the portal endpoint. You will then see the following sign-in page.

1. Continue with the next steps to get the initial credentials needed to sign in.

# [Access and download your kubeconfig](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#access-and-download-your-kubeconfig)

1. To access your cluster's kubeconfig, log in to your Cloud Manager account and navigate to the Kubernetes section.
2. From the Kubernetes listing page, click on your cluster's more options ellipsis and select Download kubeconfig. The file is saved to your computer's Downloads folder.
3. Open a terminal shell and save your kubeconfig file's path to the $KUBECONFIG environment variable. In the example command, the kubeconfig file is located in the Downloads folder, but you should alter this line with this folder's location on your computer:
   ```
   export KUBECONFIG=~/Downloads/kubeconfig.yaml
   ```

# [Obtain the initial access credentials and sign in](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#obtain-the-initial-access-credentials-and-sign-in)

1. Perform the following command to obtain the initial access credentials:
   ```
   kubectl get secret platform-admin-initial-credentials -n keycloak --template={{.data.password}} | base64 -d
   kubectl get secret platform-admin-initial-credentials -n keycloak --template={{.data.username}} | base64 -d
   ```
2. Copy the decoded password to your clipboard.
3. Sign in to the Console with the user and the decoded password provided in the output from step 1.
4. Change the initial password.

# [Provision Object Storage for the App Platform](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#provision-object-storage-for-the-app-platform)

When signed in to the console (the web UI of the App Platform), the first thing you’ll need to do is configure Object Storage. A configuration screen is displayed asking you if the App Platform should provision all the required buckets and access key for you. This is not required, but strongly recommended as this will prevent _out of disk space_ errors when using storage volumes for integrated applications. Using Object Storage also has the advantage to create backups of all databases used by the platform.

1. When asked to create all the required buckets and access key, click **Yes**.
2. Follow the instructions to [create a Personal Access Token](https://techdocs.akamai.com/linode-api/reference/get-started#personal-access-tokens) and make sure to select _Read/Write_ for the Object Storage category and _Read_ for the Kubernetes category. Copy the access token and optionally save it in a secure place.
3. Paste the new access token into the configuration screen and click **Submit** and **Deploy Changes** (in the top left)

All the required buckets and the access keys are created in your account and the App Platform is configured to use Object Storage to store persistent data and backups. The provided Personal Access Token will not be stored.

# [Onboard Teams and Users](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#onboard-teams-and-users)

You can now start enabling Applications, onboarding [Teams](https://techdocs.akamai.com/app-platform/docs/platform-teams) and create [Users](https://techdocs.akamai.com/app-platform/docs/platform-user-management). 

# [Additional Resources](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#additional-resources)

 > Note: Documentation for the Akamai App Platform
  For an overview of the App Platform, visit our [Akamai App Platform](https://techdocs.akamai.com/cloud-computing/docs/application-platform) guide. To view all of our documentation for the App Platform, visit [Akamai App Platform Docs](https://techdocs.akamai.com/app-platform/docs/welcome).

# [Known issues](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#known-issues)

If the URL of the portal endpoint does not appear in the Cluster's summary page (under the App Platform section) after 30 minutes, one of the following issues may have occurred.

## [Installation gets stuck because of a quota exceeded exception](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#installation-gets-stuck-because-of-a-quota-exceeded-exception)

Next to the resources required for LKE, the App Platform also uses a NodeBalancer and a minimum of 11 storage volumes. This might result in a quota exceeding exception. Akamai currently does not provide quota limits in your account details at this time.

The following issue might be related to quota exceeding exception. Pods that require a storage volume get stuck in a pending state with the following message:

 pod has unbound immediate PersistentVolumeClaims. preemption: 0/3 nodes are available: 3 Preemption is not helpful for scheduling.

**Resolution:** Remove any Storage Volumes that are Unattached. If you would like to know your account's limits or want to increase the number of entities you can create, then the best way is to get that information through a support ticket.

## [The Let’s Encrypt secret request was not successful](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform#the-lets-encrypt-secret-request-was-not-successful)

For each cluster with the Application Platform for LKE enabled, a Let’s Encrypt certificate will be requested. If the certificate is not ready within 30 minutes, the installation of the Application Platform will fail. Run the following command to see if the certificate is created:

```
kubectl get secret -n istio-system
```

There should be a secret called: _apl-
-wildcard-cert_. If this secret is not present, then the request failed.

**Resolution:** The current cluster cannot be recovered. Delete it and create another LKE cluster with the App Platform enabled.