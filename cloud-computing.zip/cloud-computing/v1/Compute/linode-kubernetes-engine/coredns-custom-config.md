# [Create a custom CoreDNS configuration](https://techdocs.akamai.com/cloud-computing/docs/coredns-custom-config#create-a-custom-coredns-configuration)

# [CoreDNS in LKE](https://techdocs.akamai.com/cloud-computing/docs/coredns-custom-config#coredns-in-lke)

Linode Kubernetes Engine (LKE) provides out of the box intra-cluster domain name resolution via [CoreDNS](https://coredns.io/), the _DNS server_. Every new cluster is provided with a minimal, default CoreDNS configuration, which can be customized to suit your workload's needs.

# [Before you begin](https://techdocs.akamai.com/cloud-computing/docs/coredns-custom-config#before-you-begin)

This guide assumes you have a working [Linode Kubernetes Engine (LKE)](https://www.linode.com/products/kubernetes/) cluster running on Akamai Cloud and you are familiar with Corefile, the _CoreDNS configuration file_.

1. [Install the Kubernetes CLI](https://techdocs.akamai.com/cloud-computing/docs/manage-a-cluster-with-kubectl) (`kubectl`) on the local computer.

2. Follow the instructions in [Deploying and Managing a Cluster with Linode Kubernetes Engine Tutorial](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine) to connect to an LKE cluster.

3. Ensure that Kubernetes CLI is using the right cluster context and that the context is [persistent](https://techdocs.akamai.com/cloud-computing/docs/manage-a-cluster-with-kubectl#persist-the-kubeconfig-context). Run the `get-contexts` subcommand to check the current context:

   ```
   kubectl config get-contexts
   ```

# [Default CoreDNS configuration](https://techdocs.akamai.com/cloud-computing/docs/coredns-custom-config#default-coredns-configuration)

You can view your cluster's default CoreDNS configuration by using the following command:

```
kubectl get configmap -n kube-system coredns-base -o yaml
```

The output will resemble the following:

```text Output
apiVersion: v1
data:
  Corefile: |
    .:53 {
        errors
        health {
           lameduck 5s
        }
        ready
        kubernetes cluster.local in-addr.arpa ip6.arpa {
           pods insecure
           fallthrough in-addr.arpa ip6.arpa
           ttl 30
        }
        prometheus :9153
        forward . /etc/resolv.conf {
           max_concurrent 1000
        }
        cache 30
        loop
        reload
        loadbalance
        import custom/*.include
    }
    import custom/*.server
kind: ConfigMap
metadata:
  name: coredns-base
  namespace: kube-system
  [...]
```

The default CoreDNS configuration is located under the `Corefile` field in the above ConfigMap.

 > Warning: 
  Do not modify the `kube-system/coredns-base` ConfigMap that comes with your LKE cluster. It may be restored to its original state at any time and without notice.

# [Custom CoreDNS configuration](https://techdocs.akamai.com/cloud-computing/docs/coredns-custom-config#custom-coredns-configuration)

The default CoreDNS configuration leverages the CoreDNS [`import`](https://coredns.io/plugins/import/) plugin to enable customization. Configuration extensions are added through fields in the `kube-system/coredns-custom` ConfigMap:

```yaml
    apiVersion: v1
    kind: ConfigMap
    metadata:
      name: coredns-custom
      namespace: kube-system
    data:
      sample.include: |
        # Added to the .:53 default Server Block.
      sample_a.server: |
        # Additional Server Block.
      sample_b.server: |
        # Another Server Block.
```

- Fields suffixed with `.include` are added to the default [_Server Block_](https://coredns.io/manual/configuration/#server-blocks).
- Fields suffixed with `.server` are added as new Server Blocks.

## [Create a custom configuration](https://techdocs.akamai.com/cloud-computing/docs/coredns-custom-config#create-a-custom-configuration)

1. Create a manifest for a ConfigMap named `coredns-custom` in the `kube-system` namespace, with the desired configuration. For the purpose of this guide, an example custom configuration is used. Save it as the `coredns-custom.yaml` file.

   ```yaml
   apiVersion: v1
   kind: ConfigMap
   metadata:
     name: coredns-custom
     namespace: kube-system
   data:
     # Log all incoming DNS queries.
     log.include: |
       log
     # Private DNS resolution example. Handles FQDN resolutions for *.mydomain.com
     # Replace 
 with the target IP address.
     mydomain.server: |
       mydomain.com.:53 {
         forward . 

       }
   ```

2. Apply the above ConfigMap manifest:

   ```
   kubectl apply -f coredns-custom.yaml
   ```

   > > Note: 
   > 
   > CoreDNS will attempt to reload the configuration within 45 seconds after the last modification.

3. Ensure the custom configuration has been loaded:

   ```
   kubectl logs -n kube-system -l k8s-app=kube-dns
   ```

   For the custom configuration shown above, the output will resemble the following, after the reload is complete:

   ```text Output
   [INFO] Reloading
   [INFO] plugin/health: Going into lameduck mode for 5s
   [INFO] 127.0.0.1:60399 - 40866 "HINFO IN 349145763287755047.2816822520842364744. udp 56 false 512" NXDOMAIN qr,rd,ra 131 0.000980597s
   [INFO] plugin/reload: Running configuration SHA512 = 868c96ccca274c442fefc8db8e98b1f4a5cd05c655db1d990803d4019e5d28af101b24a78f85bae7ab3a3f8894f2791fda9d2b4d9c6ae1aa942080e1a88ce3e6
   [INFO] Reloading complete
   ```

   The custom configuration is now in effect.

 > Note: 
  The `kube-system/coredns-custom` ConfigMap is persistent and will not be affected by LKE maintenance operations.

## [Restore the defaults](https://techdocs.akamai.com/cloud-computing/docs/coredns-custom-config#restore-the-defaults)

1. To restore the default CoreDNS configuration, simply delete the `coredns-custom` ConfigMap:

   ```
   kubectl delete -n kube-system coredns-custom
   ```

2. Check the logs to make sure the reload was successful:

   ```
   kubectl logs -n kube-system -l k8s-app=kube-dns
   ```

   The output looks similar to the one emitted after applying the custom configuration.

   ```text Output
   [INFO] Reloading
   [INFO] plugin/health: Going into lameduck mode for 5s
   [WARNING] No files matching import glob pattern: custom/*.include
   [WARNING] No files matching import glob pattern: custom/*.server
   [INFO] plugin/reload: Running configuration SHA512 = 591cf328cccc12bc490481273e738df59329c62c0b729d94e8b61db9961c2fa5f046dd37f1cf888b953814040d180f52594972691cd6ff41be96639138a43908
   [INFO] Reloading complete
   ```

   The emitted warning messages are now to be expected, and should not be a concern.