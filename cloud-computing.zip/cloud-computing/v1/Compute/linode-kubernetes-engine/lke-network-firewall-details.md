# [Network and firewall details](https://techdocs.akamai.com/cloud-computing/docs/lke-network-firewall-details#network-and-firewall-details)

LKE clusters implement single-stack IPv4 networking. As such, single-stack IPv6 and [dual-stack networking](https://kubernetes.io/docs/concepts/services-networking/dual-stack/) are not supported at this time.

Some entities and services within an LKE cluster are only accessible from in that cluster while others are publicly accessible (reachable from the internet).

**Private (accessible only within the cluster):**

- Pod IPs, which use a per-cluster virtual network in the range 10.2.0.0/16
- ClusterIP Services, which use a per-cluster virtual network in the range 10.128.0.0/16

**Public (accessible over the internet):**

- NodePort Services, which listen on all Nodes with ports in the range 30000-32768
- LoadBalancer Services, which automatically deploy and configure a NodeBalancer
- Any manifest which uses `hostNetwork`: true and specifies a port
- Most manifests which use `hostPort` and specify a port

# [Recommended firewall settings](https://techdocs.akamai.com/cloud-computing/docs/lke-network-firewall-details#recommended-firewall-settings)

Exposing workloads to the public internet through the above methods can be convenient, but this can also carry a security risk. To maintain strong security, consider applying firewall rules to your cluster nodes. You can do this through the [cloud-firewall-controller](https://github.com/linode/cloud-firewall-controller), which creates a Cloud Firewall ruleset with strong default policies and applies this firewall to your LKE cluster. You can also do this manually using your preferred firewall. The following policies are needed to allow communication between the node pools and the control plane and block unwanted traffic.

- **Allow kubelet health checks:** TCP port 10250 and 10256 from 192.168.128.0/17 Accept
- **Allow Wireguard tunneling for kubectl proxy:** UDP port 51820 from 192.168.128.0/17 Accept
- **Allow cluster DNS access:** TCP/UDP port 53 from 192.168.128.0/17 Accept
- **Allow Calico BGP traffic:** TCP port 179 from 192.168.128.0/17 Accept
- **Allow Calico Typha traffic:** TCP port 5473 from 192.168.128.0/17 Accept
- **Allow NodeBalancer traffic:** TCP/UDP port range 30000-32767 from 192.168.255.0/24 Accept
- **Block all other TCP traffic:** TCP All Ports All IPv4/All IPv6 Drop
- **Block all other UDP traffic:** UDP All Ports All IPv4/All IPv6 Drop
- **Block all ICMP traffic:** (Not required) ICMP All Ports All IPv4/All IPv6 Drop
- IPENCAP for IP ranges 192.168.128.0/17 for internal communication between node pools and control plane.

To ensure that all nodes in the cluster (including new or recycled nodes) are added to the same firewall ruleset, use of the [Cloud Firewall Controller](https://github.com/linode/cloud-firewall-controller) is recommended.

 > Note: 
  All new LKE clusters create a service named `Kubernetes` in the `default` namespace designed to ease interactions with the control plane. This is a standard service for LKE clusters.