# [Labels and taints](https://techdocs.akamai.com/cloud-computing/docs/labels-and-taints#labels-and-taints)

Kubernetes uses the labels and taints metadata to ensure pods are scheduled on the most appropriate nodes. _Labels_ are used to attract/schedule pods to certain nodes and _taints_ are used to repel pods away from certain nodes. This metadata is user-configurable and can be updated through kubectl (for almost any Kubernetes cluster) or, in the case of LKE, through Cloud Manager, the Linode API, and the Linode CLI. This guide demonstrates how to use these Akamai Cloud interfaces to directly adjust labels and taints.

# [Labels](https://techdocs.akamai.com/cloud-computing/docs/labels-and-taints#labels)

Labels are key-value pairs that can be attached to objects in Kubernetes. For the purpose of this guide, they are assigned to node pools, which cascade down to nodes belonging to the particular node pool. Labels do not need to be unique and node pools can have multiple labels. These key-value pairs should adhere to the specifications and restrictions outlined in the Kubernetes [Labels and Selectors](https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/) documentation.

- **Key:** A label's key must begin with a letter or number, and may contain letters, numbers, hyphens, dots, and underscores. Optionally, the key can begin with a valid DNS subdomain prefix.

  - If the key does not begin with a DNS subdomain prefix, the maximum key length is 63 characters. Example: `my-app`.
  - If the key begins with a DNS subdomain prefix, it must separate the prefix and the rest of the label with a forward slash (`/`). In this case, the maximum _total_ length of the key is 128 characters, with up to 62 characters after the forward slash. The prefix must adhere to RFC 1123 DNS subdomain restrictions. Example: `example.com/my-app`.

- **Value:** Must begin with a letter or number, and may contain letters, numbers, hyphens, dots, and underscores, up to 63 characters in length.

# [Taints](https://techdocs.akamai.com/cloud-computing/docs/labels-and-taints#taints)

Taints are arrays containing a key, value, and effect and are applied to node pools (and cascaded down to individual nodes). They repel pods unless the pods are configured to _tolerate_ the taint. Taints should adhere to the guidelines outlined in the Kubernetes [Taints and Tolerations](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) documentation.

- **Key:** The `key` value must begin with a letter or number, and may contain letters, numbers, hyphens, dots, and underscores, up to 253 characters. Optionally, the `key` value can begin with a DNS subdomain prefix and a single slash (`/`), like `example.com/my-app`. In this case the maximum allowed length of the domain prefix is 253 characters.
- **Value:** The `value` key is optional. If given, it must begin with a letter or number, and may contain letters, numbers, hyphens, dots, and underscores, up to 63 characters.
- **Effect:** The `effect` value must be NoSchedule, PreferNoSchedule, or NoExecute.

# [Add or remove labels and taints on LKE](https://techdocs.akamai.com/cloud-computing/docs/labels-and-taints#add-or-remove-labels-and-taints-on-lke)

 > Warning: 
  When applying taints to node pools on LKE (non-enterprise) clusters, at least one node pool must remain untainted. This ensures pods with critical services can be appropriately scheduled on the cluster. Here are the _minimum number of worker nodes needed on a single untainted node pool_ for clusters with and without high availability (HA) enabled:
  - **Clusters without HA enabled:** 1 worker node required (2 recommended) on 1 untainted node pool
 - **Clusters with HA enabled:** 2 worker nodes required (3 recommended) on 1 untainted node pool

Labels and taints can be updated in Cloud Manager, the Linode API, and the Linode CLI. Within the Linode API and Linode CLI, they can also be set directly when creating a new cluster. Defining labels and taints on a per-pool basis through the Linode API has several benefits compared to managing them manually with `kubectl`, including:

- Custom labels and taints automatically apply to new nodes when a pool is recycled or scaled up (either manually or through autoscaling).
- LKE ensures that nodes have the desired taints in place before they become ready for pod scheduling. This prevents newly created nodes from attracting workloads that don't have the intended tolerations.

## [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/labels-and-taints#cloud-manager)

Labels and taints are managed within the same form within Cloud Manager.

1. Navigate to the **Kubernetes** page in Cloud Manager and select the cluster you wish to edit. See [View Node Pools](https://techdocs.akamai.com/cloud-computing/docs/manage-nodes-and-node-pools#view-node-pools).
2. Within the node pool section, click the **Labels and Taints** button. The **Labels and Taints** form appears. Labels can be added and removed from the **Labels** section and taints can be added and removed from the **Taints** section.
3. Labels can be added and removed from the **Labels** section. Click the **Add Label** button to add a new label. To delete a label, click the **X** icon corresponding. Labels are entered as a key-value pair, formatted as _key:value_. 

   
4. Taints can be added and removed from the **Taints** section. Click the **Add Taint** button to add a new taint. To delete a taint, click the **X** icon corresponding. The key and value for taints are entered as a pair, formatted as _key:value_. The **Effect** field is a dropdown menu containing all possible effect values. 

   
5. Once you are satisfied with your changes, click the **Save Changes** button to update the node pool with the change you made.

 > Note: 
  When updating or adding labels and taints to an existing node pool, it is not necessary to recycle it. This is because the values are updated live on the running nodes.

 > Note: 
  Values for both labels and taints cannot contain `kubernetes.io` or `linode.com` domains as these are reserved for LKE's own usage.

## [Linode API](https://techdocs.akamai.com/cloud-computing/docs/labels-and-taints#linode-api)

The Linode API can be used to add, update, and remove taints when creating a new node pool or when updating an existing node pool. The following code samples provide snippet containing the label formatting, taint formatting, and an example cURL command.

```json Labels
"labels": {
    "myapp.io/app": "test"
}
```
```json Taints
"taints": [
    {
        "key": "myapp.io/app",
        "value": "test",
        "effect": "NoSchedule"
    }
]
```
```curl Example command
curl -H "Content-Type: application/json" \
        -H "Authorization: Bearer $TOKEN" \
        -X POST -d '{
        "type": "g6-standard-1",
        "count": 3,
        "taints": [
            {
                "key": "myapp.io/app",
                "value": "test",
                "effect": "NoSchedule"
            }
        ],
        "labels": {
            "myapp.io/app": "test"
        }
        }' https://api.linode.com/v4/lke/clusters/{{< placeholder "12345" >}}/pools
```

Additional details on using the Linode API to modify labels and taints can be found within the [Deploy and manage an LKE cluster with the Linode API](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#add-labels-and-taints-to-your-lke-node-pools)  guide and in our [API documentation](https://techdocs.akamai.com/linode-api/reference/put-lke-node-pool) . 

## [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/labels-and-taints#linode-cli)

The Linode CLI can also be used in a similar capacity to the Linode API. The code samples below provide snippets for adding labels, adding taints, and an example Linode CLI command.

```json Labels
--labels '{ "example.com/my-app":"team1", "env":"staging" }'
```
```json Taints
--taints.effect "NoSchedule" \
--taints.key "example.com/my-app" \
--taints.value "teamA"
```
```Text Example command
linode-cli lke pool-update [cluster-id] [pool-id] \
  --count 6 \
  --autoscaler.enabled true \
  --autoscaler.max 12 \
  --autoscaler.min 3 \
  --labels '{ "example.com/my-app":"team1", "env":"staging" }' \
  --taints.effect "NoSchedule" \
  --taints.key "example.com/my-app" \
  --taints.value "teamA"
```