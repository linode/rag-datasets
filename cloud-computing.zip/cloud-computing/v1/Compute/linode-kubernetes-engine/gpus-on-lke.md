# [Using GPUs on LKE](https://techdocs.akamai.com/cloud-computing/docs/gpus-on-lke#using-gpus-on-lke)

Akamai's [GPU instances](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances) are available for deployment on standard LKE clusters, enabling you to run your GPU-accelerated workloads on Akamai's managed Kubernetes service. These instances utilize NVIDIA RTX 4000 Ada GPUs. NVIDIA Quadro RTX 6000 cannot be deployed within LKE clusters at this time due to limited availability. This document outlines several options for installing the NVIDIA software components needed to configure GPU-enabled workloads.

 > Warning: GPU plans are not yet available on LKE Enterprise
  During the limited availability release period, [LKE Enterprise](https://techdocs.akamai.com/cloud-computing/docs/lke-enterprise) does not support deploying GPU plans. As such, the information in this guide is valid only for non-enterprise LKE clusters.

# [Install NVIDIA software](https://techdocs.akamai.com/cloud-computing/docs/gpus-on-lke#install-nvidia-software)

There are two primary ways to install the software components needed to use NVIDIA GPUs within Kubernetes:

- [NVIDIA Kubernetes device plugin](#nvidia-kubernetes-device-plugin): A Daemonset that manages GPUs as consumable resources and enables you to schedule workloads. 
- [NVIDIA GPU operator](#nvidia-gpu-operator): A Kubernetes operator that automates the configuration and management of NVIDIA GPUs on Kubernetes clusters.

## [NVIDIA Kubernetes device plugin](https://techdocs.akamai.com/cloud-computing/docs/gpus-on-lke#nvidia-kubernetes-device-plugin)

This Daemonset is NVIDIA's implementation of the [device plugin framework](https://kubernetes.io/docs/concepts/extend-kubernetes/compute-storage-net/device-plugins/) on Kubernetes and can advertise GPUs as consumable resources. The following is an example command that installs v0.17.3 of this plugin. For the latest installation instructions and versions, see the [NVIDIA/k8s-device-plugin](https://github.com/NVIDIA/k8s-device-plugin) GitHub repository. You must have kubectl installed and configured to use an LKE cluster with GPU worker nodes.

```
kubectl create -f https://raw.githubusercontent.com/NVIDIA/k8s-device-plugin/v0.17.3/deployments/static/nvidia-device-plugin.yml
```

## [NVIDIA GPU operator](https://techdocs.akamai.com/cloud-computing/docs/gpus-on-lke#nvidia-gpu-operator)

The [NVIDIA GPU operator](https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/index.html) automatically configures all of the software required to use GPUs on your cluster and worker nodes. While this generally includes NVIDIA drivers and toolkit components, they both are disabled in our  instructions as driver installation is automatic on LKE GPU worker nodes. To learn more about this operator and for the most recent instructions, see NVIDIA's [Installing the NVIDIA GPU Operator](https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html) guide.

Before continuing, both kubectl and Helm should be installed on your local machine. The kubectl context should be set to an LKE cluster using GPU worker nodes.

1. Add the NVIDIA Helm repository to your local machine.

   ```
   helm repo add nvidia https://helm.ngc.nvidia.com/nvidia \
     && helm repo update
   ```
2. Install the GPU operator on your cluster. Since the drivers are automatically installed, they are not enabled on the operator.

   ```
   helm install --wait --generate-name \
     -n gpu-operator --create-namespace \
     nvidia/gpu-operator \
     --set driver.enabled=false \
     --set toolkit.enabled=false
   ```

## [NVIDIA driver installation](https://techdocs.akamai.com/cloud-computing/docs/gpus-on-lke#nvidia-driver-installation)

When deploying GPU instances on LKE, the latest available NVIDIA drivers are automatically installed. For transparency, the installation script is included below. You do not need to take any action.

```
wget -q https://developer.download.nvidia.com/compute/cuda/repos/debian12/x86_64/cuda-keyring_1.1-1_all.deb
dpkg -i cuda-keyring_1.1-1_all.deb
apt update
apt install -y nvidia-driver-cuda linux-headers-cloud-amd64 nvidia-container-toolkit
nvidia-ctk runtime configure --runtime=containerd --set-as-default
```

# [Configure workloads to use GPUs](https://techdocs.akamai.com/cloud-computing/docs/gpus-on-lke#configure-workloads-to-use-gpus)

Once NIVIDIA's software has been installed, you can configure pods to consume these GPU resources. This is done by using the `nvidia.com/gpu: n` key-value pair within the [resource limits](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/) of your workload's manifest file, where _n_ is the number of GPUs that should be consumed. Here's an example:

```
---
apiVersion: v1
kind: Pod
metadata:
  name: gpu-workload
spec:
  containers:
  - name: app
    image: example-image
    resources:
      limits:
        memory: 24Gi
        cpu: 6
	nvidia.com/gpu: 1
```

For a more in-depth example of running GPU-accelerated workloads on LKE, see the [Deploy a Chatbot and RAG Pipeline for AI Inferencing on LKE](https://www.linode.com/docs/guides/ai-chatbot-and-rag-pipeline-for-inference-on-lke/) guide.