# [Create a cluster](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#create-a-cluster)

This guide walks you through creating an LKE cluster through Cloud Manager.

1. [Open the Create Kubernetes Cluster Form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#open-the-create-kubernetes-cluster-form-in-cloud-manager)
2. [Set the Label](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#set-the-label)
3. [Select a Region](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#select-a-region)
4. [Choose a Kubernetes Version](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#choose-a-kubernetes-version)
5. [Add Node Pools](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#add-node-pools)
6. [Optionally Enable High Availability](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#optionally-enable-high-availability)
7. [Deploy the Cluster](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#deploy-the-cluster)

# [Open the create Kubernetes cluster form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#open-the-create-kubernetes-cluster-form-in-cloud-manager)

Log in to [Cloud Manager](https://cloud.linode.com/) and select **Kubernetes** from the left navigation menu. Click the **Create Cluster** button. This opens the _[Kubernetes Create Cluster](https://cloud.linode.com/kubernetes/create)_ form.

# [Set the label](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#set-the-label)

Within the **Cluster Label** field, enter the label you wish to use. This label lets you identify it from within Cloud Manager, Linode CLI, and Linode API. The label must be alphanumeric, between 3 and 32 characters, and unique from other cluster labels on your account.

# [Select a tier](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#select-a-tier)

Our managed Kubernetes service is offered as two tiers: LKE Enterprise and LKE. Each of these tiers accommodates different use cases and deployment sizes.

- Select **LKE Enterprise** for large deployments or deployments that require enterprise-grade features and dedicated control plane resources. This is our new enterprise-focused offering and requires approval before deployment. See [LKE Enterprise](https://techdocs.akamai.com/cloud-computing/docs/lke-enterprise) for more details.
- Select **LKE** for small to medium sized deployments that can run with a standard array of cluster management features. This is our traditional offering that’s available for all customers.

Review the [LKE overview](https://techdocs.akamai.com/cloud-computing/docs/linode-kubernetes-engine) page for more information about each tier, including a comparison table.

# [Select a region](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#select-a-region)

Select the **region** where the LKE cluster will reside. Regions correspond with individual data centers, each located in a different geographical area. All resources attached to your cluster are deployed in the selected region, including nodes (Linodes) in the Node Pools, volumes (Block Storage volumes), and load balancers (NodeBalancers). If you haven't yet deployed Linodes or chosen a region, select the region closest to you and/or your customers. This helps reduce latency and can make a significant impact in connection speeds and quality.

- [Global Infrastructure](https://www.linode.com/global-infrastructure/)
- [Speed Tests for Data Centers](https://www.linode.com/speed-test/)
- [How to Choose a Data Center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center)

# [Choose a Kubernetes version](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#choose-a-kubernetes-version)

Next, select the **Kubernetes Version** you wish to use from the corresponding dropdown list. Only Kubernetes versions that have been approved for LKE are listed. As new versions of Kubernetes are released (and older ones are deprecated), upgrade paths are made available.

# [Enable high availability](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#enable-high-availability)

The [HA (high availability) control plane](https://techdocs.akamai.com/cloud-computing/docs/high-availability-ha-control-plane-on-lke) feature is a paid add-on for LKE and included by default for LKE Enterprise. It provides an additional layer of redundancy to the Kubernetes cluster. It creates replicas of the control plane components, eliminating a single point of failure for your cluster and providing a guaranteed uptime of 99.99%. To enable this feature for LKE clusters, check the Enable HA Control Plane box in the Cluster Summary section. The HA control plane can also be enabled any time after your cluster has been created.

 > Warning: 
  Once the high availability control plane feature has been enabled, it is not possible to remove this feature and _downgrade_ to a non-HA control plane.

# [Enable the control plane ACL](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#enable-the-control-plane-acl)

You can restrict access to your cluster's control plane components by enabling the [control plane ACL](https://techdocs.akamai.com/cloud-computing/docs/control-plane-acls) feature. This is enabled for all LKE Enterprise clusters and is optional for LKE clusters. When enabled, the default policy for the ACL is _DENY_, which means that all traffic is blocked unless it originates from one of the IP ranges you've added.

If you are enabling the ACL, add any IP addresses that you or your team will use to communicate with this cluster's control plane. Enter an individual IP address or CIDR range into either the _IPv4 Addresses or CIDRs_ and _IPv6 Addresses or CIDRs_ field. Click the **Add IPv4 / IPv6 address** link to add additional addresses.

 > Warning: 
  It's important to note that this setting only restricts access to the cluster's control plane components, not to any other web applications running on the cluster itself.

# [Add node pools](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#add-node-pools)

Each LKE cluster is created with _at least_ one node pool. Node pools are made up of individual worker nodes, which are run on top of Linodes.

1. In the **Add Node Pools** section, locate the plan type you wish to use for your first node pool. You can deploy most Linode plans within an LKE cluster, with an exception being the 1 GB Shared CPU plan. To accommodate networking sensitive workloads, especially in enterprise scenarios where low latency or high throughput is required, using Premium instances with LKE Enterprise is highly recommended.
2. Enter the number of worker nodes that you wish to be included in the node pool and click the **Add** button to add that pool to your cluster configuration. You can repeat this process to add additional node pools if desired. Node pools can also be added, resized, and deleted after the cluster has been created.

# [Deploy the cluster](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#deploy-the-cluster)

Review your cluster's configuration within the **Cluster Summary** section. This should list each Node Pool that has been added, display the HA control plane selection, and list the monthly cost associated with this cluster. When you are satisfied with the configuration of your cluster, click the **Create Cluster** button. Your cluster's detail page appears while your cluster is being created. From this page, you can [edit your existing Node Pools](https://techdocs.akamai.com/cloud-computing/docs/manage-nodes-and-node-pools), [access your Kubeconfig file](https://techdocs.akamai.com/cloud-computing/docs/manage-a-cluster-with-kubectl), and view an overview of your cluster's resource details.