# [Upgrade an LKE Enterprise cluster to a newer Kubernetes version](https://techdocs.akamai.com/cloud-computing/docs/upgrade-an-lke-enterprise-cluster-to-a-newer-kubernetes-version#upgrade-an-lke-enterprise-cluster-to-a-newer-kubernetes-version)

Users of LKE Enterprise clusters can manage Kubernetes versions and version upgrades with greater control than their non-enterprise counterparts. In addition to setting the Kubernetes version on the control plane, the version can also be defined on each node pool. Worker nodes within each node pool can then be upgraded using one of two update strategies: _rolling update_ and _on recycle_. Continue reading to learn how to upgrade your LKE Enterprise clusters to the latest Kubernetes version. 

# [Upgrade the control plane](https://techdocs.akamai.com/cloud-computing/docs/upgrade-an-lke-enterprise-cluster-to-a-newer-kubernetes-version#upgrade-the-control-plane)

The Kubernetes version running on the cluster's control plane can be upgraded in a similar way to non-enterprise LKE clusters. See [Upgrade a cluster to a newer Kubernetes version > Upgrade the control plane](https://techdocs.akamai.com/cloud-computing/docs/upgrade-a-cluster-to-a-newer-kubernetes-version#upgrade-the-control-plane) for non-enterprise LKE instructions. The key difference is that you should not follow the prompt to recycle all nodes within the cluster. Kubernetes version upgrades for worker nodes in an LKE Enterprise cluster are managed on the node pool level instead of the control plane level.

1. Navigate to the **Kubernetes** page in [Cloud Manager](http://cloud.linode.com) to see a list of all LKE clusters on your account (see [Manage Kubernetes Clusters](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke)).

2. Locate the LKE Enterprise cluster you wish to upgrade and click the corresponding **Upgrade** button in the _Version_ column. This button only appears if there is an available upgrade for that cluster.

3. A confirmation popup should appear notifying you of the current and target Kubernetes version. Click the **Upgrade Version** button to continue with the upgrade.

4. The next step is to upgrade all worker nodes in the cluster so that they use the newer Kubernetes version. A second popup should automatically appear requesting that you start the recycle process. Since these upgrades are managed on each node pool for LKE Enterprise clusters, click the **Cancel** button and perform one of the node pool upgrade procedures outlined below in the [Upgrade worker nodes](#upgrade-worker-nodes) section.

# [Upgrade worker nodes](https://techdocs.akamai.com/cloud-computing/docs/upgrade-an-lke-enterprise-cluster-to-a-newer-kubernetes-version#upgrade-worker-nodes)

Once the control plane has been upgraded to your desired Kubernetes version, you can proceed with upgrading the worker nodes within each node pool. LKE Enterprise includes two upgrade strategies when performing the upgrade: _rolling update_ and _on recycle_. See the [Update strategies](#update-strategies) section to learn more about these two strategies and how to change/set them.

1. Obtain the ID of your LKE Enterprise cluster and the ID of the node pool you wish to upgrade. These values can be viewed using Cloud Manager, the Linode CLI, or the Linode API. In Cloud Manager, the _Cluster ID_ can be viewed within the _Summary_ section of the LKE cluster's details page. The _Pool ID_ is visible on the same page within the configuration details section for that node pool.
2. Using the Linode API beta endpoint, run the following command, replacing _CLUSTER-ID_ and _POOL-ID_ with the values you obtained in the previous step. This example uses the Kubernetes version `v1.31.8+lke5`, though you can update this with the version you wish to use.
   ```
   curl -s -XPUT "https://api.linode.com/v4beta/lke/clusters/CLUSTER-ID/pools/POOL-ID" \
        --header 'accept: application/json' \
        --header 'content-type: application/json' \
        -H "Authorization: Bearer $LINODE_TOKEN" --data '{"k8s_version":"v1.31.8+lke5"}'
   ```
3. Trigger the upgrade on your node pool's worker nodes:
   - If your node pool is set to use the _rolling update_ update strategy, the worker nodes are automatically triggered to upgrade in a rolling fashion.
   - If your update strategy is set to use the _on recycle_ method, you need to manually trigger the worker nodes to be recycled. You can recycle all worker nodes within a node pool through Cloud Manager, the Linode CLI, or the Linode API. In Cloud Manager, click the **Recycle All Nodes** button within the node pool's configuration details section of the LKE cluster's details page.
4. You can confirm your node pool has been upgraded by running the following cURL command, again adding in your own cluster ID and pool ID.
   ```
   curl https://api.linode.com/v4beta/lke/clusters/CLUSTER-ID/pools/POOL-ID -H "Authorization: Bearer $LINODE_TOKEN" | jq '.k8s_version'
   ```

# [Update strategies](https://techdocs.akamai.com/cloud-computing/docs/upgrade-an-lke-enterprise-cluster-to-a-newer-kubernetes-version#update-strategies)

LKE Enterprise clusters have the ability to define an _update strategy_ on each node pool. These strategies are defined by setting the `update_strategy` parameter on the [node pool endpoint](https://techdocs.akamai.com/linode-api/reference/post-lke-cluster-pools)  to one of the following values:

- **Rolling update** (`rolling_update`): Immediately triggers a recycle of this node pool when the Kubernetes version is updated.
- **On recycle** (`on_recycle`): _Default_. Does not trigger any immediate recycle. New worker nodes are created with the new Kubernetes version. Existing worker nodes will be upgraded when a recycle is manually triggered.

This setting can be defined when creating a node pool or updated when modifying an existing node pool. To modify an existing node pool, run the following cURL command, replacing _CLUSTER-ID_ and _POOL-ID_ with the values for your cluster and node pool. This example changes the update strategy to use the rolling update method.

```
curl -s -XPUT "https://api.linode.com/v4beta/lke/clusters/CLUSTER-ID/pools/POOL-ID" \
     --header 'accept: application/json' \
     --header 'content-type: application/json' \
     -H "Authorization: Bearer $LINODE_TOKEN" --data '{"update_strategy":"rolling_update"}'
```

# [Additional considerations](https://techdocs.akamai.com/cloud-computing/docs/upgrade-an-lke-enterprise-cluster-to-a-newer-kubernetes-version#additional-considerations)

- Not all tooling supports all functionality related to upgrading LKE Enterprise clusters. The Linode API supports all functionality. Support for setting the upgrade strategy in the Cloud Manager and Linode CLI are coming soon. If you are using Terraform, use version 2.37.0 or higher.