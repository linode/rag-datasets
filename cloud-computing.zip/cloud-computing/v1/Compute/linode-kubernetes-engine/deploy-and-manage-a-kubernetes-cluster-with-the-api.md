# [Deploy and manage an LKE cluster with the Linode API](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#deploy-and-manage-an-lke-cluster-with-the-linode-api)

An LKE cluster can be deployed in one of several ways:

- Via [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster)
- With the Linode API (as presented in this guide)
- With the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-cli)

These Linode-provided interfaces can be used to create, delete, and update the structural elements of your cluster, including:

- The number of nodes that make up a cluster's node pools.
- The region where your node pools are deployed.
- The hardware resources for each node in your node pools.
- The Kubernetes version deployed to your cluster's Master node and worker nodes.

The [Kubernetes API](https://linode.com/docs/guides/beginners-guide-to-kubernetes-part-1-introduction/#kubernetes-api) and [kubectl](https://linode.com/docs/guides/beginners-guide-to-kubernetes-part-1-introduction/#kubectl) are the primary ways you interact with your LKE cluster once it's been created. These tools can be used to configure, deploy, inspect, and secure your Kubernetes workloads, deploy applications, create services, configure storage and networking, and define controllers.

 > Note: 
  The Linode API and the Kubernetes API are two separate interfaces, and both are mentioned in this article. The Linode API lets you manipulate your Linode infrastructure, while the Kubernetes API lets you manage the software objects running in your cluster.

# [In this guide](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#in-this-guide)

This guide covers how to use the Linode API to:

- [Create an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#create-an-lke-cluster)
- [Connect kubectl to your LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#connect-to-your-lke-cluster)
- [Inspect your LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#inspect-your-lke-cluster)
- [Modify an existing LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#modify-your-lke-cluster)
- [Delete an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#delete-an-lke-cluster)

# [Before you begin](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#before-you-begin)

1. [Familiarize yourself with the Linode Kubernetes Engine service](https://www.linode.com/products/kubernetes/). This information helps you understand the benefits and limitations of LKE.

2. [Create an API Token](https://techdocs.akamai.com/cloud-computing/docs/manage-personal-access-tokens#create-an-api-token). You need this to access the LKE service.

3. [Install kubectl](https://techdocs.akamai.com/cloud-computing/docs/manage-a-cluster-with-kubectl#install-kubectl) on your computer. You use kubectl to interact with your cluster once it's deployed.

4. If you are new to Kubernetes, refer to our [A Beginner's Guide to Kubernetes](https://linode.com/docs/guides/beginners-guide-to-kubernetes/) series to learn about general Kubernetes concepts. This guide assumes a general understanding of core Kubernetes concepts.

# [Create an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#create-an-lke-cluster)

| Required Parameters | Description                                                                                                                                                                                                                                                                           |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `region`            | The data center region where your cluster is deployed. Currently, `us-central` is the only available region for LKE clusters.                                                                                                                                                         |
| `label`             | A human readable name to identify your cluster. This must be unique. If no label is provided, one is assigned automatically. Labels must start with an alpha [a-z][A-Z] character, must only consist of alphanumeric characters and dashes, and must not contain two dashes in a row. |
| `node_pools`        | The collections of Linodes that serve as the worker nodes in your LKE cluster.                                                                                                                                                                                                  |
| `k8s_version`       | The desired version of Kubernetes for this cluster.                                                                                                                                                                                                                                   |

 > Note: 
  The available plan types for LKE worker nodes are [Shared](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#shared-cpu-s), [Dedicated CPU](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#dedicated-cpu-s), and [High Memory](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#high-memory-s) plans.

1. To create an LKE Cluster, send a `POST` request to the `/lke/clusters` endpoint. The example below displays all possible request body parameters. Note that `tags` is an optional parameter.

   ```
   curl -H "Content-Type: application/json" \
         -H "Authorization: Bearer $TOKEN" \
         -X POST -d '{
           "label": "cluster12345",
           "region": "us-central",
           "k8s_version": "1.16",
           "tags": ["ecomm", "blogs"],
           "node_pools": [
             { "type": "g6-standard-2", "count": 2},
             { "type": "g6-standard-4", "count": 3}
           ]
         }' https://api.linode.com/v4/lke/clusters
   ```

   You receive a response similar to:

   ```text Output
   {"k8s_version": "1.16", "updated": "2019-08-02T17:17:49", "region": "us-central", "tags": ["ecomm", "blogs"], "label": "cluster12345", "id": 456, "created": "2019-22-02T17:17:49"}%
   ```

2. Make note of your cluster's ID, as you need it to continue to interact with your cluster in the next sections. In the example above, the cluster's ID is `"id": 456`. You can also access your cluster's ID by [listing all LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) on your account.

   > > Note: 
   > 
   > Each Linode account has a limit to the number of resources they can deploy. This includes services, like Linodes, NodeBalancers, Block Storage, etc. If you run into issues deploying the number of nodes you designate for a given cluster's node pool, you may have run into a limit on the number of resources allowed on your account. Contact [Linode Support](https://techdocs.akamai.com/cloud-computing/docs/help-and-support) if you believe this may be the case.

## [Connect to your LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#connect-to-your-lke-cluster)

Now that your LKE cluster is created, you can access and manage your cluster using kubectl on your computer. This gives you the ability to interact with the Kubernetes API, and to create and manage [Kubernetes objects](https://linode.com/docs/guides/beginners-guide-to-kubernetes-part-3-objects/) in your cluster.

To communicate with your LKE cluster, kubectl requires a copy of your cluster's [_kubeconfig_](https://kubernetes.io/docs/concepts/configuration/organize-cluster-access-kubeconfig/). In this section, you access the contents of your kubeconfig using the Linode API and then set up kubectl to communicate with your LKE cluster.

1. Access your LKE cluster's kubeconfig file by sending a `GET` request to the `/lke/clusters/{clusterId}/kubeconfig` endpoint. Ensure you replace `12345` with your cluster's ID that you recorded in the previous section:

   ```
   curl -H "Authorization: Bearer $TOKEN" \
         https://api.linode.com/v4/lke/clusters/12345/kubeconfig
   ```

   The API returns a [base64](https://en.wikipedia.org/wiki/Base64) encoded string (a useful format for automated pipelines) representing your kubeconfig. Your output resembles the following:

   ```text Output
   {"kubeconfig": "YXBpVmVyc2lvbjogdjEKY2x1c3RlcnM6Ci0gY2x1c3RlcjoKICAgIGNlcnRpZmljYXRlLWF1dGhvcml0eS1kYXRhOiBMUzB0TFMxQ1JVZEpUaUJEUlZKVVNVWkpRMEZVUlMwdExTMHRDazFKU1VONVJFTkRRV0pEWjBGM1NVSkJaMGxDUVVSQlRrSm5hM0ZvYTJsSE9YY3dRa0ZSYzBaQlJFRldUVkpOZDBWUldVUldVVkZFUlhkd2NtUlhTbXdLWTIwMWJHUkhWbnBOUWpSWVJGUkZOVTFFWjNkTmFrVXpUVlJqTVUxV2IxaEVWRWsx ... 0TFMwdExRbz0K"}%
   ```

2. Copy the `kubeconfig` field's value from the response body, since you need it in the next step.

   > > Note: 
   > 
   > Make sure you only copy the long string inside the quotes following `"kubeconfig":` in your output. Do not copy the curly braces or anything outside of them. You receive an error if you use the full output in later steps.

3. Save the base64 kubeconfig to an environment variable:

   ```
   KUBE_VAR='YXBpVmVyc2lvbjogdjEK ... 0TFMwdExRbz0K'
   ```

4. Navigate to your computer's `~/.kube` directory. This is where kubectl looks for kubeconfig files, by default.

   ```
   cd ~/.kube
   ```

5. Create a directory called `configs` within `~/.kube`. You can use this directory to store your kubeconfig files.

   ```
   mkdir configs
   cd configs
   ```

6. Decode the contents of `$KUBE_VAR` and save it to a new YAML file:

   ```
   echo $KUBE_VAR | base64 -D > cluster12345-config.yaml
   ```

   > > Note: 
   > 
   > The YAML file that you decode to (`cluster12345-config.yaml` here) can have any name of your choosing.

7. Add the kubeconfig file to your `$KUBECONFIG` environment variable.

   ```
   export KUBECONFIG=cluster12345-config.yaml
   ```

8. Verify that your cluster is selected as kubectl's current context:

   ```
   kubectl config get-contexts
   ```

9. View the contents of the configuration:

   ```
   kubectl config view
   ```

   > > Note: 
   > 
   > You can also access a decoded version of your kubeconfig file in [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/manage-a-cluster-with-kubectl).

10. View all nodes in your LKE cluster using kubectl:

    ```
    kubectl get nodes
    ```

    Your output resembles the following example, but varies depending on your own cluster's configurations.

    ```text Output
    NAME                      STATUS   ROLES  AGE     VERSION
    lke166-193-5d44703cd092   Ready    none   2d22h   v1.14.0
    lke166-194-5d44703cd780   Ready    none   2d22h   v1.14.0
    lke166-195-5d44703cd691   Ready    none   2d22h   v1.14.0
    lke166-196-5d44703cd432   Ready    none   2d22h   v1.14.0
    lke166-197-5d44703cd211   Ready    none   2d22h   v1.14.0
    ```

    Now that you are connected to your LKE cluster, you can begin using kubectl to deploy applications, [inspect and manage](https://linode.com/docs/guides/troubleshooting-kubernetes/#kubectl-get) cluster resources, and [view logs](https://linode.com/docs/guides/troubleshooting-kubernetes/#kubectl-logs).

## [Persist the kubeconfig context](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#persist-the-kubeconfig-context)

If you create a new terminal window, it does not have access to the context that you specified using the previous instructions. This context information can be made persistent between new terminals by setting the [`KUBECONFIG` environment variable](https://kubernetes.io/docs/tasks/access-application-cluster/configure-access-multiple-clusters/#set-the-kubeconfig-environment-variable) in your shell's configuration file.

 > Note: 
  If you are using Windows, review the [official Kubernetes documentation](https://kubernetes.io/docs/tasks/access-application-cluster/configure-access-multiple-clusters/#set-the-kubeconfig-environment-variable) for how to persist your context.

These instructions persist the context for users of the Bash terminal. They are similar for users of other terminals:

1. Open up your Bash profile (e.g. `~/.bash_profile`) in the text editor of your choice and add your configuration file to the `$KUBECONFIG` PATH variable.

   If an `export KUBECONFIG` line is already present in the file, append to the end of this line as follows; if it is not present, add this line to the end of your file:

   ```
   export KUBECONFIG=$KUBECONFIG:$HOME/.kube/config:$HOME/.kube/configs/cluster12345-config.yaml
   ```

   > > Note: 
   > 
   > Alter the `$HOME/.kube/configs/cluster12345-config.yaml` path in the above line with the name of the file you decoded to in the previous section.

2. Close your terminal window and open a new window to receive the changes to the `$KUBECONFIG` variable.

3. Use the `config get-contexts` command for `kubectl` to view the available cluster contexts:

   ```
   kubectl config get-contexts
   ```

   You should see output similar to the following:

   ```text Output
   CURRENT  NAME                         CLUSTER     AUTHINFO          NAMESPACE
   *        kubernetes-admin@kubernetes  kubernetes  kubernetes-admin
   ```

4. If your context is not already selected, (denoted by an asterisk in the `current` column), switch to this context using the `config use-context` command. Supply the full name of the cluster (including the authorized user and the cluster):

   ```
   kubectl config use-context kubernetes-admin@kubernetes
   ```

   You should see output like the following:

   ```text Output
   Switched to context "kubernetes-admin@kubernetes".
   ```

5. You are now ready to interact with your cluster using `kubectl`. You can test the ability to interact with the cluster by retrieving a list of Pods in the `kube-system` namespace:

   ```
   kubectl get pods -n kube-system
   ```

# [Inspect your LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#inspect-your-lke-cluster)

Once you have created an LKE Cluster, you can access information about its structural configuration using the Linode API.

## [List LKE clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters)

To view a list of all your LKE clusters, send a `GET` request to the `/lke/clusters` endpoint.

```
curl -H "Authorization: Bearer $TOKEN" https://api.linode.com/v4/lke/clusters
```

The returned response body displays the number of clusters deployed to your account and general details about your LKE clusters:

```text Output
{"results": 2, "data": [{"updated": "2019-08-02T17:17:49", "region": "us-central", "id": 456, "k8s_version": "1.16", "label": "cluster-12345", "created": "2019-08-02T17:17:49", "tags": ["ecomm", "blogs"]}, {"updated": "2019-08-05T17:00:04", "region": "us-central", "id": 789, "k8s_version": "1.16", "label": "cluster-56789", "created": "2019-08-05T17:00:04", "tags": ["ecomm", "marketing"]}], "pages": 1, "page": 1}%
```

## [View an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#view-an-lke-cluster)

You can use the Linode API to access details about an individual LKE cluster. You need your cluster's ID to access information about this resource. If you don't know your cluster's ID, see the [List LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) section.

| Required Parameters | Description                      |
| ------------------- | -------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup. |

To view your LKE cluster, send a `GET` request to the `/lke/clusters/{clusterId}` endpoint. In this example, ensure you replace `12345` with your cluster's ID:

```
curl -H "Authorization: Bearer $TOKEN" https://api.linode.com/v4/lke/clusters/12345
```

Your output resembles the following:

```text Output
{"created": "2019-08-02T17:17:49", "updated": "2019-08-02T17:17:49", "k8s_version": "1.16", "tags": ["ecomm", "blogs"], "label": "cluster-12345", "id": 456, "region": "us-central"}%
```

## [List a cluster's node pools](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-a-clusters-node-pools)

A node pool consists of one or more Linodes (worker nodes). Each node in the pool has the same plan type. Your LKE cluster can have several node pools. Each pool is assigned its own plan type and number of nodes. To view a list of an LKE cluster's node pools, you need your cluster's ID. If you don't know your cluster's ID, see the [List LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) section.

| Required Parameters | Description                      |
| ------------------- | -------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup. |

To list your cluster's node pools, send a `GET` request to the `/lke/clusters/{clusterId}/pools` endpoint. In this example, replace `12345` with your cluster's ID:

```
curl -H "Authorization: Bearer $TOKEN" https://api.linode.com/v4/lke/clusters/12345/pools
```

The response body includes information on each node pool's pool ID, Linode type, and node count; and each node's individual ID and status.

```text Output
{"pages": 1, "page": 1, "data": [{"count": 2, "id": 193, "type": "g6-standard-2", "linodes": [{"id": "13841932", "status": "ready "}, {"id": "13841933", "status": "ready"}]}, {"count": 3, "id": 194, "type": "g6-standard-4", "linodes": [{"id": "13841934", "status": "ready"}, {"id": "13841935", "status": "ready"}, {"id": "13841932", "status": "ready"}]}], "results": 2}%
```

## [View a node pool](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#view-a-node-pool)

You can use the Linode API to access details about a specific node pool in an LKE cluster. You need your cluster’s ID and node pool ID to access information about this resource. To retrieve your cluster’s ID, see the [List LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) section. To find a node pool's ID, see the [List a Cluster's Node Pools](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-a-clusters-node-pools) section.

| Required Parameters | Description                        |
| ------------------- | ---------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup.   |
| `poolId`            | ID of the LKE node pool to lookup. |

To view a specific node pool, send a `GET` request to the `/lke/clusters/{clusterId}/pools/{poolId}` endpoint. In this example, replace `12345` with your cluster's ID and `456` with the node pool's ID:

```
curl -H "Authorization: Bearer $TOKEN" \
    https://api.linode.com/v4/lke/clusters/12345/pools/456
```

The response body provides information about the number of nodes in the node pool, the node pool's ID, and type. You also retrieve information about each individual node in the node pool, including the Linode's ID and status.

```text Output
{"count": 2, "id": 193, "type": "g6-standard-2", "linodes": [{"id": "13841932", "status": "ready"}, {"id": "13841933", "status": "ready"}]}%
```

 > Note: 
  If desired, you can use your node pool's Linodes ID(s) to get more details about each node in the pool. Send a `GET` request to the `/linode/instances/{linodeId}` endpoint. In this example, ensure you replace `13841932` with your Linode's ID.
  ```
 curl -H "Authorization: Bearer $TOKEN" \
 https://api.linode.com/v4/linode/instances/13841932
 ```
  Although you have access to your cluster's nodes, it is recommended that you only interact with your nodes via the Linode's LKE interfaces (like the LKE endpoints in Linode's API, or the Kubernetes section in Cloud Manager), or via the Kubernetes API and kubectl.

# [Modify your LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#modify-your-lke-cluster)

Once an LKE cluster is created, you can modify the cluster's label, node pools, and tags. In this section you learn how to modify each of these parts of your cluster.

## [Update your LKE cluster label](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#update-your-lke-cluster-label)

| Required Parameters | Description                      |
| ------------------- | -------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup. |

To update your LKE cluster's label, send a `PUT` request to the `/lke/clusters/{clusterId}` endpoint. In this example, ensure you replace `12345` with your cluster's ID:

```
curl -H "Content-Type: application/json" \
        -H "Authorization: Bearer $TOKEN" \
        -X PUT -d '{
        "label": "updated-cluster-name"
        }' https://api.linode.com/v4/lke/clusters/12345
```

The response body displays the updated cluster label:

```text Output
{"created": "2019-08-02T17:17:49", "updated": "2019-08-05T19:11:19", "k8s_version": "1.16", "tags": ["ecomm", "blogs"], "label": "updated-cluster-name", "id": 456, "region": "us-central"}%
```

## [Add a node pool to your LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#add-a-node-pool-to-your-lke-cluster)

A node pool consists of one or more Linodes (worker nodes). Each node in the pool has the same plan type and is identical to each other. Your LKE cluster can have several node pools, each pool with its own plan type and number of nodes.

You need your cluster's ID in order to add a node pool to it. If you don’t know your cluster’s ID, see the [List LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) section.

| Required Parameters | Description                                                                                                                                                |
| ------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup.                                                                                                                           |
| `type`              | The Linode plan type to use for all the nodes in the pool. Linode plans designate the type of hardware resources applied to your Linode. |
| `count`             | The number of nodes to include in the node pool. Each node has the same plan type.                                                                         |

To add a node pool to an existing LKE cluster, send a `POST` request to the `/lke/clusters/{clusterId}/pools` endpoint. The request body must include the `type` and `count` parameters. In the URL of this example, ensure you replace `12345` with your own cluster's ID:

```
curl -H "Content-Type: application/json" \
        -H "Authorization: Bearer $TOKEN" \
        -X POST -d '{
        "type": "g6-standard-1",
        "count": 5
        }' https://api.linode.com/v4/lke/clusters/12345/pools
```

The response body resembles the following:

```text Output
{"count": 5, "id": 196, "type": "g6-standard-1", "linodes": [{"id": "13841945", "status": "ready"}, {"id": "13841946", "status": "ready"}, {"id": "13841947", "status": "ready"}, {"id": "13841948", "status": "ready"}, {"id": "13841949", "status": "ready"}]}%
```

 > Note: 
  Each Linode account has a limit to the number of resources they can deploy. This includes services, like Linodes, NodeBalancers, Block Storage, etc. If you run into issues deploying the number of nodes you designate for a given cluster's node pool, you may have run into a limit on the number of resources allowed on your account. Contact [Linode Support](https://techdocs.akamai.com/cloud-computing/docs/help-and-support) if you believe this may be the case.

## [Add labels and taints to your LKE node pools](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#add-labels-and-taints-to-your-lke-node-pools)

When creating or updating an LKE node pool, you can optionally add custom labels and taints to all nodes using the `labels` and `taints` parameters. Defining labels and taints on a per-pool basis through the Linode API has several benefits compared to managing them manually with `kubectl`, including:

- Custom labels and taints automatically apply to new nodes when a pool is recycled or scaled up (either manually or through autoscaling).
- LKE ensures that nodes have the desired taints in place before they become ready for pod scheduling. This prevents newly created nodes from attracting workloads that don't have the intended tolerations.

The following cURL command provides an example of using the Linode API to create a new node pool with a custom taint and label. If you are copying this command to run on your own LKE cluster, replace {{\< placeholder "12345" >}} with the ID of your LKE cluster.

```
curl -H "Content-Type: application/json" \
        -H "Authorization: Bearer $TOKEN" \
        -X POST -d '{
        "type": "g6-standard-1",
        "count": 3,
        "taints": [
            {
                "key": "myapp.io/app",
                "value": "test",
                "effect": "NoSchedule"
            }
        ],
        "labels": {
            "myapp.io/app": "test"
        }
        }' https://api.linode.com/v4/lke/clusters/{{< placeholder "12345" >}}/pools
```

In the above command, labels are defined in the `labels` field as key-value pairs within a single object. Taints are defined as an array of objects in the `taints` field.

- **Labels:** The `labels` field expects an object with one or more key-value pairs. These key-value pairs should adhere to the specifications and restrictions outlined in the Kubernetes [Labels and Selectors](https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/) documentation.

  ```
  "labels": {
      "myapp.io/app": "test"
  }
  ```

  - **Key:** A label's key must begin with a letter or number, and may contain letters, numbers, hyphens, dots, and underscores. Optionally, the key can begin with a valid DNS subdomain prefix.

    - If the key does not begin with a DNS subdomain prefix, the maximum key length is 63 characters. Example: `my-app`.
    - If the key begins with a DNS subdomain prefix, it must separate the prefix and the rest of the label with a forward slash (`/`). In this case, the maximum _total_ length of the key is 128 characters, with up to 62 characters after the forward slash. The prefix must adhere to RFC 1123 DNS subdomain restrictions. Example: `example.com/my-app`.

  - **Value:** Must begin with a letter or number, and may contain letters, numbers, hyphens, dots, and underscores, up to 63 characters in length.

- **Taints:** The `taints` field expects an array of one or more objects, adhering to the guidelines outlined in the Kubernetes [Taints and Tolerations](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) documentation. A taint consists of a `key`, `value`, and `effect`:

  ```
  "taints": [
      {
          "key": "myapp.io/app",
          "value": "test",
          "effect": "NoSchedule"
      }
  ]
  ```

  - **Key:** The `key` value must begin with a letter or number, and may contain letters, numbers, hyphens, dots, and underscores, up to 253 characters. Optionally, the `key` value can begin with a DNS subdomain prefix and a single slash (`/`), like `example.com/my-app`. In this case the maximum allowed length of the domain prefix is 253 characters.
  - **Value:** The `value` key is optional. If given, it must begin with a letter or number, and may contain letters, numbers, hyphens, dots, and underscores, up to 63 characters.
  - **Effect:** The `effect` value must be NoSchedule, PreferNoSchedule, or NoExecute.

 > Note: 
  Taint and label values cannot contain `kubernetes.io` or `linode.com` domains as these are reserved for LKE's own usage.

You can also add, edit, or remove labels and taints on existing node pools using the Linode API. The example cURL command below demonstrates how to remove taints and update the labels on an existing node pool. If you are copying this command to run on your own LKE cluster, replace {{\< placeholder "12345" >}} with the ID of your LKE cluster and {{\< placeholder "196" >}} with the ID of your node pool.

```
curl -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -X PUT -d '{
        "type": "g6-standard-1",
        "count": 3,
        "taints": [],
        "labels": {
            "myapp.io/app": "prod",
            "example": "foo",
        }
    }' https://api.linode.com/v4/lke/clusters/{{< placeholder "12345" >}}/pools/{{< placeholder "196" >}}
```

The above command results in the following changes to the node pool, assuming the labels and taints were originally entered as shown in the first create command.

- Removes the "myapp.io/app" taint by specifying an empty array in the `taints` field.
- Changes the label "myapp.io/app" to have a value of "prod" instead of "test".
- Adds the new label "example=foo".

 > Note: 
  When updating or adding labels and taints to an existing node pool, it is not necessary to recycle it. This is because the values are updated live on the running nodes.

## [Resize your LKE node pool](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#resize-your-lke-node-pool)

You can resize an LKE cluster's node pool to add or decrease its number of nodes. You need your cluster's ID and the node pool's ID in order to resize it. If you don’t know your cluster’s ID, see the [List LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) section. If you don’t know your node pool's ID, see the [List a Cluster’s Node Pools](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-a-clusters-node-pools) section.

 > Error: 
  Shrinking a node pool results in deletion of Linodes. Any local storage on deleted Linodes (such as `hostPath` and `emptyDir` volumes, or "local" PersistentVolumes) is erased.

 > Note: 
  You cannot modify an existing node pool's plan type. If you would like your LKE cluster to use a different node pool plan type, you can [add a new node pool](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#add-a-node-pool-to-your-lke-cluster) to your cluster with the same number of nodes to replace the current node pool. You can then [delete the node pool](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#delete-a-node-pool-from-an-lke-cluster) that is no longer needed.

| Required Parameters | Description                                   |
| ------------------- | --------------------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup.              |
| `poolId`            | ID of the LKE node pool to lookup.            |
| `count`             | The number of Linodes in the node pool. |

To update your node pool's node count, send a `PUT` request to the `/lke/clusters/{clusterId}/pools/{poolId}` endpoint. In the URL of this example, replace `12345` with your cluster's ID and `196` with your node pool's ID:

```
curl -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -X PUT -d '{
        "type": "g6-standard-4",
        "count": 6
    }' https://api.linode.com/v4/lke/clusters/12345/pools/196
```

 > Note: 
  Each Linode account has a limit to the number of resources they can deploy. This includes services, like Linodes, NodeBalancers, Block Storage, etc. If you run into issues deploying the number of nodes you designate for a given cluster's node pool, you may have run into a limit on the number of resources allowed on your account. Contact [Linode Support](https://techdocs.akamai.com/cloud-computing/docs/help-and-support) if you believe this may be the case.

## [Recycle all nodes within a cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#recycle-all-nodes-within-a-cluster)

You can recycle all nodes within an LKE cluster to upgrade the nodes to the most recent patch of the cluster's Kubernetes version and to otherwise replace the Linodes that comprise the cluster. Nodes are recycled on a rolling basis, meaning that only one node is down at a time throughout the recycling process. You need your cluster's ID in order to recycle it's nodes. If you don’t know your cluster’s ID, see the [List LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) section.

 > Error: 
  Recycling your cluster involves deleting each of the Linodes in the node pool and replacing them with new Linodes. Any local storage on deleted Linodes (such as `hostPath` and `emptyDir` volumes, or "local" PersistentVolumes) is erased.

| Required Parameters | Description                      |
| ------------------- | -------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup. |

To recycle all nodes within a cluster, send a `POST` request to the `/lke/clusters/{clusterId}/pools/{poolId}/recycle` endpoint. In the URL of this example, replace `12345` with your cluster's ID:

```
curl -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -X POST \
    https://api.linode.com/v4/lke/clusters/12345/recycle
```

## [Recycle your LKE node pool](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#recycle-your-lke-node-pool)

You can recycle an LKE cluster's node pool to upgrade its nodes to the most recent patch of the cluster's Kubernetes version. Nodes are recycled on a rolling basis, meaning that only one node is down at a time throughout the recycling process. You need your cluster's ID and the node pool's ID in order to recycle it. If you don’t know your cluster’s ID, see the [List LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) section. If you don’t know your node pool's ID, see the [List a Cluster’s Node Pools](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-a-clusters-node-pools) section.

 > Error: 
  Recycling your node pool involves deleting each of the Linodes in the node pool and replacing them with new Linodes. Any local storage on deleted Linodes (such as `hostPath` and `emptyDir` volumes, or "local" PersistentVolumes) is erased.

| Required Parameters | Description                        |
| ------------------- | ---------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup.   |
| `poolId`            | ID of the LKE node pool to lookup. |

To recycle your node pool, send a `POST` request to the `/lke/clusters/{clusterId}/pools/{poolId}/recycle` endpoint. In the URL of this example, replace `12345` with your cluster's ID and `196` with your node pool's ID:

```
curl -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -X POST \
    https://api.linode.com/v4/lke/clusters/12345/pools/196/recycle
```

## [Recycle a single node within a node pool](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#recycle-a-single-node-within-a-node-pool)

You can recycle an individual node within a LKE Cluster's Node Pool. You need your cluster's ID and the node ID in order to recycle it. If you don’t know your cluster’s ID, see the [List LKE Clusters](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-lke-clusters) section. If you don’t know your node ID, see the [List a Cluster’s Node Pools](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#list-a-clusters-node-pools) section.

 > Error: 
  Recycling a Node involves deleting that Linode and replacing it with a new Linode. Any local storage on the deleted Linode (such as `hostPath` and `emptyDir` volumes, or "local" PersistentVolumes) is erased.

| Required Parameters | Description                      |
| ------------------- | -------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup. |
| `nodeId`            | ID of the LKE node to lookup.    |

To recycle your node, send a `POST` request to the `/lke/clusters/{clusterId}/nodes/{nodeId}/recycle` endpoint. In the URL of this example, replace `12345` with your cluster's ID and `12345-6aa78910bc` with your node ID:

```
curl -H "Authorization: Bearer $TOKEN" \
    https://api.linode.com/v4/lke/clusters/12345/nodes/12345-6aa78910bc
```

## [Upgrade your LKE cluster to the next minor version](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#upgrade-your-lke-cluster-to-the-next-minor-version)

| Required Parameters | Description                          |
| ------------------- | ------------------------------------ |
| `clusterId`         | ID of the LKE cluster to lookup.     |
| `k8s_version`       | The next minor version of Kubernetes |

To upgrade your LKE cluster's version, send a `PUT` request to the `/lke/clusters/{clusterId}` endpoint. In this example, ensure you replace `12345` with your cluster's ID, and `1.17` with whichever Kubernetes version is the next currently available:

```
curl -H "Content-Type: application/json" \
        -H "Authorization: Bearer $TOKEN" \
        -X PUT -d '{
        "k8s_version": "1.17"
        }' https://api.linode.com/v4/lke/clusters/12345
```

The response body displays the cluster version that will be applied following a [recycle](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#recycle-all-nodes-within-a-cluster):

```text Output
{"created": "2019-08-02T17:17:49", "updated": "2019-08-05T19:11:19", "k8s_version": "1.17", "tags": ["ecomm", "blogs"], "label": "updated-cluster-name", "id": 456, "region": "us-central"}%
```

 > Error: 
  Nodes within the LKE cluster _must_ be [recycled](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#recycle-all-nodes-within-a-cluster) before the cluster version will be successfully upgraded.

## [Add new tags to your LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#add-new-tags-to-your-lke-cluster)

Like many Linode resources, you can [add tags](https://techdocs.akamai.com/cloud-computing/docs/tags-and-groups) to your LKE Cluster for organizational purposes. This section shows you how to add new tags to an existing LKE Cluster.

 > Note: View all of your account's tags
  To view all of the tags existing on your account, issue the following request against the API:
  ```
 curl -H "Authorization: Bearer $TOKEN" \
 https://api.linode.com/v4/tags
 ```
  Your response resembles the example:
  ```text Output
 {"data": [{"label": "blogs"}, {"label": "ecomm"}, {"label": "prod"}, {"label": "monitoring"}], "page": 1, "pages": 1, "results": 4}%
 ```

1. View the tags currently assigned to your cluster:

   ```
   curl -H "Authorization: Bearer $TOKEN" \
     https://api.linode.com/v4/lke/clusters/12345
   ```

   The response body contains an array of your cluster's tags. In the example response, the cluster's tags are `blog`, and `ecomm`.

   ```text Output
   {"id": 12345, "status": "ready", "created": "2020-04-13T20:17:22", "updated": "2020-04-13T20:17:22", "label": "cluster-12345", "region": "us-central", "k8s_version": "1.17", "tags": ["blog", "ecomm"]}%
   ```

2. To add new tags to your cluster's existing tags, your request must include a `tags` array with all **previous** and **new** tags. The example request adds the new tags `prod` and `monitoring` to the cluster.

   ```
   curl -H "Content-Type: application/json" \
         -H "Authorization: Bearer $TOKEN" \
         -X PUT -d '{
           "tags" : ["ecomm", "blog", "prod", "monitoring"]
         }' \
         https://api.linode.com/v4/lke/clusters/12345
   ```

   The response displays all of your cluster's tags. In the example response, the cluster's tags are now `blog`, `ecomm`, `prod`, and `monitoring`.

   ```text Output
   {"id": 12345, "status": "ready", "created": "2020-04-13T20:17:22", "updated": "2020-04-13T20:17:22", "label": "cluster-12345", "region": "us-central", "k8s_version": "1.17", "tags": ["blog", "ecomm", "monitoring", "prod"]}%
   ```

## [Delete tags from your LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#delete-tags-from-your-lke-cluster)

This section shows you how to delete tags from your LKE Cluster.

1. View the tags currently assigned to your cluster:

   ```
   curl -H "Authorization: Bearer $TOKEN" \
     https://api.linode.com/v4/lke/clusters/12345
   ```

   The response body contains an array of your cluster's tags. In the example response, the cluster's tags are `blog`, `ecomm`, `prod`, and `monitoring`.

   ```text Output
   {"id": 12345, "status": "ready", "created": "2020-04-13T20:17:22", "updated": "2020-04-13T20:17:22", "label": "cluster-12345", "region": "us-central", "k8s_version": "1.17", "tags": [["blog", "ecomm", "monitoring", "prod"]}%
   ```

2. To delete a tag from your cluster, issue a request with only the tags you would like to keep assigned to your cluster. In the example request, the tags `monitoring` and `prod` are excluded from the `tags` array and so are deleted from your cluster.

   ```
   curl -H "Content-Type: application/json" \
         -H "Authorization: Bearer $TOKEN" \
         -X PUT -d '{
           "tags" : ["ecomm", "blog"]
         }' \
         https://api.linode.com/v4/lke/clusters/12345
   ```

   The response displays all of your cluster's current tags. In the example response, the cluster's tags are now `blog`, and `ecomm`.

   ```text Output
   {"id": 12345, "status": "ready", "created": "2020-04-13T20:17:22", "updated": "2020-04-13T20:17:22", "label": "cluster-12345", "region": "us-central", "k8s_version": "1.17", "tags": ["blog", "ecomm"]}%
   ```

## [Delete a node pool from an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#delete-a-node-pool-from-an-lke-cluster)

When you delete a node pool you also delete the Linodes (nodes) and routes to them. The Pods running on those nodes are evicted and rescheduled. If you have [assigned Pods to the deleted Nodes](https://kubernetes.io/docs/concepts/configuration/assign-pod-node), the Pods might remain in an unschedulable condition if no other node in the cluster satisfies the [node selector](https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#nodeselector).

| Required Parameters | Description                        |
| ------------------- | ---------------------------------- |
| `clusterId`         | ID of the LKE cluster to lookup.   |
| `poolId`            | ID of the LKE node pool to lookup. |

To delete a node pool from a LKE cluster, send a `DELETE` request to the `/lke/clusters/{clusterId}/pools/{poolId}` end point. In the URL of this example, replace `12345` with your cluster's ID and `196` with your cluster's node pool ID:

 > Error: 
  This step is permanent and results in the loss of data.

```
curl -H "Authorization: Bearer $TOKEN" \
    -X DELETE \
    https://api.linode.com/v4/lke/clusters/12345/pools/196
```

# [Delete an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#delete-an-lke-cluster)

Deleting an LKE cluster deletes the **Master node**, all **worker nodes**, and all **NodeBalancers** created by the cluster. However, it does **not delete any volumes** created by the LKE cluster.

To delete an LKE Cluster, send a `DELETE` request to the `/lke/clusters/{clusterId}` endpoint. In the URL of this example, replace `12345` with your cluster's ID:

 > Error: 
  This step is permanent and results in the loss of data.

```
curl -H "Authorization: Bearer $TOKEN" \
    -X DELETE \
    https://api.linode.com/v4/lke/clusters/12345
```

# [Where to go from here?](https://techdocs.akamai.com/cloud-computing/docs/deploy-and-manage-a-kubernetes-cluster-with-the-api#where-to-go-from-here)

Now that you have created an LKE cluster, you can start deploying workloads to it. Review these guides for further help:

- [How to Install Apps on Kubernetes with Helm 3](https://linode.com/docs/guides/how-to-install-apps-on-kubernetes-with-helm-3/)
- [Create and Deploy a Docker Container Image to a Kubernetes Cluster](https://linode.com/docs/guides/deploy-container-image-to-kubernetes/)
- [Troubleshooting Kubernetes](https://linode.com/docs/guides/troubleshooting-kubernetes/)