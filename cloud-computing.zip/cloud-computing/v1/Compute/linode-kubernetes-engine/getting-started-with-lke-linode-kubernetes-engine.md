# [Getting started with LKE](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-lke-linode-kubernetes-engine#getting-started-with-lke)

# [Create an LKE cluster](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-lke-linode-kubernetes-engine#create-an-lke-cluster)

For complete instructions on creating a cluster, see [Create a cluster](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster). 

1. Log into your [Cloud Manager](https://cloud.linode.com/) account.

2. Select Kubernetes from the left navigation menu and then click **Create Cluster**.

3. The **Create a Kubernetes Cluster** page appears. At the top of the page, you are required to select the following options:

   - In the **Cluster Label** field, provide a name for your cluster. The name must be unique between all of the clusters on your account. This name is how you identify your cluster in Cloud Manager’s Dashboard.

   - From the **Region** dropdown menu, select the **Region** where you would like your cluster to reside.

   - From the **Version** dropdown menu, select a Kubernetes version to deploy to your cluster.

4. In the **Add Node Pools** section, select the [hardware resources](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#compute-resources) for the Linode worker node(s) that make up your LKE cluster. To the right of each plan, select the plus `+` and minus `-` to add or remove a Linode to a node pool one at time.

5. Once you're satisfied with the number of nodes in a node pool, select **Add** to include it in your configuration. If you decide that you need more or fewer hardware resources after you deploy your cluster, you can always [edit your Node Pool](https://techdocs.akamai.com/cloud-computing/docs/manage-nodes-and-node-pools).

6. Once a pool has been added to your configuration, it is listed in the **Cluster Summary** on the right-hand side of Cloud Manager detailing your cluster's hardware resources and monthly cost. Additional pools can be added before finalizing the cluster creation process by repeating the previous step for each additional pool.

7. When you are satisfied with the configuration of your cluster, click the **Create Cluster** button on the right hand side of the screen. Your cluster's detail page appears, and your Node Pools are listed on this page. From this page, you can [edit your existing Node Pools](https://techdocs.akamai.com/cloud-computing/docs/manage-nodes-and-node-pools), [access your Kubeconfig file](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-lke-linode-kubernetes-engine#access-and-download-your-kubeconfig), and view an overview of your cluster's resource details.

# [Install kubectl](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-lke-linode-kubernetes-engine#install-kubectl)

For complete instructions on installing and using kubectl with LKE, see [Manage a cluster with kubectl](https://techdocs.akamai.com/cloud-computing/docs/manage-a-cluster-with-kubectl).

**macOS:**

Install via [Homebrew](https://brew.sh):

```
brew install kubernetes-cli
```

**Linux:**

1. Download the latest kubectl release:

   ```
   curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl
   ```

2. Make the downloaded file executable:

   ```
   chmod +x ./kubectl
   ```

3. Move the command into your PATH:

   ```
   sudo mv ./kubectl /usr/local/bin/kubectl
   ```

**Windows:**

Visit the [Kubernetes documentation](https://kubernetes.io/docs/tasks/tools/install-kubectl/#install-kubectl-on-windows) for a link to the most recent Windows release.

# [Access and download your kubeconfig](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-lke-linode-kubernetes-engine#access-and-download-your-kubeconfig)

1. To access your cluster's kubeconfig, log in to your Cloud Manager account and navigate to the **Kubernetes** section.

2. From the Kubernetes listing page, click on your cluster's **more options ellipsis** and select **Download kubeconfig**. The file is saved to your computer's `Downloads` folder.

3. Open a terminal shell and save your kubeconfig file's path to the `$KUBECONFIG` environment variable. In the example command, the kubeconfig file is located in the `Downloads` folder, but you should alter this line with this folder's location on your computer:

   ```
   export KUBECONFIG=~/Downloads/kubeconfig.yaml
   ```

4. View your cluster's nodes using kubectl.

   ```
   kubectl get nodes
   ```

# [General network and firewall information](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-lke-linode-kubernetes-engine#general-network-and-firewall-information)

See [Network and firewall details](https://techdocs.akamai.com/cloud-computing/docs/lke-network-firewall-details) . 

# [Next steps](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-lke-linode-kubernetes-engine#next-steps)

Now that you have a running LKE cluster, you can start deploying workloads to it. Refer to our other guides to learn more:

- [How to Deploy a Static Site on Linode Kubernetes Engine](https://linode.com/docs/guides/how-to-deploy-a-static-site-on-linode-kubernetes-engine/)
- [Create and Deploy a Docker Container Image to a Kubernetes Cluster](https://linode.com/docs/guides/deploy-container-image-to-kubernetes/)
- [Troubleshooting Kubernetes Guide](https://linode.com/docs/guides/troubleshooting-kubernetes/)
- [See all our Kubernetes guides](https://linode.com/docs/guides/kubernetes/)