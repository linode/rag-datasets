# [High availability (HA) control plane on LKE](https://techdocs.akamai.com/cloud-computing/docs/high-availability-ha-control-plane-on-lke#high-availability-ha-control-plane-on-lke)

In Kubernetes, the control plane is the set of components that orchestrate the cluster and manage the worker nodes (Linodes) in that cluster and the pods (containers) within the worker nodes. The control plane components include the Kubernetes API server (`kube-apiserver`), etcd, the Kubernetes scheduler (`kube-scheduler`), the cloud controller manager (`cloud-controller-manager`), and the Kubernetes controller manager (`kube-controller-manager`).

Within Akamai Cloud, this control plane is fully managed by LKE (the Linode Kubernetes Engine). By default, these components are not replicated. If any of them fail, it's possible that there may be issues with your cluster. Enabling **HA (High Availability) Control Plane** adds an additional layer of redundancy by replicating these control plane components. In doing so, this feature can ensure that the cluster experiences maximum uptime and is recommended for all production applications running on LKE.

# [Cost](https://techdocs.akamai.com/cloud-computing/docs/high-availability-ha-control-plane-on-lke#cost)

The HA control plane feature is an optional billable service that starts at $60/month per cluster, depending on region. For more information, see our [pricing page](https://www.linode.com/pricing/).

 > Error: 
  While upgrading to an HA cluster is always possible, **downgrading your cluster is not currently supported**. Enabling HA is an **irreversible** change for your cluster.

# [Replication and uptime details](https://techdocs.akamai.com/cloud-computing/docs/high-availability-ha-control-plane-on-lke#replication-and-uptime-details)

When HA control plane is enabled on a cluster, the following control plane components are replicated:

- **etcd** and **kube-apiserver** increases from _one_ to _three_ replicas.
- All other components, including the **Cloud Controller Manager**, **kube-scheduler**, and **kube-controller-manager**, increase from _one_ to _two_ replicas, with leader election put in place.

When multiple replicas are created, they are always placed on separate infrastructure to better support uptime and redundancy. This configuration maintains a guaranteed 99.99% uptime for the control plane and worker nodes (API service).

# [Enable during cluster creation](https://techdocs.akamai.com/cloud-computing/docs/high-availability-ha-control-plane-on-lke#enable-during-cluster-creation)

To enable this feature when creating a cluster, check the **Enable HA Control Plane** box in the Cluster Summary section. Review the [Create a Cluster](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#optionally-enable-high-availability) guide for full instructions.

  

# [Enable on existing clusters](https://techdocs.akamai.com/cloud-computing/docs/high-availability-ha-control-plane-on-lke#enable-on-existing-clusters)

If a cluster was created _without_ this feature, you can enable it at any time.

 > Warning: 
  Enabling the high availability control plane feature may result in _brief and temporary_ downtime while the cluster is upgraded and the following actions are performed:
  - All nodes will be deleted and new nodes are created to replace them.
 - Any local storage (such as `hostPath` volumes) will be erased.
  The upgrade process may take several minutes to complete, as nodes are replaced on a rolling basis.

High Availability can be added to pre-existing clusters at any given time through the cluster's **Summary Page**.

1. To reach the summary page for the cluster, navigate first to the [Kubernetes section of Cloud Manager](https://cloud.linode.com/kubernetes/clusters).

2. Select the Cluster by label that you would like to enable HA for. The summary page for the cluster appears.

3. To enable HA, select the **Upgrade to HA** button at the top of the page.

   

4. A new window appears, asking you to confirm all of the changes that come with High Availability. Read through the message and select the **Enable HA Control Plane** checkbox to confirm that you agree to the changes. Then click the **Upgrade to HA** button.

   