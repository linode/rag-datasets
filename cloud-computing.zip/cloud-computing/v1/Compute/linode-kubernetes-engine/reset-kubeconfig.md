# [Reset kubeconfig](https://techdocs.akamai.com/cloud-computing/docs/reset-kubeconfig#reset-kubeconfig)

## [Reset cluster kubeconfig](https://techdocs.akamai.com/cloud-computing/docs/reset-kubeconfig#reset-cluster-kubeconfig)

In cases where access to a cluster using a current kubeconfig must be revoked, LKE provides the ability to **Reset** a cluster kubeconfig. This will effectively remove the current kubeconfig, and create a new one for cluster administrators to use.

1. To reset the cluster kubeconfig access the [cluster's details page](https://techdocs.akamai.com/cloud-computing/docs/manage-kubernetes-clusters-on-lke).

2. Select the **Reset** button under the **kubeconfig** sub-category.

   

3. A confirmation message will appear confirming the Kubeconfig reset. Select the **Reset kubeconfig** button to proceed.

A new kubeconfig will now be created. Once this process is completed, the new kubeconfig can be [Accessed and Downloaded](https://techdocs.akamai.com/cloud-computing/docs/manage-a-cluster-with-kubectl) as usual.