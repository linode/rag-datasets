# [Control Plane ACLs](https://techdocs.akamai.com/cloud-computing/docs/control-plane-acls#control-plane-acls)

Every Kubernetes cluster has a control plane containing the core components responsible for cluster orchestration. To protect against unwanted changes to these control plane components, it’s important to take proper steps to restrict access. Akamai has updated LKE to include support for control plane access control lists (ACLs), available on all clusters at no additional charge. Using control plane ACLs, you can block all traffic to these core components by default and allow only the IP addresses that will be used by your team. This prevents unintended or malicious traffic from reaching these critical systems.

A control plane ACL is specific to each cluster. It is currently not possible to cascade a single ACL across multiple clusters. If you wish to utilize similar ACLs across your LKE deployments, you must manually define the ACL settings for each cluster.

# [Configuration Options](https://techdocs.akamai.com/cloud-computing/docs/control-plane-acls#configuration-options)

Control plane ACLs offer simplified configuration options compared to other firewall solutions. You can adjust the activation state (enabled or disabled), add or remove IP addresses, and view or adjust the revision ID to track changes.

- **Activation Status:** This defines if the ACL is enabled or disabled. When enabled, the default policy is to _DENY_ incoming traffic unless it originates from one of the allowed IP addresses.
- **Addresses:** Addresses consist of a list of IPv4 and IPv6 addresses and ranges (in CIDR format). When the ACL is enabled on the cluster, all traffic to the control plane is blocked _unless_ it originates from one of these IP addresses or ranges.
- **Revision ID:** This is a unique string for identifying each revision to the cluster's ACL policy. It can be used by clients to track events related to ACL update requests and enforcement. While this defaults to a randomly generated string, you can edit it if you prefer to specify your own string to use for tracking a particular revision.

# [Enable the control plane ACL during cluster creation](https://techdocs.akamai.com/cloud-computing/docs/control-plane-acls#enable-the-control-plane-acl-during-cluster-creation)

To enable the ACL when creating a cluster, make sure the **Enable Control Plane ACL** toggle is set to _Enabled_. Then, add any IP addresses you or your team plan on using to connect to the cluster. You can always adjust this setting or add / remove IP addresses after the cluster has been created. Review the [Create a Cluster](https://techdocs.akamai.com/cloud-computing/docs/create-a-cluster#enable-a-control-plane-acl-optional) guide for full instructions.

# [View, enable, and change ACL settings](https://techdocs.akamai.com/cloud-computing/docs/control-plane-acls#view-enable-and-change-acl-settings)

Within the Cloud Manager, you can determine the status of the control plane ACL by looking at the **Control Plane ACL** field within a cluster's summary page.

- A value of _Enable_ means the ACL is not enabled but can be enabled by clicking the **Enable** link.
- A value of _Enabled (x IP addresses)_ , where _x_ the number of IP addresses configured on the ACL, means that the ACL is enabled. Click the link to change the ACL status or modify the IP addresses.

If you enable the control plane ACL on an existing cluster, it may take up to 20 minutes for the ACL rules to take effect.