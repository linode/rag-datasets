# [Akamai App Platform (for LKE)](https://techdocs.akamai.com/cloud-computing/docs/application-platform#akamai-app-platform-for-lke)

The Akamai App Platform is a ready-to-run platform for Kubernetes that makes it easy to build, manage, and deploy applications. It's integrated with LKE, our managed Kubernetes solution. The App Platform offers the following features:

- A self-service portal for developers to deploy services, build images, create secrets, and publicly expose services.
- An integrated and pre-configured stack of open source projects to support all the essential capabilities for running cloud native applications in production on Kubernetes.
- A catalog with pre-built customizable templates.
- Kubernetes Operators and GitOps to manage the state of the platform based on configuration-as-code.

 > Note: Documentation for the Akamai App Platform
  To learn more about the App Platform, visit our [Getting Started](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-akamai-application-platform) guide. To view all of our documentation for the App Platform, visit [Akamai App Platform Docs](https://techdocs.akamai.com/app-platform/docs/welcome).

# [Benefits of the Akamai App Platform](https://techdocs.akamai.com/cloud-computing/docs/application-platform#benefits-of-the-akamai-app-platform)

## [Key benefits](https://techdocs.akamai.com/cloud-computing/docs/application-platform#key-benefits)

- Speed up time to market by automating and simplifying building and running applications on Kubernetes, reducing the complexity for development teams.
- Reduce developer workloads and avoid technical debt by providing a pre-configured and integrated suite of tools for CI/CD, observability and security out-of-the-box, accelerating an application's delivery and enhancing its security.
- Support multi-tenancy by allowing multiple teams or projects to share the same cluster, with self-service features that enable faster, independent deployments by developers.
- Allow developers to build, deploy, expose, observe and secure containerized applications on Kubernetes using a web based self-service portal

## [Additional developer benefits](https://techdocs.akamai.com/cloud-computing/docs/application-platform#additional-developer-benefits)

- Build OCI compliant images from source code.
- Deploy containerized workloads the GitOps way using the provided quickstarts or BYO golden path templates.
- Automatically update container images of workloads.
- Publicly expose applications.
- Get instant access to logs, metrics and traces.
- Store images in a private registry.
- Configure network policies, response headers and CNAMEs.
- Check applications against a comprehensive set of build-in security policies.
- Create and manage secrets.
- Create private git repositories and use the built-in CI/CD pipelines

## [Additional administrative benefits](https://techdocs.akamai.com/cloud-computing/docs/application-platform#additional-administrative-benefits)

- Get all the required capabilities in an integrated and automated way.
- Onboard development Teams in a comprehensive multi-tenant setup and make them self-serving.
- Manage users.
- Ensure governance with security policies.
- Implement zero-trust networking.
- Change the desired state of the platform based on Configuration-as-Code.
- Support multi-cloud and hybrid cloud scenarios.
- Prevent cloud provider lock-in.
- Implement full observability.
- Comply to Disaster Recovery requirements

# [Akamai Cloud integration](https://techdocs.akamai.com/cloud-computing/docs/application-platform#akamai-cloud-integration)

The Akamai App Platform is offered as a one-click extension for the Linode Kubernetes Engine (LKE). When enabled, the following integrations are included:

- Akamai Edge DNS for name resolving
- Let’s Encrypt certificates for all exposed services
- (optional) Object Storage for storing images, logs, metrics, traces and database backups

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/application-platform#pricing)

Using the App Platform is free of charge, though certain paid products and services are required.

- An LKE cluster with at least 3 worker nodes, each with a minimum of 16 GB of memory and 4 vCPUs.
- HA control plane enabled on the LKE cluster.
- A NodeBalancer.
- 11 Block Storage volumes.
- When the option is selected to use Object Storage, additional costs will be charged for data stored in seven (7) Buckets.

Make sure your account limits are sufficient before enabling the App Platform when creating a new LKE cluster.