# [Linode Managed](https://techdocs.akamai.com/cloud-computing/docs/linode-managed#linode-managed)

Downtime is expensive and puts your company’s reputation at risk. [Linode Managed](https://www.linode.com/products/managed/) helps minimize this risk through a suite of services and products aimed at monitoring your Linodes and minimizing downtime.

 > Note: 
  Linode Managed applies to all Linodes on your account _except_ for nodes created and implemented by [Linode Kubernetes Engine (LKE)](https://www.linode.com/products/kubernetes/). If you don't need this service for all of your Linodes, you can create a second account, to separate your Linode Managed Linodes from non-Linode Managed ones. To move Linodes between accounts, review the [Transfer Services to a Different Account](https://techdocs.akamai.com/cloud-computing/docs/transfer-services-to-a-different-account) guide.

# [Benefits](https://techdocs.akamai.com/cloud-computing/docs/linode-managed#benefits)

- **24/7 Monitoring and Incident Response**. The core benefit of Linode Managed is 24/7 monitoring and incident response. You can configure monitors for URLs, IP addresses, or TCP ports. This monitor periodically makes a TCP or HTTP request to that property. If a check fails, our experts take immediate steps to get your systems back online as quickly as possible. If they are not able to fix the issue, our experts will share their findings and the steps they've taken so far. Linode Managed does not include assistance with maintenance, updates, or the configuration of software on your Linodes. 

- **Included Services and Software**. The following services and software applications are included at no additional charge to Managed Services customers

  - [cPanel](https://cpanel.net/). A cPanel license is included for each Linode on your account. Each license automatically scales to accommodate the number of [cPanel accounts](https://support.cpanel.net/hc/en-us/articles/1500004931582-What-is-an-Account/) you've configured within the cPanel installation.
  - [Backups](https://techdocs.akamai.com/cloud-computing/docs/backup-service). The Backups service is added to each Linode on your account for no extra charge. This service automatically backs up the Linode each day and lets you restore from the most recent daily backup, weekly backup, and biweekly backup. See [Get Started with Backups](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-the-linode-backup-service) for more information on backup restore points.
  - [Longview Pro](https://techdocs.akamai.com/cloud-computing/docs/longview). Longview is our own metric service designed to help you keep track of your Linodes' performance. The free version of Longview is limited to collecting data at 5 minute intervals and storing only 12 hours worth of historical data. Longview Pro dramatically increases the data collection intervals and retains this data longer:
    - 1 minute resolution for the past 24 hours
    - 5 minute resolution for the past week
    - 2 hour resolution for the past month
    - 1 day resolution for the past year

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/linode-managed#pricing)

The cost for Linode Managed is $100 per Linode, per month. For example, if you have 10 Linode on your account, your total monthly cost will be $1,000.

 > Note: 
  Worker nodes created by the [Linode Kubernetes Engine (LKE)](https://www.linode.com/products/kubernetes/) are not considered Linodes for Linode Managed billing purposes. These Linode are not billed when enrolling in Linode Managed.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/linode-managed#availability)

Linode Managed can be added to any account to monitor services across all [all core compute regions](https://www.linode.com/global-infrastructure/), but is not supported in distributed compute regions.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/linode-managed#technical-specifications)

- Monitors can be configured to send TCP or HTTP requests to an IP address or URL on any TCP port (default port is 80).
  - **TCP**. Periodically initiates a TCP handshake to the specified property.
  - **HTTP**. Periodically sends an HTTP/S request to the specified property and either looks for a `200 OK` response header or a specified string in the response body.
- Credentials can be added to allow our experts access to your system when troubleshooting. These credentials are encrypted and can be revoked by you at any time.