# [Reset the root password on a Linode](https://techdocs.akamai.com/cloud-computing/docs/reset-the-root-password-on-a-compute-instance#reset-the-root-password-on-a-linode)

All Linodes deployed using an [official distribution image](https://techdocs.akamai.com/cloud-computing/docs/choose-a-distribution) provide the ability to reset the root password on the system. This is useful if you ever lock yourself out of your Linode's root account or are simply rotating your password for security. Follow the instructions below to reset your root password:

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.

2. Click the **Power Off** button in the upper right of the Linode's dashboard or within the **ellipsis** menu. Wait until the Linode has been fully powered off before continuing to the next step.

   

3. Navigate to the **Settings** tab.

4. Scroll down to the **Reset Root Password** section.

   ![A screenshot of the Reset Root Password section.](https://techdocs.akamai.com/linode/compute/img/linodes-reset-root-password-v1.png)

5. Select your primary disk from the **Disk** dropdown menu.

6. Enter a new password for the root user in the **New Root Password** field.

7. Click **Save** to make the change.

8. Click **Power On** button to turn on your Linode.

You can now use this new password when logging in as the root user on your Linode over [SSH](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) (Linode Shell). If you're able to log in as root using Lish but not SSH, there may be an issue with the SSH configuration, firewall rules, or other network issues. The following guides provide more troubleshooting steps:

- [Troubleshooting basic connection issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-basic-connection-issues-on-compute-instances)
- [Troubleshooting SSH on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-ssh-on-compute-instances)
- [Troubleshooting firewall issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances)