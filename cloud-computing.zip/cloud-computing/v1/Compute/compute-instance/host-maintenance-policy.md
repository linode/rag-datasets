# [Maintenance events and policies](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy#maintenance-events-and-policies)

 > Warning: Beta notice for maintenance policies
  The user-definable maintenance policy setting has been launched as part of an open beta in all regions. During the beta period, not all planned maintenance events may respect your selected preference.

During the lifecycle of most cloud-based virtual machines, such as Linodes, it's often necessary for maintenance to be performed by the service provider. At Akamai, host upgrades and other types of planned maintenance are crucial for maintaining our cloud infrastructure's security, performance, and compliance. Our goal is to maintain our fleet while minimizing any impact to our customers.

# [Types of maintenance](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy#types-of-maintenance)

- **Planned (scheduled) maintenance**: Routine maintenance, such as host upgrades, and other non-emergency maintenance activities are scheduled in advance. 
- **Emergency maintenance:** In rarer circumstances, issues may arise with the underlying host or infrastructure that necessitates emergency maintenance. In these cases, swift action will be taken to minimize downtime experienced by Linodes and correct the underlying issue. Affected customers will be notified of the emergency maintenance event shortly after we become aware of the issue and will be kept apprised of any action taken on their Linode(s).

# [Maintenance policies](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy#maintenance-policies)

During most planned maintenance activities, the maintenance can be performed while the Linode is still running. For some workloads, you may prefer that your VM is instead powered off during maintenance. You can define your preference as part of the **Maintenance policy** setting, which can be set on the account-level (the default for new Linodes) and on each individual Linode. The following policy options are available:

- **Migrate**: _Recommended for maximizing availability_.  Migrates the Linode to a new host while it is still running. During the migration, the instance remains fully operational, though there is a temporary performance impact. For most maintenance events and Linode types, no reboot is required after the migration completes. If a reboot is required, it is automatically performed. This method employs live migrations for most Linode plans, though warm migrations will be used in some cases, such as for GPU plans. If your Linode is in a powered off state before the maintenance begins, the system will fall back to the _power off / power on_ method.
- **Power off / power on**: _Recommended for maximizing performance_. Powers off the Linode at the start of the maintenance event and reboots it once the maintenance finishes. While your Linode is powered off, any workloads running on it exclusively will experience downtime. Downtime can be mitigating by employing a high availability application architecture. Depending on the maintenance event and Linode type, the Linode may or may not remain on the same host. Do not select this option for Linode that are used for container orchestration solutions like Kubernetes. This method includes both cold migrations and in-place upgrades.

The selected maintenance policy setting is used (whenever possible) during planned maintenance. During some maintenance, it may not be possible to perform a migration in which your Linode remains operational. In these cases, the system will fall-back to the _power off / power on_ method and your Linode will experience some amount of downtime.

To learn more about migration methods employed on the Akamai Cloud platform, see [Migrations within Akamai Cloud](https://techdocs.akamai.com/cloud-computing/docs/compute-migrations).

# [Events and notification windows](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy#events-and-notification-windows)

A maintenance event is created whenever maintenance is performed (or scheduled to be performed) on your Linode. These maintenance events are visible through the following services:

- **Cloud Manager:** Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Maintenance** (under **Administration**) in the sidebar menu. This page lists all maintenance events that are in progress, upcoming, or have already been completed.
- **Linode API:** The [GET /account/maintenance](https://techdocs.akamai.com/linode-api/reference/get-maintenance)  operation outputs an array of all maintenance events for your account.
- **Metadata API:** The [/v1/maintenance/events](https://techdocs.akamai.com/cloud-computing/docs/metadata-service-api#maintenance-events-v1maintenanceevents)  operation outputs all maintenance events for the Linode. Since this requires access to the Linode, this is primarily for programmatically obtaining details on upcoming scheduled maintenance.

For scheduled maintenance, a timeline is also communicated through these maintenance events so that you can prepare and, if needed, make any necessary adjustments to your workloads or applications. For maintenance that requires your Linode be powered off, you are notified through a support ticket and email.

- **Migration-based maintenance:** A maintenance event is added to your account 3 hours before any planned maintenance starts. Due to seamless nature of most migrations, no support ticket or email is sent to customers.
- **Power off/on maintenance:** A maintenance event is added to your account 3 days (72 hours) before any planned maintenance starts. At that time, a support ticket is created to notify you of the maintenance and an email is sent to your email address on file.

# [Set the maintenance policy](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy#set-the-maintenance-policy)

## [Account-wide setting](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy#account-wide-setting)

To set the default policy for new Linodes, you can adjust the account-wide **Maintenance policy** setting. _Adjusting your preference here does not impact the maintenance policy setting on your existing Linodes._

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Account Settings** (under **Administration**) in the sidebar menu.

2. Scroll down to the _Host Maintenance Policy_ section and select your desired setting in the dropdown menu.

   

3. Click the **Save Maintenance Policy** button to use the selected policy as the default policy for new Linodes.

To adjust any existing Linodes, see the [Individual Linode setting](#individual-linode-setting) section below.

## [Individual Linode setting](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy#individual-linode-setting)

The **Maintenance policy** setting for a Linode can be defined when deploying a new Linode or modifying an existing Linode. Within Cloud Manager, this setting is visible in both the **Create Linode** form and in the **Settings** tab when viewing an existing Linode. To adjust this setting on an existing Linode, follow the steps below.

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to the **Linodes** page from the link in the sidebar.

2. Select the Linode that you wish to modify and navigate to the **Settings** tab.

3. Scroll down to the section labeled **Host Maintenance Policy** and select your preferred policy setting.

   

4. Click the **Save** button to save the maintenance policy for this Linode.