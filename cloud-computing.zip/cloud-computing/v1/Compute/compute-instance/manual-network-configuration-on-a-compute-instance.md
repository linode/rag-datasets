# [Manual network configuration on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance#manual-network-configuration-on-a-linode)

Every Linode is assigned several IP addresses, including a public IPv4 address and a public IPv6 [SLAAC](https://en.wikipedia.org/wiki/IPv6#Stateless_address_autoconfiguration_.28SLAAC.29) address. By default, a utility called [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) automatically configures these IP addresses within the network configuration files on the Linode. While this is preferred in most cases, there are some situations which may require you to manually configure networking yourself. These situations include:

- Installing a custom distribution on a Linode
- Configuring failover (see [Configuring Failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance))
- Assigning addresses from an IPv6 routed range
- Using other DNS resolvers (not Akamai's)
- Other advanced use cases where custom network configuration is required

The guides in this series walk you through how to manually configure your networking in most common Linux distributions. To learn more about the types of IP addresses available on a Linode, review the [Managing IP addresses on a Linode](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#types-of-ip-addresses) guide. Additional public IPv4 addresses, private IPv4 addresses, and IPv6 routed ranges (/64 or /56) can be added manually or by opening a [support ticket](https://techdocs.akamai.com/cloud-computing/docs/help-and-support) and detailing your requirements.

# [Network configuration software in Linux](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance#network-configuration-software-in-linux)

All Linux distributions have pre-installed software whose purpose is to manage the internal networking on the system. In most cases, using this default software is preferred. That said, advanced users may wish to install their own preferred tool.

## [Default network configuration software by distribution](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance#default-network-configuration-software-by-distribution)

The following table contains a list of each Linux distribution. Alongside each distribution is the default network software that it uses and a link to a guide for help with configuring that software.

| Distribution              | Network Manager                                                                                                             |
| ------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| AlmaLinux 8 and above     | [NetworkManager](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-networkmanager)                                                            |
| Alpine                    | [ifupdown-ng](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown)                                                                     |
| Arch                      | [systemd-networkd](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd)                                                        |
| CentOS 7 and 8            | [NetworkManager](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-networkmanager)                                                            |
| CentOS Stream 8 and above | [NetworkManager](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-networkmanager)                                                            |
| Debian 9 and above        | [ifupdown](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown)                                                                        |
| Fedora                    | [NetworkManager](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-networkmanager)                                                            |
| Gentoo                    | netifrc                                                                                                                     |
| Rocky Linux 8 and above   | [NetworkManager](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-networkmanager)                                                            |
| Slackware                 | netconfig                                                                                                                   |
| openSUSE Leap             | wicked                                                                                                                      |
| Ubuntu 16.04              | [ifupdown](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown)                                                                        |
| Ubuntu 18.04 and above    | [systemd-networkd](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd) and [Netplan](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-netplan) |

To manually configure networking, follow the associated guide and/or the official manual for the networking software and Linux distribution you are using.

# [Static vs dynamic addressing](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance#static-vs-dynamic-addressing)

IP addresses can be statically configured or dynamically configured through DHCP (for public IPv4 addresses) and SLAAC (for primary IPv6 addresses).

- **Static** configuration means explicitly defining the IP address within your system's network configuration. IPv4 addresses are configured this way through Network Helper and static configuration of IPv4 and IPv6 routed ranges is typically recommended when manually configuring your networking.

- **DHCP** (Dynamic Host Configuration Protocol) can be used to automatically configure a single IPv4 address on a Linode. If you intend on adding or removing public IPv4 addresses after you initially configure networking, using DHCP is not recommended as it may configure a different public IPv4 address after you make those changes.

  - **Public interfaces**: If multiple IPv4 addresses are on the system, the first IP address (sorted alpha-numerically) is used. DHCP does not configure private IPv4 addresses or any IPv6 addresses.
  - **VPC interfaces**: DHCP can be used to automatically configure the VPC IP address.

  > > Note: 
  > 
  > If you do enable DHCP and are using a firewall (such as Cloud Firewalls), you must configure the firewall to allow communication with our DHCP servers. See the [DHCP IP address reference](https://techdocs.akamai.com/cloud-computing/docs/dhcp-ip-address-reference) guide for a list of IP addresses to allow.

  > > Note: 
  > 
  > If you have a Linode with a public interface and a VPC interface, a default gateway will be configured for both interfaces when using DHCP. This will cause issues routing traffic towards the internet and other VPC subnets. To address this, manually remove one of the default gateways.

- **SLAAC** (Stateless address autoconfiguration) can _and should_ be used to automatically configure the main IPv6 address on a Linode. It does not configure any IPv6 routed ranges (/64 or /56) that may also be assigned to that Linode. For SLAAC to function, the Linode needs to accept router advertisements. This is accomplished by enabling router advertisements and disabling IPv6 privacy extensions within your system's networking configuration files. These settings are properly configured by default in our supported distributions.

Static and dynamic addressing can be used together within a single configuration file. As an example, you can use DHCP to configure the public IPv4 address on your system, use SLAAC to configure your IPv6 address, and statically configure any remaining addresses (such as private IPv4 address or addresses from an IPv6 routed range).

# [Networking terms](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance#networking-terms)

- **IP address:** A unique and structured combination of numbers (and letters, for IPv6 address) used to identify a device over a network. Every Linode is assigned a public IPv4 address and a public IPv6 address. Additional IP addresses, including private IPv4 addresses and IPv6 routed ranges, are available. See [Managing IP addresses on a Linode](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance) for information on viewing your IP addresses.

- **Interface:** A real or virtual device that is responsible for facilitating a connection to a network. There are three available network interfaces corresponding to the devices assigned within the Linux system: _eth0_, _eth1_, and _eth2_. See [Manage configuration profiles](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance) for instructions on viewing the interfaces configured on your Linode.

- **Gateway:** Provides access to a larger network, such as the internet. When configuring a Linode, you only need to specify a gateway for one interface. See [Managing IP addresses on a Linode](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance) for details on finding the gateway IP address that corresponds with the primary IPv4 address you wish to use.

- **DNS resolver:** A server responsible for matching domain names to IP addresses. We provide DNS resolvers for each data center, though you are free to use others if you choose. See [DNS resolvers](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers) for more information.