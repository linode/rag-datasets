# [DNS resolvers](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers#dns-resolvers)

# [Overview](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers#overview)

Each region is assigned 10 DNS resolvers, which support queries over IPv4 and IPv6. When a Linode is created with [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) enabled, three of DNS resolvers' IPv4 addresses are assigned to the Linode in its local DNS nameserver configuration file (typically `/etc/resolv.conf`). While these are recursive resolvers, they are not considered “open.” That is, they can only be queried from within Linode IP network space. DNSSEC queries are supported. As of July 2025, DNS over TLS (DoT) and DNS over HTTPS (DoH) queries are not supported.

# [Obtaining regions’ DNS resolvers’ addresses](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers#obtaining-regions-dns-resolvers-addresses)

You can retrieve a list of a region’s DNS resolvers in the following ways.

### [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers#cloud-manager)

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Linodes** link in the sidebar.
2. Click on your Linode from the list to view more details.
3. Navigate to the **Network** tab and review the **DNS Resolvers** list, which should appear to the right of (or below) the _Network Transfer History_ graph.

### [API](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers#api)

You can make a GET request to retrieve DNS resolvers’ addresses from either [all regions](https://techdocs.akamai.com/linode-api/reference/get-regions) at once or a [specific region](https://techdocs.akamai.com/linode-api/reference/get-region). The response will return both IPv4 and IPv6 sets of addresses as part of the resolvers object.

### [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers#linode-cli)

You can also use the [Linode CLI](https://techdocs.akamai.com/cloud-computing/docs/cli). See [List regions](https://techdocs.akamai.com/linode-api/reference/get-regions) and [Get a region](https://techdocs.akamai.com/linode-api/reference/get-region) for specific command examples. You can find them at the top of each page.

# [Security](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers#security)

In order to protect the reliability and integrity of our DNS resolvers, we impose rate-limiting mechanisms intended to throttle potentially abusive traffic. This involves two types of rate protections:

- Limiting the volume of inbound queries per IP address. As of July 2025, we permit 7,500 queries per client IP address over a 5 second interval. Any queries in excess of this limit are dropped.
- Limiting the volume of outbound responses per IP address. As of July 2025, we permit 75,000 large byte responses over a 60 second interval. Large byte responses are defined as exceeding 512 bytes. Any responses in excess of this limit are dropped.

 > Warning: 
  These limits are subject to change.

If you find that one or more of your Linodes are consistently exceeding these limits, consider the following solutions:

- Investigate possible OS or application misconfigurations. These might cause unnecessary queries at a high rate.
- Use local DNS caching. There are a number of open-source free solutions that offer the ability to keep responses cached locally for a set amount of time.
- Install your own recursive resolvers. Many free recursive DNS resolution solutions are available to install on one or more of your Linodes. Rather than pointing your Linodes at our nameservers, you can point them at your own, giving you full control over how queries are handled.
- Contact customer support. If the previous options are insufficient, a member from our support team can help provide guidance on how to best address your requirements.