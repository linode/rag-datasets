# [Configure IP failover over BGP using FRR (advanced)](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#configure-ip-failover-over-bgp-using-frr-advanced)

This guide covers using the open source FRRouting (FRR) tool to configure failover between two Linodes. FRR is a routing service that uses BGP to monitor and fail over components in a high availability configuration. These instructions supplement the general [Configure failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance) guide and are intended as an advanced alternative to lelastic when more control and customization is needed.

# [Before you begin](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#before-you-begin)

Before following this guide, ensure the following has been done on each Linode used within your IP failover strategy.

1. Read through the [Configure failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance) guide to learn more about how failover is implemented within Akamai Cloud.
   > > Note: 
   > 
   > To support the BGP method of IP Sharing and failover, your Linode must be assigned an IPv6 address. This is not an issue for most Linodes as an IPv6 address is assigned during deployment. If your Linode was created _before_ IPv6 addresses were automatically assigned, and you would like to enable IP Sharing within a data center that uses BGP-based failover, contact [Support](https://www.linode.com/support/).
2. Set the [hostname](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#configure-a-custom-hostname) and [update the hosts file](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#update-your-systems-hosts-file) for each Linode.
3. Verify Python3 is installed. See [FRR's official documentation](http://docs.frrouting.org/en/latest/installation.html#python-dependency-documentation-and-tests) to learn about FRR's Python dependencies.

# [Configure failover](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#configure-failover)

These instructions enable you to configure failover using FRR, which is very configurable and can be used for advanced failover implementation. This guide depends on the general [Configure failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance) guide for many steps.

To configure failover, complete each section in the order shown:

1. [Create and share the shared IP address](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#1-create-and-share-the-shared-ip-address)
2. For _each_ Linode:
   - [Add the shared IP to the networking configuration](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#2-add-the-shared-ip-to-the-networking-configuration)
   - [Install FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#install-frr)
   - [Configure FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#configure-frr)
3. [Test failover](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#test-failover)

# [Install FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#install-frr)

This section provides instructions for installing FRR on Debian, Ubuntu, and CentOS systems through their native package managers. If you're using a different distribution or prefer to install FRR from source, follow [FRR's official installation instructions](http://docs.frrouting.org/en/latest/installation.html) to install FRR using git.

## [Debian and Ubuntu](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#debian-and-ubuntu)

**Supported distributions:** _Ubuntu 20.04, 18.04, and 16.04 | Debian 11, 10, and 9_

1. Set the FRR environment variable to the version you would like to install. The possible values are `frr-6`, `frr-7`, `frr-8`, and `frr-stable`, though it is recommended to use `frr-stable` to install the latest stable version.

   ```
   FRRVER="frr-stable"
   ```

   > > Note: 
   > 
   > For more information on FRR versions, see the [FRR Debian repository](https://deb.frrouting.org/) and [FRR's Github Releases](https://github.com/FRRouting/frr/releases).

2. If you're running an older Debian-based system, you may need to install the packages below, which come default with most modern Debian-based distributions.

   ```
   sudo apt update && sudo apt install apt-transport-https gnupg
   ```

3. Add FRR's GPG key:

   ```
   curl -s https://deb.frrouting.org/frr/keys.asc | sudo apt-key add -
   ```

4. Add FRR's Debian repository to your system's source's list:

   ```
   echo deb https://deb.frrouting.org/frr $(lsb_release -s -c) $FRRVER | sudo tee -a /etc/apt/sources.list.d/frr.list
   ```

5. Install FRR:

   ```
   sudo apt install frr frr-pythontools
   ```

## [CentOS/RHEL 7 and 8](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#centosrhel-7-and-8)

**Supported distributions:** _CentOS Stream 9 (and 8), CentOS 8 (and 7), other RHEL derivatives (including AlmaLinux 8, and Rocky Linux 8), and Fedora._

1. Set the FRR environment variable to the version you would like to install. The possible values are `frr-6`, `frr-7`, `frr-8`, and `frr-stable`, though it is recommended to use `frr-stable` to install the latest stable version.

   ```
   FRRVER="frr-stable"
   ```

   > > Note: 
   > 
   > For more information on FRR versions, see the [FRR RPM repository](https://rpm.frrouting.org/) and [FRR's Github Releases](https://github.com/FRRouting/frr/releases).

2. Add FRR's RPM repository to your system:

   - **CentOS/RHEL 8**

     ```
     curl -O https://rpm.frrouting.org/repo/$FRRVER-repo-1-0.el8.noarch.rpm
     sudo dnf install ./$FRRVER*

     ```

   - **CentOS/RHEL 7**

     ```
     curl -O https://rpm.frrouting.org/repo/$FRRVER-repo-1-0.el7.noarch.rpm
     sudo yum install ./$FRRVER*
     ```

3. Install FRR:

   - **CentOS/RHEL 8**

     ```
     sudo dnf install frr frr-pythontools
     ```

   - **CentOS/RHEL 7**

     ```
     sudo yum install frr frr-pythontools
     ```

# [Configure FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced#configure-frr)

With FRR installed, you can now configure it to enable IP failover.

1. FRR works using a variety of protocols. Since we're using FRR for its BGP support, the next step is to explicitly enable the `bgpd` daemon. Using a text editor of your choice, enable the `bgpd` daemon by updating its value to `yes` in the FRR daemons configuration file:

   ```text /etc/frr/daemons
   # The watchfrr and zebra daemons are always started.
   #
   bgpd=yes
   ```

2. Gather the following information, which is required for the next step:

   - **Shared IP address** (`[SHARED_IP]`): The IPv4 address you shared or an address from the IPv6 range that you shared. You can choose any address from the IPv6 range. For example, within the range _2001:db8:e001:1b8c::/64_, the address `2001:db8:e001:1b8c::1` can be used.
   - **Prefix** (`[PREFIX]`): For an IPv4 address, use `32`. For an IPv6 address, use either `56` or `64` depending on the size of the range you are sharing.
   - **Protocol** (`[PROTOCOL]`): Use `ipv4` when sharing an IPv4 address and `ipv6` when sharing an IPv6 address.
   - **Hostname** (`[HOSTNAME]`): The hostname defined on the Linode you are configuring (ex: `atl-bgp-1`).
   - **Role** (`[ROLE]`): The role of this Linode within your failover strategy.
     - `primary`: All requests are routed to this Linode, provided it is accessible.
     - `secondary`: If the `primary` Linode fails, all requests are routed to this Linode, provided it is accessible.
   - **Data center ID** (`[DC_ID]`): The ID of your data center. See [IP Sharing availability](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#ip-sharing-availability) for the corresponding ID.

3. Edit the `/etc/frr/frr.conf` file and add the following lines. Ensure you replace any Linodes of `[SHARED_IP]`, `[HOSTNAME]`, `[ROLE]`, and `[DC_ID]` as outlined above.

   ```text /etc/frr/frr.conf
   hostname [HOSTNAME]

   router bgp 65001
   no bgp ebgp-requires-policy
   coalesce-time 1000
   bgp bestpath as-path multipath-relax
   neighbor RS peer-group
   neighbor RS remote-as external
   neighbor RS ebgp-multihop 10
   neighbor RS capability extended-nexthop
   neighbor 2600:3c0f:[DC_ID]:34::1 peer-group RS
   neighbor 2600:3c0f:[DC_ID]:34::2 peer-group RS
   neighbor 2600:3c0f:[DC_ID]:34::3 peer-group RS
   neighbor 2600:3c0f:[DC_ID]:34::4 peer-group RS

   address-family [PROTOCOL] unicast
     network [SHARED_IP]/[PREFIX] route-map [ROLE]
     redistribute static
     neighbor RS activate
   exit-address-family

   route-map primary permit 10
     set community 65000:1
   route-map secondary permit 10
     set community 65000:2

   ipv6 nht resolve-via-default
   ```

4. Restart the FRR service:

   ```
   sudo systemctl restart frr
   ```