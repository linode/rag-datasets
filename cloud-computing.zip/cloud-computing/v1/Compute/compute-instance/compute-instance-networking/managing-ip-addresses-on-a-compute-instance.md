# [Manage IP addresses on a Linode](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#manage-ip-addresses-on-a-linode)

Each Linode is equipped with several IP addresses, which may enable it to be accessible over the public Internet and other Akamai services or accessible just to other Linodes within a VPC. This guide covers how to manage these IP addresses (including viewing, adding, removing, transferring, or sharing them) through Cloud Manager.

# [Viewing IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#viewing-ip-addresses)

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Linodes** link in the sidebar.

2. Click on your Linode from the list to view more details.

3. Within the top _Summary_ section, you can view the primary IPv4 and IPv6 addresses.

   

4. To view all public and private IP addresses for this Linode (along with any associated rDNS values), click the **View all IP Addresses** link or navigate to the **Network** tab and review the **IP Addresses** section.

   

   IP addresses for a VPC or VLAN interface are visible in the **Configurations** tab.

# [Types of IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#types-of-ip-addresses)

## [IPv4](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#ipv4)

- **Public IPv4 Address:** Most Linodes (those created without a VPC) have a single public IPv4 address, which enables your applications to be accessible over the Internet. Additional addresses can be provided with technical justification. If a VPC interface is configured when a Linode is created, that Linode typically does not have a public IPv4 address _unless_ the _Assign a public IPv4 address_ option is selected.

- **VPC IPv4 Address:** If a Linode is assigned to a VPC, that Linode is assigned an IPv4 address from the CIDR range configured on the subnet. This IP address can be automatically generated or manually provided. Optionally, if the _Assign a public IPv4 address_ option is selected during creation, the Linode is assigned public IPv4 address as well.

- **VLAN IPv4 Address:** When a Linode is configured with a VLAN, you assign it a IPv4 address to use within the VLAN. It is also automatically assigned a public IPv4 address.

- **Private IPv4 Address:** Optionally, a private IPv4 address can be assigned to a Linode. This allows it to connect to other services located in the same data center, such as NodeBalancers or other Linodes. Private IPv4 addresses are available for [configuration profile interfaces](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance) but are not supported on [Linode interfaces](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces). Private IP addresses are not supported for Linodes in [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions). For Linodes in these regions, you may be able to use IPv6 or VLAN instead.

 > Note: A VPC is the recommended method for network isolation
  In most cases, a VPC is the better option for true network isolation than either a VLAN or a private IP address. For a comparison between these methods, review the [VPC](https://techdocs.akamai.com/cloud-computing/docs/vpc#difference-between-private-network-options-vpcs-vlans-and-private-ips) documentation.

## [IPv6 addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#ipv6-addresses)

- **IPv6 SLAAC Address:** This is the main IPv6 address used to communicate over the public Internet and with other services in the same data center. All Linodes are assigned a single SLAAC address, which cannot be removed or transferred. Additional SLAAC addresses cannot be provided. If you need an additional IPv6 address, consider using a /64 range (see below).

- **IPv6 Link Local:** This IPv6 address is assigned to each Linode and used for internal routing.

- **/64 Routed Range:** This is the most common range provided to our customers and sufficient for most applications that require additional IPv6 addresses. A single /64 range provides 18,446,744,073,709,551,616 addresses that can be used when configuring the applications within your system. See the [Manual network configuration on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) guide for instructions on configuring specific addresses from a range. By default, up to one /64 range can be added per customer per data center.

- **/56 Routed Range:** These larger ranges are typically only required by specialized systems or networking applications. A single /56 range provides 4,722,366,482,869,645,213,696 addresses that can be used when configuring the applications within your system. See [Manual network configuration on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) for instructions on configuring specific addresses from a range. By default, up to one /56 range can be added per customer per data center.

- **/116 Pool:** _(4,096 addresses)_ An IPv6 pool is accessible from every Linode on your account within the assigned data center. Addresses from that pool can be configured on each Linode within that data center. This can enable features like IPv6 failover. By default, up to one /116 pool can be added per customer per data center.

  > > Error: 
  > 
  > The IPv6 /116 prefix has been deprecated and is no longer available for new Linodes. If you have an existing Linode with a /116 pool, please review the [Upcoming changes related to network infrastructure upgrades](https://techdocs.akamai.com/cloud-computing/docs/upcoming-changes-related-to-network-infrastructure-upgrades) to learn about changes that may affect your services.

# [Adding an IP address](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#adding-an-ip-address)

## [Configuration profile interfaces](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuration-profile-interfaces)

Follow the instructions below to add an public IPv4, private IPv4, or IPv6 range to your Linode. By default, up to one /64 and /56 range can be added per customer per data center.

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Linodes** link in the sidebar.

2. Click on your Linode from the list and navigate to the **Network** tab.

3. Click the **Add an IP Address** button under the _IP Address_ section. This displays the _Add an IP Address_ panel.

   

4. Within the form, select the type of IP address (or range) you wish to add. If you aren't sure, review the [Types of IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#types-of-ip-addresses) section and consider your own use case.

   ![A screenshot of the Add an IP Address panel showing two sections: IPv4 and IPv6. For IPv4, you can select Public or Private. For IPv6, you can select /64 or /56.  There's the Allocate button under both sections.](https://techdocs.akamai.com/linode/compute/img/linodes-add-ip-address-form-v1.png)

5. Click the **Allocate** button to add the additional address. If you receive a message similar to the following, you need to [contact our Support team](https://www.linode.com/support/) to request the IP address. Make sure to include any additional information or technical reasoning for the request.

   > Additional IPv4 addresses require technical justification. Please open a Support Ticket describing your requirement

   Once the IP address or range has been added, it should be visible in the _IP Address_ section.

6. To make sure the new IP address is configured within the internal system of the Linode, verify that [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) is enabled and reboot the Linode.

 > Note: 
  Network Helper sorts IP addresses numerically. This may result in the gateway being updated to match the lowest enumerated IP.

If Network Helper is turned off _and_ you've [configured a static IP address](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance), you need to update the configuration files with the new IP address or enable Network Helper.

 > Note: 
  Due to the [impending exhaustion of the IPv4 address space](http://en.wikipedia.org/wiki/IPv4_address_exhaustion), you're requires to provide technical justification for additional public IPv4 addresses. If you have an application that requires multiple IP addresses, consider using an IPv6 /64 range instead. Note that pricing for additional public IPv4 addresses may vary by region.

## [Linode interfaces (BETA)](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#linode-interfaces-beta)

You can add IP addresses for Public and VPC interfaces. For more information, see [Manage Linode interfaces](managing-linode-interfaces#edit-public-or-vpc-network-interfaces).

# [Configuring rDNS](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuring-rdns)

To change the rDNS value on an IP address, follow the instructions in [Configure rDNS (reverse DNS) on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-rdns-reverse-dns-on-a-compute-instance).

# [Deleting an IP address](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#deleting-an-ip-address)

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Linodes** link in the sidebar.

2. Click your Linode in the list and navigate to the **Network** tab.

3. Select the **Delete** menu option for the IP address you'd like to remove

   

4. A pop-up confirmation dialog appears. Click the **Delete Range** button to confirm the request.

5. To make sure the IP address is removed from the internal system of the Linode, verify that [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) is enabled and reboot the Linode.

   If Network Helper is turned off _and_ you've [configured a static IP address](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance), you need to update the configuration files to remove the IP address or enable Network Helper.

# [Transferring IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#transferring-ip-addresses)

If you have two Linodes in the same data center, you can use the _IP transfer_ feature to move or swap their IP addresses. This feature is especially useful when replacing one Linode with another. It lets you quickly move the IP addresses to the new Linode without needing to manually adjust DNS records with the new addresses.

 > Note: 
  This process only transfers IPv4 addresses and IPv6 ranges, not IPv6 SLAAC addresses. See [Transferring an IPv6 SLAAC address](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#transferring-an-ipv6-slaac-address) below for a workaround.

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Linodes** link in the sidebar.

2. Click on your Linode from the list and navigate to the **Network** tab.

3. Press the **IP Transfer** button in the _IP Addresses_ table.

   

4. Locate the IP address or range you would like to transfer and select an action from the dropdown menu:

   - **Move To:** moves the IP address to another Linode. When choosing this option, select the destination Linode in the next dropdown menu that appears. If you are moving a public IPv4 address, there needs to be at least one remaining public IPv4 address on the source Linode.
   - **Swap With:** swaps the IP addresses of two Linodes. When choosing this option, select the destination Linode in the next dropdown menu that appears. Then select the IP address (belonging to the destination Linode) you would like to swap with the originally selected IP address.

   > > Note: 
   > 
   > The _IP Transfer_ form only displays Linodes hosted in the same data center as the current Linode.

5. Click **Save** to transfer the requested IPs.

6. To make sure the new IP addresses take affect within the internal configuration of each Linode, verify that [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) is enabled and reboot the affected Linode(s). It may take up to 1-2 minutes for the transfer to take affect.

   If Network Helper is turned off _and_ you've [configured a static IP address](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance), you need to update the configuration files with the new IP addresses or enable Network Helper.

   > > Note: 
   > 
   > If the IP is unreachable after a few minutes, you may need to notify the router directly of the IP change with the `arp` command run on your Linode:
   > 
   > ````
   > ```
   > arping -c5 -I eth0 -s 198.51.100.10 198.51.100.1
   > ping -c5 198.51.100.10 198.51.100.1
   > ```
   > Replace `198.51.100.10` with your new IP address, and `198.51.100.1` with the gateway address listed in your Networking tab under the **Default Gateways** column of the *IP Addresses* table.
   > ````

## [Transferring an IPv6 SLAAC address](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#transferring-an-ipv6-slaac-address)

IPv6 SLAAC addresses are not able to be transferred between Linodes. If this is something you need to do, consider moving the applications you want to be hosted on that IPv6 address over to the Linode containing that IPv6 address. One way to accomplish this is to clone the disks containing the data. See the [Clone to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/clone-a-compute-instance#clone-to-an-existing-linode) section of the **Clone a Linode** guide. After the cloning process has completed, transfer any required IPv4 addresses.

# [Configuring IP Sharing](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuring-ip-sharing)

_IP Sharing_ is a feature that enables two Linodes to be assigned the same IP address for the purpose of configuring failover. Within a typical failover setup, traffic on the shared IP address is routed to the primary Linode. In the event that Linode fails or goes down, traffic is automatically re-routed to the secondary Linode. While IP Sharing can be configured in Cloud Manager, failover must be manually configured within the internal system of both Linodes. See [Configure failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance) to learn more about configuring failover.

 > Warning: 
  When IP Sharing is enabled for an IP address, all connectivity to that IP address is immediately lost _until_ it is configured on [Lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#3-install-and-configure-lelastic), [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced), or another routing software. This is not an issue when adding a new IP address, but should be considered if you are enabling IP Sharing on an existing IP address that is actively being used.

To learn how to enable IP Sharing within Cloud Manager, review the following steps.

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Linodes** link in the sidebar.

2. Determine which two Linodes are to be used within your failover setup. They both must be located in the same data center. Make sure the IP address you wish to share has been added to one of those Linodes. If not, add it now. See [Adding an IP address](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#adding-an-ip-address).

3. Of those two Linodes, select the one that does not yet have the Shared IP addresses assigned to it. Then, navigate to the **Network** tab.

4. Click the **IP Sharing** button under the _IP Addresses_ section.

   

5. The _IP Sharing_ form appears with a list of IP addresses that are available to be shared. Select the IP address you wish to share with this Linode.

   > > Note: 
   > 
   > If your desired IP address does not appear in that list, verify that the Linode to which it belongs has at least two public IPv4 addresses or has been assigned an IPv6 routed range (/56 or /64).

6. Click **Save** to enable IP Sharing.

7. After enabling IP Sharing in Cloud Manager, the next step is to configure a failover service (such as FRR, lelastic, or Keepalived) within the internal system on each Linode. For more information, see [Configure failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance).

# [Viewing the DNS resolvers' IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#viewing-the-dns-resolvers-ip-addresses)

Each data center has its own set of [DNS resolvers](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers), which are accessed through both IPv4 or IPv6 addresses. To view the DNS resolvers, follow the instructions below.

1. Log in to [Cloud Manager](https://cloud.linode.com) and click the **Linodes** link in the sidebar.

2. Click on your Linode from the list to view more details.

3. Navigate to the **Network** tab and review the **DNS Resolvers** list, which should appear to the right of (or below) the network transfer graph.

   

# [Confirming IP addresses are correctly configured](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#confirming-ip-addresses-are-correctly-configured)

Our platform's [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) tool automatically configures the internal network settings of your Linode's Linux system. This ensures changes made to your IP addresses within Cloud Manager are also made internally on your Linode. If you decide not to use Network Helper or are using a custom unsupported distribution, you need to manually configure your system's networking. In this case, review the [Manual network configuration on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) guide.

To verify that your IP addresses are correctly configured, run the `ip` command on your Linode (see [man pages reference](https://linux.die.net/man/8/ip)), specifically `ip a show` (`ip addr show`). For more information on using this command, see [Use the IP command in Linux](https://linode.com/docs/guides/how-to-use-the-linux-ip-command/#how-to-find-your-ip-address) .