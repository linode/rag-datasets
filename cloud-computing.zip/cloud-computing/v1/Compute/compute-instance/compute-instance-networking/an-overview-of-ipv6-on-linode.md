# [IPv6 on Linodes](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode#ipv6-on-linodes)

All Linodes are created with one IPv6 address, which is acquired by [_Stateless Address Autoconfiguration_](https://en.wikipedia.org/wiki/IPv6#Stateless_address_autoconfiguration_(SLAAC)) (SLAAC). IPv6 is fully enabled on all supported operating systems and uses hardware-based addressing.

Private IPv6 address allocations aren't offered, but our IPv6 accounting was designed so that local IPv6 traffic does not count against your [network transfer quota](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs), so you can use your default IPv6 address as if it were a private IP address.

 > Note: 
  In order for your Linode to receive its SLAAC address, it must respond to IPv6's ping protocol.
  Please be sure to allow ICMPv6 in your [firewall](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#configure-a-firewall). For example, in `iptables`, you can issue the following commands:
  ```
 ip6tables -A INPUT -p icmpv6 -j ACCEPT
 ip6tables -A FORWARD -p icmpv6 -j ACCEPT
 ```

# [How to find your IPv6 address](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode#how-to-find-your-ipv6-address)

You can find your Linode's IPv6 address using Cloud Manager or the `ip` tool with the Linux Terminal.

## [Using Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode#using-cloud-manager)

See the [Viewing IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#viewing-ip-addresses) section of _Managing IP addresses on a Linode_.

## [Linux terminal](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode#linux-terminal)

1. Using your terminal, SSH into the Linode whose IPv6 address you would like to find.

   ```
   ssh user@192.0.2.0
   ```

2. Use the `ip` tool to find your Linode's IPv6 address:

   ```
   ip -6 address
   ```

   ```text Output
   1: lo: 
 mtu 65536 state UNKNOWN qlen 1
       inet6 ::1/128 scope host
         valid_lft forever preferred_lft forever
   3: eth0: 
 mtu 1500 state UP qlen 1000
       inet6 2600:3c02::f03c:91ff:fe24:3a2f/64 scope global mngtmpaddr dynamic
         valid_lft 2591998sec preferred_lft 604798sec
       inet6 fe80::f03c:91ff:fe24:3a2f/64 scope link
         valid_lft forever preferred_lft forever
   ```

- Line 3 shows the IPv6 loopback interface, `::1/128`. This is used for IPv6 traffic within the system, similar to the `127.0.0.0/8` IPv4 address block.

- Line 6 is the Linode's public IP address, `2600:3c02::f03c:91ff:fe24:3a2f/64`. You can see it's in a `/64` range.

- Line 8 is the link-local IPv6 address, `fe80::f03c:91ff:fe24:3a2f/64`. An IPv6 link-local address is a unicast address that is automatically configured on any interface.

If your Linode does not have the correct IPv6 address or any IPv6 address at all, you should verify that you have router advertisements enabled and IPv6 privacy extensions disabled. Your Linode will need to accept router advertisements for SLAAC to function. These settings are properly configured by default in our supported distributions.

# [Additional IPv6 addresses](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode#additional-ipv6-addresses)

If a single IPv6 address isn't sufficient for your application, additional IPv6 addresses are provided through large address blocks, also called routed ranges or pools. From these ranges, you can manually configure individual IPv6 addresses on your Linode. See the [Managing IP addresses on a Linode](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#adding-an-ip-address) and [Manual network configuration on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) guides for instructions on adding an IPv6 range and to learn how to configure it within your system.

The size of each block is identified through a prefix. These are indicated with a slash `/` followed by a number in base 10: the length of the network **prefix** in bits. This translates to the number of available addresses that are available in the range (or pool). For example, the prefix `/48` contains 2
128-48
 = 2
80
 = 1,208,925,819,614,629,174,706,176 addresses. For an address like `2001:db8:1234::/48` the block of addresses is `2001:db8:1234:0000:0000:0000:0000:0000` to `2001:db8:1234:ffff:ffff:ffff:ffff:ffff`.

The IPv6 prefixes and their respective quantity of IPv6 addresses provided are listed below.

## [IPv6 routed ranges](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode#ipv6-routed-ranges)

An IPv6 routed range is assigned to a single Linode. Addresses from that range can only be configured on that Linode.

 > Note: 
  Configuring a `/64` or `/56` routed range requires you to [disable Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#enable-or-disable-network-helper) on your Linode and manually configure its network settings. Please review the [Managing IP addresses on a Linode](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#adding-an-ip-address) and [Manual network configuration on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) guides for details on this process.

- `/64` **routed range** _(18,446,744,073,709,551,616 addresses)_: This is the most common range provided to our customers and sufficient for most applications that require additional IPv6 addresses.
- `/56` **routed range** _(4,722,366,482,869,645,213,696 addresses)_: These larger ranges are typically only required by specialized systems or networking applications.

## [IPv6 pools](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode#ipv6-pools)

An IPv6 pool is accessible from every Linode on your account within the assigned data center. Addresses from that pool can be configured on each Linode within that data center. This can enable features like IPv6 failover.

- `/116` **pool** _(4,096 addresses)_

 > Error: 
  The IPv6 /116 prefix has been deprecated and is no longer available for new Linodes. If you have an existing Linode with a /116 pool, please review the [Upcoming changes related to network infrastructure upgrades](https://techdocs.akamai.com/cloud-computing/docs/upcoming-changes-related-to-network-infrastructure-upgrades) to learn about changes that may affect your services.

# [IPv6 forwarding](https://techdocs.akamai.com/cloud-computing/docs/an-overview-of-ipv6-on-linode#ipv6-forwarding)

If needed, IPv6 packets can be forwarded between two networks on our platform. By default, most Linux systems disable both IPv4 and IPv6 forwarding. To enable this functionality, see the [IP Forwarding](https://linode.com/docs/guides/linux-router-and-ip-forwarding/) guide.