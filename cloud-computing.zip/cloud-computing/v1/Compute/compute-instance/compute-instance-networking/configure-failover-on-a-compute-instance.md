# [Configure failover on a Linode](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover-on-a-linode)

In cloud computing, _failover_ is the concept of rerouting traffic to a backup system should the original system become inaccessible. Linodes support failover through the [IP Sharing](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuring-ip-sharing) feature. This allows two Linodes to share a single IP address, one serving as the _primary_ and one serving as the _secondary_. If the primary Linode becomes unavailable, the shared IP address is seamlessly routed to the secondary Linode (fail_over_). Once the primary Linode is back online, the IP address route is restored (fail_back_).

# [Why should I implement failover?](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#why-should-i-implement-failover)

When hosting web-based services, the total uptime and availability of those services should be an important consideration. There’s always a possibility that your Linode may become inaccessible, perhaps due to a spike in traffic, your own internal configuration issues, a natural disaster, or planned (or unplanned) maintenance. When this happens, any websites or services hosted on that Linode would also stop working. Failover provides a mechanism for protecting your services against a single point of failure.

The term _high availability_ describes web application architectures that eliminate single points of failure, offering redundancy, monitoring, and failover to minimize downtime for your users. Adding a load balancing solution to your application’s infrastructure is commonly a key component of high availability. Managed solutions, like NodeBalancers, combine load balancing with built-in IP address failover. However, self-hosted solutions like Nginx or haproxy do not include built-in IP failover. Should the system running the load balancing software experience downtime, the entire application goes down. To prevent this, you need an additional server running your load balancing software and a mechanism to failover the IP address. On our cloud platform, this is accomplished through the IP Sharing feature and some additional software configuration.

 > Note: 
  For many production applications, you may want to consider a load balancing tool that goes beyond basic failover. [NodeBalancers](https://techdocs.akamai.com/cloud-computing/docs/nodebalancer) combines load balancing with built-in failover. If you are using self-hosted load balancing software, such as NGINX or [HAProxy](https://linode.com/docs/guides/how-to-use-haproxy-for-load-balancing/), on your own Linodes, you must use the IP Sharing feature to provide failover for IP addresses.

# [IP Sharing availability](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#ip-sharing-availability)

Failover is configured by first enabling [IP Sharing](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuring-ip-sharing) and then configuring software on both the primary and secondary Linodes. IP Sharing availability varies by region. Review the list below to learn which core compute regions support IP Sharing and how it can be implemented. To learn about IP Sharing in distributed compute regions, see [IP Sharing and failover in Distributed Compute Regions](https://techdocs.akamai.com/cloud-computing/docs/ip-sharing-distributed).

| Data center                | IP Sharing support | Failover method | Software                                                                                                                                      | ID |
| -------------------------- | ------------------ | --------------- | --------------------------------------------------------------------------------------------------------------------------------------------- | -- |
| Amsterdam (nl-ams)         | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 22 |
| Atlanta, GA (us-southeast) | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 4  |
| Chennai (in-maa)           | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 25 |
| Chicago, IL (us-ord)       | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 18 |
| Dallas, TX (us-central)    | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 2  |
| Frankfurt (eu-central)     | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 10 |
| Frankfurt 2 (de-fra-2)     | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 47 |
| Fremont, CA (us-west)      | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover)  / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced) | 3  |
| Jakarta (id-cgk)           | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 29 |
| London (eu-west)           | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 7  |
| London 2 (gb-lon)          | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 44 |
| Los Angeles, CA (us-lax)   | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 30 |
| Madrid (es-mad)            | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 24 |
| Melbourne (au-mel)         | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 45 |
| Miami, FL (us-mia)         | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 28 |
| Milan (it-mil)             | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 27 |
| Mumbai (ap-west)           | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 14 |
| Mumbai 2 (in-bom-2)        | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 46 |
| Newark, NJ (us-east)       | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 6  |
| Osaka (jp-osa)             | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 26 |
| Paris (fr-par)             | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 19 |
| São Paulo (br-gru)         | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 21 |
| Seattle, WA (us-sea)       | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 20 |
| Singapore (ap-south)       | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 9  |
| Singapore 2 (sg-sin-2)     | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 48 |
| Stockholm (se-sto)         | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 23 |
| Sydney (ap-southeast)      | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 16 |
| Tokyo 2 (ap-northeast)     | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 11 |
| Tokyo 3 (jp-tyo-3)         | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 49 |
| Toronto (ca-entral)        | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 15 |
| Washington, DC (us-iad)    | **Supported**      | BGP-based       | [lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover) / [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced)  | 17 |

 > Note: 
  - BGP-based IP Sharing uses IPv6 to communicate to the route-servers. This means both Linodes must have IPv6 configured and enabled on both Linodes, regardless of how they configure their BGP service.
 - IP failover for VLAN IP addresses is supported within every data center where VLANs are available. It does not depend on the IP Sharing feature. It depends on ARP-based failover software, such as keepalived.

# [IP address failover methods](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#ip-address-failover-methods)

- **ARP-based (legacy method):** Supports IPv4. This method is no longer supported.

- **BGP-based :** Supports IPv4 (public and private) and IPv6 routed ranges (/64 and /56). This is currently being rolled out across our fleet in conjunction with our [planned network infrastructure upgrades](https://techdocs.akamai.com/cloud-computing/docs/upcoming-changes-related-to-network-infrastructure-upgrades). Since it is implemented using BGP routing, customers can configure it on their Linodes using lelastic (our tool) or software like FRR, BIRD, or GoBGP.

  > > Note: 
  > 
  > While keepalived is not used directly for failover, you can still make use of `vrrp_scripts` for health checks. You might do so if you wish to retain some of your existing keepalived functionality when migrating to a BGP-based failover method.

# [Configure failover](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#configure-failover)

The instructions within this guide enable you to configure failover using IP Sharing and the [lelastic](https://github.com/linode/lelastic) tool we provide, which is based on GoBGP that automates much of the configuration. While lelastic enables many basic implementations of failover, you may want to consider using FRR or any other BGP client if your implementation is more advanced. See [Configure IP failover over BPG using FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced).

 > Note: 
  - If you've included your Linodes in a [placement group](https://techdocs.akamai.com/cloud-computing/docs/work-with-placement-groups), the group needs to use **Anti-affinity** as its Affinity Type, which spreads them out in a data center. The opposite Affinity Type, **Affinity** physically places Linodes close together, sometimes on the same host. This defeats the purpose of fail over.

To configure failover, complete each section that follows. Currently, only a two Linode failover solution is supported, with one as the _primary_ and the other as the _secondary_. Configuring more than two Linodes or setting both Linodes to the same role is not supported.

## [1. Create and share the Shared IP address](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#1-create-and-share-the-shared-ip-address)

1. Log in to [Cloud Manager](https://cloud.linode.com/).

2. Determine which two Linodes are to be used within your failover setup. They both must be located in the same data center. If you need to, create those Linodes now and allow them to fully boot up.

   > > Note: 
   > 
   > To support the BGP method of IP Sharing and failover, your Linode must be assigned an IPv6 address. This is not an issue for most Linodes as an IPv6 address is assigned during deployment. If your Linode was created _before_ IPv6 addresses were automatically assigned, and you would like to enable IP Sharing within a data center that uses BGP-based failover, contact [Support](https://www.linode.com/support/).

3. Disable Network Helper on both Linodes. For instructions, see the [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#individual-compute-instance-setting) guide.

4. Of the IP addresses assigned to your Linodes, determine which IP address you wish to use as the shared IP. You may want to add an additional IPv4 address _or_ IPv6 range (/64 or /56) to one of the Linodes, as this avoids temporary connectivity loss to applications that may be using your existing IP addresses. See [Managing IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#adding-an-ip-address) for instructions. _Each additional IPv4 address costs $2 per month_.

5. On the Linode that _is not_ assigned the IP address you selected in the previous step, add that IPv4 address or IPv6 range as a _Shared IP_ using the **IP Sharing** feature. See [Managing IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance#configuring-ip-sharing) for instructions on configuring IP sharing.

   > > Warning: 
   > 
   > When IP Sharing is enabled for an IP address, all connectivity to that IP address is immediately lost _until_ it is configured on [Lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#3-install-and-configure-lelastic), [FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced), or another BGP routing tool. This is not an issue when adding a new IP address, but should be considered if you are enabling IP Sharing on an existing IP address that is actively being used.

## [2. Add the shared IP to the networking configuration](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#2-add-the-shared-ip-to-the-networking-configuration)

Adjust the network configuration file on _each_ Linode, adding the shared IP address and restarting the service.

1. Log in to the Linode using [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

2. Add the shared IP address to the system's networking configuration file. Within the instructions for your distribution below, open the designated file with a text editor (such as [nano](https://linode.com/docs/guides/use-nano-to-edit-files-in-linux/) or vim) and add the provided lines to the end of that file. When doing so, make the following replacements:

   - **[shared-ip]**: The IPv4 address you shared or an address from the IPv6 range that you shared. You can choose any address from the IPv6 range. For example, within the range _2001:db8:e001:1b8c::/64_, the address `2001:db8:e001:1b8c::1` can be used.
   - **[prefix]**: For an IPv4 address, use `32`. For an IPv6 address, use either `56` or `64` depending on the size of the range you are sharing.

   > > Note: 
   > 
   > Review the configuration file and verify that the shared IP address does not already appear. If it does, delete associated lines before continuing.

   - **Ubuntu 18.04 LTS and newer**: Using [netplan](https://netplan.io/). The entire configuration file is shown below, though you only need to copy the `lo:` directive.

     ```yaml /etc/netplan/01-netcfg.yaml
     network:
       version: 2
       renderer: networkd
       ethernets:
         eth0:
           dhcp4: yes
         lo:
           match:
             name: lo
           addresses:
             - [shared-ip]/[prefix]
     ```

     To apply the changes, reboot the Linode or run:

     ```
     sudo netplan apply
     ```

   - **Debian and Ubuntu 16.04 (and older)**: Using [ifupdown](https://manpages.debian.org/unstable/ifupdown/ifup.8.en.html). Replace _[protocol]_ with `inet` for IPv4 or `inet6` for IPv6.

     ```text /etc/network/interfaces
     ...
     # Add Shared IP Address
     iface lo [protocol] static
         address [shared-ip]/[prefix]
     ```

     To apply the changes, reboot the Linode or run:

     ```
     sudo ifdown lo && sudo ip addr flush lo && sudo ifup lo
     ```

     If you receive the following output, you can safely ignore it: _RTNETLINK answers: Cannot assign requested address_.

   - **CentOS/RHEL**: Using [NetworkManager](https://en.wikipedia.org/wiki/NetworkManager). Since NetworkManager does not support managing the loopback interface, you need to first add a dummy interface named _shared_ (or any other name that you wish). Instead of editing the file directly, the [nmcli](https://linux.die.net/man/1/nmcli) tool is used.

     ```
     nmcli con add type dummy ifname shared
     ```

     Next, add your Shared IP address (or addresses) and bring up the new interface. Run the commands below, replacing _[protocol]_ with `ipv4` for IPv4 or `ipv6` for IPv6 (in addition to replacing _[shared-ip]_ and _[prefix]_)

     ```
     nmcli con mod dummy-shared [protocol].method manual [protocol].addresses [shared-ip]/[prefix]
     nmcli con up dummy-shared
     ```

     Since the loopback interface is not used, you must also add the `-allifs` option to the lelastic command (discussed in a separate section below).

## [3. Install and configure lelastic](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#3-install-and-configure-lelastic)

Next, we need to configure the failover software on _each_ Linode. For this, the [lelastic](https://github.com/linode/lelastic) utility is used. For more control or for advanced use cases, follow the instructions within the [Configuring IP failover over BPG using FRR](https://techdocs.akamai.com/cloud-computing/docs/configuring-ip-failover-over-bgp-using-frr-advanced) guide instead of using lelastic.

1. Log in to the Linode using [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

2. Install lelastic by downloading the latest release from the GitHub repository, extracting the contents of the archived file, and moving the lelastic executable to a folder within your PATH. This same process can be used to update lelastic, making sure to restart the lelastic service (detailed in a later step) to complete the upgrade. Before installing or updating lelastic, review the [releases page](https://github.com/linode/lelastic/releases) and update the version variable with the most recent version number.

   ```
   version=v0.0.6
   curl -LO https://github.com/linode/lelastic/releases/download/$version/lelastic.gz
   gunzip lelastic.gz
   chmod 755 lelastic
   sudo mv lelastic /usr/local/bin/
   ```

   > > Note: 
   > 
   > **CentOS/RHEL:** If running a distribution with SELinux enabled (such as most CentOS/RHEL distributions), you must also set the SELinux type of the file to `bin_t`.
   > 
   > ````
   > ```
   > sudo chcon -t bin_t /usr/local/bin/lelastic
   > ```
   > ````

3. Next, prepare the command to configure BGP routing through lelastic. Replace _[id]_ with the ID corresponding to your data center in the [table above](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#ip-sharing-availability) and _[role]_ with either `primary` or `secondary`. You do not need to run this command, as it is configured as a service in the following steps.

   ```
   lelastic -dcid [id] -[role] &
   ```

   **Additional options:**

   - `-send56`: Advertises an IPv6 address as a /56 subnet (defaults to /64). This is needed when using an IP address from a IPv6 /56 routed range.
   - `-allifs`: Looks for the shared IP address on all interfaces, not just the loopback interface.

     > > Note: 
     > 
     > **CentOS/RHEL:** Since the Shared IP address is configured on the _eth0_ interface for NetworkManager distributions (like CentOS/RHEL), you must add the `-allifs` option to the lelastic command.

   See [Test failover](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#test-failover) to learn more about the expected behavior for each role.

4. Create and edit the service file using either nano or vim.

   ```
   sudo nano /etc/systemd/system/lelastic.service
   ```

5. Paste in the following contents and then save and close the file. Replace _$command_ with the lelastic command you prepared in a previous step.

   ```text etc/systemd/system/lelastic.service
   [Unit]
   Description= Lelastic
   After=network-online.target
   Wants=network-online.target

   [Service]
   Type=simple
   ExecStart=/usr/local/bin/$command
   ExecReload=/bin/kill -s HUP $MAINPID

   [Install]
   WantedBy=multi-user.target
   ```

6. Apply the correct permissions to the service file.

   ```
   sudo chmod 644 /etc/systemd/system/lelastic.service
   ```

7. Start and enable the lelastic service.

   ```
   sudo systemctl start lelastic
   sudo systemctl enable lelastic
   ```

   You can check the status of the service to make sure it's running (and to view any errors)

   ```
   sudo systemctl status lelastic
   ```

   If you need to, you can stop and disable the service to stop failover functionality on the particular Linode.

   ```
   sudo systemctl stop lelastic
   sudo systemctl disable lelastic
   ```

# [Test failover](https://techdocs.akamai.com/cloud-computing/docs/configure-failover-on-a-compute-instance#test-failover)

Once configured, the shared IP address is routed to the _primary_ Linode. If that Linode becomes inaccessible, the shared IP address is automatically routed to the _secondary_ Linode (fail_over_). Once the primary Linode is back online, the shared IP address is restored to that Linode (fail_back_).

You can test the failover functionality of the shared IP using the steps below.

1. Using a machine other than the two Linodes within the failover configuration (such as your local machine), ping the shared IP address.

   ```
   ping [shared-ip]
   ```

   Review the output to verify that the ping is successful. The output should be similar to the following:

   ```text Output
   64 bytes from 192.0.2.1: icmp_seq=3310 ttl=64 time=0.373 ms
   ```

   > > Note: 
   > 
   > If you are sharing an IPv6 address, the machine from which you are running the `ping` command must have IPv6 connectivity. Not all ISPs have this functionality.

2. Power off the _primary_ Linode or stop the lelastic service on that Linode. Once the service has stopped or the Linode has fully powered down, the shared IP address should be routed to the secondary Linode.

   ```
   sudo systemctl stop lelastic
   ```

3. Verify that the shared IP is still accessible by again running the ping command. If the ping is successful, failover is working as intended.