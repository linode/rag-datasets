# [Configure multi-queue NICs on Linodes](https://techdocs.akamai.com/cloud-computing/docs/multi-queue-nics#configure-multi-queue-nics-on-linodes)

Multi-queue NICs (network interface cards) are supported on all Linodes that have 2 or more CPU cores (vCPUs). This feature provides multiple receive (RX) and transmit (TX) queues, assigns them to different network interrupts, and balances them over multiple vCPUs. Historically, this traffic was all handled by a single vCPU core. Depending on the server's workload and network traffic, multi-queue can dramatically enhance network performance.

**For most Linodes deployed after June 2nd, 2021, no action is needed to enable multi-queue NICs**. If your Linode was deployed before that date, a reboot may be required. On older Linux distributions, such as Debian 8 and 9, multi-queue NICs needs to be manually enabled by following the instructions within this guide.

# [Determining if multi-queue is enabled](https://techdocs.akamai.com/cloud-computing/docs/multi-queue-nics#determining-if-multi-queue-is-enabled)

Check if multi-queue is already enabled on your network devices by using the [ethtool](https://en.wikipedia.org/wiki/Ethtool) command-line tool.

1. Review the number of CPU cores (vCPUs) available on your Linode by finding your plan within the [pricing](https://www.linode.com/pricing/) page or by logging in to [Cloud Manager](https://cloud.linode.com/), selecting your Linode, and reviewing the _CPU Cores_ value under **Summary**.

2. Log in to your Linode through [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) or [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/).

3. Install the `ethtool` utility if not already installed.

   **Ubuntu and Debian:**

   ```
   sudo apt-get update
   sudo apt-get install ethtool
   ```

   **Fedora, CentOS, and other RHEL-derivatives, such as AlmaLinux and Rocky Linux:**

   ```
   sudo yum install ethtool
   ```

4. Run the following command, replacing _eth0_ if you've configured a network device other than _eth0_.

   ```
   ethtool -l eth0
   ```

   This should result in output similar to the following:

   ```text Output
   Channel parameters for eth0:
   Pre-set maximums:
   RX:             0
   TX:             0
   Other:          0
   Combined:       8
   Current hardware settings:
   RX:             0
   TX:             0
   Other:          0
   Combined:       2
   ```

5. In the output above, locate the **Combined** value under the **Current hardware settings** section. This indicates the number of queues that are in effect. If multi-queue is fully enabled, this value should equal the number of vCPUs equipped on your Linode (which is determined by your Linode plan and type).

# [Enabling multi-queue on network devices](https://techdocs.akamai.com/cloud-computing/docs/multi-queue-nics#enabling-multi-queue-on-network-devices)

If multi-queue is not enabled and a reboot did not automatically enable it, you can manually enable this feature through the following instructions.

1. Review the number of vCPU cores available on your Linode by finding your plan within the [pricing](https://www.linode.com/pricing/) page or by logging in to [Cloud Manager](https://cloud.linode.com/), selecting your Linode, and reviewing the _CPU Cores_ value under **Summary**.

2. Run the following command to enable multiple queues, replacing _[cpu-count]_ with the number of vCPUs on your Linode.

   ```
   ethtool -L eth0 combined [cpu-count]
   ```

3. Verify that the feature is enabled by again following the instructions within the [Determining if multi-queue is enabled](https://techdocs.akamai.com/cloud-computing/docs/multi-queue-nics#determining-if-multi-queue-is-enabled) section above.

# [Disabling multi-queue on network devices](https://techdocs.akamai.com/cloud-computing/docs/multi-queue-nics#disabling-multi-queue-on-network-devices)

If you start to see performance issues, such as CPU spikes related to network traffic that impact other software on your server, you can disable multi-queue NICs if desired.

1. Run the following command on your Linode to disable multiple queues:

   ```
   ethtool -L eth0 combined 1
   ```

2. Verify that the feature is disabled by following the instructions within the [Determining if multi-queue is enabled](https://techdocs.akamai.com/cloud-computing/docs/multi-queue-nics#determining-if-multi-queue-is-enabled) section above.

# [Installing irqbalance](https://techdocs.akamai.com/cloud-computing/docs/multi-queue-nics#installing-irqbalance)

While network interrupts will be balanced across all vCPUs once multi-queue NICs are enabled, you may want to also install the [irqbalance](https://github.com/Irqbalance/irqbalance) utility if you have familiarity using it or wish to have additional configuration options. This additional utility is **not required** and, in our workloads, we did not notice a difference in performance.

To install irqbalance, run the following commands on your Linode:

**Ubuntu and Debian:**

```
sudo apt-get update
sudo apt-get install irqbalance
```

**Fedora, CentOS, and other RHEL-derivatives, such as AlmaLinux and Rocky Linux:**

```
sudo yum install irqbalance
```