# [Automatically configure networking (Network Helper)](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#automatically-configure-networking-network-helper)

# [Overview](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#overview)

Network Helper is an optional tool that makes network configuration easier on Linodes. It automatically adjusts the appropriate internal network configuration files for your distribution during each system boot. This enables you to start using (and connecting to) your Linode right away, without needing to manually configure these files yourself.

Network Helper automatically configures the following network settings:

- Statically configures all assigned IPv4 addresses (public and private)
- Statically configures the IPv4 gateway
- Adds settings to enable IPv6 assignment through SLAAC
- Adds Linode DNS resolvers

 > Note: 
  Network Helper sorts IP addresses numerically. This may result in the gateway being updated to match the lowest enumerated IP.

# [Use cases](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#use-cases)

For most common use cases, it is recommended to enable Network Helper. Here are some scenarios in which Network Helper automatically configures networking:

- Deploying a Linode
- Adding a public or private IPv4 address (private IPv4 address are available only for configuration profile interfaces)
- Restoring from a backup
- Migrating to a different data center
- Cloning from another Linode

However, there are some advanced use cases that require Network Helper to be disabled so that you can manually configure networking yourself:

- Installing a custom distribution on a Linode
- Configuring failover
- Configuring addresses from an IPv6 routed range
- Using other DNS resolvers (not Akamai Cloud)
- Other advanced use cases where custom network configuration is required

 > Error: 
  If you choose to manually edit your network configuration files, Network Helper must be disabled. If enabled, any configuration changes will be overwritten on the next system boot.

# [Enable or disable Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#enable-or-disable-network-helper)

Network Helper can be enabled or disabled for each Linode. There is also a global setting that applies to all _new_ Linodes.

## [Global (account-wide) setting](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#global-account-wide-setting)

The global Network Helper setting enables or disables Network Helper on _new_ Linodes. Existing Linodes are not affected by any changes to this global setting. When Network Helper is enabled globally, all _new_ Linodes are created with Network Helper enabled by default.

1. Log in to [Cloud Manager](https://cloud.linode.com) and navigate to **Settings** (under **Administration**) in the sidebar menu.

2. Scroll down to the _Network Helper_ section and set the **Enabled** switch to the desired setting. Your selection is automatically saved.

## [Individual Linode setting](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#individual-linode-setting)

Network Helper can also be enabled or disabled on a specific Linode, regardless of the global setting. There are different instructions for configuration profile interfaces and Linode interfaces (Beta).

### [Configuration profile interfaces](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#configuration-profile-interfaces)

1. Follow the [Editing a configuration profile](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance#edit-a-configuration-profile) instructions.

2. Within the **Edit Configuration** form, scroll down to the **Filesystem/Boot Helpers** section.

3. Set the **Auto-configure networking** switch to the desired setting. This toggles Network Helper on or off.

   

4. Once the setting has been adjusted, click the **Save Changes** button. If you are enabling Network Helper, reboot the Linode so that Network Helper can run and adjust your system's network configuration files.

### [Linode Interfaces (BETA)](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#linode-interfaces-beta)

1. Power off the Linode.
2. Follow the [View Linode interfaces](https://techdocs.akamai.com/cloud-computing/docs/managing-linode-interfaces#view-linode-interfaces) instructions.
3. Within the **Interface Settings** form, navigate to the **Network Helper** section. 
4. Set the **Enable Network Helper** to the desired setting. This toggles Network Helper on or off.

   
5. Once the setting has been adjusted, click the **Save** button. 
6. Power on the Linode for the changes to take effect.

# [Files maintained by Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#files-maintained-by-network-helper)

Network Helper automatically edits the appropriate network configuration files for the distribution you have installed. Here is a list of the network configuration files that are maintained by Network Helper for each supported distribution.

- **Alpine:**

  ```
  /etc/network/interfaces
  /etc/resolv.conf
  ```

- **Arch:**

  ```
  /etc/systemd/network/05-eth0.network
  ```

- **CentOS, CentOS Stream, AlmaLinux, and Rocky Linux:**

  ```
  /etc/sysconfig/network-scripts/ifcfg-eth0
  ```

- **Debian:**

  ```
  /etc/network/interfaces
  /etc/resolv.conf
  ```

- **Fedora:**

  ```
  /etc/sysconfig/network-scripts/ifcfg-eth0
  ```

- **Gentoo:**

  ```
  /etc/conf.d/net
  /etc/resolv.conf
  ```

- **openSUSE Leap:**

  ```
  /etc/sysconfig/network/ifcfg-eth0
  /etc/sysconfig/network/routes
  /etc/resolv.conf
  ```

- **Slackware:**

  ```
  /etc/rc.d/rc.inet1.conf
  /etc/resolv.conf
  ```

- **Ubuntu 16.04 LTS (and earlier)**

  ```
  /etc/network/interfaces
  /etc/resolv.conf
  ```

- **Ubuntu 18.04 LTS (and later)**

  ```
  /etc/systemd/network/05-eth0.network
  ```

# [Restore previous network configuration files](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#restore-previous-network-configuration-files)

Network Helper creates backups of the original distribution-supplied configuration file, as well as a backup each time it edits the networking configuration.

- A copy of the interface and resolver file as the distribution provided it: `.interfaces.linode-orig` and `/etc/.resolv.conf.linode-orig`. Note that Network Helper does not modify `/etc/resolv.conf` on all of our distributions.

- A copy of the interface and resolver files from the previous boot: `.interfaces.linode-last` and `/etc/.resolv.conf.linode-last`. If you manually changed either of these file before the previous boot, you'll find them saved there.

Use the following command to restore manual changes made before the previous reboot. Be sure to replace `/etc/network/interfaces` with the network interface file for your distribution from above.

```
mv /etc/network/.interfaces.linode-last /etc/network/interfaces
```