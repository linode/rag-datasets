# [Choose a Linode plan](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#choose-a-linode-plan)

There are several Linode types, each of which can be equipped with varying amounts of resources. This lets you create a Linode tailored to the requirements of your application or workload. For example, some applications may need to store a lot of data but require less processing power. Others may need more memory than CPU. Some may be especially CPU-intensive and require more computing power.

This guide provides you with the information needed to select the most appropriate Linode for the job.

 > Note: 
  You can easily change between Linode types and plans on an existing Linode at any time. Review the [Resizing a Linode](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance) for instructions.

# [Linode types](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#linode-types)

The following Linode types are available in all core compute regions. Dedicated CPU is the only available Linode type in distributed compute regions.

- [Shared CPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#shared-cpu-s)
- [Dedicated CPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#dedicated-cpu-s)
- [Premium Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#premium-s)
- [High Memory Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#high-memory-s)
- [GPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#gpu-s)
- [Accelerated Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#accelerated-s)

They each have unique characteristics and their resources are optimized for different types of workloads. Learn about each of these Linode types below, along with the resources provided and their suggested use cases.

Most of these plan types are equipped with dedicated CPU cores for maximum peak performance and competition-free resources, though the Shared CPU plan comes with shared CPU cores. To learn more about the differences, see [Choosing between shared and dedicated CPUs](https://linode.com/docs/guides/comparing-shared-and-dedicated-cpus/).

## [Shared CPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#shared-cpu-linodes)

**1 GB - 192 GB Memory, 1 - 32 Shared vCPU Cores, 25 GB - 3840 GB Storage**  

  
Starting at $5/mo ($0.0075/hour). See [Shared CPU pricing](https://www.linode.com/pricing/#compute-shared) for a full list of plans, resources, and pricing.

[Shared CPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/shared-cpu-compute-instances) offer a balanced array of resources coupled with shared CPU cores. These CPU cores can be used at 100% for short bursts, but should remain below 80% sustained usage on average, including virtualization overheads. To account for overheads, CPU usage should be monitored through [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/monitor-and-maintain-a-compute-instance#cloud-manager) or the Linode API. This keeps costs down while still supporting a wide variety of cloud applications. Your processes are scheduled on the same CPU cores as processes from other Linodes. This shared scheduling is done in a secure and performant manner. While Akamai Technologies, Inc.works to minimize competition for CPU resources between your Linode and other Linodes on the same hardware, it's possible that high usage from neighboring Linodes can negatively impact the performance of your Linode.

**Recommended Use Cases:**

_Best for development servers, staging servers, low traffic websites, personal blogs, and production applications that may not be affected by resource contention._

- Medium to low traffic websites, such as for marketing content and blogs
- Forums
- Development and staging servers
- Low traffic databases
- Worker nodes within a container orchestration cluster

## [Dedicated CPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#dedicated-cpu-linodes)

**4 GB - 512 GB\* Memory, 2 - 64 Dedicated vCPUs, 80 GB - 7200 GB Storage**  

  
Starting at $36/mo ($0.05/hour). Pricing may vary by region, and differs for [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions). See [Dedicated CPU pricing](https://www.linode.com/pricing/#compute-dedicated) for a full list of plans, resources, and pricing.  

\*512 GB plans are in limited availability.

[Dedicated CPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances) reserve physical CPU cores that you can utilize at 100% load 24/7 for as long as you need. This provides competition free guaranteed CPU resources and ensures your software can run at peak speed and efficiency. With Dedicated CPU Linodes, you can run your software for prolonged periods of maximum CPU usage, and you can ensure the lowest latency possible for latency-sensitive operations. These Linodes offer a perfectly balanced set of resources for most production applications.

**Recommended Use Cases:**

_Best for production websites, high traffic databases, and any application that requires 100% sustained CPU usage or may be impacted by resource contention._

- [CI/CD](https://linode.com/docs/guides/introduction-ci-cd/) toolchains and build servers
- [Game servers](https://linode.com/docs/game-servers/) (like Minecraft or Team Fortress)
- [Audio and video transcoding](https://linode.com/docs/applications/media-servers/)
- [Big data](https://linode.com/docs/applications/big-data/) (and data analysis)
- Scientific computing
- [Machine learning](https://linode.com/docs/guides/how-to-move-machine-learning-model-to-production/) and AI
- High traffic databases (Galera, PostgreSQL with Replication Manager, MongoDB using Replication Sets)
- Replicated or distributed file systems (GlusterFS, DRBD)

## [Premium Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#premium-linodes)

**4 GB - 512 GB\* Memory, 2 - 64 Dedicated vCPUs, 80 GB - 7200 GB Storage**  

  
Starting at $43/mo ($0.06/hr). See [Premium pricing](https://www.linode.com/pricing/#compute-premium) for a full list of plans, resources, and pricing.

\*512 GB plans are in limited availability.

[Premium Linodes](https://techdocs.akamai.com/cloud-computing/docs/premium-compute-instances) build off our Dedicated CPU Linodes and guarantee a minimum hardware class utilizing the latest available [AMD EPYC™](https://www.linode.com/amd/) CPUs. This provides consistent performance to your workloads and is suitable for running mission-critical applications. Premium iLinodes are available in select data centers (see [Availability](https://techdocs.akamai.com/cloud-computing/docs/premium-compute-instances#availability)).

**Recommended Use Cases:**

_Best for enterprise-grade, business-critical, and latency-sensitive applications._

- Any workload that benefits from consistent performance.
- [Audio and video transcoding](https://linode.com/docs/applications/media-servers/)
- [Big data](https://linode.com/docs/applications/big-data/) (and data analysis)
- Scientific computing
- [Machine learning](https://linode.com/docs/guides/how-to-move-machine-learning-model-to-production/) and AI

## [High Memory Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#high-memory-linodes)

**24 GB - 300 GB Memory, 2 - 16 Dedicated vCPUs, 20 GB - 340 GB Storage**  

  
Starting at $60/mo ($0.09/hour). See [High Memory pricing](https://www.linode.com/pricing/#compute-high-memory) for a full list of plans, resources, and pricing.

[High Memory Linodes](https://techdocs.akamai.com/cloud-computing/docs/high-memory-compute-instances) are optimized for memory-intensive applications and equipped with dedicated CPUs, which provide competition free guaranteed CPU resources. These Linodes feature higher RAM allocations and relatively fewer vCPUs and less storage. This keeps your costs down and provides power to memory-intensive applications.

**Recommended Use Cases:**

_Best for in-memory databases, in-memory caching systems, big data processing, and any production application that requires a large amount of memory while keeping costs down._

- Any production application that requires large amounts of memory
- In-memory database caching systems, such as [Redis](https://redis.io/) and [Memcached](https://memcached.org/). These applications offer very fast retrieval of data, but they store data in a non-persistent manner (with some caveats). So, they are usually used in conjunction with another persistent database server running on a separate Linode.
- In-memory databases, such as possible with [NoSQL](https://linode.com/docs/guides/what-is-nosql/) and [other solutions](https://en.wikipedia.org/wiki/List_of_in-memory_databases)
- [Big data processing](https://linode.com/docs/applications/big-data/) (and data analysis)

## [GPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#gpu-linodes)

**16 GB - 196 GB Memory, 4 - 48 Dedicated vCPUs, 640 GB - 2.56 TB GB Storage**  

  
NVIDIA RTX 4000 Ada GPU plans starting at $350/mo ($0.52/hour) with 1 GPU card, 4 vCPU cores, 16 GB of memory, and 500 GB of SSD storage. NVIDIA Quadro RTX 6000 plans starting at $1000/mo ($1.50/hr) with 1 GPU card, 8 vCPU cores, 32 GB of memory, and 640 GB of storage. For a full list of plans, resources, and pricing, see [GPU pricing](https://www.linode.com/pricing/#compute-gpu).

[GPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances) are the only Linodes equipped with [NVIDIA RTX 4000 Ada GPU cards](https://resources.nvidia.com/en-us-design-viz-stories-ep/rtx-4000-ada-datashe?lx=CCKW39&contentType=data-sheet) or [NVIDIA Quadro RTX 6000 GPU cards](https://www.nvidia.com/content/dam/en-zz/Solutions/design-visualization/technologies/turing-architecture/NVIDIA-Turing-Architecture-Whitepaper.pdf) for on demand execution of complex processing workloads. These GPUs have CUDA cores, Tensor cores, and RT (Ray Tracing) cores. GPUs are designed to process large blocks of data in parallel, meaning that they are an excellent choice for any workload requiring thousands of simultaneous threads. With significantly more logical cores than a standard CPU, GPUs can perform computations that process large amounts of data in parallel more efficiently.

**Recommended Use Cases:**

_Best for applications that require massive amounts of parallel processing power, including machine learning, AI inferencing, graphics processing, and big data analysis._

- [Video encoding](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances#video-encoding)
- [Graphics processing](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances#graphics-processing)
- [AI inferencing](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances#machine-learning-and-ai)
- [Big data analysis](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances#big-data)
- [General Purpose computing using NVIDIA's CUDA Toolkit](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances#general-purpose-computing-using-cuda)

## [Accelerated Linodes](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#accelerated-linodes)

**16 GB – 24 GB Memory, 8 – 12 Dedicated vCPUs, 200 — 300 GB Storage**  

  
Starting at $280/mo ($0.42/hour). See [Accelerated pricing](https://www.linode.com/pricing/#compute-vpu) for a full list of plans, resources, and pricing.

[Accelerated Linodes](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances) are optimized for transcoding.  Backed by NETINT Quadra T1U video processing units (VPUs), Accelerated Linodes can offer significant performance and cost advantages over transcoding setups that rely on CPUs or GPUs.

**Recommended Use Cases:**

_Best for video processing, including streaming content directly to viewers over the internet._

- [Live streaming](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#live-streaming)
- [Video on demand transcoding](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#video-on-demand-vod-transcoding)

# [Compute resources](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#compute-resources)

When selecting a plan, it is important to understand the hardware resources allocated to your Linode. These resources include the amount of vCPU cores, memory, storage space, network transfer, and more. Start by reviewing each resource below and the implications it may have for your application.

| Resource     | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Memory (RAM) | The working memory available for your server's processes. Your server stores information in memory that is needed to carry out its functions. Or, it caches data in memory for fast retrieval in the future, if it is likely that the data will be needed. Data stored in RAM is accessed faster than data stored in your disks, but it is not persistent storage.                                                                                                                                                                                                                                      |
| vCPU Cores   | The number of virtual CPUs (vCPUs) available to your server. Your software is often designed to execute its tasks across multiple CPUs in parallel. The higher your vCPU count, the more work you can perform simultaneously. Plans are also equipped with either shared CPU cores or dedicated CPU cores. Dedicated CPU cores allow your system to utilize 100% of your CPU resources at all times, while shared CPU cores require a lower sustained usage and may be affected by resource contention. See [Choose between shared and dedicated CPUs](https://techdocs.akamai.com/cloud-computing/docs/choosing-between-shared-and-dedicated-cpus). |
| Storage      | Your server's built-in persistent storage. Large databases, media libraries, and other stores of files will require more storage space. Your Linode's storage is maintained on high-performance SSDs for fast access. You can also supplement your disks with extra [Block Storage volumes](https://techdocs.akamai.com/cloud-computing/docs/block-storage).                                                                                                                                                                                                                                                                                   |
| Transfer     | The total amount of traffic your server can emit over the course of a month. Inbound traffic sent to your Linode does not count against your transfer quota. If you exceed your quota, your service will not be shut off; instead, an overage will be billed. See [Network transfer usage and costs](https://techdocs.akamai.com/cloud-computing/docs/network-transfer-usage-and-costs) for more information about how transfer works.                                                                                                                                                                                                         |
| Network In   | The maximum bandwidth for inbound traffic sent to your Linode. The bandwidth you observe will also depend on other factors, like the geographical distance between you and your Linode and the bandwidth of your local ISP. For help with choosing a data center that will feature the lowest latency and best bandwidth, review the [Choose a data center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center) guide.                                                                                                                                                                                         |
| Network Out  | The maximum bandwidth for outbound traffic emitted by your Linode. The bandwidth you observe will also depend on other factors, like the geographical distance between you and your Linode and the bandwidth of your local ISP. For help with choosing a data center that will feature the lowest latency and best bandwidth, review the [Choose a data center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center) guide.                                                                                                                                                                                     |
| GPU          | GPU's, or Graphical Processing Units are specialized hardware units only available on our GPU Linodes. Originally designed to manipulate computer graphics and handle image processing, GPUs are now commonly also used for many compute intensive tasks that require thousands of simultaneous threads and the higher number of logical cores that a CPU can not provide alone.                                                                                                                                                                                                                  |

# [Pricing](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan#pricing)

If you run a business or not, you likely need to think about pricing when considering which plan is right for you. You can view all pricing on our [pricing](https://www.linode.com/pricing/) page. Note that pricing and plan options may vary between regions.

Compare cost per month and save with predictable and transparent pricing using our [Cloud Estimator](https://www.linode.com/estimator/). Explore bundled compute, storage, and transfer packages against AWS, GCP, and Azure.

Migrating from on-premise or between cloud providers for hosting, cloud storage, or cloud computing? Use our total cost of ownership [Cloud Computing Calculator](https://www.linode.com/cloud-pricing-calculator/)  to receive a full cost breakdown and technical recommendations.