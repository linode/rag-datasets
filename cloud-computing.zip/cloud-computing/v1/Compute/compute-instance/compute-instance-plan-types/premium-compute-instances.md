# [Premium Linodes](https://techdocs.akamai.com/cloud-computing/docs/premium-compute-instances#premium-linodes)

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/premium-compute-instances#availability)

Premium Linodes are currently available in select data centers.

| Data center                       | Status          |
| --------------------------------- | --------------- |
| **Amsterdam (Netherlands)**       | **Available**   |
| Atlanta (Georgia, USA)            | _Not available_ |
| **Chennai (India)**               | **Available**   |
| **Chicago (Illinois, USA)**       | **Available**   |
| Dallas (Texas, USA)               | _Not available_ |
| Frankfurt (Germany)               | _Not available_ |
| **Frankfurt 2 (Germany)**         | **Available**   |
| Fremont (California, USA)         | _Not available_ |
| **Jakarta (Indonesia)**           | **Available**   |
| London (United Kingdom)           | _Not available_ |
| **London 2 (United Kingdom)**     | **Available**   |
| **Los Angeles (California, USA)** | **Available**   |
| **Madrid (Spain)**                | **Available**   |
| **Melbourne (Australia)**         | **Available**   |
| **Miami (Florida, USA)**          | **Available**   |
| **Milan (Italy)**                 | **Available**   |
| Mumbai (India)                    | _Not available_ |
| **Mumbai 2 (India)**              | **Available**   |
| Newark (New Jersey, USA)          | _Not available_ |
| **Osaka (Japan)**                 | **Available**   |
| **Paris (France)**                | **Available**   |
| **São Paulo (Brazil)**            | **Available**   |
| **Seattle (Washington, USA)**     | **Available**   |
| Singapore                         | _Not available_ |
| **Singapore 2**                   | **Available**   |
| **Stockholm (Sweden)**            | **Available**   |
| Sydney (Australia)                | _Not available_ |
| Tokyo (Japan)                     | _Not available_ |
| **Tokyo 3 (Japan)**               | **Available**   |
| Toronto (Canada)                  | _Not available_ |
| **Washington, DC (USA)**          | **Available**   |

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/premium-compute-instances#plans-and-pricing)

| Resource                   | Available Plans  |
| -------------------------- | ---------------- |
| vCPU cores                 | 2-64 cores       |
| Memory                     | 4 GB - 512 GB\*  |
| Storage                    | 80 GB - 7,200 GB |
| Outbound Network Transfer  | 4 TB - 12 TB     |
| Outbound Network Bandwidth | 4 Gbps - 12 Gbps |

\*512 GB plans are in limited availability.

Pricing may vary by region. Review the [Pricing page](https://www.linode.com/pricing/) for additional plans and their associated costs. Review the [Plans](https://techdocs.akamai.com/cloud-computing/docs/compute-instance-plan-types) page to learn more about other Linode types.