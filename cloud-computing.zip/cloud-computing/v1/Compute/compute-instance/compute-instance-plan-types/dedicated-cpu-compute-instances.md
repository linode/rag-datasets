# [Dedicated CPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#dedicated-cpu-linodes)

Dedicated CPU Linodes are virtual machines that provide you with dedicated CPU resources. Their vCPU cores are guaranteed (and, thus, competition-free) so there are no surprises or CPU-related performance degradation. This enables you to run your production applications with confidence that your performance won't be impacted by others. These Linodes are CPU-optimized and can sustain CPU resource usage at 100% for as long as your workloads need.

**Dedicated CPU plans are ideal for nearly all production applications and CPU-intensive workloads, including high traffic websites, video encoding, machine learning, and data processing.** If your application would benefit from dedicated CPU cores as well as a larger amounts of memory, see [High Memory Linodes](https://techdocs.akamai.com/cloud-computing/docs/high-memory-compute-instances).

# [Dedicated competition-free resources](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#dedicated-competition-free-resources)

A Dedicated CPU Linode provides entire vCPU cores accessible only to you. Because the vCPU cores are not shared, no other Linodes can utilize them. Your instance never has to wait for another process, enabling your software to run at peak speed and efficiency. This lets you run workloads that require full-duty work (100% CPU all day, every day) at peak performance.

# [Upgrading from a Shared CPU Linode](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#upgrading-from-a-shared-cpu-linode)

Moving from a Shared CPU Linode to a Dedicated CPU Linode is a seamless process that can positively impact your applications and users. See [Choosing between shared and dedicated CPUs](https://techdocs.akamai.com/cloud-computing/docs/choosing-between-shared-and-dedicated-cpus) to learn more about the differences between Shared and Dedicated CPU plans and when each one might be appropriate. This guide also shows you how to investigate your CPU performance to determine if your application is experiencing resource contention on a Shared CPU Linode. If you wish to upgrade, see [Resize a Linode](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance) for more information about resizing your Linode to a different plan type.

# [Recommended workloads](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#recommended-workloads)

Dedicated CPU Linodes are suitable for almost any workload that requires consistently high performant CPU resources. This includes:

- Production websites and e-commerce sites
- Applications that required 100% sustained CPU usage.
- Applications that might be impacted by resource contention.
- [CI/CD](https://linode.com/docs/guides/introduction-ci-cd/) toolchains and build servers
- [Game servers](https://linode.com/docs/game-servers/) (like Minecraft or Team Fortress)
- [Audio and video transcoding](https://linode.com/docs/applications/media-servers/)
- [Big data](https://linode.com/docs/applications/big-data/) (and data analysis)
- Scientific computing
- [Machine learning](https://linode.com/docs/guides/how-to-move-machine-learning-model-to-production/) and AI
- High Traffic Databases (Galera, PostgreSQL with Replication Manager, MongoDB using Replication Sets)
- Replicated or Distributed Filesystems (GlusterFS, DRBD)

For more details and use cases, see the [Dedicated CPU use cases](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#dedicated-cpu-use-cases) section.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#availability)

Dedicated CPU Linodes are available across [all regions](https://www.linode.com/global-infrastructure/).

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#plans-and-pricing)

| Resource                   | Available Plans  |
| -------------------------- | ---------------- |
| vCPU cores                 | 2-64 cores       |
| Memory                     | 4 GB - 512 GB\*  |
| Storage                    | 80 GB - 7200 GB  |
| Outbound Network Transfer  | 4 TB - 12 TB     |
| Outbound Network Bandwidth | 4 Gbps - 12 Gbps |

\*512 GB plans are in limited availability.

Pricing starts at $36/month for a Dedicated CPU Linode with 2 vCPU cores, 4GB of memory, and 80 GB of SSD storage. Pricing may vary by region, and differs for [distributed compute regions](https://techdocs.akamai.com/cloud-computing/docs/distributed-compute-regions). Review the [pricing page](https://www.linode.com/pricing/#compute-dedicated) for additional plans and their associated costs. Review the [Plans](https://techdocs.akamai.com/cloud-computing/docs/compute-instance-plan-types) page to learn more about other instance types.

# [Dedicated CPU use cases](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#dedicated-cpu-use-cases)

While a shared plan is usually a good fit for most use cases, a Dedicated CPU Linode may be recommended for a number of workloads related to high and constant CPU processing. Such examples include:

- [CI/CD toolchains and build servers](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#cicd-toolchains-and-build-servers)
- [Game servers](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#game-servers)
- [Audio and video transcoding](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#audio-and-video-transcoding)
- [Big data and data analysis](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#big-data-and-data-analysis)
- [Scientific computing](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#scientific-computing)
- [Machine learning](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#machine-learning)

## [CI/CD toolchains and build servers](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#cicd-toolchains-and-build-servers)

CI and CD are abbreviations for _Continuous Integration_ and _Continuous Delivery_, respectively, and refer to an active approach to DevOps that reduces overall workloads by automatically testing and regularly implementing small changes. This can help to prevent last-minute conflicts and bugs, and keeps tasks on schedule. For more information on the specifics of CI and CD, see our [Introduction to CI/CD](https://linode.com/docs/guides/introduction-ci-cd/) guide.

In many cases, the CI/CD pipeline can become resource-intensive if many new code changes are built and tested against your build server. When a Linode is used as a remote server and is expected to be regularly active, a Dedicated CPU Linode can add an additional layer of speed and reliability to your toolchain.

## [Game servers](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#game-servers)

Depending on the intensity of demands they place on your Linode, [game servers](https://linode.com/docs/game-servers/) may benefit from a Dedicated CPU. Modern multiplayer games need to coordinate with a high number of clients, and require syncing entire game worlds for each player. If CPU resources are not available, then players will experience issues like stuttering and lag. Below is a short list of popular games that may benefit from a Dedicated CPU:

- [Rust](https://www.linode.com/docs/marketplace-docs/guides/rust/)
- [Minecraft](https://www.linode.com/docs/marketplace-docs/guides/minecraft/)
- [CS:GO](https://www.linode.com/docs/marketplace-docs/guides/counter-strike-go/)

## [Audio and video transcoding](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#audio-and-video-transcoding)

[Audio and video transcoding](https://linode.com/docs/applications/media-servers/) (AKA Video/Audio Encoding) is the process of taking a video or audio file from its original or source format and converting it to another format for use with a different device or tool. Because this is often a time-consuming and resource-intensive task, a Dedicated CPU or [GPU](https://techdocs.akamai.com/cloud-computing/docs/gpu-compute-instances) Linode is suggested to maximize performance. [FFmpeg](https://ffmpeg.org/) is a popular open source tool used specifically for the manipulation of audio and video, and is recommended for a wide variety of encoding tasks.

## [Big data and data analysis](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#big-data-and-data-analysis)

[Big data and data analysis](https://linode.com/docs/applications/big-data/) is the process of analyzing and extracting meaningful insights from datasets so large they often require specialized software and hardware. Big data is most easily recognized with the **"three V's"** of big data:

- **Volume:** Generally, if you are working with terabytes, petabytes, exabytes, or more amounts of information you are in the realm of big data.
- **Velocity:** With Big Data, you are using data that is being created, called, moved, and interacted with at a high velocity. One example is the real time data generated on social media platforms by their users.
- **Variety:** Variety refers to the many different types of data formats with which you may need to interact. Photos, video, audio, and documents can all be written and saved in a number of different formats. It is important to consider the variety of data that you will collect in order to appropriately categorize it.

Processing big data is often especially hardware-dependent. A Dedicated CPU can give you access to the isolated resources often required to complete these tasks.

The following tools can be extremely useful when working with big data:

- [Hadoop](https://linode.com/docs/guides/how-to-install-and-set-up-hadoop-cluster/) - an Apache project for the creation of parallel processing applications on large data sets, distributed across networked nodes.

- [Apache Spark](https://spark.apache.org/) - a unified analytics engine for large-scale data processing designed with speed and ease of use in mind.

- [Apache Storm](https://storm.apache.org/) - a distributed computation system that processes streaming data in real time.

## [Scientific computing](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#scientific-computing)

**Scientific computing** is a term used to describe the process of using computing power to solve complex scientific problems that are either impossible, dangerous, or otherwise inconvenient to solve via traditional means. Often considered the "Third Pillar" of modern science behind Theoretical Analysis and Experimentation, Scientific Computing has quickly become a prevalent tool in scientific spaces.

Scientific Computing involves many intersecting skills and tools for a wide array of more specific use cases, though solving complex mathematical formulas dependent on significant computing power is considered to be standard. While there are a large number of open source software tools available, below are two general purpose tools we can recommend to get started with Scientific Computing.

- [Jupyter Notebook](https://jupyter.org/)
- [NumPy](https://numpy.org/)

It's worth keeping in mind that, beyond general use cases, there are many more example of tools and software available and often designed for individual fields of science.

## [Machine learning](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances#machine-learning)

[Machine learning](https://linode.com/docs/guides/how-to-move-machine-learning-model-to-production/) is a powerful approach to data science that uses large sets of data to build prediction algorithms. These prediction algorithms are commonly used in “recommendation” features on many popular music and video applications, online shops, and search engines. When you receive intelligent recommendations tailored to your own tastes, machine learning is often responsible. Other areas where you might find machine learning being used are in self-driving cars, process automation, security, marketing analytics, and health care.

Below is a list of common tools used for machine learning and AI that can be installed on a CPU Linode:

- [TensorFlow](https://www.tensorflow.org/) - a free, open-source, machine learning framework and deep learning library. Tensorflow was originally developed by Google for internal use and later fully released to the public under the Apache License.

- [PyTorch](https://pytorch.org/) - a machine learning library for Python that uses the popular GPU-optimized Torch framework.

- [Apache Mahout](https://mahout.apache.org/) - a scalable library of machine learning algorithms and  distributed linear algebra framework designed to let mathematicians, statisticians, and data scientists quickly implement their own algorithms.