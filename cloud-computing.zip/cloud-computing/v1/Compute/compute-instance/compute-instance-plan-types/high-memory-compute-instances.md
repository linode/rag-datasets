# [High Memory Linodes](https://techdocs.akamai.com/cloud-computing/docs/high-memory-compute-instances#high-memory-linodes)

High Memory Linodes are virtual machines that offer a greater price-to-performance ratio for memory-intensive applications. When compared to [Dedicated CPU Linode](https://techdocs.akamai.com/cloud-computing/docs/dedicated-cpu-compute-instances), High Memory Linodes provide the same dedicated CPU resources but are equipped with more memory per CPU core. This tunes them specifically for memory-intensive applications that value larger amounts of memory over a larger number of CPU cores.

**High Memory plans are ideal for production applications and CPU-intensive workloads that value greater memory over CPU resources, including caching systems, high-performance databases, and in-memory data processing.**

# [Fast data retrieval and in-memory processing](https://techdocs.akamai.com/cloud-computing/docs/high-memory-compute-instances#fast-data-retrieval-and-in-memory-processing)

Optimized for in-memory databases and caches, the High Memory Linode is perfect for high-performance querying and is a good addition to any enterprise-level database solution.

Keep recently-accessed data in memory to speed up retrieval times. Use a High Memory Linode as a Memcached or Redis in-memory data store for better application performance.

Run queries on large data volumes. High memory Linodes make it possible to process your data completely in memory and quickly get query results.

# [Dedicated competition-free resources](https://techdocs.akamai.com/cloud-computing/docs/high-memory-compute-instances#dedicated-competition-free-resources)

A High Memory Linode provides entire vCPU cores accessible only to you. Because the vCPU cores are not shared, no other Linodes can utilize them. Your Linode never has to wait for another process, enabling your software to run at peak speed and efficiency. This lets you run workloads that require full-duty work (100% CPU all day, every day) at peak performance.

# [Recommended workloads](https://techdocs.akamai.com/cloud-computing/docs/high-memory-compute-instances#recommended-workloads)

High Memory Linodes are suitable for workloads that value much larger amounts of memory than other plans of a similar price. This includes:

- Any production application that requires large amounts of memory
- In-memory database caching systems, such as [Redis](https://redis.io/) and [Memcached](https://memcached.org/)
- In-memory databases, such as possible with [NoSQL](https://linode.com/docs/guides/what-is-nosql/) and [other solutions](https://en.wikipedia.org/wiki/List_of_in-memory_databases)
- [Big data processing](https://linode.com/docs/applications/big-data/) (and data analysis)

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/high-memory-compute-instances#availability)

High Memory Linodes are available across [all core compute regions](https://www.linode.com/global-infrastructure/), but are not available in distributed compute regions.

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/high-memory-compute-instances#plans-and-pricing)

| Resource                   | Available Plans |
| -------------------------- | --------------- |
| vCPU cores                 | 2-16 cores      |
| Memory                     | 24 GB - 300 GB  |
| Storage                    | 20 GB - 340 GB  |
| Outbound Network Transfer  | 5 TB - 9 TB     |
| Outbound Network Bandwidth | 5 Gbps - 9 Gbps |

Pricing starts at $60 for a High Memory Linode with 2 vCPU cores, 24GB memory, and 20GB of SSD storage. Pricing may vary by region. Review the [pricing page](https://www.linode.com/pricing/#compute-high-memory) for additional plans and their associated costs. Review the [Plans](https://techdocs.akamai.com/cloud-computing/docs/compute-instance-plan-types) page to learn more about other Linode types.