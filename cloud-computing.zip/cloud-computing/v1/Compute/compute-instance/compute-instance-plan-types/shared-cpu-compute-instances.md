# [Shared CPU Linodes](https://techdocs.akamai.com/cloud-computing/docs/shared-cpu-compute-instances#shared-cpu-linodes)

Shared CPU Linodes are our most affordable virtual machines that offer a significant price-to-performance ratio. They provide a well balanced set of resources that are ideal for a wide range of applications. While most of our other Linode types are equipped with dedicated CPUs, shared Linodes are not. This means that CPU resources are shared with other Linodes and a small amount of resource contention is possible.

**Shared plans are ideal for development servers, staging servers, low traffic websites, personal blogs, and production applications that may not be affected by resource contention.**

# [Recommended workloads](https://techdocs.akamai.com/cloud-computing/docs/shared-cpu-compute-instances#recommended-workloads)

Shared CPU Linodes are suitable for general workloads that value cost over maximum performance:

- Production applications with low to medium CPU requirements and are not affected by resource contention
- Applications that require a balanced set of resources
- Medium to low traffic websites, such as for marketing content and blogs
- Forums
- Development and staging servers
- Low traffic databases
- Worker nodes within a container orchestration cluster

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/shared-cpu-compute-instances#availability)

Shared CPU Linodes are available across [all core compute regions](https://www.linode.com/global-infrastructure/), but are not available in distributed compute regions.

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/shared-cpu-compute-instances#plans-and-pricing)

| Resource                   | Available Plans  |
| -------------------------- | ---------------- |
| vCPU cores                 | 1-32 cores       |
| Memory                     | 1 GB - 192 GB    |
| Storage                    | 25 GB - 3840 GB  |
| Outbound Network Transfer  | 1 TB - 20 TB     |
| Outbound Network Bandwidth | 1 Gbps - 12 Gbps |

Pricing starts at $5 for a Shared CPU Linode with 1 vCPU core, 1 GB of memory, and 25 GB of SSD storage. Pricing may vary by region. Review the [pricing page](https://www.linode.com/pricing/#row--compute) for additional plans and their associated costs. Review the [Plans](https://techdocs.akamai.com/cloud-computing/docs/compute-instance-plan-types) page to learn more about other Linode types.

# [Usage monitoring](https://techdocs.akamai.com/cloud-computing/docs/shared-cpu-compute-instances#usage-monitoring)

These CPU cores can be used at 100% for short bursts, but should remain below 80% sustained usage on average, including virtualization overheads. To account for overheads, CPU usage should be monitored through [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/monitor-and-maintain-a-compute-instance#cloud-manager) or the [Linode API](https://techdocs.akamai.com/linode-api/reference/api).