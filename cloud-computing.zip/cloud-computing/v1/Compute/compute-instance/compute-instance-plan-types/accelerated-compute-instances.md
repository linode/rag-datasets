# [Accelerated Linodes](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#accelerated-linodes)

Accelerated Linodes are virtual machines optimized for transcoding. Transcoding is the process of converting digital media files from one format to another, which typically involves changing the file’s encoding, bit rate, resolution, or format to ensure compatibility with different devices, platforms, or bandwidth conditions.

Accelerated  Linodes are backed by NETINT Quadra T1U video processing units (VPUs)—ASIC-based media accelerator cards purpose-built for transcoding tasks. Accelerated Linodes may offer significant performance and cost advantages over transcoding setups that rely on CPUs or GPUs. 

Accelerated Linodes are particularly well-suited to live streaming and video on demand (VOD) transcoding workloads. You can leverage Accelerated Linodes to maximize video transcoding performance while leaving your other application resources available to perform other mission-critical tasks. To learn more about workloads that could benefit from Accelerated Linodes, see [Use cases](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#use-cases).

**Accelerated Linode plans are ideal for media service providers engaged in video processing, including those that stream content directly to viewers over the internet.**

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#availability)

Accelerated Linodes are currently available in the following regions:

- Chennai, IN
- Frankfurt 2, DE
- Los Angeles, US
- Melbourne, AU
- Miami, US

# [Plans and pricing](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#plans-and-pricing)

| Resource                   | Available Plans |
| -------------------------- | --------------- |
| vCPU cores                 | 8-12 cores      |
| Memory                     | 16 GB - 24 GB   |
| Storage                    | 200 GB - 300 GB |
| Outbound Network Transfer  | 0 TB            |
| Outbound Network Bandwidth | 16 Gbps         |

Pricing starts at $280/mo ($0.42/hr) for a NETINT Quadra T1U x1 Small Linode with 1 VPU, 8 vCPU cores, 16 GB of memory, and 200 GB of SSD storage.

See the [pricing page](https://www.linode.com/pricing/#row--compute) for plan pricing information. See the [Plans](https://techdocs.akamai.com/cloud-computing/docs/compute-instance-plan-types) page to learn about other Linode plans. 

# [VPU specifications](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#vpu-specifications)

Each NETINT Quadra T1U VPU supports the following.

Error parsing table data: name 'null' is not defined

# [Use cases](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#use-cases)

Over-the-top (OTT) media service providers (streaming platforms) offer content directly to viewers on the internet, bypassing cable and broadcast platforms. To ensure smooth, high-quality delivery of streamed content, video files are transcoded into various formats and resolutions to accommodate different devices and network conditions. Transcoding-optimized Accelerated Linodes may offer significant advantages over other solutions, especially in the following use cases.

## [Live Streaming](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#live-streaming)

Accelerated Linodes can generally achieve greater density and handle more streams simultaneously than other solutions. This allows providers to use fewer hardware units. Accelerated Linodes also consume less power and generate less heat than general-purpose CPUs or GPUs, reducing energy and cooling costs.

NETINT Quadra TIU cards leverage hardware acceleration to handle video encoding and decoding tasks, which increases the efficiency of those operations. This translates into lower latency and higher throughput, which is essential for streaming and on-demand video. 

Accelerated Linodes are also ideal for continuous stream handling. This is because they can optimize bitrate efficiency by dynamically adjusting encoding parameters to match network bandwidth, which reduces buffering and enhances the viewer experience. 

## [Video on demand (VOD) Transcoding](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#video-on-demand-vod-transcoding)

On-demand transcoding typically involves processing large libraries of video content, where the focus is on throughput and quality rather than immediate real-time delivery. NETINT Quadra T1U cards support a variety of codecs, including AV1. They can handle multi-pass encoding and advanced compression techniques to ensure the final output meets quality standards. 

These cards excel at batch processing, as they support simultaneous transcoding of multiple files without compromising quality. The ability to handle large volumes of content with high throughput and quality ensures that VOD providers can meet their audience's expectations.

# [Configuration instructions](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#configuration-instructions)

## [Supported Operating Systems](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#supported-operating-systems)

When creating your NETINT Quadra T1U VPU-backed Accelerated Linode, we recommend using one of the following distributions:

- Ubuntu 20.04
- Ubuntu 22.04
- Ubuntu 22.10

## [Configure your card with the Quadra SDK](https://techdocs.akamai.com/cloud-computing/docs/accelerated-compute-instances#configure-your-card-with-the-quadra-sdk)

To use a NETINT VPU, some initial configuration is necessary to ensure optimal performance. This includes installing the appropriate drivers, setting up the required software, and integrating tools like FFmpeg with NETINT’s libxcoder library.

To configure your card:

1. Install pre-requisites
   ```shell
   sudo apt-get install nasm yasm -y
   ```

2. Download the latest release of the [Quadra SDK](https://docs.netint.com/vpu/quadra/) and extract it to /root/ of your Accelerated Linode. 

3. Install the required software and firmware: 

   1. Navigate to the folder containing the extracted the files and run the command  

      `bash quadra_quick_installer.sh`

   2. Type '**Y**' and press Enter to confirm that you want to use the release packages listed.

      A script menu appears.

   3. Complete each of the following by typing the corresponding number and pressing Enter:
      - Setup environment variables (**1**)   
      - Install the prerequisite software libraries for your operating system (**3**)
      - Install the NVMe CLI tool (**4**)  
        (You may receive an error message if you're running a newer version of Ubuntu. If so, ignore and continue to the next step.)   
      - Install Libxcoder (**5**)  
      - Install your preferred version of FFmpeg (**7-15**)

4. Type '**22**' and press Enter to exit the script menu.