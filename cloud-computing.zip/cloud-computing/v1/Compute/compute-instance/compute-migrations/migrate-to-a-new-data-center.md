# [Migrate to a new data center](https://techdocs.akamai.com/cloud-computing/docs/migrate-to-a-new-data-center#migrate-to-a-new-data-center)

When you create a Linode, it's stored on a specific data center you select. If you need to change this, you can initiate a cross-data-center migration, to move it to another data center. Linodes can be migrated from one core region to another, or one distributed compute region to another, but cannot be migrated between core and distributed compute regions.

 > Note: 
  Review the [Choosing a data center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center) guide to learn how to choose and speed test a data center.

# [Before you begin](https://techdocs.akamai.com/cloud-computing/docs/migrate-to-a-new-data-center#before-you-begin)

Various changes applied by the migration can impact your Linode's configuration and the devices connected to it. They can all be seen in a caution message before proceeding with your migration within Cloud Manager. Here are some changes you should be aware of:

- **IP addresses are not transferrable** They aren't migrated to the new data center with your Linode. Akamai issues a new IPv4 and IPv6 address for your Linode, and you can access them once the migration completes. When your Linode enters the migration queue, new IP addresses are reserved and you can see them in your Linode's **Networking** detail page. See [Manage IP addresses on a Linode](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance) to learn how to access Networking information in Cloud Manager.

- **DNS records need to be updated**. You need to update DNS records with the new IP address once migrated. If you're hosting your DNS with us, this can be done through the [DNS Manager](https://techdocs.akamai.com/cloud-computing/docs/dns-manager), while [rDNS](https://techdocs.akamai.com/cloud-computing/docs/configure-rdns-reverse-dns-on-a-compute-instance) can be configured directly on each Linode's Networking detail page.

  > > Note: 
  > 
  > If any DNS records are in use, the software using them won't be able to connect during or after the migration. After the migration, you need to make the necessary changes to the DNS, and they need to propagate.

- **Existing Backups can't be migrated**. Any [Backup](https://techdocs.akamai.com/cloud-computing/docs/backup-service) you have scheduled during the migration is skipped. Once the migration completes, Cloud Manager restarts your backup service on its normal schedule.

- **Block Storage volumes can't be migrated to other data centers**. If you have a Block Storage volume attached to your Linode, the migration detaches it as it begins. See our [Transfer Block Storage data between data centers](https://techdocs.akamai.com/cloud-computing/docs/transfer-block-storage-data-between-data-centers) guide to learn how to transfer a Block Storage volume's data between data centers.

- **Services need to be supported in the target data center**. If the Linode is using IPv6 pools, VLANs, or other features that have not yet been deployed to all data centers, the destination data center needs to support these features, too. Any non-supported service is stripped from the migrated Linode.

- **There is downtime during the migration**. Data transfer requires some time. This downtime varies, based on your total disk size and the speeds expected between each data center. Before the migration, Cloud Manager displays a calculated estimate for this downtime in the "Caution" message.

- **Pricing can vary between data centers**. In some newer data centers, services and network transfer are billed at separate rates due to higher region-based infrastructure costs. Before you migrate from one region to another, confirm any applicable price differences. See our [pricing](https://www.linode.com/pricing/) page for a list of pricing and plan options.

- **Migration removes a Linode from a placement group**. A [placement group](https://techdocs.akamai.com/cloud-computing/docs/work-with-placement-groups) needs to exist in a specific data center, and its member Linodes need to be in that _same data center_. If the target data center supports them, you can select to create a new placement group during the migration set up.

# [Migrate to a new data center](https://techdocs.akamai.com/cloud-computing/docs/migrate-to-a-new-data-center#migrate-to-a-new-data-center)

1. Log in to [Cloud Manager](https://cloud.linode.com) and click on the **Linodes** link in the sidebar.

2. Locate the Linode within the **Linodes** table, click the corresponding **More Options** ellipsis menu, and select _Migrate_ to open the **Migrate Linode** form.

   

   This same menu also appears within each individual Linode's dashboard page.

3. In **Migrate Linode** form, review the details of the migration and check the **Accept** box to agree to these conditions and expectations.

4. Under **Configure Migration**, select the destination **Region** for the migration.

5. Click **Enter Migration Queue**. You can monitor the progress of your migration from the list of Linodes and the Linode's dashboard. Cloud Manager returns your Linode to its previous state (powered on or off) once the migration completes.