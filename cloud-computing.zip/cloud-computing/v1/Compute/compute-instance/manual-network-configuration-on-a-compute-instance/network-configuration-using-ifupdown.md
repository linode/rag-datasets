# [Network configuration using ifupdown](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#network-configuration-using-ifupdown)

The [ifupdown](https://manpages.debian.org/bullseye/ifupdown/ifup.8.en.html) package is an older network configuration software that's still used by Debian and older Ubuntu distributions (such as 16.04 LTS and earlier).

 > Note: 
  Newer Ubuntu releases use Netplan in conjunction with systemd-networkd (or NetworkManager). Newer Debian releases also include systemd-networkd, though ifupdown is still the default.

 > Note: 
  This guide serves as a supplement to the main [Manual network configuration on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) guide. Please review that guide before making any configuration changes to your Linode.

# [Configuration files](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#configuration-files)

Network configuration settings for ifupdown are managed inside of an [interfaces](https://manpages.debian.org/bullseye/ifupdown/interfaces.5.en.html) file or series of files. The main configuration is typically stored in `/etc/network/interfaces` and additional files are typically added within `/etc/network/interfaces.d/*`

- **Default configuration file:** `/etc/network/interfaces`

# [Starter configuration](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#starter-configuration)

Here is an example of a typical configuration file for ifupdown. It statically defines the IPv4 address and allows SLAAC to configure the IPv6 address.

```text /etc/network/interfaces
auto lo
iface lo inet loopback

source /etc/network/interfaces.d/*

auto eth0

allow-hotplug eth0

iface eth0 inet6 auto
iface eth0 inet static
    address 192.0.2.123/24
    gateway 192.0.2.1
```

# [Configuring IP addresses manually](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#configuring-ip-addresses-manually)

1. Log in to [Cloud Manager](https://cloud.linode.com/) and review your Linode's IP addresses. See [Managing IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance). Make a note of the following pieces of information or keep this page accessible so you can reference it later.

   - Public IPv4 address(es) and the associated IPv4 gateway
   - Private IPv4 address (if one has been added)
   - IPv6 SLAAC address and the associated IPv6 gateway
   - IPv6 /64 or /56 routed range (if one has been added)
   - DNS resolvers (if you want to use Linode resolvers)

2. Disable Network Helper on the Linode so that it doesn't overwrite any of your changes on the next system reboot. For instructions, see the [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#individual-linode-setting) guide. This guide covers disabling Network Helper _globally_ (for all Linodes on your account) or just for a single Linode.

3. Log in to the Linode using [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish). You may want to consider using Lish to avoid getting locked out in the case of a configuration error.

4. Perform any necessary configuration steps as outlined in the workflows below. You can edit your network configuration file using a text editor like [nano](https://linode.com/docs/guides/use-nano-to-edit-files-in-linux/) or [vim](https://linode.com/docs/guides/what-is-vi/).

   ```
   sudo nano /etc/network/interfaces
   ```

5. Once you've edited the configuration file to fit your needs, you need to apply the changes or reboot the Linode. To apply your changes with ifupdown, run the following commands:

   ```
   sudo ifdown eth0 && sudo ip addr flush eth0 && sudo ifup eth0
   ```

# [Changing the primary IPv4 address](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#changing-the-primary-ipv4-address)

To change the main IPv4 address configured on the system, set the `address` and `gateway` parameters under `iface eth0 inet static` to match the new IP address and its corresponding gateway IP address.

```text /etc/network/interfaces
...
iface eth0 inet static
    address 192.0.2.123/24
    gateway 192.0.2.1
```

# [Configuring the primary IPv4 address through DHCP](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#configuring-the-primary-ipv4-address-through-dhcp)

DHCP can be used to automatically configure your primary IPv4 address. The primary IPv4 address is defined as the IPv4 address assigned to your system that is in the first position when sorted numerically. To enable DHCP, modify or add an `iface` for your interface using `dhcp` instead of `static`.

```text /etc/network/interfaces
...
iface eth0 inet dhcp
# [Iface eth0 inet static](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#iface-eth0-inet-static)
# [Address 192.0.2.123/24](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#address-1920212324)
# [Gateway 192.0.2.1](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#gateway-192021)
```

 > Error: 
  When using DHCP, the IPv4 address configured on your system may change if you add or remove IPv4 addresses on your Linode. If this happens, any tool or system using the original IPv4 address will no longer be able to connect.

To disable DHCP, switch `dhcp` back to `static` and manually add the relevant `address` and `gateway` lines.

# [Configuring additional IPv4 addresses](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#configuring-additional-ipv4-addresses)

Additional IP addresses can be configured by adding or modifying the `iface` group for the desired interface. Multiple `address` lines can be provided to configure more than one IP address.

```text /etc/network/interfaces
...
iface eth0 inet static
    address [ip-address]/[prefix]
```

In the example above, make the following replacements:

- **[ip-address]**: The IPv4 address that you wish to statically configure.
- **[prefix]**: The prefix is based on the type of IP address you are adding. It should be `24` for public IPv4 addresses and `17` for private IPv4 addresses.

# [Configuring the primary IPv6 address through SLAAC](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#configuring-the-primary-ipv6-address-through-slaac)

SLAAC is used to automatically configure your primary IPv6 address. Within ifupdown, you can configure an IPv6 SLAAC address by adding or modifying the `iface` for your interface and the `inet6` protocol, making sure to set it to `auto` instead of `static`.

```text /etc/network/interfaces
...
iface eth0 inet6 auto
    accept_ra 2
```

If you wish to disable IPv6 SLAAC addressing and instead statically configure your primary IPv6 address (not recommended), you can modify the `iface eth0 inet6` group by setting it to `static` and adding your primary IPv6 address within the `address` parameter (using the prefix of `/128`).

```text /etc/network/interfaces
...
iface eth0 inet6 static
    address [ip-address]/128
    # accept_ra 2
```

# [Configuring additional IPv6 addresses](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#configuring-additional-ipv6-addresses)

If you have an IPv6 range assigned to your Linode, addresses from this range can be configured within the `iface eth0 inet6` group, making sure it's set to `static` instead of `auto`. Multiple `address` lines can be provided to configure more than one IP address.

```text /etc/network/interfaces
...
iface eth0 inet6 static
    address [ip-address]/[prefix]
    autoconf 1
    accept_ra 2
```

In the example above, make the following replacements:

- **[ip-address]**: The IPv6 address that you wish to statically configure. You can choose any address within your available range. For example, within the range _2001:db8:e001:1b8c::/64_, the address `2001:db8:e001:1b8c::1` can be used.
- **[prefix]**: The prefix should either be `64` or `56` (depending on the size of your IPv6 range).

The `autoconf` parameter (when set to `1`), allows the primary IPv6 address to be automatically configured through SLAAC, which is the preferred behavior for most cases.

# [Changing the DNS resolvers](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-ifupdown#changing-the-dns-resolvers)

DNS resolvers are the entities that resolve domain names to their corresponding IPv4 address. By default, the Linode should be using the [DNS resolvers](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers) for the data center in which it resides. You can change these through the `/etc/resolv.conf` file, setting the `nameserver` parameters to your preferred DNS resolvers.

```text /etc/resolv.conf
domain ip.linodeusercontent.com
search ip.linodeusercontent.com
nameserver 203.0.113.1
nameserver 203.0.113.2
nameserver 203.0.113.3
...
```

In the above example, replace the IP addresses provided with the IP addresses of the DNS resolvers you wish to use.