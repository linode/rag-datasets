# [Network configuration using systemd-networkd](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#network-configuration-using-systemd-networkd)

The [systemd-networkd](https://wiki.archlinux.org/title/systemd-networkd) tool is a newer tool developed as part of systemd. Arch and modern versions of Ubuntu (17.10 and above) currently use systemd-networkd as their default network configuration software.

 > Note: 
  By default, Network Helper tool manages networking in Ubuntu using systemd-networkd. Ubuntu also has utility called Netplan that serves as a front end for configuring either systemd-networkd or NetworkManager. To use Netplan instead, review the [Network configuration using Netplan](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-netplan) guide.

 > Note: 
  This guide serves as a supplement to the main [Manual network configuration on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) guide. Please review that guide before making any configuration changes to your Linode.

# [Configuration files](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#configuration-files)

Here are details regarding the network configuration files for systemd-networkd, including information on the default configuration file location.

- **File extension:** `.network`
- **File location:** `/etc/systemd/network/`
- **Naming convention:** `[priority]-[interface].network`, with _[priority]_ being used to order the files (files are processed alpha-numerically\*) and _[interface]_ providing a convenient way for a user to associate a file with a particular interface.
- **Default configuration file:** `/etc/systemd/network/05-eth0.network`.

\* _When systemd-networkd brings up the network interfaces, the configuration files are processed alpha-numerically. As such, you'll see that files are typically prepended with a 2-digit number to help order them. The default configuration file is prepended with `05`. If we wanted to create a configuration file for a different interface, we could prepend it with a number below `05` (to be processed before) or above (to be processed after)._

# [Starter configuration](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#starter-configuration)

Here is an example of a typical configuration file for systemd-networkd. It statically defines the IPv4 address and allows SLAAC to configure the IPv6 address.

```text /etc/systemd/network/05-eth0.network
[Match]
Name=eth0

[Network]
DHCP=no
DNS=203.0.113.1 203.0.113.2 203.0.113.3
Domains=ip.linodeusercontent.com
IPv6PrivacyExtensions=false

Gateway=192.0.2.1
Address=192.0.2.123/24
```

- [**Name**](https://www.freedesktop.org/software/systemd/man/systemd.network.html#Name=): `eth0`, the default interface configured for the public internet on most Linodes. When using a VLAN, the public internet interface may be configured differently.

- [**DHCP**](https://www.freedesktop.org/software/systemd/man/systemd.network.html#DHCP=): `no`, which disables DHCP and lets you statically define the main IPv4 address in later fields.

- [**DNS**](https://www.freedesktop.org/software/systemd/man/systemd.network.html#DNS=): A list of IP addresses that map to Linode DNS resolvers. The IP addresses provided in this example are placeholders and do not function.

- [**Domains**](https://www.freedesktop.org/software/systemd/man/systemd.network.html#Domains=): `ip.linodeusercontent.com`, which is defined as a "search domain". This is a quick way of converting single-label hostnames to FQDNs, but isn't often needed.

- [**IPv6PrivacyExtensions**](https://www.freedesktop.org/software/systemd/man/systemd.network.html#IPv6PrivacyExtensions=): `false`, which disables privacy extensions and helps to resolve any issues with automatically configuring your IPv6 SLAAC address.

- [**Gateway**](https://www.freedesktop.org/software/systemd/man/systemd.network.html#Gateway=): Statically configures the IPv4 gateway address.

- [**Address**](https://www.freedesktop.org/software/systemd/man/systemd.network.html#Gateway=): Statically configures the IPv4 address.

# [Configuring IP addresses manually](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#configuring-ip-addresses-manually)

1. Log in to [Cloud Manager](https://cloud.linode.com/) and review your Linode's IP addresses. See [Managing IP addresses](https://techdocs.akamai.com/cloud-computing/docs/managing-ip-addresses-on-a-compute-instance). Make a note of the following pieces of information or keep this page accessible so you can reference it later.

   - Public IPv4 address(es) and the associated IPv4 gateway
   - Private IPv4 address (if one has been added)
   - IPv6 SLAAC address and the associated IPv6 gateway
   - IPv6 /64 or /56 routed range (if one has been added)
   - DNS resolvers (if you want to use Linode resolvers)

2. Disable Network Helper on the Linode so that it doesn't overwrite any of your changes on the next system reboot. For instructions, see the [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking#individual-linode-setting) guide. This guide covers disabling Network Helper _globally_ (for all Linodes on your account) or just for a single Linode.

3. Log in to the Linode using [SSH](https://linode.com/docs/guides/connect-to-server-over-ssh/) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish). You may want to consider using Lish to avoid getting locked out in the case of a configuration error.

4. Perform any necessary configuration steps as outlined in the workflows below. You can edit your network configuration file using a text editor like [nano](https://linode.com/docs/guides/use-nano-to-edit-files-in-linux/) or [vim](https://linode.com/docs/guides/what-is-vi/).

   ```
   sudo nano /etc/systemd/network/05-eth0.network
   ```

5. Once you've edited the configuration file to fit your needs, you need to apply the changes or reboot the Linode. To apply your changes with systemd-networkd, restart the service:

   ```
   sudo systemctl restart systemd-networkd
   ```

# [Changing the primary IPv4 address](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#changing-the-primary-ipv4-address)

To change the IPv4 address configured on the system, set the `Gateway` and `Address` parameters to match the new IP address and its corresponding gateway IP address.

```text /etc/systemd/network/05-eth0.network
...
Gateway=192.0.2.1
Address=192.0.2.123/24
```

# [Configuring the primary IPv4 address through DHCP](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#configuring-the-primary-ipv4-address-through-dhcp)

DHCP can be used to automatically configure your primary IPv4 address. The primary IPv4 address is defined as the IPv4 address assigned to your system that is in the first position when sorted numerically. To enable DHCP, set the `DHCP` parameter to `yes` and remove (or comment out) the lines that define the `Gateway` and `Address` of the primary IPv4 address.

```text /etc/systemd/network/05-eth0.network
...
[Network]
DHCP=yes
...
# [Gateway=192.0.2.1](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#gateway192021)
# [Address=192.0.2.123/24](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#address1920212324)
```

 > Error: 
  When using DHCP, the IPv4 address configured on your system may change if you add or remove IPv4 addresses on your Linode. If this happens, any tool or system using the original IPv4 address will no longer be able to connect.

# [Configuring the primary IPv6 address through SLAAC](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#configuring-the-primary-ipv6-address-through-slaac)

SLAAC is used to automatically configure your primary IPv6 address. For this to work, your system must accept router advertisements. You also may need to disable IPv6 privacy extensions. Within systemd-networkd, this means setting `IPv6PrivacyExtensions` to `false` and `IPv6AcceptRA` to `true`.

```text /etc/systemd/network/05-eth0.network
...
[Network]
...
IPv6PrivacyExtensions=false
IPv6AcceptRA=true
```

 > Note: 
  The `IPv6AcceptRA` parameter isn't strictly required as long as running the `net.ipv6.conf.eth0.autoconf` kernel variable is set to `1` (not a `0`). You can determine the setting by running the following command.
  ```
 sysctl net.ipv6.conf.eth0.autoconf
 ```

If you wish to disable IPv6 SLAAC addressing and instead statically configure your IPv6 address (not recommended), you can explicitly set the `IPv6AcceptRA` parameter to `false` and then add your primary IPv6 address (using the prefix of `/128`).

```text /etc/systemd/network/05-eth0.network
...
IPv6AcceptRA=false
Address=[ip-address]/128
```

# [Configuring additional IP addresses](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#configuring-additional-ip-addresses)

Additional IP addresses can be configured by adding another `Address` parameter within the `[Network]` section of the configuration file.

```text /etc/systemd/network/05-eth0.network
...
Address=[ip-address]/[prefix]
```

In the example above, make the following replacements:

- **[ip-address]**: The IP address that you wish to statically configure. If configuring an address from an IPv6 range, you can choose any address within that range. For example, within the range _2001:db8:e001:1b8c::/64_, the address `2001:db8:e001:1b8c::1` can be used.
- **[prefix]**: The prefix is based on the type of IP address you are adding:
  - Public IPv4 address: `/24`
  - Private IPv4 address: `/17`
  - IPv6 SLAAC address: `/128` (though it's recommended to configure this automatically through SLAAC)
  - IPv6 address from a range: `/64` or `/56` (depending on the size of the range)

# [Changing the DNS resolvers](https://techdocs.akamai.com/cloud-computing/docs/network-configuration-using-systemd-networkd#changing-the-dns-resolvers)

DNS resolvers are the entities that resolve domain names to their corresponding IPv4 address. By default, the  Linode should be using the [DNS resolvers](https://techdocs.akamai.com/cloud-computing/docs/dns-resolvers) for the data center in which it resides. You can change these by setting the `DNS` parameter to a space delimited list of the IP addresses for your preferred DNS resolvers.

```text /etc/systemd/network/05-eth0.network
...
DNS=203.0.113.1 203.0.113.2 203.0.113.3
```

In the above example, replace the IP addresses provided with the IP addresses of the DNS resolvers you wish to use. Both IPv4 and IPv6 addresses can be used together.