# [Disk encryption](https://techdocs.akamai.com/cloud-computing/docs/local-disk-encryption#disk-encryption)

Disk encryption ensures that your data stored on Linodes is secured. In addition to Akamai's [information security compliance](https://www.akamai.com/legal/compliance) with standards such as SOC 2, disk encryption provides further protections by keeping data encrypted, even if the disk is removed, decommissioned, or disposed of. 

The platform manages the encryption and decryption for you. 

By default, disk encryption is enabled on all Linodes.

## [How disk encryption works with different services and features](https://techdocs.akamai.com/cloud-computing/docs/local-disk-encryption#how-disk-encryption-works-with-different-services-and-features)

Error parsing table data: name 'null' is not defined

## [Considerations](https://techdocs.akamai.com/cloud-computing/docs/local-disk-encryption#considerations)

- You can enable disk encryption on existing, non-encrypted Linodes by using [Rebuild](https://techdocs.akamai.com/cloud-computing/docs/rescue-and-rebuild#rebuilding).

- After a Linode is created, changing the **Encrypt Disk** setting requires a [Rebuild](https://techdocs.akamai.com/cloud-computing/docs/rescue-and-rebuild#rebuilding).

- Disk encryption is enabled by default for Linodes in distributed regions, and cannot be disabled.

- LKE clusters are not encrypted. Contact support to enable this feature on your account. 

- Encryption in general, can increase CPU overhead and decrease realized throughput.
  - For performance-sensitive workloads on Linodes, you can opt-out of disk encryption or disable **Encrypt Disk** by performing a [Rebuild](https://techdocs.akamai.com/cloud-computing/docs/rescue-and-rebuild#rebuilding).

## [Check if disk encryption is enabled on a Linode](https://techdocs.akamai.com/cloud-computing/docs/local-disk-encryption#check-if-disk-encryption-is-enabled-on-a-linode)

1. Log into [Cloud Manager](https://cloud.linode.com/linodes) and click the **Linodes** link in the sidebar.

2. Click on a Linode from the list to view more details.

3. Within the top _Summary_ section, you can view if the Linode is `Encrypted` or `Not Encrypted`.

   

## [Check if disk encryption is enabled on a cluster's node pools](https://techdocs.akamai.com/cloud-computing/docs/local-disk-encryption#check-if-disk-encryption-is-enabled-on-a-clusters-node-pools)

1. Log into [Cloud Manager](http://cloud.linode.com), click **Kubernetes** in the left menu, and select the cluster you wish to view.

2. Scroll down to the **Node Pools** section. This lists all node pools for your cluster and their encryption status.

   

 > Note: Disk encryption support on LKE
  Disk encryption is currently not available on LKE. Any Kubernetes clusters created will have unencrypted nodes in node pools.