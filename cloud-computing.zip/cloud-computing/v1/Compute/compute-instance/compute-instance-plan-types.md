# [Plans](https://techdocs.akamai.com/cloud-computing/docs/compute-instance-plan-types#plans)

