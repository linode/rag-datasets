# [Copy a disk to a different account](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#copy-a-disk-to-a-different-account)

You can copy a disk of a Linode from one account to another. This is a great way to prepare a disk for another customer and transfer it from one individual account to another individual account. Or if you have multiple accounts, this guide provides instructions to consolidate all the disks in one account.

 > Note: 
  If you're copying a disk from a Linode that hosts applications, complete the backup and migrate steps for those applications.

# [Preparing the receiving Linode](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#preparing-the-receiving-linode)

You need to prepare the _receiving_ Linode before initiating the transfer. First, create a Linode with a new disks to hold the files from the other Linode.

## [Creating a new receiving Linode](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#creating-a-new-receiving-linode)

1. Log in to [Cloud Manager](https://cloud.linode.com) with the username and password you created when signing up.

2. Click **Create** at the top of the page and select **Linode**.

3. Click **X** to not choose any **Image** in the **Choose a Distribution** section of the [Distributions](https://techdocs.akamai.com/cloud-computing/docs/choose-a-distribution) tab.

   ![A screenshot of the Linux Distribution dropdown menu highlighting the x button.](https://techdocs.akamai.com/linode/compute/img/linodes-image-selection-v1.png)

4. Choose the region where you would like the Linode to reside. If you're not sure which to select, see our [Choosing a data center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center) guide. You can also generate [MTR reports](https://linode.com/docs/guides/diagnosing-network-issues-with-mtr/) for a deeper look at the route path between you and a data center in each specific region.

5. Select a plan.

6. Give the Linode a label. This is a name to help you easily identify it within Cloud Manager's Dashboard. If desired, assign a tag to the Linode in the **Add Tags** field.

7. Skip the **Root Password** and **SSH Keys** fields, as they are disabled when creating an empty Linode.

8. Click **Create Linode**. The system directs you to the _Linodes_ page that reports the status of the Linode as it boots up.

## [Creating new disks](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#creating-new-disks)

 > Note: 
  A Linode can have up to 50 disks.

To hold the files transferred from the other Linode, create two new disks labeled `copy` and `swap`:

1. Select the Linode that is receiving the disk. The Linode's dashboard appears.

2. Go to the **Storage** tab and click **Add a Disk** in the **Disks** section. The **Add Disk** window appears.

   ![A screenshot of the Create Disk window showing options for creating empty disk or creating from image and followed by the fields for Label, Filesystem, and Size.](https://techdocs.akamai.com/linode/compute/img/linodes-add-disk-drawer-v1.png)

3. Type a descriptive name such as `copy` for the disk in the **Label** field.

4. Select `ext4` in the **Filesystem** dropdown field.

5. Set the size of the disk in the **Size** field. The size of the disk must be large enough to hold the contents of the disk that you want to copy.

6. Click **Add** to create the disk.

7. Repeat the steps to create a disk labeled `swap` and select `swap` in the **Filesystem** dropdown field. Ensure that the size of the `swap` disk is the same as that of the `swap` disk of the disk that you want to copy.

The system creates disks to hold the files from the disk of other account.

## [Booting into rescue mode](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#booting-into-rescue-mode)

Start the receiving Linode in rescue mode:

1. Select the Linode that is receiving the disk. The Linode's dashboard appears.

2. Select the **More Options Ellipsis** and click the **Rescue** button.

3. Set the **/dev/sda** field to `copy` and **/dev/sdb** to `swap`.

4. Click **Reboot into Rescue Mode**.

## [Access the Linode in rescue mode](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#access-the-linode-in-rescue-mode)

After the Linode has booted, connect to it through [LISH](https://techdocs.akamai.com/cloud-computing/docs/rescue-and-rebuild#connecting-to-a-linode-running-in-rescue-mode).

1. Select the Linode that is receiving the disk. The Linode's dashboard appears.

2. Click **Launch Lish Console** . A new window appears that displays the Lish console, a `Welcome to Finnix!` message, and a root prompt.

3. Set the `root` password for the Finnix rescue environment by entering the following command:

   ```
   passwd
   ```

   > > Note: 
   > 
   > This root password is separate from the root password of the disk that you normally boot from. Setting the root password for Finnix does not affect the root account of the distribution.

4. Type the new password for the `root` user.

5. Start the SSH server:

   ```
   service ssh start
   ```

You can now connect to the server as root with the SSH client on the local computer.  
The Linode is now ready to receive the files from the other Linode account.

# [Copy the disk](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#copy-the-disk)

To start copying the files on the disk from one account to another, initiate the file transfer:

1. Connect to the _source_ Linode through an SSH client.

2. Type the following command to start copying the disk, replace `192.0.2.0` with  the IP address of the _receiving_ Linode:

   ```
   dd if=/dev/sda | ssh -C 192.0.2.0 "dd of=/dev/sda" status=progress
   ```

3. The following output appears. Enter `yes` to continue connecting:

   ```text Output
   The authenticity of host '192.0.2.0 (192.0.2.0)' can't be established.
   RSA key fingerprint is 20:f4:de:4d:5c:6e:a9:c7:e6:1f:8a:ad:60:62:96:3f.
   Are you sure you want to continue connecting (yes/no)?
   ```

4. The system prompts you for the `root` password. Enter the password you created in the last section when you started the SSH server:

   ```text Output
   root@192.0.2.0's password:
   ```

5. The file transfer starts, as shown below:

   ```text Output
   2048000+0 records in
   2048000+0 records out
   1048576000 bytes (1.0 GB) copied, 391.504 seconds, 2.7 MB/s
   2048000+0 records in
   2048000+0 records out
   1048576000 bytes (1.0 GB) copied, 387.843 seconds, 2.7 MB/s
   ```

Wait for the transfer to complete. Note that this process can take a while, depending on the size of your disk.

# [Verifying the disk](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#verifying-the-disk)

After the file transfer has completed, you should verify the disk by mounting it on the _receiving_ Linode. Ensure that the [Network Helper](https://techdocs.akamai.com/cloud-computing/docs/automatically-configure-networking) is on for the _receiving_ Linode or the [Static IP](https://techdocs.akamai.com/cloud-computing/docs/manual-network-configuration-on-a-compute-instance) is configured to enable networking with the new IP addresses.

1. Connect to the _receiving_ Linode through SSH as `root`.

2. To check that the disks are transferred successfully make a new directory for the disk by typing the following command:

   ```
   mkdir linode
   ```

3. Mount the disk by typing the following command:

   ```
   mount /dev/sda linode
   ```

4. View the directories in the disk by typing the following command:

   ```
   ls linode/
   ```

   The output is similar to:

   ```text Output
   bin   dev  home  lost+found  mnt  proc  sbin     srv  tmp  var
   boot  etc  lib   media       opt  root  selinux  sys  usr
   ```

 > Note: 
  If the system displays any disk errors, then perform the [Copy the disk](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#copy-the-disk) steps again.

Now the Linode is ready to boot from the disk.

# [Booting from the disk](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#booting-from-the-disk)

Boot the _receiving_ Linode from the disk. First, create a configuration profile on the _receiving_ Linode, and then boot the _receiving_ Linode with the disk that you just transferred.

## [Creating the configuration profile](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#creating-the-configuration-profile)

To boot the _receiving_ Linode from the transferred disk, create a new configuration profile:

1. Click the **Linodes** tab.

2. Select the Linode that received the disk. The Linode's dashboard appears.

3. Select the **Configurations** tab followed by the **Add a Configuration** button. The **Add a Linode Configuration** window appears.

4. Enter a name for the configuration profile in the **Label** field, such as _Received disk_.

5. In the _Block Device Assignment_ section, set **/dev/sda** to `copy` and **/dev/sdb** to `swap` disk.  

   ![A screenshot of the Block Device Assignment window.](https://techdocs.akamai.com/linode/compute/img/linodes-block-device-assignment-v1.png)

6. Click **Submit**.

You have successfully created the configuration profile.

## [Booting the receiving Linode](https://techdocs.akamai.com/cloud-computing/docs/copy-a-disk-to-a-different-account#booting-the-receiving-linode)

Now to start the _receiving_ Linode from the transferred disk, select the configuration profile that you created:

1. From the **Configurations** tab of the Linode's dashboard, find the _Received disk_ configuration profile that you created.

2. Click the **Boot** button to restart the Linode using the selected configuration profile, and boot from the transferred disk.

The Linode boots using the disk you transferred.