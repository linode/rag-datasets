# [Troubleshooting firewall issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances#troubleshooting-firewall-issues-on-linodes)

This guide presents troubleshooting strategies for Linodes that may be unresponsive due to issues caused by a firewall. These could be [Cloud Firewalls](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-cloud-firewalls), which are applied on the network level or a software firewall, like UFW (Uncomplicated Firewall), that is configured on your Linode's operating system.

In many cases, you might suspect a firewall issue if some of your services are inaccessible, or in situations of limited access. A firewall issue may also be suspected if you have connectivity problems not long after implementing new firewall rules.

While a firewall is often responsible for cases of limited access, these issues may also potentially be caused by a wide array of other issues such as limited network access, resource contention like throttled memory, or internal processes or services that are not configured to communicate over the internet.

# [The Linode shell (Lish)](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances#the-linode-shell-lish)

[_Lish_](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) is a shell that provides access to your Linode's serial console and is a helpful tool for diagnosing and troubleshooting connection problems. Lish does not establish a network connection to your Linode, so you can use it when your networking is down or your Linode's Secure Shell (SSH) port is inaccessible. If you find yourself locked out of SSH, you can use Lish to perform much of the troubleshooting for basic connection issues.

To learn about Lish in more detail, and for instructions on how to connect to your Linode via Lish, review the [Access your system console using Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish) guide. A fast and simple way to access Lish is [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#through-cloud-manager-weblish).

 > Note: 
  When using Lish, you can log in to your Linode with the `root` user, even if `root` user login is disabled by your system's SSH configuration file.

# [Is the Linode powered on?](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances#is-the-linode-powered-on)

Ensure that your Linode is powered on and running.

1. Log into [Cloud Manager](https://cloud.linode.com/) and navigate to the Linode listing page.

2. Verify your Linode's displayed status to determine if it's running or offline. If it your Linode is offline, use the **more options** ellipsis to power it on.

# [Is there a Cloud Firewall assigned to my Linode?](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances#is-there-a-cloud-firewall-assigned-to-my-linode)

If you are using Cloud Firewalls, then it's important to verify which Cloud Firewall(s) your Linode is assigned to and to check its firewall rules. Likewise, if your Linode is sitting behind a NodeBalancer, you may want to investigate whether or not that NodeBalancer is assigned to any Cloud Firewall. Note that only inbound rules apply to NodeBalancers.

1. Log into [Cloud Manager](https://cloud.linode.com) and select **Firewalls** from the menu.

2. The Firewalls listing page displays a list of all the firewalls currently active on your account.

3. Find the Linode or NodeBalancer you are troubleshooting under the **Services** column to determine which firewall is assigned to it.

4. Next, check the **Status** column to confirm that the firewall is **Enabled**.

   

5. If the Cloud Firewall is enabled, check to see which rules are currently active by clicking on its label. This takes you to your Cloud Firewall's **Rules** page.

6. The **Rules** page displays a list of all of the Cloud Firewall rules that are filtering your service's network traffic. If you notice that the Cloud Firewall rules do not allow traffic for a specific service's port that you are troubleshooting, you may consider [updating your rules](https://techdocs.akamai.com/cloud-computing/docs/manage-firewall-rules) to allow connections for that port.

   > > Note: 
   > 
   > If the Cloud Firewall is assigned to more than one Linode or NodeBalancer, modifying the Cloud  rules affect all services assigned to the firewall.

   > > Note: 
   > 
   > Cloud Firewalls rules are applied on the network level and are not detectable internally on Linodes. For more information on setting up and using Cloud Firewalls, see [Getting started with Cloud Firewalls](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-cloud-firewalls).

# [Checking firewall rules with UFW](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances#checking-firewall-rules-with-ufw)

_Uncomplicated Firewall (UFW)_ is an [iptables](https://linode.com/docs/guides/control-network-traffic-with-iptables/) front end that is designed for ease-of-use. See our [How to configure a firewall with UFW](https://linode.com/docs/guides/configure-firewall-with-ufw/) for a deeper dive into UFW.

 > Note: 
  All steps in this section are performed on your Linode. Connect to your Linode via [SSH](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-instance) or using [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

To see all active UFW rules, enter the following command:

```
sudo ufw status
```

Your output will be similar to the following:

```text Output
Status: active

To                         Action      From
--                         ------      ----
22                         ALLOW       Anywhere
80/tcp                     ALLOW       Anywhere
443                        ALLOW       Anywhere
22 (v6)                    ALLOW       Anywhere (v6)
80/tcp (v6)                ALLOW       Anywhere (v6)
443 (v6)                   ALLOW       Anywhere (v6)
```

If the status is active, the rules listed are all in place and may be blocking one of your services. To remove any individual firewall rule, use the following syntax:

```
sudo ufw delete 
 

```

For example, to delete the Allow rule for port 80 from the example output above, enter the following command:

```
sudo ufw delete allow 80
```

# [Checking firewall rules with firewalld](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances#checking-firewall-rules-with-firewalld)

_firewalld_ is the default firewall tool for CentOS and Fedora. While also a front end for iptables like UFW, firewalld has some unique features, like configuration sets and zones.

 > Note: 
  All steps in this section are performed on your Linode. Connect to your Linode via [SSH](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode) or using [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

To list all configurations for all zones, enter the following command:

```
sudo firewall-cmd --list-all-zones
```

If you find a rule that doesn't belong, you can safely remove it using the following syntax:

```
sudo firewall-cmd --zone=zonename --remove-service=servicename --permanent
```

For more information on understanding firewalld, see our [Introduction to FirewallD on CentOS](https://linode.com/docs/guides/introduction-to-firewalld-on-centos/) guide.

# [Checking firewall rules with iptables](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances#checking-firewall-rules-with-iptables)

_iptables_ is the most common firewall used on Linux systems. If you're unsure of which firewall software you may be using, chances are that it's iptables in some form.

 > Note: 
  All steps in this section are performed on your Linode. Connect to your Linode via [SSH](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode) or using [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish).

To list all active firewall rules using iptables, enter the following commands for IPv4 and IPv6 respectfully:

```
sudo iptables -L -nv
sudo ip6tables -L -nv
```

Removing rules uses the same syntax to add rules, with the addition of the `-D` or `--delete` option. For example, use the following commands to delete a rule that drops connections to port 110, on the eth0 interface, towards the IPv4 address 198.51.100.0:

```
iptables --delete INPUT -j DROP -p tcp --destination-port 110 -i eth0 -d 198.51.100.0
```

or

```
iptables -D INPUT -j DROP -p tcp --destination-port 110 -i eth0 -d 198.51.100.0
```

For more information on reading and interpreting iptables rules see our guide on iptables, [A Tutorial for Controlling Network Traffic with iptables](https://linode.com/docs/guides/control-network-traffic-with-iptables/#basic-iptables-rulesets-for-ipv4-and-ipv6)