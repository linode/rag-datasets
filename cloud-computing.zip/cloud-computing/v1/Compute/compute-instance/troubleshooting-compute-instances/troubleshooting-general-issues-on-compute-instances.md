# [Troubleshooting general issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#troubleshooting-general-issues-on-linodes)

This guide provides common troubleshooting scenarios you may encounter when managing your Linode. Each troubleshooting section provides ways to further diagnose your issue and the corresponding steps, when applicable, to resolve the issue. We recommend using this guide in the following way:

- Browse the guide's headings and select the issue that best describes your problem.

- Follow the troubleshooting steps in the order they are presented.

- Once you've confirmed a specific problem, try fixing it with the suggested solutions.

If the troubleshooting steps in this guide don't apply to your issue, review these additional troubleshooting guides that cover other topics:

- [Troubleshooting connection issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-basic-connection-issues-on-compute-instances)
- [Troubleshooting SSH on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-ssh-on-compute-instances)
- [Troubleshooting memory issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-memory-issues-on-compute-instances)
- [Troubleshooting firewall issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-firewall-issues-on-compute-instances)
- [Troubleshooting web servers, databases, and other services](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-web-servers)

 > Note: Additional resources for help
  This guide explains how to use different troubleshooting commands on your Linode. These commands can produce diagnostic information and logs that may expose the root of your connection issues. For some specific examples of diagnostic information, this guide also explains the corresponding cause of the issue and presents solutions for it.
  If the information and logs you gather do not match a solution outlined here, consider searching the [Community Site](https://www.linode.com/community/questions/) for posts that match your system's symptoms. Or, post a new question in the Community Site and include your commands' output.
  We are not responsible for the configuration or installation of software on your Linode. Refer to our [scope of support](https://techdocs.akamai.com/cloud-computing/docs/help-and-support#scope-of-support) for a description of the issues with which Support can help.

# [Linode is unresponsive](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#linode-is-unresponsive)

If your Linode is unresponsive, either at the Lish console or to basic network requests, read through the [Troubleshooting basic connection issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-basic-connection-issues-on-compute-instances) guide.

# [Linode is slow](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#linode-is-slow)

 > Note: 
  You should follow all steps in the [Troubleshooting basic connection issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-basic-connection-issues-on-compute-instances) guide before using the checklist in this section.

## [Is the disk full?](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#is-the-disk-full)

If your Linode's disk is full, this can cause performance degradation and instability for your applications. Use the following command to determine the free space on your Linode's filesystem:

```
df -h
```

The output will resemble the following example:

```text Output
Filesystem      Size  Used Avail Use% Mounted on
/dev/root       189G  166G   14G  93% /
devtmpfs        3.9G     0  3.9G   0% /dev
tmpfs           3.9G   16K  3.9G   1% /dev/shm
tmpfs           3.9G  399M  3.6G  10% /run
tmpfs           5.0M     0  5.0M   0% /run/lock
tmpfs           3.9G     0  3.9G   0% /sys/fs/cgroup
tmpfs           799M     0  799M   0% /run/user/1000
```

In the example output, you can see that the root filesystem is 93% full. Issue the following command to list all files over 200MB on your root filesystem:

```
sudo find / -xdev -type f -size +200M -exec ls -lah {} \;
```

You can adjust the `+200M` value in this command, as needed, to search for files above a specific size.

### [Deleted files](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#deleted-files)

If a service deletes a file that it is no longer needed, the file remains on your disk until the next time the service has been rebooted. The following example demonstrates how deleted files belonging to Apache can continue to take up space after they have been deleted.

Use the following command to check for deleted files that are currently open:

```
sudo lsof | grep deleted  | numfmt --field=8 --to=iec
```

This command will check the output of `lsof` for files marked as deleted, and will convert the file sizes so that they're more easily readable. In this example Apache is holding on to several old files:

```text Output
apache2   32341         www-data   13u      REG                8,0          0        24K /tmp/.ZendSem.OmCTIC (deleted)
apache2   32341         www-data   14w      REG               0,19          0       243M /run/lock/apache2/proxy.13748 (deleted)
apache2   32341         www-data   15w      REG               0,19          0       243M /run/lock/apache2/mpm-accept.13748 (deleted)
apache2   32342         www-data   12w      REG               0,19          0       158M /run/lock/apache2/ssl-cache.13747 (deleted)
apache2   32342         www-data   13u      REG                8,0          0        24K /tmp/.ZendSem.OmCTIC (deleted)
apache2   32342         www-data   14w      REG               0,19          0       243M /run/lock/apache2/proxy.13748 (deleted)
apache2   32342         www-data   15wW     REG               0,19          0       243M /run/lock/apache2/mpm-accept.13748 (deleted)
apache2   32343         www-data   12w      REG               0,19          0       158M /run/lock/apache2/ssl-cache.13747 (deleted)
```

To free up this space, you can simply restart the Apache service on your Linode. This command restarts the Apache service using [systemd](https://linode.com/docs/guides/what-is-systemd/) on Ubuntu 18.04:

```
sudo systemd restart apache2
```

## [Is the Linode out of memory?](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#is-the-linode-out-of-memory)

The applications on your Linode require a certain amount of physical memory to function correctly. If all of the available physical memory is consumed, your system could slow down, display out of memory errors, or become unresponsive. Here's how to tell if your Linode is out of memory:

1. Log in to [Cloud Manager](https://cloud.linode.com).
2. Click the **Linodes** link in the sidebar to view a list of all your Linode.
3. Select a Linode to view its dashboard.
4. Click on the **Launch Console** link in the upper-right hand corner to launch the LISH Console. The LISH console window appears. If memory errors are displayed in the LISH console, stop some running services to free up memory or [upgrade to a larger plan](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance).
5. Read through the [Troubleshooting memory issues on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-memory-issues-on-compute-instances) guide for troubleshooting commands which display your memory use.
6. If an application is consuming all of your available memory, you have three options. You can kill the application, change the application's settings to reduce its memory footprint, or [upgrade your Linode](https://www.linode.com/pricing) to a larger plan.

If your Linode is not out of memory, continue to the next section.

## [Is there a disk I/O bottleneck?](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#is-there-a-disk-io-bottleneck)

Disk input/output (I/O) bottlenecks can occur when an application or service is reading or writing an excessive amount of information to disk and the processor has to wait to process the information. High I/O wait can significantly slow down your server. To determine if your server currently has an I/O bottleneck, follow the steps below:

1. [Log in to your Linode via SSH](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-compute-instances#connect-to-the-linode).

2. Enter `top` to access the `top` monitoring utility. The screen shown below appears.

   

3. Examine the I/O wait percentage, as shown above. If the number is zero, your server does not currently have a bottleneck.

4. If your I/O wait percentage is above zero, verify that your server has enough [free memory available](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-memory-issues-on-compute-instances). In many cases, high I/O is an indication that your server has started "swapping," or using disk space as memory.

5. If your server has free memory available and is not using swap space, use `iotop` or [vmstat](https://linode.com/docs/guides/use-vmstat-to-monitor-system-performance/) to find the application responsible for the excessive I/O. Databases are often a source of excessive I/O. You may need to stop and/or reconfigure the application.

   > > Note: 
   > 
   > You must run `iotop` as `root` or with `sudo`.

6. If you cannot determine the source of the IO bottleneck, contact [Support](https://techdocs.akamai.com/cloud-computing/docs/help-and-support) for assistance.

Since `top` only reports what is currently happening, and most I/O issues are temporary, it helps to have a monitoring utility set up so you can see a graph of I/O trends and spot potential issues _before_ they become major problems. See the [server monitoring](https://linode.com/docs/uptime/monitoring/) guides for instructions on setting up a server monitoring utility.

# [Website is not loading](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#website-is-not-loading)

If your website is unresponsive or not loading correctly, see [Troubleshooting web servers, databases, and other services](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-web-servers).

 > Note: 
  You should follow all steps [Linode is slow](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#linode-is-slow)  section before following the recommendations in [Troubleshooting web servers, databases, and other services](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-web-servers).

# [Can't connect via SSH or FTP](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#cant-connect-via-ssh-or-ftp)

If you can't connect to your Linode over SSH, see [Troubleshooting SSH on Linodes](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-ssh-on-compute-instances) guide.

 > Note: 
  You should follow all steps in the [Linode is slow](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#linode-is-slow) section before following the [Troubleshooting SSH](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-ssh-on-compute-instances) guide.

## [Are you using Telnet or FTP?](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#are-you-using-telnet-or-ftp)

Telnet and FTP are disabled on your Linode by default, and we strongly recommend that you do not use those protocols. Instead, please use Secure Shell (SSH) and SSH File Transfer Protocol (SFTP) -- the secure versions of the Telnet and FTP protocols. All Linodes come with an SSH server enabled, and you can connect to port 22 with SSH and SFTP clients. For more information, see [Set up and secure a Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-linode).

# [Forgot my username or password](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#forgot-my-username-or-password)

## [System user/root password](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#system-userroot-password)

If you've forgotten the password for the root user on your Linode, you can follow the steps for [resetting your root password](https://techdocs.akamai.com/cloud-computing/docs/reset-the-root-password-on-a-compute-instance) from Cloud Manager.

Once you have access to your Linode as the root user, you can reset the password for any additional system users with the `passwd` command. The example resets the password for the `username` user:

```
passwd username
```

## [Cloud Manager user](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#cloud-manager-user)

- If you forget your Cloud Manager username, you can confirm it by supplying your email address on the [Recover Username](https://login.linode.com/forgot/username) page.

- Assuming you know your Cloud Manager username, but you've forgotten the password, you can retrieve it on the [Reset Password](https://login.linode.com/forgot/password) page.

If you've followed these steps, but you're still having trouble accessing your account, please contact [Support](https://www.linode.com/support/).

# [Cloud Manager is displaying "incorrect" information](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#cloud-manager-is-displaying-incorrect-information)

Use the following checklist if Cloud Manager is displaying "incorrect" information.

## [Did you recently change your account?](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#did-you-recently-change-your-account)

If you recently created a new account, resized an existing Linode, or added extra bandwidth, the bandwidth displayed in Cloud Manager will be prorated for the amount of time left in the current billing cycle. For example, if you create an account on the 15th day of the month, the Manager will indicate that your account has been allocated half of the plan's bandwidth for the current month. This information is an accurate representation of the bandwidth available for the rest of the billing period. When then next billing period starts, the Manager will indicate that all of the plan's bandwidth is available. View the [Billing](https://techdocs.akamai.com/cloud-computing/docs/understanding-how-billing-works) guide for more information.

## [Did you add additional storage?](https://techdocs.akamai.com/cloud-computing/docs/troubleshooting-general-issues-on-compute-instances#did-you-add-additional-storage)

If you recently upgraded your plan, your Linode won't be able to take advantage of the additional space until you resize the disk. You can use Cloud Manager to verify if there's additional storage space available for disks:

1. Log in to [Cloud Manager](https://cloud.linode.com).
2. Click the **Linodes** link in the sidebar to view a list of your Linodes.
3. Select a Linode and the **Storage** tab.
4. Compare the total available disk space with the **Size** Column in the **Disks** table. If you have free storage space, you can allocate that space to your existing disks, or create new disks as needed.

   

   Follow our steps for [resizing a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#resize-a-disk) to take advantage of the extra space.