# [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#create-a-linode)

 > Note: 
  If you're using Linode interfaces, follow the instructions from [Create a Linode (using Linode interfaces or Configuration profile interfaces) (BETA)](https://techdocs.akamai.com/cloud-computing/docs/create-a-linode-with-networking-interfaces).

This guide walks you through creating a Linode in a core compute region using Cloud Manager. If you wish to create a Linode in a distributed compute region, see [Create a Linode  in a Distributed Compute Region](https://techdocs.akamai.com/cloud-computing/docs/create-compute-instance-distributed).

To create a Linode, you will:

1. [Open the Create form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#open-the-create-form-in-cloud-manager)
2. [Select a region](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#select-a-region)
3. [Choose a distribution, app, or image](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#choose-a-distribution-app-or-image)
4. [Choose a plan](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#choose-a-compute-instance-type-and-plan)
5. [Set the label, add tags, and assign to a placement group](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#set-the-label-add-tags-and-assign-to-a-placement-group)
6. [Create a password and add SSH keys](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#create-a-password-and-add-ssh-keys)
7. [Enable or disable disk encryption](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#enable-or-disable-disk-encryption)
8. [Assign to a VPC (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#assign-to-a-vpc-optional)
9. [Assign to a Cloud Firewall (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#assign-to-a-cloud-firewall-optional)
10. [Assign to a VLAN (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#assign-to-a-vlan-optional)
11. [Configure additional options](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#configure-additional-options)
12. [Add user data](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#add-user-data)
13. [Deploy the Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#deploy-the-linode)

# [Open the Create form in Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#open-the-create-form-in-cloud-manager)

Log in to [Cloud Manager](https://cloud.linode.com/), click the **Create** dropdown menu on the top bar, and select _Linode_. This opens the **Create** form.

# [Select a region](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#select-a-region)

Next, you must select the **region** where the Linode will reside. Regions correspond with individual data centers, each located in a different geographical area. You should likely select the region closest to you and/or your customers. This helps reduce latency and can make a significant impact in connection speeds and quality. If you wish to make use of a particular product or service, you may also wish to verify that the product is available within your desired data center.

You need to select a region before selecting your plan type. [Pricing](https://www.linode.com/pricing/) may vary between data centers. The following resources will help you choose a data center.

- [Global infrastructure map](https://www.linode.com/global-infrastructure/)
- [Speed tests for data centers](https://www.linode.com/speed-test/)
- [Choosing a data center](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-data-center) (guide)

# [Choose a distribution, app, or image](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#choose-a-distribution-app-or-image)

One of the first steps to deploy a Linode is to decide _what_ you actually wish to deploy. You're able to select a Linux distribution for a barebones install, a Marketplace App with your desired software, and a few other options.

- **Distributions:** Select from any [supported Linux distribution](https://www.linode.com/distributions/). This option lets you start with a stable Linux operating system and build your own software stack from scratch. Popular distributions include the latest LTS releases of Ubuntu, Debian, CentOS Stream, RHEL-derivatives (such AlmaLinux and Rocky Linux), and more. Each distribution comes with its own set of preinstalled software and commands. See [Choose a Linux distribution](https://techdocs.akamai.com/cloud-computing/docs/choose-a-distribution) for a full list of distributions.

- **Marketplace**: Select from the many [Apps](https://www.linode.com/marketplace/apps/) currently featured in [Marketplace](https://www.linode.com/marketplace/). This installs and configures your desired software, allowing you to start using your applications right away. Popular apps include [Wordpress](https://www.linode.com/marketplace/apps/linode/wordpress/), [WooCommerce](https://www.linode.com/marketplace/apps/linode/woocommerce/), [LEMP](https://www.linode.com/marketplace/apps/linode/lemp/), [cPanel](https://www.linode.com/marketplace/apps/cpanel/cpanel/), [Plesk](https://www.linode.com/marketplace/apps/plesk/plesk/), and [Nextcloud](https://www.linode.com/docs/marketplace-docs/guides/nextcloud/). See [Marketplace Apps - Get started](https://www.linode.com/docs/marketplace-docs/get-started/).

- **StackScripts:** Select from any StackScripts previously created on your account or from a community StackScript. StackScripts automate the deployment of software and configuration by executing commands within your system after the first boot. See [Deploy a Linode using a StackScript](https://techdocs.akamai.com/cloud-computing/docs/deploy-a-compute-instance-using-a-stackscript).

- **Images:** Select from any Custom Image or Recovery Image stored on your account. _Recovery Images_ are generated after a Linode has been deleted and _Custom Images_ can be created based on existing Linodes or image files. See [Images](https://techdocs.akamai.com/cloud-computing/docs/images).

- **Backups:** If you have the Backups service enabled on an existing Linode, you can select any available backup snapshot to deploy from. See [Restore a backup to a new Linode](https://techdocs.akamai.com/cloud-computing/docs/restore-a-backup-to-a-new-compute-instance).

- **Clone Linode:** Creates a new Linode from the disks and configuration on an existing Linode. See [Clone a Linode](https://techdocs.akamai.com/cloud-computing/docs/clone-a-compute-instance).

This guide assumes you are creating a Linode from a **Distribution**. If you select a different option, you may wish to follow the specific instructions within their own corresponding guides.

# [Choose a Linode type and plan](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#choose-a-linode-type-and-plan)

There are several different Linode types and plan sizes, each with a preset amount of hardware resources (such as vCPU cores, memory, and storage space). Review the [Choose a Linode plan](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan) guide for advice on selecting the best plan for your needs, application’s requirements, and pricing considerations. Note that [pricing and plan options](https://www.linode.com/pricing/) may vary between data centers.

 > Note: 
  You can resize to a different plan size or Linode type at any time. This means your aren't locked in to whichever plan you select here. See [Resize a Linode](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance) for instructions.

# [Set the label, add tags, and assign to a placement group](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#set-the-label-add-tags-and-assign-to-a-placement-group)

- **Label:** The label is the name of the Linode, allowing you to easily identify it from other Linodes. A good label should provide some indication as to what the Linode is used for. As an example, a label of `acme-web-prod` may indicate that the Linode is the production website for the company Acme. If you have already implemented your own naming conventions for your cloud infrastructure, follow those conventions. Labels must only use letters, numbers, underscores, dashes, and periods.

- **Tags:** Adding tags gives you the ability to categorize your services however you wish. If you're a web development agency, you could add a tag for each client you have. You could also add tags for which services are for development, staging, or production.

- **Placement Groups:** (Optional) Add this Linode to a placement group to manage its physical location in a data center ("region"). Placement groups can be set up to group your Linodes close together to help with performance, or further apart to support high availability. Placement groups are available at no additional cost, but they're not available in all regions. See [Work with placement groups](https://techdocs.akamai.com/cloud-computing/docs/work-with-placement-groups) to learn more.

 > Note: If you don't have a placement group
  Click **Create Placement Group** to create one. This takes you to a separate interface, outside creating your Linode. For ease of use, create your Linodes in a supported region, then later create a placement group and assign your Linodes to it.

# [Create a password and add SSH keys](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#create-a-password-and-add-ssh-keys)

- **Root Password:** The password used to log in to the system as the root user. The root user is the main account and has access to the entire system, including files and commands. This password should be extremely strong to prevent attackers from gaining access to your system. By default, the root user can log in over Lish and SSH using this password, though we do recommend disabling this in the [Set up and secure a Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance) guide.

- **SSH Keys:** Add any SSH Keys to the root user account on the server. This enables you to log in through SSH without needing a password. SSH keys are created as a pair: a _private key_ stored on your local computer and a _public key_ that you can upload to remote systems and services. Since you only share your public key and your private key is kept safe and secure, this is a much more secure method for authentication than passwords. Learn more about uploading SSH keys through Cloud Manager on the [Manage SSH keys](https://techdocs.akamai.com/cloud-computing/docs/manage-ssh-keys) guide.

# [Enable or disable disk encryption](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#enable-or-disable-disk-encryption)

Consider enabling **Encrypt Disk** on this Linode. The platform manages encryption and decryption for you. After a Linode is created, use [Rebuild](https://techdocs.akamai.com/cloud-computing/docs/rescue-and-rebuild#rebuilding) to change this setting.

 > Note: Limited availability
  Disk Encryption is not currently available in all regions.

More information is available from the [Local Disk Encryption](https://techdocs.akamai.com/cloud-computing/docs/local-disk-encryption) guide.

# [Assign to a VPC (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#assign-to-a-vpc-optional)

Consider using a [VPC](https://techdocs.akamai.com/cloud-computing/docs/vpc) (Virtual Private Network) to isolate your new Linode from other systems on  Akamai Cloud and the internet. This adds an additional layer of privacy and can be used alongside Cloud Firewalls. If you are not sure you need a VPC, you can skip this step. You can add this new Linode to a VPC at any time in the future by following the steps within the [Assign a Linode to a VPC](https://techdocs.akamai.com/cloud-computing/docs/assign-a-compute-instance-to-a-vpc) guide.

- **Select VPC:** To assign this Linode to a VPC, select the VPC from the **Assign VPC** dropdown menu. If you do not yet have a VPC in the selected data center, click the **Create a VPC** button and follow the instructions on the [Create a VPC](https://techdocs.akamai.com/cloud-computing/docs/create-a-vpc) guide.

- **Select Subnet:** A Linode can be assigned to a single subnet, which lets you further segment traffic and services within a VPC. Select the desired subnet within the **Subnet** dropdown menu.

- **Auto-Assign IPv4 address:** By default, an IPv4 address will be automatically generated for the Linode on the subnet’s defined CIDR range. If you want to manually assign an IP address, uncheck the **Auto-assign a VPC IPv4 address for this Linode** option and enter your custom IPv4 address. This address must still be within the subnet’s IP range.

- **Public IPv4 address:** If you wish to enable public internet access on this new Linode, check the **Assign a public IPv4 address for this Linode** option. By default, this is unchecked and you will not be able to access the internet from this Linode.

- **Additional IPv4 ranges:** You can assign additional IPv4 ranges that can be used to reach this Linode and/or the services running on it. For example, you may wish to assign additional IPv4 ranges to directly expose Docker containers to the VPC.

For additional information and considerations, review the [Assign a Linode to a VPC](https://techdocs.akamai.com/cloud-computing/docs/assign-a-compute-instance-to-a-vpc) guide.

# [Assign to a Cloud Firewall (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#assign-to-a-cloud-firewall-optional)

To protect your new Linode from unwanted traffic, consider using a [Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/cloud-firewall). This lets you cascade firewall rules across multiple services and manage those rules within Cloud Manager, Linode CLI, and Linode API.

To assign your Linode to a Cloud Firewall, select the firewall from the **Assign Firewall** dropdown menu. If you do not have a firewall or wish to create a new one, click the **Create Firewall** link and follow the instructions within the [Create a Cloud Firewall](https://techdocs.akamai.com/cloud-computing/docs/create-a-cloud-firewall) guide. You can always skip this step and assign a firewall at a later time by following the instructions in the [Apply firewall rules to a service](https://techdocs.akamai.com/cloud-computing/docs/apply-firewall-rules-to-a-service) guide.

# [Assign to a VLAN (optional)](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#assign-to-a-vlan-optional)

Add this Linode to a secure private network. VLANs are available at no additional cost, though not all data centers currently support this feature. See [VLANs](https://techdocs.akamai.com/cloud-computing/docs/vlan) to learn more.

 > Warning: Consider using a VPC instead of a VLAN
  In most cases, it's recommended to use a VPC over a VLAN. VPCs operate on a higher network layer and come with more IP addressing and IP routing functionality. Additionally, you can further segment out network traffic through subnets, each of which has its own CIDR range. Review [these differences](https://techdocs.akamai.com/cloud-computing/docs/vpc#difference-between-private-network-options-vpcs-vlans-and-private-ips) to learn more.

# [Configure additional options](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#configure-additional-options)

The following features and services can be configured during the Linode's creation or at any point after.

- **Set the maintenance policy:** Set a preference for how routine maintenance is performed on your new Linode. Choose _Migrate_ to perform maintenance while your instance is running or _Power off / power on_ to turn off your instance during maintenance. To learn more about these policy options, see [Maintenance events and policies](https://techdocs.akamai.com/cloud-computing/docs/host-maintenance-policy) . 
- **Add the Backups service:** Safeguard your data with the Backups service, enabling automatic backups of the disks on your Linodes. Up to four backups are stored as part of this service, including automated daily, weekly, and biweekly backups in addition to a manual backup snapshot. See [Backups](https://techdocs.akamai.com/cloud-computing/docs/backup-service) to learn more and view pricing.
- **Add a private IP:** A private IP gives you access to the data center's private network. This enables you to communicate with other Linodes with private IPs in the same region without using a public IPv4 address. Private IPs are needed to configure your Linode as a NodeBalancer back end. The private IP feature requires a _Public Internet_ network interface. As such, Linodes configured with both VPCs _and_ a private IP address are configured with the _VPC_ network interface on `eth0` and the _Public Internet_ interface on `eth1`.

  > > Warning: Consider using a VPC instead of the private IP address feature
  > 
  > Private IP addresses are accessible by any other Linode in the same data center, provided that Linode also has a private IP. To further isolate your Linode, consider using a VPC instead. Review [these differences](https://techdocs.akamai.com/cloud-computing/docs/vpc#difference-between-private-network-options-vpcs-vlans-and-private-ips) to learn more.

# [Add user data](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#add-user-data)

User data can be provided to the Metadata service, which is then consumed by cloud-init when your Linode boots up for the first time. For information on the Metadata service, user data formats, and our cloud-init integration, see [Metadata Service](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service).

# [Deploy the Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#deploy-the-linode)

Confirm the details for this Linode within the _Linode Summary_ section. Once you are satisfied, click **Create Linode** to start the deployment process. This process can take anywhere from 3 minutes for Distribution Images to up to 30 minutes for some Marketplace Apps. After the creation process has started, you are automatically redirected to the detail page for this Linode. From here, you can follow the status as the Linode is deployed as well as see information about the new Linode, such as the IP addresses.

# [Next steps](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance#next-steps)

Once the Linode has been created and is done initializing, you can start configuring and using it. Follow [Set up and secure a Linode](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance) for guidance on connecting your Linode, performing any initial configuration steps on your Linux system, and securing your server.

