# [Default distro packages](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#default-distro-packages)

Base Linux images are installed to all distributions. This includes all of the packages included by the base image by default. However, this also includes images added to nearly all Distros which provide access to common tools and functionalities. The packages are tailored to help with systems administration in the cloud, and ensure that all  images work with all products and services. Below is a list of the additional packages installed for all of our distributions.

 > Note: 
  Gentoo and Slackware do not use any packages not provided by the distribution.

# [AlmaLinux](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#almalinux)

```
'authconfig'
'authselect-compat'
'chrony'
'cloud-init'
'file'
'grub2'
'grub2-pc'
'iotop'
'kernel'
'langpacks-en'
'lsof'
'mtr'
'nano'
'net-tools'
'qemu-guest-agent'
'sysstat'
'vim-enhanced'
'whois'
```

# [Alpine](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#alpine)

```
'acct'
'blkid'
'chrony'
'curl'
'docs'
'e2fsprogs'
'grub-bios'
'haveged'
'iotop'
'linux-virt'
'mtools'
'mtr'
'nano'
'openssh'
'openssh-client'
'openssh-server'
'openssh-sftp-server'
'openssl'
'sudo'
'sysstat'
'vim'
```

# [Arch](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#arch)

```
'cloud-init'
'grub'
'haveged'
'inetutils'
'iotop'
'linux'
'linux-firmware'
'lsof'
'man-db'
'man-pages'
'mtr'
'nano'
'net-tools'
'openssh'
'sudo'
'sysstat'
'vim'
'whois'
```

# [CentOS Stream](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#centos-stream)

```
'authconfig'
'authselect-compat'
'cloud-init'
'file'
'grub2'
'grub2-pc'
'iotop'
'kernel'
'langpacks-en'
'lsof'
'mtr'
'nano'
'net-tools'
'qemu-guest-agent'
'sysstat'
'vim-enhanced'
```

# [CentOS](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#centos)

```
'authconfig'
'authselect-compat'
'chrony'
'cloud-init'
'file'
'grub2'
'grub2-pc'
'iotop'
'kernel'
'langpacks-en'
'lsof'
'mtr'
'nano'
'net-tools'
'qemu-guest-agent'
'sysstat'
'vim-enhanced'
'whois'
```

# [Debian](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#debian)

```
'apt-listchanges'
'bash-completion'
'bind9-host'
'cloud-init'
'console-setup'
'curl'
'dnsutils'
'grub-pc'
'haveged'
'hdparm'
'iotop'
'irqbalance-'
'keyboard-configuration'
'less'
'liblockfile-bin'
'libnss-systemd'
'linux-image-amd64'
'locales'
'lsb-release'
'lsof'
'man-db'
'manpages'
'mtr-tiny'
'netcat-traditional'
'openssh-server'
'pciutils'
'perl'
'pigz-'
'python-minimal'
'reportbug'
'sudo'
'sysstat'
'task-english'
'telnet'
'traceroute'
'vim'
'wget'
'whois'
```

# [Fedora](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#fedora)

```
'@server-product-environment'
'authselect-compat'
'chrony'
'cloud-init'
'fedora-release-server'
'fedora-release-identity-server'
'grub2'
'grub2-pc'
'iotop'
'kernel'
'langpacks-en'
'python2.7'
'sysstat'
'vim-enhanced'
'whois'
```

# [openSUSE](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#opensuse)

```
'pattern:basesystem'
'pattern:console'
'pattern:enhanced_base'
'pattern:minimal_base'
'pattern:yast2_basis'
'acl'
'at'
'attr'
'bash-completion'
'bind-utils'
'bzip2'
'ca-certificates-mozilla'
'chrony'
'chrony-pool-openSUSE'
'cloud-init'
'cronie'
'e2fsprogs'
'grub2-i386-pc'
'haveged'
'iotop'
'iputils'
'issue-generator'
'kernel-default'
'kexec-tools'
'logrotate'
'man'
'man-pages'
'mosh'
'mtr'
'nano'
'netcat-openbsd'
'qemu-guest-agent'
'rsync'
'rsyslog'
'screen'
'sharutils'
'sudo'
'terminfo'
'time'
'tmux'
'vim'
'vim-data'
'wget'
'which'
'whois'
```

# [Rocky Linux](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#rocky-linux)

```
'authconfig'
'authselect-compat'
'chrony'
'cloud-init'
'file'
'grub2'
'grub2-pc'
'iotop'
'kernel'
'langpacks-en'
'lsof'
'mtr'
'nano'
'net-tools'
'qemu-guest-agent'
'sysstat'
'vim-enhanced'
'whois'
```

# [Ubuntu](https://techdocs.akamai.com/cloud-computing/docs/default-distro-packages#ubuntu)

```
'gcc-10-base'
'grub-pc'
'haveged'
'iotop'
'libnss-nis'
'libnss-nisplus'
'linux-generic'
'linux-headers-generic'
'mime-support'
'sysstat'
'ubuntu-advantage-tools'
'ubuntu-standard'
'whois'
'openssh-server^'
'cloud-image^'
'server^'
```