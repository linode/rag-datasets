# [Package mirrors](https://techdocs.akamai.com/cloud-computing/docs/package-mirrors#package-mirrors)

When installing or updating packages using a package manager, a package repository is used to get a list of all available packages and to download those packages. Package mirrors are replicas of these package repositories. Akamai offers public package mirrors for Ubuntu, Debian, and CentOS. Since our mirrors are hosted in every data center, responses and downloads are typically much faster than using other public mirrors.

 > Note: 
  By default, all new Linodes use our package mirrors. No additional configuration is required.

# [Package mirror settings](https://techdocs.akamai.com/cloud-computing/docs/package-mirrors#package-mirror-settings)

For best performance, you will want to use the mirror in the same data center as your Linode. When using the our DNS resolvers, **mirrors.linode.com** will resolve to the mirror within the same data center. For public queries, mirrors.linode.com will return a round robin of the US locations.

Instructions for setting the package mirror location are provided in the following subsections.

## [Ubuntu system settings](https://techdocs.akamai.com/cloud-computing/docs/package-mirrors#ubuntu-system-settings)

For a Ubuntu system follow the instructions below:

1. Edit the `sources.list` file with the following command:

   ```
   sudo nano /etc/apt/sources.list
   ```

2. Replace the line containing the address 
 with the new address location:

   ```
   http://mirrors.linode.com/ubuntu/
   ```

3. Do not modify lines containing the address 
. These lines contain security updates for packages.

4. Save and exit the `sources.list` file.

## [Debian system settings](https://techdocs.akamai.com/cloud-computing/docs/package-mirrors#debian-system-settings)

For a Debian system follow the instructions below:

1. Edit the `sources.list` file with the following command:

   ```
   sudo nano /etc/apt/sources.list
   ```

2. Replace the line containing the address 
 with the new address location:

   ```
   http://mirrors.linode.com/debian/
   ```

3. Do not modify lines containing the address 
. These lines contains security updates for packages.

4. Save and exit the `sources.list` file.

## [CentOS system settings](https://techdocs.akamai.com/cloud-computing/docs/package-mirrors#centos-system-settings)

For a CentOS system follow the instructions below:

1. By default, `yum` will try using fastest mirror available. This need to be disabled to use our mirror. Edit the `fastestmirror.conf` file with the following command:

   ```
   sudo nano /etc/yum/pluginconf.d/fastestmirror.conf
   ```

2. Change the `enabled=` variable to **0**:

   ```text /etc/yum/pluginconf.d/fastestmirror.conf
   ...
   enabled=0
   ...
   ```

3. Save and exit the `fastestmirror.conf` file.

4. Edit the `CentOS-Base.repo` file with the following command:

   ```
   sudo nano /etc/yum.repos.d/CentOS-Base.repo
   ```

5. Comment each `mirrorlist` line by adding the **\#** sign before each line.

6. Uncomment each `baseurl` line by removing the **\#** sign before each line.

7. Edit all `baseurl` lines containing the address `http://mirror.centos.org/centos/$releasever/os/$basearch/` to reflect the new address location:

   ```
   http://mirrors.linode.com/centos/$releasever/os/$basearch/
   ```

8. Save and exit the `CentOS-Base.repo` file.