# [Manage disks and storage on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#manage-disks-and-storage-on-a-linode)

# [Understanding storage](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#understanding-storage)

Every Linode is equipped with persistent storage, the amount of which varies based on size and type of Linode plan. This local storage is built entirely on enterprise-grade SSDs (solid state disks) and is extremely performant and reliable.

## [Disks](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#disks)

The storage space on a Linode can be allocated to individual _disks_. Disks can be used to store any data, including the operating system, applications, and files. Most Linodes are deployed with two disks. A large primary disk is used to store the Linux distribution, software, and data. There's also a much smaller swap disk, which is used if your Linode runs out of memory.

While two disks may be the default, a Linode can be configured to have many more disks. These additional disks can serve a variety of purposes, including dedicated file storage or switching between entirely different Linux distributions. When multiple disks are added, [configuration profiles](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance) are used to determine the disks that are accessible when the Linode is powered on, as well as which of those disks serves as the primary root disk.

## [Add additional storage](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#add-additional-storage)

The local storage capacity of a Linode can only be increased by upgrading to a larger plan. This lets you increase the size of existing disks or add additional disks. [Block Storage](https://techdocs.akamai.com/cloud-computing/docs/block-storage) volumes can also be used to add additional storage, though these volumes are separate from a Linode's local disks and, for some use cases, may be less performant.

# [View disks](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#view-disks)

A Linode's total storage space and disks can be viewed and managed from [Cloud Manager](https://cloud.linode.com).

1. Log in to [Cloud Manager](https://cloud.linode.com), click the **Linodes** link in the sidebar, and select a Linode from the list.

2. Look within the **Summary** section of the Linode's dashboard to view the total storage.

   

3. Navigate to the **Storage** tab and find the **Disks** section, which lists all disks on the Linode.

   

From here, a [disk can be created](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#create-a-disk) using the **Add a Disk** button. To take action on an disk, locate the disk within the **Disks** table and select from the list of actions, some or all of which may appear within the **ellipsis** menu:

- **Rename:** Change the name of the disk.
- **Resize:** Increase or decrease the size of the disk. See [Resize a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#resize-a-disk).
- **Imagize:** Create a Custom Image based on the disk. See [Capture an image](https://techdocs.akamai.com/cloud-computing/docs/capture-an-image).
- **Clone:** Duplicate the disk, adding it to any Linode on your account. See [Clone a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#clone-a-disk).
- **Delete:** Permanently delete's the disk and all of its data (cannot be undone). See [Delete a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#delete-a-disk).

# [Create a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#create-a-disk)

Each Linode can have multiple disks. Follow these instructions to create a new disk.

 > Note: 
  - A Linodecan have up to 50 disks.
 - These instructions cover how to add a new, empty disk to an existing Linode. If you have a custom image you want to use to create a disk, see [Deploy an image to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-an-existing-compute-instance).

1. Navigate to the **Storage** tab on the Linode you wish to edit. See [View disks](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#view-disks).

2. Click the **Add a Disk** button to show the **Add Disk** form.

   

   > > Note: 
   > 
   > If this button is disabled, all of the Linode's storage space has been allocated towards disks. Before continuing, [resize an existing disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#resize-a-disk) or [upgrade the Linode](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance) to a larger plan. You'll want to confirm there is enough unallocated storage space to accommodate the desired size of the new disk.

3. Select from either the **Create Empty Disk** or **Create from Image** options.

   **Empty disks:** An empty disk can store additional data, be used as a swap disk, or it can be used to manually [install a custom distribution](https://linode.com/docs/guides/install-a-custom-distribution/). When creating an empty disk, select the desired _Filesystem_. In most cases, it's recommended to use the _ext4_ filesystem. This ensures compatibility with our Backups service. If needed, _ext3_ and _raw_ disks are also available. If creating a swap disk, select the _swap_ option.

   **Images:** Selecting an Image lets you deploy a [Distribution Image](https://www.linode.com/distributions/), a [Custom Image](https://techdocs.akamai.com/cloud-computing/docs/images), or a Recovery Image to the new disk. When creating a disk based on an Image, select the _Image_, _Root Password_, and optionally add _SSH Keys_.

4. Once an option is chosen, complete the remaining fields in the form. Enter the _Label_ and the _Size_ for the new disk. The _maximum size_ of the disk is pre-populated and based on the Linode's remaining storage allocation, though a smaller size can be entered if desired.

5. Click the **Add** button to create the disk. The progress can be monitored from the new entry appearing for the disk within the Linode's **Storage** page.

Once a disk has been created, you will need to modify the existing configuration profile or add a new configuration profile. Specifically, the disk will need to be assigned to a device and optionally marked as the root device if this new disk will function as the primary boot disk. See [Deploy an image to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/deploy-an-image-to-an-existing-compute-instance) or [Manage configuration profiles on a Linode](https://techdocs.akamai.com/cloud-computing/docs/manage-configuration-profiles-on-a-compute-instance) for additional details.

# [Resize a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#resize-a-disk)

The size of a Linode's disk can be increased or decreased as needed. When resizing, it's important to keep the following restrictions in mind:

- The **maximum size** of a disk is equal to the current size of the disk and the remaining unallocated storage space on the Linode. The maximum size is displayed underneath the **Size** field when resizing the disk.
- The **minimum size** of a disk is equal to the current disk usage within the filesystem. This number is not displayed in Cloud Manager. To determine how much space the files on the disk are using, run the command `df -h` within the Linode's command line (through [SSH](https://techdocs.akamai.com/cloud-computing/docs/set-up-and-secure-a-compute-instance#connect-to-the-instance) or [Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish)).
- **Raw disks** can only be resized to a larger disk.
- Disks with **custom partitions** cannot be resized.

The following instructions cover how to resize a disk. For instructions regarding resizing a Linode's plan (including downgrading to a smaller plan), see [Resize a Linode](https://techdocs.akamai.com/cloud-computing/docs/resize-a-compute-instance).

1. Navigate to the **Storage** tab on the Linode you wish to edit. See [View disks](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#view-disks).

2. Click the **Power Off** button in the upper right of the page or within the **ellipsis** menu. Wait until the Linode has been fully powered off before continuing to the next step.

   

3. Within the **Disks** table, locate the disk you wish to resize and click the corresponding **Resize** button, which may also appear within the **ellipsis** menu.

   

   > > Note: 
   > 
   > If the **Resize** button is disabled, confirm that the Linode has been fully powered off.

4. The **Resize Disk** form is displayed. In the **Size** field, enter the new size for the disk in megabytes. The new size of the disk needs to be within the maximum and minimize disk size discussed above.

5. Click **Resize**. The progress can be monitored from the corresponding entry for the disk within the **Disks** table on the Linode's **Storage** page.

6. Once the disk has been successfully resized, click the **Power On** button to boot up the Linode.

# [Clone a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#clone-a-disk)

A disk can be duplicated onto the same Linode or any other Linode on the account. See [Cloning to an existing Linode](https://techdocs.akamai.com/cloud-computing/docs/clone-a-compute-instance#clone-to-an-existing-linode) for instructions.

# [Delete a disk](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#delete-a-disk)

A disk can be deleted to remove it from the Linode and free up additional storage space that can be used for other disks.

 > Error: 
  Deleting a disk is permanent and cannot be undone. Make sure all required data is properly backed up before continuing.

1. Navigate to the **Storage** tab on the Linode you wish to edit. See [View disks](https://techdocs.akamai.com/cloud-computing/docs/manage-disks-on-a-compute-instance#view-disks).

2. Click the **Power Off** button in the upper right of the page or within the **ellipsis** menu. Before proceeding, wait until the Linode has been fully powered off.

   

3. Within the **Disks** table, locate the disk you wish to delete and click the corresponding **Delete** button, which may also appear within the **ellipsis** menu.

   

   > > Note: 
   > 
   > If the **Delete** button is disabled, confirm that the Linode has been fully powered off.

4. A confirmation dialog window will appear. Click the **Delete** button to confirm.

5. The disk will be deleted within a few seconds. Click the **Power On** button to boot up the Linode.