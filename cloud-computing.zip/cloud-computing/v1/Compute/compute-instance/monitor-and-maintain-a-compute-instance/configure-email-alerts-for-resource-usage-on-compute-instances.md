# [Configure email alerts for resource usage on Linodes](https://techdocs.akamai.com/cloud-computing/docs/configure-email-alerts-for-resource-usage-on-compute-instances#configure-email-alerts-for-resource-usage-on-linodes)

The Cloud Manager allow you to configure _email alerts_ that automatically notify you through email if certain performance thresholds are reached, including:

- CPU Usage
- Disk IO Rate
- Incoming Traffic
- Outbound Traffic
- Transfer Quota

When setting the threshold for CPU usage, the maximum value can be calculated by multiplying the total number of available CPUs by 100. For example, this means that if a Linode has 4 CPUs, the maximum threshold is 400%. Therefore, if you wish to be notified of relative CPU usage greater than 80% over 2 hours, you would set the **Usage Threshold** value to 320%.

 > Note: 
  The default CPU usage alert threshold for all new Linodes is 90% relative to the number of available cores.

To turn on and customize the alerts:

1. Log in to the [Cloud Manager](https://cloud.linode.com).
2. Click the **Linodes** link in the sidebar.
3. Select your Linode. The Linode's details page appears.
4. Click the **Alerts** tab. The _Alerts_ panel appears.
5. To enable an email alert, toggle the appropriate switch.
6. To configure the threshold for an alert, set a value in the threshold text field.
7. Click **Save** to save the email alert thresholds.

You have successfully configured email alerts in the Cloud Manager.

 > Note: 
  If you receive an email threshold alert from the Cloud Manager, do not be alarmed. It does not mean there is anything necessarily wrong with your Linode.
  For example, the Linode may be operating above its normal threshold if it is performing intensive tasks such as compiling software (CPU, IO, or both) or if a major website just linked to your blog (increased traffic).