# [Access your system console using Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#access-your-system-console-using-lish)

The **Lish Console**, also called the _Linode Shell_, provides direct console access to all of your Linodes. Through Lish, you can easily access your Linode's internal Linux system and run commands, install software, or configure applications. Lish is especially useful when you are not able to connect to your server through other means, such as SSH.

# [Access Lish](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#access-lish)

There are two ways to access Lish. You can use a terminal application to connect to a _Lish SSH gateway_, or you can log in to the [Cloud Manager](https://cloud.linode.com) and use the Lish console in your web browser. This section explains both methods.

## [Through Cloud Manager (weblish)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#through-cloud-manager-weblish)

You can connect to Lish using a web browser. This is useful when you don't have access to a terminal application, or if you just need quick and easy console access from Cloud Manager.

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Click on the **Linodes** link in the sidebar and select the desired Linode.

3. Click on the **Launch LISH Console** link in the top right-hand corner of Cloud Manager.

   

4. The Lish Web Console window appears, as shown below. From here, you can log in to your Linode with any other username and password available on that system (such as `root`).

   

You can exit to the Lish prompt by pressing **CTRL+A** then **D**. You cannot exit to a Lish gateway box using your web browser. To exit the session entirely, just close the Lish Web Console window.

## [Through SSH (using a terminal)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#through-ssh-using-a-terminal)

You can connect to Lish with the SSH client of your choice. For example, you can use the Terminal application in Mac OS X, PuTTY in Windows, or your favorite X11 terminal emulator.

This section applies to core regions only.  Distributed compute regions don't support LISH via SSH at this time.

 > Note: 
  If you have [third party authentication](https://techdocs.akamai.com/cloud-computing/docs/enable-third-party-authentication) enabled on your account, you will not be able to log in to your Linode through Lish with password authentication, and must instead use SSH key authentication. Read the [Add your public key](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#add-your-public-key) section for more instructions on how to add an SSH key to your account for use with Lish.

1. Determine which Lish SSH gateway you wish to use. There's one in every data center. See [Lish gateways](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#lish-gateways) for a full list.

2. Open a terminal window and enter the following command, replacing `username` with your Cloud Manager username, and `location` with your preferred Lish SSH gateway.

   ```
   ssh username@location
   ```

   For example, logging in as `user` via the Newark gateway would look like:

   ```
   ssh user@lish-newark.linode.com
   ```

   > > Note: 
   > 
   > Users who have been granted "Access" rights on a particular Linode will have access to its Lish console via the gateway. Linodes that a user can't access in Cloud Manager won’t show up in the Lish list. For more information about creating user accounts and configuring permissions, see [Manage users on your account](https://techdocs.akamai.com/cloud-computing/docs/manage-users-on-your-account).

3. Verify that the Lish SSH gateway's fingerprint is valid by verifying the Terminal's output against the list of our [Lish gateway fingerprints](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#lish-gateways). Once verified, enter _yes_ to proceed.

   ```text Output
   The authenticity of host 'lish-newark.linode.com (66.228.40.59)' can't be established.
   ECDSA key fingerprint is SHA256:57OGBNARJ1fhI+zrE3eTEeQWXVVDHRU8QHcP+BsWmN8.
   Are you sure you want to continue connecting (yes/no)?
   ```

   > > Warning: ECDSA host key warning
   > 
   > If after verifying the authenticity of the Lish SSH gateway's fingerprint, you receive a message indicating that the ECDSA host key differs from the key for the IP address, remove the cached IP address on your local machine. Ensure you replace `192.0.2.0` with the IP address indicated by the Terminal.
   > 
   > ```
   > ssh-keygen -R 192.0.2.0
   > ```
   > 
   > Once you have removed the cached IP address, you can again attempt to SSH into the Lish gateway.

4. Enter the password you use to log in to Cloud Manager. You are now at the Lish shell. A list of your Linodes appears, as shown below:

   ```text Output
   Linodes located in this data center:
   linode241706         Newark, NJ
   linode276072         Newark, NJ

   Linodes located in other data centers:
   linode287497         Dallas, TX
   ```

   > > Warning: 
   > 
   > You can add a public SSH key for Lish in Cloud Manager to automatically connect to Lish without a password. See [Add your public key](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#add-your-public-key) for more information.

5. At the Lish command prompt, type a Linode's name from the list. For example, typing `linode241706` will connect you to the screen console session for that Linode.

6. Log in to the system with your username and password.

After you log in, you'll have console access to your Linode. You'll be able to restart services like `sshd`, edit firewall settings, and make other changes. To exit the console, press **CTRL+A** then **D** to return to the host machine, and then press **CTRL+D** to return to the Lish menu. If you'd like to see the list of your Linodes again, type `list` from the gateway.

# [Add your public key](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#add-your-public-key)

If you don't want to enter your password every time you connect to Lish, or if you have [Third party authentication](https://techdocs.akamai.com/cloud-computing/docs/enable-third-party-authentication) enabled on your account, you can add your public SSH key to the Cloud Manager. If you haven't yet created SSH keys, please see [Use SSH Public Key Authentication on Linux, macOS, and Windows](https://linode.com/docs/guides/use-public-key-authentication-with-ssh/) for more information.

1. Log in to [Cloud Manager](https://cloud.linode.com).

2. Click on the profile icon in the top right hand corner of the Manager and select **LISH Console Settings**.

3. Copy your public SSH key into the **SSH Public Key** field, as shown below.

   

4. Click the **Save** button. Your Lish key will be saved in Cloud Manager.

Now you can log in to any of the Lish gateway boxes without having to type your password.

If you wish to disable Lish access for users without keys, use the **Authentication Mode** dropdown menu on the same page, and select **Allow key authentication only** then click **Save**.

# [Lish commands](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#lish-commands)

The Lish shell provides access to many functions which are otherwise only accessible via Cloud Manager. Enter the `help` command to see a full list of available commands. The output provides an introduction to Lish functionality:

```text Output
kill            - kill stuck screen sessions
exit            - exit from lish
help            - this menu

[return]        - connect to console
version         - display running kernel version
boot            - boot last used (or the only) config profile
boot N          - boot the specified config profile
shutdown        - shut down the Linode
reboot          - shut down, then boot the last used config profile
reboot N        - shut down, then boot the specified config profile
sysrq X         - send SysRq X to your Linode
destroy         - pulls the plug on a running Linode, no fs sync, no warning

jobs            - view the job queue for your Linode
configs         - view the configuration profiles for your Linode
config N        - view configuration profile details for profile N
status          - view the status of your Linode
logview         - view contents of console log
```

There are two ways to run these commands for a specific Linode. If you are at the main Lish gateway, you can prefix the command with a ID, like this:

```
linode123456 logview
```

You can also bring up the Linode's console, then type **CTRL+A** then **D** to drop back to the host for that Linode. Now all of the commands above will be run for that Linode specifically. To exit back to the main Lish menu, type `exit`.

 > Note: 
  You can activate the ability to scroll back through the Lish console by pressing **CTRL-A + ESC**

# [Advanced Lish tricks](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#advanced-lish-tricks)

While the Lish interface as described above is useful as a basic command-line interface, you may find that you want to issue commands to your Linode without going through the Lish login process.

You can directly connect to a Linode's console:

```
ssh -t [manager-username]@lish-[location].linode.com [linode-name]
```

You can also append Lish commands to the SSH command on your system prompt. For instance, to reboot your system, using your Cloud Manager username, location, and the host-id for your Linode:

```
ssh -t [manager-username]@lish-[location].linode.com [linode-name] reboot
```

Similarly, you can generate a view of the log using Lish:

```
ssh -t [manager-username]@lish-[location].linode.com [linode-name] logview
```

This command format works for all Lish functionality.

# [Lish gateways](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#lish-gateways)

Each data center has its own gateways, which provides access to Lish, Weblish, and Glish. When connecting through Lish, you can use the corresponding gateway within any data center, though we recommend choosing the data center the Linode is located within. These gateways are accessible over IPv4 and IPv6.

This section applies to core regions only.  Distributed compute regions don't support LISH via SSH at this time.

 > Note: 
  If you are having issues accessing Lish, Weblish, or Glish, you may be blocked by a local firewall. Make sure your firewall allows outbound connections to the following ports and the gateway you wish to access:
  - **Lish ports:** 22, 443, 2200
 - **Weblish port:** 8181
 - **Glish port:** 8080

### [Amsterdam (Netherlands)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#amsterdam-netherlands)

- **Lish SSH Gateway:** `lish-nl-ams.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:/y+83+sA3JdDGkv/KLnIAIXqfgqWfgp5RZ+DCx1T4yU lish-nl-ams.linode.com
  >     ECDSA 256 SHA256:iR/He+teo+c7jqr8LzaTikbTlMDdIkIERhJBXdIjO8w lish-nl-ams.linode.com
  >     ED25519 256 SHA256:vxF9arB2lYBVP45ZA7t1JEE9w/vthPmzU3a2oOR8O7Y lish-nl-ams.linode.com
  > ```

- **Weblish/Glish Gateway:** `nl-ams.webconsole.linode.com`

### [Atlanta, GA (USA)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#atlanta-ga-usa)

- **Lish SSH Gateway:** `lish-us-southeast.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:OWzHHclIp4zt5sHt+QZ002HYgnxtec+skWPAgFNfx4w lish-us-southeast.linode.com
  >     ECDSA 256 SHA256:qVMUsKTjxiSFvElIRMvjzKv4eRth37i2OBaaSODO6us lish-us-southeast.linode.com
  >     ED25519 256 SHA256:ZpNQYxIc25e4vVfFgscSJm1/jGaUy3Gti4kuzB1aTuc lish-us-southeast.linode.com
  > ```

- **Weblish/Glish Gateway:** `us-southeast.webconsole.linode.com`

### [Chennai (India)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#chennai-india)

- **Lish SSH Gateway:** `lish-in-maa.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:kXCaKnn1nVlVEC5SCuez6FApcXr/2UUiaSANUy0rlLI lish-in-maa.linode.com
  >     ECDSA 256 SHA256:Jj+pb1AkDdKs77o6ozgkOk83rg7auLSOQrnebE8n91o lish-in-maa.linode.com
  >     ED25519 256 SHA256:v1KaIB0togivalP7OVvlrLpu/y80qsm5cj50qclTWc0 lish-in-maa.linode.com
  > ```

- **Weblish/Glish Gateway:** `in-maa.webconsole.linode.com`

### [Chicago, IL (USA)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#chicago-il-usa)

- **Lish SSH Gateway:** `lish-us-ord.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:rRwktOKfSApeffa+YOVxXXL70Ba1CpTYp/oFywEH2Pc lish-us-ord.linode.com
  >     ECDSA 256 SHA256:SV9A/24Jdb++ns/+6Gx7WqZCyN4+0y4ICFsaqK3Rm8s lish-us-ord.linode.com
  >     ED25519 256 SHA256:J+yN8rjhr9j27M4zLSF6OX9XmIoipWbPP/J1AGRlRYc lish-us-ord.linode.com
  > ```

- **Weblish/Glish Gateway:** `us-ord.webconsole.linode.com`

### [Dallas, TX (USA)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#dallas-tx-usa)

- **Lish SSH Gateway:** `lish-us-central.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:y1H5qzNB3yjvmPX/e8HcYbTffQb9qANjtT7r5vqIZl8 lish-us-central.linode.com
  >     ECDSA 256 SHA256:3FY9mXdhRJjaJ7eTDO8SUWoLxdJBshz5229Wwsg7/iQ lish-us-central.linode.com
  >     ED25519 256 SHA256:bC/I0G2IrWlICtzsGYT84dzdft1weRd28SIUt+D31P8 lish-us-central.linode.com
  > ```

- **Weblish/Glish Gateway:** `us-central.webconsole.linode.com`

### [Frankfurt (Germany)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#frankfurt-germany)

- **Lish SSH Gateway:** `lish-eu-central.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:4Xkz0V7ZQd277GpfnHzvdshuH3gjsv9+UXlgO0/gNhA lish-eu-central.linode.com
  >     ECDSA 256 SHA256:W3V3zB1vYWlpoRaBy97RZk6GP+DZrFLsm1vAE27eCXQ lish-eu-central.linode.com
  >     ED25519 256 SHA256:/105/zGMByknAKw5Hm7554oZ25wwN0+3owhJTZWOvNc lish-eu-central.linode.com
  > ```

- **Weblish/Glish Gateway:** `eu-central.webconsole.linode.com`

### [Frankfurt 2, Germany](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#frankfurt-2-germany)

- **Lish SSH Gateway:** `lish-de-fra-2.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ````
  >     RSA 3072 3072 SHA256:ZAHVy8xSwQYJAb9lhehlzJTIzZm43mJmr49F1SYTnLI lish-de-fra-2.linode.com
  >     ECDSA 256 SHA256:lIKxqbF4Tg5oGWKpdPMAWqgpjfBFrdieVA9B35ZdlmQ lish-de-fra-2.linode.com
  >     ED25519 256 SHA256:rt0BIurDkCqHomM5/omzbt1lW+hKRjWWthUiMM1LMGU lish-de-fra-2.linode.com
  >     ```
  > ````

- **Weblish/Glish Gateway:** `de-fra-2.webconsole.linode.com`

### [Fremont, CA (USA)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#fremont-ca-usa)

- **Lish SSH Gateway:** `lish-us-west.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:s4ACk4T42uMnOpMWybsZFSVn9PCd/0Q/LEqs0pWKVj4 lish-us-west.linode.com
  >     ECDSA 256 SHA256:2CnS4CkZsymw6PuT5bE8hLfVTMwkMPr8D9lYbUOgE7E lish-us-west.linode.com
  >     ED25519 256 SHA256:whGbGnOqEIv9HrvvEgXO6PdNnCDEr7OwL0pHzrTDBYo lish-us-west.linode.com
  > ```

- **Weblish/Glish Gateway:**`us-west.webconsole.linode.com`

### [Jakarta (Indonesia)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#jakarta-indonesia)

- **Lish SSH Gateway:** `lish-id-cgk.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:n+f2JBMBYvvJUw11nYafKrX1nU3gdohnWfj9qdTXU+I lish-id-cgk.linode.com
  >     ECDSA 256 SHA256:CwM8d4D9yU0Mw/Odu4bxs6OWpfzJHSrSUUgtkZNRvsk lish-id-cgk.linode.com
  >     ED25519 256 SHA256:RvdTsLHAWcjmXU2h5JD821Xk4x40FcHLzpX2/ppMLh0 lish-id-cgk.linode.com
  > ```

- **Weblish/Glish Gateway:** `id-cgk.webconsole.linode.com`

### [London (UK)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#london-uk)

- **Lish SSH Gateway:** `lish-eu-west.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:8EgXMpjYma0BpjghpUcFwlJCMv1cZROKv1CE35QElnI lish-eu-west.linode.com
  >     ECDSA 256 SHA256:CfmDU3U4/F0z34iosz9uWrsmeuy2L/8W+otq44Avonw lish-eu-west.linode.com
  >     ED25519 256 SHA256:K6Hh7inkt5vJYrPKz3sB3yLd/+rtyrmyV7vYSCQ+8mU lish-eu-west.linode.com
  > ```

- **Weblish/Glish Gateway:** `eu-west.webconsole.linode.com`

### [London 2 (UK)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#london-2-uk)

- **Lish SSH Gateway:** `lish-gb-lon.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:EIKjJlF0nmpuj795Y4DhwYjIMCDa2yodWKk9rKxg67o lish-gb-lon.linode.com
  >     ECDSA 256 SHA256:MvMwule197MvqJIjvJq7vjnxlvX0XveAocRPDs5jbMA lish-gb-lon.linode.com
  >     ED25519 256 SHA256:4IUSmmru/F/Q4nHVZjBZUzSol7XLaE33i8hLPD8VJ2o lish-gb-lon.linode.com
  > ```

- **Weblish/Glish Gateway:** `gb-lon.webconsole.linode.com`

### [Los Angeles, CA (USA)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#los-angeles-ca-usa)

- **Lish SSH Gateway:** `lish-us-lax.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:TVyXe3i1iJF9rU+j/t57wpdRB2h56Kh2tnZsUra30kA lish-us-lax.linode.com
  >     ECDSA 256 SHA256:Yh+jEgxiGIgETrC9uz4wUqnKvi7yPrlqgmpxsa65QDI lish-us-lax.linode.com
  >     ED25519 256 SHA256:kFi+ignk5bxYxnk/F3Lehk0HoM98BuUzEGhlEzhHo9I lish-us-lax.linode.com
  > ```

- **Weblish/Glish Gateway:** `us-lax.webconsole.linode.com`

### [Madrid (Spain)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#madrid-spain)

- **Lish SSH Gateway:** `lish-es-mad.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:sIYL6fvcNZVz3pXa6fp6YNS4ITfcCTu918pH0dxmaL0 lish-es-mad.linode.com
  >     ECDSA 256 SHA256:eSqy+KAkPlzqRxYnPzGKJXuVd6D5APZsM/qWAWVk5xs lish-es-mad.linode.com
  >     ED25519 256 SHA256:Sm20p3dsXSoqdRF8RwehfHn2sJszSuP/Z454glxohbc lish-es-mad.linode.com
  > ```

- **Weblish/Glish Gateway:** `es-mad.webconsole.linode.com`

### [Melbourne, Australia](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#melbourne-australia)

- **Lish SSH Gateway:** `lish-au-mel.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:JX2eVSdHIJzb3iDJFpTtHVGQq1paEh53D9cnsEPNvvU lish-au-mel.linode.com
  >     ECDSA 256 SHA256:88mN/wieI4kG1rkuohob3ZyqhvCMiMWiCTVN1XECvLU lish-au-mel.linode.com
  >     ED25519 256 SHA256:e8xMMpHXjDRi9vSiNliiMEHtsKzAjGdG0WkeFS3W1RU lish-au-mel.linode.com
  > ```

- **Weblish/Glish Gateway:** `au-mel.webconsole.linode.com`

### [Miami, FL, USA](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#miami-fl-usa)

- **Lish SSH Gateway:** `lish-us-mia.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:kfwzGjXR+WV1JxvufbsZTv4qzVUI5Nkmh3Z3/XhpAT8 lish-us-mia.linode.com
  >     ECDSA 256 SHA256:cZVK7bB8cwci3sXJJNIaBlX9Z3DlBj3hAL5J8Hc+vr0 lish-us-mia.linode.com
  >     ED25519 256 SHA256:+sBLV01KzOiVJw4OJGmO71+NUm2cE7ndpj1aqW2tNLg lish-us-mia.linode.com
  > ```

- **Weblish/Glish Gateway:** `us-mia.webconsole.linode.com`

### [Milan (Italy)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#milan-italy)

- **Lish SSH Gateway:** `lish-it-mil.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:toVfir7U8Ixg0wELAx0qCC91ld+HIxmTwggUP/+itkU lish-it-mil.linode.com
  >     ECDSA 256 SHA256:XQDX+diXFBAT8OjpN+zwZN5sukTAQwtqe+i89Kh6gXQ lish-it-mil.linode.com
  >     ED25519 256 SHA256:Uxw1KbWQVz5QYHHfUzFJcZM+HLbdu6vJ/R3ksEv2k3M lish-it-mil.linode.com
  > ```

- **Weblish/Glish Gateway:** `it-mil.webconsole.linode.com`

### [Mumbai (India)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#mumbai-india)

- **Lish SSH Gateway:** `lish-ap-west.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:cZv3NjjPKvjKuG4/ETTs8dQEn/sk/ryXJMn/wAqRSdk lish-ap-west.linode.com
  >     ECDSA 256 SHA256:PUjmIqCe7ViewBrmronVU1Ss/yU63Zgp0yFe4PCZSQk lish-ap-west.linode.com
  >     ED25519 256 SHA256:s5LimAwVgNrnDOVWhLhv8RyBo3jk6OjiSCxPUQSefQ8 lish-ap-west.linode.com
  > ```

- **Weblish/Glish Gateway:** `ap-west.webconsole.linode.com`

### [Mumbai 2, India](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#mumbai-2-india)

- **Lish SSH Gateway:** `lish-in-bom-2.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ````
  >     RSA 3072 SHA256:Up/dBmIvUKXuAhQgVWxiPLCwdIOfX8n3jIkjCtGSQio lish-in-bom-2.linode.com
  >     ECDSA 256 SHA256:dy7XzPxap8lx8lm6bBedqp9ajmBJ3gMaGXCz0YjRZuc lish-in-bom-2.linode.com
  >     ED25519 256 SHA256:LVNQLrVZpXzvkq8pBbCorW9fobQDgUlwrInjYiFmpBs lish-in-bom-2.linode.com
  >     ```
  > ````

- **Weblish/Glish Gateway:** `in-bom-2.webconsole.linode.com`

### [Newark, NJ (USA)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#newark-nj-usa)

- **Lish SSH Gateway:** `lish-us-east.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:u7ayBzPWsFmc2/sLrP8zYh0pFGFvo2m/H13Gmw7tZlA lish-us-east.linode.com
  >     ECDSA 256 SHA256:Q7TDu+Qa3OpO6TUlgtG8ROa0MfRP5uagjSfavqT4oqs lish-us-east.linode.com
  >     ED25519 256 SHA256:uUaOWG4KM2k+ZLCgtVFEi90TiNbNElXEP/orB57+8WI lish-us-east.linode.com
  > ```

- **Weblish/Glish Gateway:** `us-east.webconsole.linode.com`

### [Osaka (Japan)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#osaka-japan)

- **Lish SSH Gateway:** `lish-jp-osa.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:VXDxZ8+0b1Q54Bzvt7a6A4bvvKAI5OHxBYxwIC4OsDQ lish-jp-osa.linode.com
  >     ECDSA 256 SHA256:qM6cfmK2/Vrho1exDZ9qe4cLWVdp5U0dv5MJ22K+lwE lish-jp-osa.linode.com
  >     ED25519 256 SHA256:1CJ7P/i5XUP6XWizukQ7XIEiQ5rlIM+06N6qF2WfDMc lish-jp-osa.linode.com
  > ```

- **Weblish/Glish Gateway:** `jp-osa.webconsole.linode.com`

### [Paris (France)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#paris-france)

- **Lish SSH Gateway:** `lish-fr-par.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:qTliFB86axo9n07H0hUP/z5nm7Fbkzlf8eKnmtXBhZU lish-fr-par.linode.com
  >     ECDSA 256 SHA256:NU4UctBefhWIR3mpCrh+r2p5lNmtwFFoeelZspjMNYM lish-fr-par.linode.com
  >     ED25519 256 SHA256:GYNvVuHJqGIdCiU6yTPbkJmMgj+ZYBGRVGDqnrtJoQc lish-fr-par.linode.com
  > ```

- **Weblish/Glish Gateway:** `fr-par.webconsole.linode.com`

### [São Paulo (Brazil)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#so-paulo-brazil)

- **Lish SSH Gateway:** `lish-br-gru.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:lmtONyLfe0tiLEdNrbEUd8j10A/o/Ss1HaUYJDgc8ks lish-br-gru.linode.com
  >     ECDSA 256 SHA256:ftl4kIcxzeGUsT9FPQ49GF7afel1yrOQgclJN7/8kuk lish-br-gru.linode.com
  >     ED25519 256 SHA256:EKqBawVESQnL4oQOMskpBAtrEiOlE+qD9M6WLiFbCyU lish-br-gru.linode.com
  > ```

- **Weblish/Glish Gateway:** `br-gru.webconsole.linode.com`

### [Seattle, WA (USA)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#seattle-wa-usa)

- **Lish SSH Gateway:** `lish-us-sea.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:XqkskcFrRzZbMU/XeR1diiNM6zCsWs2wL4pmTvBLNII lish-us-sea.linode.com
  >     ECDSA 256 SHA256:FEqVGwuv/BgbLtNkcfFg7Lgm0R6KQVUnPY+wIoimrrA lish-us-sea.linode.com
  >     ED25519 256 SHA256:6R7iWvSe7OQSDcVmhwrH/EJiE51+ntiub3CPXfzupDA lish-us-sea.linode.com
  > ```

- **Weblish/Glish Gateway:** `us-sea.webconsole.linode.com`

### [Singapore](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#singapore)

- **Lish SSH Gateway:** `lish-ap-south.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:ed7vvOh2m4DtwwUruYiyDQLegcjh3AAeLZ/C9HYWjS0 lish-ap-south.linode.com
  >     ECDSA 256 SHA256:dVVAqiJMdolMgD81T1ELjPPM2P3EZ9b9li8dj8UssTw lish-ap-south.linode.com
  >     ED25519 256 SHA256:+gcOBQjBvMDrGuxKQdmV+fs7+sWqQ9e4khIFYlPvooM lish-ap-south.linode.com
  > ```

- **Weblish/Glish Gateway:** `ap-south.webconsole.linode.com`

### [Singapore 2](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#singapore-2)

- **Lish SSH Gateway:** `lish-sg-sin-2.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ````
  >     RSA 3072 SHA256:IlLbYQnIeJOWoZxIeZKEX3Z3LbDyS+P26Ir6m3mEBI8 lish-sg-sin-2.linode.com
  >     ECDSA 256 SHA256:7p6TLm5nzq5+0gwS0BxFhYgOz4HvxPwILLNucUzECfQ lish-sg-sin-2.linode.com
  >     ED25519 256 SHA256:SFwIRt273ZHXr2rLjipbaykc0sDTT25IUWJvpWsa9XY lish-sg-sin-2.linode.com
  >     ```
  > ````

- **Weblish/Glish Gateway:** `sg-sin-2.webconsole.linode.com`

### [Stockholm (Sweden)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#stockholm-sweden)

- **Lish SSH Gateway:** `lish-se-sto.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:oC6WZwUMm+S/myz7aEBP6YsAUXss7csmWzJRlwDfpyw lish-se-sto.linode.com
  >     ECDSA 256 SHA256:lr6m6BKQBqFW/iw/WDq2QQqh5kUlMjidawEEKv9lNRg lish-se-sto.linode.com
  >     ED25519 256 SHA256:phubC9JMR6DNal0BIvu2ESvmDfs2rSquBrhKdr0IbmU lish-se-sto.linode.com
  > ```

- **Weblish/Glish Gateway:** `se-sto.webconsole.linode.com`

### [Sydney (Australia)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#sydney-australia)

- **Lish SSH Gateway:** `lish-ap-southeast.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:rbamZevowgslIHGX34frmWv/Qvt863skVo5q2gKFCFs lish-ap-southeast.linode.com
  >     ECDSA 256 SHA256:FmtrulPNisf4KVfOEtxiC0jLQfLW6iNdM2bZ5AWWFyM lish-ap-southeast.linode.com
  >     ED25519 256 SHA256:dRp40pJoimqpzoRM9yCY8OIzDxESMIkLWYCes0nFRdQ lish-ap-southeast.linode.com
  > ```

- **Weblish/Glish Gateway:** `ap-southeast.webconsole.linode.com`

### [Tokyo (Japan)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#tokyo-japan)

- **Lish SSH Gateway:** `lish-ap-northeast.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:Ral4+nR7A3jnhOqcebKTZQ+uDCIJ2rHQLnDUizDwIHY lish-ap-northeast.linode.com
  >     ECDSA 256 SHA256:mxhd/vUfH9+8CDfOVmpfAbGDXdt1o35QKwAxO20GAqw lish-ap-northeast.linode.com
  >     ED25519 256 SHA256:CDH9IcgWQ2iwx27ZotyvNbWl5os+QbeRZ/SLagLBckQ lish-ap-northeast.linode.com
  > ```

- **Weblish/Glish Gateway:** `ap-northeast.webconsole.linode.com`

### [Tokyo 3, Japan](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#tokyo-3-japan)

- **Lish SSH Gateway:** `lish-jp-tyo-3.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ````
  >     RSA 3072 SHA256:vOVLu8N8PjXxhnNiw2cFKYHk+3xopI8/Ea0EWrB7Tuo lish-jp-tyo-3.linode.com
  >     ECDSA 256 SHA256:Yqh9Ei7UaX/mqWlLJY4aj6rS2wapOIqWNV1qQ+RKJIk lish-jp-tyo-3.linode.com
  >     ED25519 256 SHA256:I+oKzHpddGWyD3AaanALGALDIsryvac2ABDNpS6yJ6I lish-jp-tyo-3.linode.com
  >     ```
  > ````

- **Weblish/Glish Gateway:** `jp-tyo-3.webconsole.linode.com`

### [Toronto (Canada)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#toronto-canada)

- **Lish SSH Gateway:** `lish-ca-central.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:FetyiRe7La3cAdpHz17sfKgQHaXEQPWcIq8A0sI11go lish-ca-central.linode.com
  >     ECDSA 256 SHA256:YhHGT3h4elvJjLTRBcjwNU+DK3TkvrQBrTtaiut5bIw lish-ca-central.linode.com
  >     ED25519 256 SHA256:hf6BTXkLy8dnGBD1z2IiMwD+J+o9xc/nkhxmOX69hWM lish-ca-central.linode.com
  > ```

- **Weblish/Glish Gateway:** `ca-central.webconsole.linode.com`

### [Washington, DC (USA)](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#washington-dc-usa)

- **Lish SSH Gateway:** `lish-us-iad.linode.com`

  > > Note: Lish SSH Gateway Fingerprints
  > 
  > ```
  >     RSA 3072 SHA256:mzFtMaMVX6CsLXsYWn6c8BXnXk0XHfoOXGExDUEH2OI lish-us-iad.linode.com
  >     ECDSA 256 SHA256:of9osuoFwh7g5ZiO0G3ZGYi/8JcCw3BA/ZdkpaKQlT0 lish-us-iad.linode.com
  >     ED25519 256 SHA256:oFoUJn/xXV/+b7EJIcIt6G6hV5jXzjM/pOsoceDDOaA lish-us-iad.linode.com
  > ```

- **Weblish/Glish Gateway:** `us-iad.webconsole.linode.com`