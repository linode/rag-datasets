# [Get started with Linodes](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-compute-instances#get-started-with-linodes)

Linodes (cloud-based virtual machines) are the foundational infrastructure components for most cloud computing applications and workloads. They offer a fully virtualized Linux system with root access. As such, you can install whatever software you need and configure to be perfectly tuned for your use cases. Linodes can host anything from a personal blog or small business website all the way up to enterprise applications serving millions of people a day.

# [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-compute-instances#create-a-linode)

Linodes can be deployed using Cloud Manager, the Linode API, or the Linode CLI. For instructions on deploying a Linode through Cloud Manager, see the following guides:

- [Choose a Linode plan](https://techdocs.akamai.com/cloud-computing/docs/how-to-choose-a-compute-instance-plan)
- [Create a Linode](https://techdocs.akamai.com/cloud-computing/docs/create-a-compute-instance)

 > Note: 
  Consider deploying an app from the [Marketplace](https://www.linode.com/marketplace/apps/) to quickly get up and running with many popular applications, including [Wordpress](https://www.linode.com/marketplace/apps/linode/wordpress/), [WooCommerce](https://www.linode.com/marketplace/apps/linode/woocommerce/), [LEMP](https://www.linode.com/marketplace/apps/linode/lemp/), [cPanel](https://www.linode.com/marketplace/apps/cpanel/cpanel/), [Plesk](https://www.linode.com/marketplace/apps/plesk/plesk/), and [Nextcloud](https://www.linode.com/marketplace/apps/linode/nextcloud/). See [Marketplace Apps - Get started](https://www.linode.com/docs/marketplace-docs/get-started/).

# [Connect to the Linode](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-compute-instances#connect-to-the-linode)

After the Linode is finished provisioning and has fully booted up, you can connect to it through the built-in Lish Console in Cloud Manager (or via the SSH Lish Gateway) or SSH directly to your new system.

- **Weblish (via Cloud Manager):** Click the **Launch LISH Console** link at the top right corner of the Linode's detail page. See [Access your system console using Lish > Through Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#through-cloud-manager-weblish).

- **SSH:** Copy the command from the _SSH Access_ field that is available in Cloud Manager under the **Access** section on the Linode's detail page. Paste the command into your local computer's terminal. The command should look similar to the following, only with the IP address of your newly created Linode.

  ```
  ssh root@192.0.2.1
  ```

  - **Windows:** Windows 10 and 11 users can connect to their Linode using the [Command Prompt (or PowerShell)](https://linode.com/docs/guides/connect-to-server-over-ssh-on-windows/#command-prompt-or-powershell---windows-10-or-11) application, provided their system is fully updated. For users of Windows 8 and earlier, [Secure Shell on Chrome](https://linode.com/docs/guides/connect-to-server-over-ssh-on-chrome/), [PuTTY](https://linode.com/docs/guides/connect-to-server-over-ssh-using-putty/), or many other third party tools can be used instead. See [Connecting to a Remote Server Over SSH on Windows](https://linode.com/docs/guides/connect-to-server-over-ssh-on-windows/).
  - **macOS:** The _Terminal_ application is pre-installed on macOS. See [Connecting to a Remote Server Over SSH on a Mac](https://linode.com/docs/guides/connect-to-server-over-ssh-on-mac/).
  - **Linux:** You can use a terminal window, regardless of desktop environment or window manager. See [Connecting to a Remote Server Over SSH on Linux](https://linode.com/docs/guides/connect-to-server-over-ssh-on-linux/)

- **Lish (via SSH):** Copy the command from the _LISH Console via SSH_ field that is available in Cloud Manager under the **Access** section on the Linode's detail page. Paste the command into your local computer's terminal. The command should look similar to the one below, only with your username, data center, and Linode label. Review [Access your system console using Lish > Through SSH](https://techdocs.akamai.com/cloud-computing/docs/access-your-system-console-using-lish#through-ssh-using-a-terminal) for more instructions.

  ```
  ssh -t user@lish-newark.linode.com example-instance
  ```

# [Migrate existing workloads](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-compute-instances#migrate-existing-workloads)

Linodes and related products and services can run almost any workload you may have on other hosting providers. Review the [migration guides](https://linode.com/docs/guides/platform/migrate-to-linode/) for instructions.

# [Deploy new applications](https://techdocs.akamai.com/cloud-computing/docs/getting-started-with-compute-instances#deploy-new-applications)

Now you can start using your Linode. Whether you're trying things out or looking to host a specific application with us, we may have a guide that can help you get up and running. Open the [Guides](https://linode.com/docs/guides/) section and start browsing or use the search tool to find guides related to your use case.

