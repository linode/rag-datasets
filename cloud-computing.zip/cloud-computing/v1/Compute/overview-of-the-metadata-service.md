# [Metadata service](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#metadata-service)

When deploying Linodes, additional configuration is often required before hosting your website or running workloads. This configuration may include creating a new user, adding an SSH key, or installing software. The Metadata service simplifies this process by providing instance data and optional user data. To automate this configuration, we recommend using the Metadata service.

# [Overview](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#overview)

The Metadata service provides a convenient method to automate software configuration when deploying a Linode. It's an API that's accessible only from within a provisioned Linode, and provides relevant metadata to that Linode. The Metadata service is compatible with [cloud-init](https://cloudinit.readthedocs.io/en/latest/), an industry standard software that automates cloud instance initialization. This allows you to use the same tool across multiple cloud providers, enabling a pathway for provisioning your systems as part of a multi-cloud infrastructure strategy. 

# [Key Benefits](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#key-benefits)

- **Faster Deployments:** Quickly provision and configure Linodes.
- **Consistent Setups** Ensure uniform configurations across your infrastructure
- **Reduced Errors** Minimize human error with automated tasks.
- **Enhanced Security** Implement security measures during deployment

# [How it Works](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#how-it-works)

The Metadata service provides _instance data_, _network data_,  _ssh-keys_, and optional _user data_, which are outlined below:

- **Instance data:** Information about the Linode configuration including its label, plan size, region, host identifier, and more.
- **Network data** Information about the Linode network configuration including interfaces and IP addresses.
- **SSH Key Data** The ssh-keys assigned to the Linode during provisioning.
- **(Optional) User data:** Optionally supplied by the user when deploying a Linode, user data enables you to define your desired system configuration. This can include creating users, installing software, configuring settings, and more. This user data can be written as a cloud-config file, or it can be any script that can be executed on the target distribution image, such as a bash script.

  User data can be submitted directly in Cloud Manager, Linode CLI, or Linode API. It can also be submitted through Infrastructure as Code (IaC) provisioning tools like [Terraform](https://linode.com/docs/guides/how-to-build-your-infrastructure-using-terraform-and-linode/).

When a Linode first boots up, cloud-init runs locally on the system, accesses the Metadata service, and then configures your system using that information.

# [Availability](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#availability)

The Metadata service is available in all regions. 

For the current list of supported distributions, please refer to the [Linode Distributions](https://www.linode.com/distributions/)  page.

When selecting a distribution in Cloud Manager, the following icon designates distributions that fully support the Metadata service:

 > Note: 
  Linodes deployed in a supported region can always access the [Metadata service API](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#access-the-metadata-service-api) to obtain Linode data, regardless of the distribution. However, user data cannot be submitted for distributions that do not have cloud-init support.

# [Technical specifications](https://techdocs.akamai.com/cloud-computing/docs/overview-of-the-metadata-service#technical-specifications)

- The Metadata service cloud-init datasource is available in cloud-init version 23.3.1 and greater.
- All user data is encrypted and the Metadata service is only accessible from within the Linode.
- Supports custom user data in the form of cloud-config scripts, shell scripts, and more.
- User data can be added when creating a Linode. User data can also be added when performing one of those functions using a custom image created from a compatible distribution image.