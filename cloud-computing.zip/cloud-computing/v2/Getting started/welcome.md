# [Welcome to Akamai Linode Cloud Computing](https://techdocs.akamai.com/cloud-computing/docs/welcome#welcome-to-akamai-linode-cloud-computing)

Get started with these Akamai Linode cloud computing quick links, or browse our cloud computing products and services grouped by area on the left.

- [Get started with Linode](https://www.linode.com/docs/products/platform/get-started/) 
- [Migrate to Linode](A) 
- [Linode API](https://techdocs.akamai.com/linode-api/reference/api) 
- [Linode CLI](https://www.linode.com/docs/products/tools/cli/)