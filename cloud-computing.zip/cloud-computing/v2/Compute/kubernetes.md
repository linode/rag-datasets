# [Kubernetes](https://techdocs.akamai.com/cloud-computing/docs/kubernetes#kubernetes)
