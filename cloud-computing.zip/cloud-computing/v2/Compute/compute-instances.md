# [Compute instances](https://techdocs.akamai.com/cloud-computing/docs/compute-instances#compute-instances)
