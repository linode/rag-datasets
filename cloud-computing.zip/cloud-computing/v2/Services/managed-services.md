# [Managed services](https://techdocs.akamai.com/cloud-computing/docs/managed-services#managed-services)
