# [DDoS protection](https://techdocs.akamai.com/cloud-computing/docs/ddos-protection#ddos-protection)
