# [NodeBalancer](https://techdocs.akamai.com/cloud-computing/docs/nodebalancers#nodebalancer)
