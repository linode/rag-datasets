# [VLAN](https://techdocs.akamai.com/cloud-computing/docs/vlans#vlan)
