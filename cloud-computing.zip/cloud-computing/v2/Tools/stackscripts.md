# [StackScripts](https://techdocs.akamai.com/cloud-computing/docs/stackscripts#stackscripts)
