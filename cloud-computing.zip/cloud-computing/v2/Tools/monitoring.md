# [Monitoring](https://techdocs.akamai.com/cloud-computing/docs/monitoring#monitoring)
