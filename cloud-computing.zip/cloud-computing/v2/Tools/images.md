# [Images](https://techdocs.akamai.com/cloud-computing/docs/images#images)
