# [Cloud Manager](https://techdocs.akamai.com/cloud-computing/docs/cloud-manager#cloud-manager)

<
>

<
>