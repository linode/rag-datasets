# [Accounts](https://techdocs.akamai.com/cloud-computing/docs/accounts#accounts)
