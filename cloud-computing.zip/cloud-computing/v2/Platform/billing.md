# [Billing](https://techdocs.akamai.com/cloud-computing/docs/billing#billing)
