# [Object storage](https://techdocs.akamai.com/cloud-computing/docs/object-storage#object-storage)
