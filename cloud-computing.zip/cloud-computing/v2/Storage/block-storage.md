# [Block storage](https://techdocs.akamai.com/cloud-computing/docs/block-storage#block-storage)
