# [Backups](https://techdocs.akamai.com/cloud-computing/docs/backups#backups)
