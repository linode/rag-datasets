# [Managed databases](https://techdocs.akamai.com/cloud-computing/docs/managed-databases#managed-databases)
